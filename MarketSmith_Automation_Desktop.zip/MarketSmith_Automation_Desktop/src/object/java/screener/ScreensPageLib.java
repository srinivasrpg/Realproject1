package screener;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class ScreensPageLib {
	@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.label.communityImg.label_arrowHV > div > div")
	private WebElement leftPanelScreenerButton;
	
	@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.label.communityImg.label_arrowHV > div > span")
	private WebElement leftPanelScreenerText;
	
	@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.content")
	private WebElement leftScreenSubPanelsContent;
	
	/*@FindAll(@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.content.expendToMedium > div.choosePanel > div"))
	private List<WebElement> leftScreenSubPanelButtons; */
	
	@FindAll(@FindBy(css=".sidebar.screenerAlertsAndNotes>div:nth-of-type(1)>div:nth-of-type(1)>div:not([style])"))
	private List<WebElement> leftScreenSubPanelButtons; 
	
	@FindBy(css="[class*='infoOption choosePanelScreen']")
	private WebElement ScreensSubPanel_button;
	
	@FindBy(css="html body div.MST div.sidebar.screenerAlertsAndNotes div.content.expendToMedium div.screener.leftSidebar.contentShow div.screenListView div.newBtnWrap div.chartButton.newScreen.toolTip-help")
	private WebElement ScreenNewScreen_button;
	
	@FindAll(@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.content.expendToMedium > div.screener.leftSidebar.contentShow > div.screenListView > div.screenExplorerTreeDiv > div[class=screenTree]"))
	private List<WebElement> SceenSubPanel_ScreenSections;
	
	//MS MY SCREENS
	@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.content.expendToMedium > div.screener.leftSidebar.contentShow > div.screenListView > div.screenExplorerTreeDiv > div#MyScreens.screenTree > div[name='My Screens']")
	private WebElement msMyScreens_SectionButton;
	
	@FindAll(@FindBy(css="div#MyScreens.screenTree > div[class=screenExplorerChild] > div.screenExplorerItem.screenExplorerMarkItem"))
	private List<WebElement> msMyScreens_CreatedScreens;
	
	//MS PRESET STOCK screens
	@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.content.expendToMedium > div.screener.leftSidebar.contentShow > div.screenListView > div.screenExplorerTreeDiv > div#MarketSmithStockScreens.screenTree > div[name='MarketSmith Stock Screens']")
	private WebElement msStockScreens_PresetSectionButton;
	
	@FindAll(@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.content.expendToMedium > div.screener.leftSidebar.contentShow > div.screenListView > div.screenExplorerTreeDiv > div#MarketSmithStockScreens.screenTree > div[class=screenExplorerChild] > div"))
	private List<WebElement> msStockScreens_PresetScreens;
	
	//MS PRESET FUND screens
	@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.content.expendToMedium > div.screener.leftSidebar.contentShow > div.screenListView > div.screenExplorerTreeDiv > div#MarketSmithFundScreens.screenTree > div[name='MarketSmith Fund Screens']")
	private WebElement msFundScreens_PresetSectionButton;
	
	@FindAll(@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.content.expendToMedium > div.screener.leftSidebar.contentShow > div.screenListView > div.screenExplorerTreeDiv > div#MarketSmithFundScreens.screenTree > div[class=screenExplorerChild] > div"))
	private List<WebElement> msFundScreens_PresetScreens;
	
	//Global Screener Menu
	//html body div.MST div.globalPopUpMenu
	//body > div.MST > div.globalPopUpMenu > ul > li.inMyScreen.optionsScreenCopy
	@FindAll(@FindBy(css="body > div.MST > div.globalPopUpMenu > ul>li"))
	private List<WebElement> ScreenerGlobalMenu;
	
	//locate marketsmith Stock screens Folder
	@FindBy(css="div#MarketSmithStockScreens > div:nth-of-type(1)")
	private WebElement msScreensFolder;  
	
	//locate open edit button
	@FindBy(css="div.screenEditBtnDiv > span")
	private WebElement openEditButton;
	
	//locate marketsmith stock screen
	@FindBy(css="div#MarketSmithStockScreens > div:nth-of-type(2) > div:nth-of-type(1) > label")
	private WebElement msFirstStockScreen;
	
	//locate screen description
	@FindBy(css=".userDescriptionContentSecond")
	private WebElement screenDescription;
	
	//locate ms screen message
	@FindBy(css=".trackedCopyContent")
	private WebElement msScreenMsg;
	
	//locate new screen button
	@FindBy(css=".newScreenFont")
	private WebElement newScreenButton;
	
	//locate new screen option window
	@FindBy(css=".screenNewOptions")
	private WebElement screenOptionsWindow;
	
	//locate all new options
	@FindAll(@FindBy(css=".screenNewOptions>div"))
	private List<WebElement> newScreenOptions;
	
	//first  screen dropdown img
	@FindBy(css="div#MyScreens.screenTree > div[class=screenExplorerChild] > div:nth-of-type(1)>div>img")
	private WebElement firstDropDownImg; 
	
	//locate share screen window
	@FindBy(css=".popUpCommonView.screenShareView.ui-draggable>.popup-title")
	private WebElement shareScreenWindow;
	
	//sharing options
	@FindAll(@FindBy(css=".shareConditionRadioButton"))
	private List<WebElement> allSharingOptions;
	
	//share apply button
	@FindBy(css=".shareApplyButton")
	private WebElement shareApplyButton;
	
	//shared icon
	@FindBy(css="div#MyScreens.screenTree > div[class=screenExplorerChild] > div:nth-of-type(1)>span:nth-of-type(2)")
	private WebElement firstSharedIcon;
	/*******************************************************Accessor Functions*****************************************************
	******************************************************************************************************************************/
	public WebElement getLeftPanelScreenerButton(){
		return leftPanelScreenerButton;
	}
	
	public WebElement getLeftPanelScreenerText(){
		return leftPanelScreenerText;
	}
	
	public WebElement getLeftScreenSubPanels(){
		return leftScreenSubPanelsContent;
	}
	
	public List<WebElement> getLeftScreenSubPanelButtons(){
		return leftScreenSubPanelButtons;
	}
	
	public WebElement getScreensSubPanel_button(){
		return ScreensSubPanel_button;
	}
	
	public WebElement getScreenNewScreen_button(){
		return ScreenNewScreen_button;
	}
	
	public List<WebElement> getSceenSubPanel_ScreenSections(){
		return SceenSubPanel_ScreenSections;
	}
	
	//MS MY SCREENS
	public WebElement getmsMyScreens_SectionButton(){
		return msMyScreens_SectionButton;
	}
	
	public List<WebElement> getmsMyScreens_CreatedScreens(){
		return msMyScreens_CreatedScreens;
	}
	
	//MS PRESET STOCK screens
	public WebElement getmsStockScreens_PresetSectionButton(){
		return msStockScreens_PresetSectionButton;
	}
	
	public List<WebElement> getmsStockScreens_PresetScreens(){
		return msStockScreens_PresetScreens;
	}
	
	//MS PRESET FUND screens
	public WebElement getmsFundScreens_PresetSectionButton(){
		return msFundScreens_PresetSectionButton;
	}
	
	public List<WebElement> getmsFundScreens_PresetScreens(){
		return msFundScreens_PresetScreens;
	}
	
	//Global Screener Menu
	public List<WebElement> getScreenerGlobalMenu(){
		return ScreenerGlobalMenu;
	}
	public WebElement getmsScreensFolder(){
		return msScreensFolder;
	}
	public WebElement getopenEditButton(){ 
		return openEditButton;
	}
	public WebElement getmsFirstStockScreen(){
		return msFirstStockScreen;
	}
	public WebElement getscreenDescription(){
		return screenDescription;
	}
	public WebElement getmsScreenMsg(){
		return msScreenMsg;
	}
	public WebElement getnewScreenButton(){
		return newScreenButton;
	}
	public WebElement getscreenOptionsWindow(){
		return screenOptionsWindow;
	}
	public List<WebElement> getnewScreenOptions(){
		return newScreenOptions;
	}
	public WebElement getfirstDropDownImg(){
		return  firstDropDownImg;
	}
	public WebElement getshareScreenWindow(){
		return shareScreenWindow;
	}
	public List<WebElement> getallSharingOptions(){
		return allSharingOptions;
	}
	public WebElement getShareApplyButton(){
		return shareApplyButton;
	}
	public WebElement getfirstSharedIcon(){
		return firstSharedIcon;
	}
	
	//Tracked Screens folder section
	@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.content.expendToMedium > div.screener.leftSidebar.contentShow > div.screenListView > div.screenExplorerTreeDiv > div#TrackedScreens.screenTree > div[name='Tracked Screens']")
	private WebElement TrackedScreensSection_Button;
	
	public WebElement getTrackedScreensSection_Button()
	{
		return TrackedScreensSection_Button;
	}
	
	//All tracked screens
	@FindAll(@FindBy(css="div#TrackedScreens.screenTree > div[class=screenExplorerChild] > div"))
	private List<WebElement> AllTrackedScreens;
	
	public List<WebElement> getAllTrackedScreens()
	{
		return AllTrackedScreens;
	}
	
	//Favorite Screens folder section
	@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.content.expendToMedium > div.screener.leftSidebar.contentShow > div.screenListView > div.screenExplorerTreeDiv > div#FavoriteScreens.screenTree > div[name='Favorite Screens']")
	private WebElement FavoriteScreensSection_Button;
	
	public WebElement getFavoriteScreensSection_Button()
	{
		return FavoriteScreensSection_Button;
	}
	
	//All favorite sreens
	@FindAll(@FindBy(css="div#FavoriteScreens.screenTree > div[class=screenExplorerChild] > div"))
	private List<WebElement> AllFavoriteScreens;
	
	public List<WebElement> getAllFavoriteScreens()
	{
		return AllFavoriteScreens;
	}
	
	
	@FindBy(css="body > div.MST > div.listManager > div.listDetail > div.navbar > div.itemsNum")
	private WebElement LMNavBarTitle;
	
	public WebElement getLMNavBarTitle()
	{
		return LMNavBarTitle;
	}
	
	@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.content.expendToMedium > div.screener.leftSidebar.contentShow > div.screenListView > div.newBtnWrap > div:nth-child(2) > span")
	private WebElement BrowseScreensButton;
	
	public WebElement getBrowseScreensButton()
	{
		return BrowseScreensButton;
	}
	
	@FindBy(css="div.screenDetail")
	private WebElement EditScreenDetails;
	
	public WebElement getEditScreenDetails()
	{
		return EditScreenDetails;
	}
	
	@FindBy(css="div.screenDetail > div.screenInfo > div.symbolSelected > span")
	private WebElement ScreenEditName;
	
	public WebElement getScreenEditName()
	{
		return ScreenEditName;
	}
	
	@FindBy(css="div.screenDetail > div.screenInfo > div.descriptionSelected > span.screenUniverseListLink.toolTip-help")
	private WebElement ScreenFromLink;
	
	public WebElement getScreenFromLink()
	{
		return ScreenFromLink;
	}
	
	@FindBy(css="#ModalPanel > div.popUpCommonView.popUpAddToListView")
	private WebElement ScreenerSelectAListModal;
	
	public WebElement getScreenerSelectAListModal()
	{
		return ScreenerSelectAListModal;
	}
	
	@FindBy(css="div.screenNewFolder.screenNewElemDiv")
	private WebElement ScreenNewFolderOption;
	
	public WebElement getScreenNewFolderOption()
	{
		return ScreenNewFolderOption;
	}
	
	@FindBy(css="#ModalPanel > div.popUpListManagerNewElementView.ui-droppable")
	private WebElement NewElementViewModal;
	
	public WebElement getNewElementViewModal()
	{
		return NewElementViewModal;
	}
	
	@FindBy(css="#ModalPanel > div.popUpListManagerNewElementView.ui-droppable > div > div.popUpNewElementContent > div.contentText > input")
	private WebElement NewElementModalInput;
	
	public WebElement getNewElementModalInput()
	{
		return NewElementModalInput;
	}

	@FindBy(css="#ModalPanel > div.popUpScreenDeleteConfirmView.ui-droppable > div > div.deleteConfirm > button.deleteConfirmBtn.deleteConfirmSave")
	private WebElement ConfirmDeleteButton;
	
	public WebElement getConfirmDeleteButton()
	{
		return ConfirmDeleteButton;
	}
	
	@FindBy(css="div.screenNewStock.screenNewElemDiv")
	private WebElement ScreenNewScreenOption;
	
	public WebElement getScreenNewScreenOption()
	{
		return ScreenNewScreenOption;
	}
	
	@FindBy(css="div.screenNoResultView")
	private WebElement ScreenFilterViewEmpty;
	
	public WebElement getScreenFilterViewEmpty()
	{
		return ScreenFilterViewEmpty;
	}
	
	@FindAll(@FindBy(css="div.screenDetail > div.screenResultsView > div.resultPositionCnt > ul > li"))
	private List<WebElement> AllScreenFilterCriterias;
	
	public List<WebElement> getAllScreenFilterCriterias()
	{
		return AllScreenFilterCriterias;
	}
	
	@FindBy(css="#ModalPanel > div.screenBrowseView.ui-draggable")
	private WebElement BrowseScreensModal;
	
	public WebElement getBrowseScreensModal()
	{
		return BrowseScreensModal;
	}
	
	@FindAll(@FindBy(css="div.screenBrowseMiddleLeftTitle"))
	private List<WebElement> LHSSectionTitles_BrowseScreensModal;
	
	public List<WebElement> getLHSSectionTitles_BrowseScreensModal()
	{
		return LHSSectionTitles_BrowseScreensModal;
	}
	
	@FindAll(@FindBy(css="#ModalPanel > div.screenBrowseView.ui-draggable > div.screenBrowseMiddleRight > table > thead > tr > td"))
	private List<WebElement> AllColumnHeaders_BrowseScreen;
	
	public List<WebElement> getAllColumnHeaders_BrowseScreen()
	{
		return AllColumnHeaders_BrowseScreen;
	}
	
	@FindAll(@FindBy(css="#ModalPanel > div.screenBrowseView.ui-draggable > div.screenBrowseMiddleRight > table > tbody > tr"))
	private List<WebElement> AllSharedScreens;
	
	public List<WebElement> getAllSharedScreens()
	{
		return AllSharedScreens;
	}
	
	@FindBy(css="#ModalPanel > div.screenBrowseView.ui-draggable > div.screenBrowseMiddleLeft > table > tbody > tr:nth-child(1) > td:nth-child(1) > input")
	private WebElement FirstFilterCheckBox_BrowseScreens;
	
	public WebElement getFirstFilterCheckBox_BrowseScreens()
	{
		return FirstFilterCheckBox_BrowseScreens;
	}
	
	@FindAll(@FindBy(css="div[class*='communityActivityLeft'] > div[class*='Head']"))
	private List<WebElement> SelectedSharedScreenSections;
	
	public List<WebElement> getSelectedSharedScreenSections()
	{
		return SelectedSharedScreenSections;
	}
	
	@FindBy(css="div.communityActivityLeftRatingName")
	private WebElement SelectedSharedScreenRatingSection;
	
	public WebElement getSelectedSharedScreenRatingSection()
	{
		return SelectedSharedScreenRatingSection;
	}
	
	@FindAll(@FindBy(css="div.communityActivityRight > div[class*='communityActivityRightComment']"))
	private List<WebElement> CommentAreaSelectedSharedScreenModal;
	
	public List<WebElement> getCommentAreaSelectedSharedScreenModal()
	{
		return CommentAreaSelectedSharedScreenModal;
	}
	
	@FindAll(@FindBy(css="#ModalPanel > div.communityActivityView.ui-draggable.ui-droppable > div.communityActivityLeft > div.communityActivityLeftPannel > button"))
	private List<WebElement> TopTwoButtonsSelectedSharedScreenModal;
	
	public List<WebElement> getTopTwoButtonsSelectedSharedScreenModal()
	{
		return TopTwoButtonsSelectedSharedScreenModal;
	}
	
	@FindBy(css="div.communityActivityTop")
	private WebElement ModalSharedScreenName;
	
	public WebElement getModalSharedScreenName()
	{
		return ModalSharedScreenName;
	}
	
	@FindBy(css="div.communityActivityLeftResultsFoot > span")
	private WebElement ModalSharedScreenResultNum;
	
	public WebElement getModalSharedScreenResultNum()
	{
		return ModalSharedScreenResultNum;
	}
	
	@FindBy(css="#ModalPanel > div.communityActivityView.ui-draggable.ui-droppable")
	private WebElement ScreenDetailsModal;
	
	public WebElement getScreenDetailsModal()
	{
		return ScreenDetailsModal;
	}
	
	@FindBy(css="#ModalPanel > div.popUpListManagerNewElementView.ui-droppable > div > div.popUpNewElementConfirm > button.popUpNewElemBtn.newElemSave")
	private WebElement LMNewElementModalSaveButton;
	
	public WebElement getLMNewElementModalSaveButton()
	{
		return LMNewElementModalSaveButton;
	}
	
	@FindBy(css="#ModalPanel > div.popUpScreenDeleteConfirmView.ui-droppable > div > div.deleteConfirmContent > div.deleteConfirmTips > span.deleteConfirmTipsTitle")
	private WebElement ImportantRedDeleteMsg;
	
	public WebElement getImportantRedDeleteMsg()
	{
		return ImportantRedDeleteMsg;
	}
	
	@FindBy(css="#ModalPanel > div.popUpScreenDeleteConfirmView.ui-droppable > div > div.deleteConfirm > button.deleteConfirmBtn.deleteConfirmCancel")
	private WebElement DeleteConfirmCancelButton;
	
	public WebElement getDeleteConfirmCancelButton()
	{
		return DeleteConfirmCancelButton;
	}
	
	@FindBy(css="div.screenEditBtnDiv > div.closePanel.toolTip-help")
	private WebElement ScreenerCloseButton;
	
	public WebElement getScreenerCloseButton()
	{
		return ScreenerCloseButton;
	}
	//@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.content.expendToMedium")
}