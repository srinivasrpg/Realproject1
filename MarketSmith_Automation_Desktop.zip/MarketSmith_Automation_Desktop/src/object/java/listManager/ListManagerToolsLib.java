package listManager;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.events.WebDriverEventListener;

public class ListManagerToolsLib {
    //locate default button 
	@FindBy(css="div.navbar > div:nth-of-type(12) > div:nth-of-type(2)")
	private WebElement defaultViewButton;
	
	//locate play button
	@FindBy(css="#playButtonID")
	private WebElement playButton;
	
	//locate play dropdown
	@FindBy(css="div.navbar > div:nth-of-type(12) > div:nth-of-type(7) > div > div:nth-of-type(1)")
	private WebElement playDropDown;
	
	//locate help button
	@FindBy(css=".LMBtn.help.toolTip-help")
	private WebElement listManagerHelpOption;
	
	//locate Chart View button
	@FindBy(css="div.navbar > div:nth-of-type(12) > div:nth-of-type(1)")
	private WebElement chartViewButton;
	
	//locate list View button
	@FindBy(css="div.navbar > div:nth-of-type(12) > div:nth-of-type(3)")
	private WebElement listViewButton; 
	
	//locate play intervals
	@FindAll(@FindBy(css=".toolsLst.intervalMenuShowToggle>li"))
	private List<WebElement> playIntervals;
	
	//locate play drop down interval 10seconds
	@FindBy(css=".toolsLst.intervalMenuShowToggle>li:nth-of-type(4)")
	private WebElement singleInterval;
	
	//locate stocks from list panel
	@FindBy(css="div.freezeVirtualizedPanel > div:nth-of-type(1)> div:nth-of-type(5) > div:nth-of-type(1) > span")
	private WebElement selectedStock;
	
	//get all the tickers
	@FindAll(@FindBy(css="div.freezeVirtualizedPanel > div > div:nth-of-type(5)>div>span"))
	private List<WebElement> symbolList;
	
	//locate end of list msg
	@FindBy(css="#navbarTips>span")
	private WebElement endOfListMsg;
	
	//get chart information
	@FindBy(css=".symbolInformation")
	private WebElement chartSymbol;
	
	//locate on symbol entry field
	@FindBy(css="body > div.MST > div.header > input")
	private WebElement symbolEntryField;
	
	//locate all rows
	@FindAll(@FindBy(css="div.freezeVirtualizedPanel>div"))
	private List<WebElement> entireRow;
	
	//locate resume playing window
	@FindBy(css=".popUpPlayPauseView")
	private WebElement resumePlayWindow;
	
	//resume play button
	@FindBy(css=".playPauseButton>span:nth-of-type(2)")
	private WebElement resumePlayButton;
	
	//locate contents of resume play window
	@FindBy(css=".tipContent>span")
	private WebElement resumePlayContent;
	
	 //locate arrow of related information
	 @FindBy(css="div.sidebar.relatedInformation > div:nth-of-type(2) > div > div")
	 private WebElement riArrow;
		
	 //locate RI tab
	 @FindBy(css="div.sidebar.relatedInformation > div:nth-of-type(2) > div > span")
	 private WebElement relatedInfoTab;
	 
	 //locate daily button
	 @FindBy(css="div.MST > div:nth-of-type(1) > span:nth-of-type(1)")
	 private WebElement dailyButton;
	 
	 //locate 15second interval
	 @FindBy(css=".toolsLst.intervalMenuShowToggle>li:nth-of-type(5)")
	 private WebElement fifthInterval;
	 
	 //locate news tab from RI
	 @FindBy(css="div.optionPanel > div:nth-of-type(8)")
	 private WebElement newsTab;
	 
	 //locate wrench icon List Manager
	 @FindBy(css=".LMBtnTools.toolTip-help")
	 private WebElement listManagerTool;
	 
	 //locate tools window
	 @FindBy(css="div.navbar > div:nth-of-type(12) > div:nth-of-type(4) > ul")
	 private WebElement toolsWindow;
	 
	 //locate tools options
	 @FindAll(@FindBy(css="div.LMBtn.tools.click > ul>li"))
	 private List<WebElement> toolsOptions;
	 
	 //locate LM tool triangle
	 @FindBy(css="div.LMBtn.tools > div:nth-of-type(2)")
	 private WebElement lmTriangle;
	 
	 //locate view details option
	 @FindBy(css="div.LMBtn.tools.click > ul>li:nth-of-type(1)")
	 private WebElement viewDetailsOption;
	 
	 //locate community window
	 @FindBy(css=".listManagerCommunityActivityTop")
	 private WebElement communityWindow;
	 
	//locate close button
	@FindBy(css="div#ModalPanel > div.listManagerCommunityActivityView > span")
	private WebElement closeButton;
	
	//locate listtitle name
	@FindBy(css=".listItemName")
	private WebElement listTitle; 
	
	//locate rating
    @FindBy(css=".listManagerCommunityActivityLeftRatingName")
	private WebElement ratingName;
		
	//locate tracked by
	@FindBy(css=".listManagerCommunityActivityLeftTrackedHead")
	private WebElement trackedByLabel;
		
	//author field
	@FindBy(css=".listManagerCommunityActivityLeftAuthorHead")
	private WebElement authorLabel;
		
	//last Updated
	@FindBy(css=".listManagerCommunityActivityLeftUpdatedHead")
	private WebElement lastUpdatedField;
		
	//no of items or results
	@FindBy(css=".listManagerCommunityActivityLeftResultsHead")
	private WebElement noOfResults;
		
	//Description label
	@FindBy(css=".listManagerCommunityActivityLeftDescriptionHead")
	private WebElement descriptionLabel;
		
	//tags section
	@FindBy(css=".listManagerCommunityActivityLeftTagsHead")
	private WebElement tagsSection;
		
	//locate show comments
	@FindBy(css=".listManagerCommunityActivityRightCommentShowContent")
	private WebElement showComments;
	
	//locate add a comment
	@FindBy(css=".listManagerCommunityActivityRightCommentAddContent")
	private WebElement addCommentSection;
		
	//locate submit button
	@FindBy(css=".listManagerCommunityActivityRightCommentAddUnableSubmit")
	private WebElement submitButton;
	
	//locate sharing status
	@FindBy(css=".listManagerCommunityActivityView.ui-draggable.ui-droppable>div:nth-of-type(2)>div:nth-of-type(3)>span:nth-of-type(2)")
	private WebElement sharingstatus;
	
	//locate change link
	@FindBy(css=".listManagerCommunityActivityLeftPannel.listManagerSharingStatusPanel>span>a")
	private WebElement statusChangeLink;
	
	//locate sharelist title
	@FindBy(css="div#ModalPanel > div.popUpCommonView.screenShareView.ui-draggable > div:nth-of-type(1)")
	private WebElement shareListWindow;
	
	//locate 3 sharing radio buttons;
	@FindAll(@FindBy(css=".shareConditionRadioButton"))
	private List<WebElement> sharingOptions; 
	
	//locate description
	@FindBy(css=".descriptionText")
	private WebElement descriptionArea;
	
	//locate characters left num
	@FindBy(css=".charatersLeftNum")
	private WebElement charLeftNum;
	
	//locate all tags section
	@FindBy(css=".tagsList")
	private WebElement alltagsSection;
	
	//locate about sharing screen
	@FindBy(css=".aboutSharingScreens")
	private WebElement aboutSharingScreen; 
	
	//locate each and every tags
	@FindAll(@FindBy(css=".tagsButton"))
	private List<WebElement> allTags;
	
	//locate applied tags
	@FindBy(css=".tagsApplied")
	private WebElement tagsApplied;
	
	//locate apply button
	@FindBy(css=".shareApplyButton")
	private WebElement applybutton;
	
	//user created list or folder
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(1) > label")
	private WebElement createdList;
	
	//locate shared  icon
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(1) > span:nth-of-type(2)")
	private WebElement sharedIcon;
	
	//locate shared Icon for second list
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(2) > span:nth-of-type(2)")
	private WebElement secSharedIcon;
	
	//locate export in option
	@FindBy(css="div.LMBtn.tools.click > ul>li:nth-of-type(3)")
	private WebElement exportButton;
	
	//locate all export options
	@FindAll(@FindBy(css=".exportIn>ul>li"))
	private List<WebElement> allExportOptions;
	
	//locate wait for export options
	@FindBy(css=".exportIn>ul")
	private WebElement waitForExportOptions;
	
	//locate customize column layout
	@FindBy(css="div.LMBtn.tools.click > ul>li:nth-of-type(5)")
	private WebElement customizeColumnOption;
	
	//locate customize column window
	@FindBy(css=".popupTitle")
	private WebElement customizeColumnLayout;
	
	//locate cancel button customize column layout
	@FindBy(css=".cancelButton")
	private WebElement customizeColumnCancelButton;
	
	//locate columnLayout
	@FindBy(css="div.LMBtn.tools.click > ul>li:nth-of-type(6)")
	private WebElement columnLayoutOption;
	
	//wait for columnLayout options
	@FindBy(css=".selectColumnLayout>ul")
	private WebElement waitForColumnLayoutOptions;
	
	//locate all column layout options
	@FindAll(@FindBy(css=".selectColumnLayout>ul>li"))
	private List<WebElement> columnLayoutOptions;
	
	//locate all columns
	@FindAll(@FindBy(css="div.listManagerFlexibleHeaderCellInner>span.listManagerFlexibleHeaderCellText"))
	private List<WebElement> columnNames;
	
	//locate column width preferences window
	@FindBy(css="div.popUpCommonView.popUpColumnWidthPreferenceView.ui-draggable.ui-droppable > div:nth-of-type(1)")
	private WebElement columnWidthPrefWindow;
	
	//locate column width preferences option
	@FindBy(css="div.LMBtn.tools.click > ul>li:nth-of-type(8)")
	private WebElement columnWidthPreference;
	
	//locate scroll drag list manager
	@FindBy(css="div#dragLM")
	private WebElement dragLM;
	
	//drop here
	@FindBy(css="div#chartCnt > div:nth-of-type(14) > div:nth-of-type(2) > div:nth-of-type(1)")
	private WebElement dropHere;
	
	//locate columnwidth radio buttons
	@FindAll(@FindBy(css=".adjustColumn"))
	private List<WebElement> columnWidthButtons; 
	
	//locate columnwidth cancel button 
	@FindBy(css=".columnPreferenceCancel")
	private WebElement columPrefCancel;
	
	//locate accept button in column width
	@FindBy(css=".columnPreferenceAccept")
	private WebElement columnPrefAccept; 
	
	//locate symbol column name
	@FindBy(css="div.listManagerGridFreeze > div:nth-of-type(2) > div:nth-of-type(4)")
	private WebElement symbolColumn;
	
	//second list
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(2) > label")
	private WebElement secondList;
	
	//locate text area of View Details
	@FindBy(css="div#ModalPanel > div > div:nth-of-type(3) > div:nth-of-type(2) > textarea")
	private WebElement textArea;
	
	//locate submitText
	@FindBy(css="div#ModalPanel > div> div:nth-of-type(3) > div:nth-of-type(2) > button:nth-of-type(1)")
	private WebElement commentSubmit;
	
	//locate rating
	@FindBy(css="div#ModalPanel > div> div:nth-of-type(2) > div:nth-of-type(4) > div:nth-of-type(2) > span:nth-of-type(1)")
	private WebElement ratingSection;
	
	//locate Browse buttons
	@FindBy(css=".buttonBar > div:nth-of-type(2)>button")
	private WebElement browseButton;
	
	//locate browse list window
	@FindBy(css=".listManagerBrowseTop")
	private WebElement browseListWindow;
	
	//locate shared list
	@FindBy(css="div.listManagerBrowseMiddleRight > table > tbody > tr:nth-of-type(1) > td:nth-of-type(2) > span:nth-of-type(1)")
	private WebElement sharedList;
	
	//locate view List button
	@FindBy(css=".listManagerCommunityActivityLeftPannelViewScreen")
	private WebElement viewListButton;
	
	//list header
	@FindBy(css="div.listCategory > div:nth-of-type(1) > span:nth-of-type(3)")
	private WebElement currentListName;
	
	//locate author name
	@FindBy(css=".listManagerCommunityActivityLeftAuthorFoot>a")
	private WebElement authorLink;
	
	//locate  browse list close window
	@FindBy(css="div#ModalPanel > div.listManagerBrowse.ui-draggable > span")
	private WebElement browseListWindowClose;
	
	//locate second shared list
	@FindBy(css="div.listManagerBrowseMiddleRight > table > tbody > tr:nth-of-type(2) > td:nth-of-type(2) > span:nth-of-type(1)")
	private WebElement secondSharedList;
	
	//locate track button
	@FindBy(css="div.listManagerCommunityActivityView.ui-draggable.ui-droppable>div:nth-of-type(2)>div:nth-of-type(2)>button:nth-of-type(2)")
	private WebElement trackButton;
	
	//locate un track button
	@FindBy(css="div.listManagerCommunityActivityView.ui-draggable.ui-droppable>div:nth-of-type(2)>div:nth-of-type(2)>button:nth-of-type(3)")
	private WebElement untrackButton;
	
	//locate share cancel button
	@FindBy(css=".shareCancelButton")
	private WebElement shareCancelButton;
	
	//locate dropdown of selectable criteria
	@FindBy(css="div.stocksTable > div > div:nth-of-type(1) > div:nth-of-type(1) > span")
	private WebElement cellExtendDropdown;
	
	//locate all columns comes under ratings
	@FindAll(@FindBy(css="div.stocksTable > div > div:nth-of-type(1) > div:nth-of-type(2)>div"))
	private List<WebElement> allRatingColumns;
	/************************************GETTERS******************************
	 **************************************************************************/
	public WebElement getDefaultViewButton(){
		return defaultViewButton;
	}
    public WebElement getPlayButton(){
		return playButton;
	}
	public WebElement getPlayDropDown(){
		return playDropDown;
	}
	public WebElement getListManagerHelpOption(){
		return listManagerHelpOption;
	}
	public WebElement getChartViewButton(){
		return chartViewButton;
	}
	public WebElement getlistViewButton(){
		return listViewButton;
	}
	public List<WebElement> getplayIntervals(){
		return playIntervals;
	}
	public WebElement getsingleInterval(){
		return singleInterval;
	}
	public WebElement getselectedStock(){
    	return  selectedStock;
    }
	public List<WebElement> getsymbolList(){
    	return symbolList;
    }
	public WebElement getChartSymbol(){
	    	return chartSymbol;
	}
	public WebElement getSymbolEntryField(){
			return symbolEntryField;
	} 
	public List<WebElement> getEntireRow(){
		return entireRow;
	}
	public WebElement getresumePlayWindow(){
		return resumePlayWindow;
	}
	public WebElement getResumePlayButton(){
		return resumePlayButton;
	}
	public WebElement getresumePlayContent(){
		return resumePlayContent;
	}
	public WebElement getRiArrow(){
		return riArrow;
	}
    public WebElement getRelatedInfoTab(){
		return relatedInfoTab;
	}
    public WebElement getDailyButton(){
    	return dailyButton;
    }
    public WebElement getFifthInterval(){
    	return fifthInterval;
    }
    public WebElement getnewsTab(){
    	return newsTab;
    }
    public WebElement getListManagerTool(){
    	return listManagerTool;
    }
    public WebElement gettoolsWindow(){
    	return toolsWindow;
    }
    public List<WebElement> gettoolsOptions(){
    	return toolsOptions;
    }
    public WebElement getlmTriangle(){
    	return lmTriangle;
    }
    public WebElement getviewDetailsOption(){
    	return viewDetailsOption;
    }
    public WebElement getcommunityWindow(){
    	return communityWindow;
    }
    public WebElement getcloseButton(){
    	return closeButton;
    }
    public WebElement getlistTitle(){
    	return listTitle;
    }
    public WebElement getRatingName(){
    	return ratingName;
    }
    public WebElement getTrackedByLabel(){
    	return trackedByLabel;
    }
    public WebElement getAuthorLabel(){
    	return authorLabel;
    }
    public WebElement getLastUpdatedField(){
    	return lastUpdatedField;
    }
    public WebElement getnoOfResults(){
    	return noOfResults;
    }
    public WebElement getDescriptionLAbel(){
    	return descriptionLabel;
    }
    public WebElement getTagsSection(){
    	return tagsSection;
    }
    public WebElement getShowComments(){
    	return showComments;
    }
    public WebElement getAddCommentSection(){
    	return addCommentSection;
    }
    public WebElement getsubmitButton(){
    	return submitButton;
    }
    public WebElement getsharingstatus(){
    	return sharingstatus;
    }
    public WebElement getstatusChangeLink(){
    	return statusChangeLink;
    }
    public WebElement getShareListWindow(){
    	return shareListWindow;
    }
    public List<WebElement> getSharingOptions(){
    	return sharingOptions;
    }
    public WebElement  getdescriptionArea(){
    	return descriptionArea;
    }
    public WebElement getcharLeftNum(){
    	return charLeftNum;
    }
    public WebElement getalltagsSection(){
    	return alltagsSection;
    }
    public WebElement getaboutSharingScreen(){
    	return aboutSharingScreen;
    }
    public List<WebElement> getAllTags(){
    	return allTags;
    }
    public WebElement gettagsApplied(){
    	return tagsApplied;
    }
    public WebElement getApplyButton(){
    	return applybutton;
    }
    public WebElement getUserCreatedList(){
		return createdList;
	}
    public WebElement getSharedIcon(){
    	return sharedIcon;
    }
    public WebElement getexportButton(){
    	return exportButton;
    }
    public List<WebElement> getallExportOptions(){
    	return allExportOptions;
    }
    public WebElement getwaitForExportOptions(){
    	return waitForExportOptions;
    }
    public WebElement getcustomizeColumnOption(){
    	return customizeColumnOption;
    }
    public WebElement getcustomizeColumnLayout(){
    	return customizeColumnLayout;
    }
    public WebElement getcustomizeColumnCancelButton(){
    	return customizeColumnCancelButton;
    }
    public WebElement getcolumnLayoutOption(){
    	return columnLayoutOption;
    }
    public WebElement getwaitForColumnLayoutOptions(){
    	return waitForColumnLayoutOptions;
    }
    public List<WebElement> getcolumnLayoutOptions(){
    	return columnLayoutOptions;
    }
    public List<WebElement> getColumnNames(){
    	return columnNames;
    }
    public WebElement getcolumnWidthPrefWindow(){
    	return columnWidthPrefWindow;
    }
    public WebElement getcolumnWidthPreference(){
    	return columnWidthPreference;
    }
    public WebElement getdragLM(){
    	return dragLM;
    }
    public WebElement getdropHere(){
    	return dropHere;
    }
    public List<WebElement> getcolumnWidthButtons(){
    	return columnWidthButtons;
    }
    public WebElement getcolumPrefCancel(){
    	return columPrefCancel;
    }
    public WebElement getcolumnPrefAccept(){
    	return columnPrefAccept;
    }
    public WebElement getsymbolColumn(){
    	return symbolColumn;
    }
    public WebElement getSecondList(){
    	return secondList;
    }
    public WebElement getTextArea(){
    	return textArea;
    }
    public WebElement getcommentSubmit(){
    	return commentSubmit;
    }
    public WebElement getRatingSection(){
    	return ratingSection;
    }
    public WebElement getBrowseButton(){
    	return browseButton;
    }
    public WebElement getBrowseListWindow(){
    	return browseListWindow;
    }
    public WebElement getSharedList(){
    	return sharedList;
    }
    public WebElement getViewListButton(){
    	return viewListButton;
    }
    public WebElement getCurrentListName(){
		return currentListName;
	}
    public WebElement getAuthorLink(){
    	return authorLink;
    }
    public WebElement getbrowseListWindowClose(){
    	return browseListWindowClose;
    }
    public WebElement getsecondSharedList(){
    	return secondSharedList;
    }
    public WebElement getTrackButton(){
    	return trackButton;
    }
    public WebElement getUnTrackButton(){
    	return untrackButton;
    }
    public WebElement getshareCancelButton(){
    	return shareCancelButton;
    }
    public WebElement getendOfListMsg(){
    	return endOfListMsg;
    }
    public WebElement getcellExtendDropdown(){
    	return cellExtendDropdown;
    }
    public List<WebElement> getallRatingColumns(){
    	return allRatingColumns;
    }
    public WebElement getsecSharedIcon(){
    	return secSharedIcon;
    }
}
