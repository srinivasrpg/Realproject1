package listManager;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class ListManager1Lib {
	//Locate all folders of left side
	@FindAll(@FindBy(css=".listExplorerFather"))
    private List<WebElement> foldersList;
	
	//locate Screen Results list
	@FindBy(css="div#ScreenResults > div > label")
	private WebElement screenResultList;
	
	//locate screenResults
	@FindBy(css="div#ScreenResults")
	private WebElement screenResults;
	
	@FindBy(css="div#MyLists > div:nth-of-type(1) > span")
	private WebElement myListsLink;
	
	@FindBy(css="div#MyLists > div:nth-of-type(1) > label")
	private WebElement  myListName;
	
	//user created list or folder
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(1) > label")
	private WebElement createdList;
    
	//user created folder
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(1)>div:nth-of-type(1) > label")
	private WebElement createdFolder;
	
	//list header
	@FindBy(css="div.listCategory > div:nth-of-type(1) > span:nth-of-type(3)")
	private WebElement currentListName;
	
	//locate user created list or folder
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(1)")
	private WebElement MyListelements;
	
	//get all lists and folders comes under My list
	@FindBy(css="div#MyLists > div:nth-of-type(2)>div")
	private List<WebElement> allCreatedLists;
	
	//locate dropdown
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(1) > div > img")
	private WebElement dropdown;
	
	//wait for listwindow
	@FindBy(css=".optionsMenuList.myListMenuType")
	private WebElement waitOptions;
	
	//list all elements on mouse over
	@FindAll(@FindBy(css=".myListMenuType>ul>li:not([style]),div[style*='inline-block']>.viewDetails"))
	private List<WebElement> dropdownElements;
	
	//Markets 197 industry group
	@FindBy(css="div[id='Markets/197IndustryGroups']> div:nth-of-type(1)>span")
	private WebElement market197IndustryGroup;
	
	//Markets 197 industry group name
	@FindBy(css="div[id='Markets/197IndustryGroups']> div:nth-of-type(1)>label")
	private WebElement market197IGname;
	
	//197 Industry group list
	@FindBy(css="div[id='Markets/197IndustryGroups']> div:nth-of-type(2) >div:nth-of-type(2)>label")
	private WebElement m197Industrygroups;
	
	//197 dropdown
	@FindBy(css="div[id='Markets/197IndustryGroups']> div:nth-of-type(2) > div:nth-of-type(2)>div>img")
	private WebElement msDropdown;
	
	//wait for drpdown options of ms list
	@FindBy(css=".optionsMenuList.marketIndustryListsMenuType")
	private WebElement waitForDropdownOptions;
	
	//getdropdownelements of ms list
	@FindAll(@FindBy(css=".marketIndustryListsMenuType>ul>li:not([style]),div[style*='inline-block']>.viewDetails"))
	private List<WebElement> msDropDownElements;
	
	//New and Browse buttons
	@FindAll(@FindBy(css=".buttonBar > div"))
	private List<WebElement> newAndBrowseButtons;
	
	//locate new button
	@FindBy(css=".buttonBar > div:nth-of-type(1)>button")
	private WebElement newButton;
	
	//locate new window
	@FindBy(css=".listManagerNewMenu")
	private WebElement newWindow;
	
	//locate list
	@FindBy(css=".listManagerNewMenu >div:nth-of-type(1)")
	private WebElement listMenu;
	//locate new Elements
	@FindAll(@FindBy(css=".listManagerNewMenu >div"))
	private  List<WebElement> newOptions;
	
	//locate folder
	@FindBy(css=".listManagerNewMenu >div:nth-of-type(2)")
	private WebElement folderMenu;
	
	//validate folder is empty
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(1) > div:nth-of-type(1) > div")
	private WebElement folderstatus;
	
	//locate list window
	@FindBy(css=".popUpNewElementTitle")
	private WebElement newListWindow;
	
	//locate name entry text field
	@FindBy(css=".newElementName")
	private WebElement listNameField;
	
	//locate save
	@FindBy(css=".popUpNewElemBtn.newElemSave")
	private WebElement listNamesave;
	
	//locate copy
	@FindBy(css=".myListMenuType>ul>li:nth-of-type(1)")
	private WebElement copyCreatedList;
	
	//locate all symbols from list
	@FindAll(@FindBy(css="div.freezeVirtualizedPanel > div> div:nth-of-type(4) > div > span"))
	private List<WebElement> listSymbols;
	
	//locate rename
	@FindBy(css=".myListMenuType>ul>li:nth-of-type(2)")
	private WebElement renameList;
	
	//locate smartlists
	@FindBy(css="div#ActivityLists> div:nth-of-type(1)>span")
	private WebElement smartList;
	
	//locate recent symbols
	@FindBy(css="div#ActivityLists > div:nth-of-type(2) > div:nth-of-type(1) > label")
	private WebElement recentSymbols;
	
	//locate dropdown of recentsymbol
	@FindBy(css="div#ActivityLists > div:nth-of-type(2) > div:nth-of-type(1) > div > img")
	private WebElement dropdownRecent;
	
	//locate Flagged symbols dropdown options
	@FindAll(@FindBy(css=".optionsMenuList.smartListsMenuType>ul>li:not([style]),div[style*='inline-block']>.viewDetails"))
	private List<WebElement> flaggedSymbolsDropDownOptions;
	
	//locate options window
	@FindBy(css=".optionsMenuList.smartListsMenuType")
	private WebElement waitRecentOptions;
	
	//locate add to favorites
	@FindBy(css=".smartListsMenuType>ul>li:nth-of-type(3)")
	private WebElement addToFavourite;
	
	//locate add to favourite of my lists
	@FindBy(css=".myListMenuType>ul>li:nth-of-type(4)")
	private WebElement addToFavoriteMyList;
	
	//locate favourites folder
	@FindBy(css="div#Favorites > div:nth-of-type(1) > span")
	private WebElement favouriteFolder;
	
	//locate view details of favorite list
	@FindBy(css=".optionsMenuList.favoritesListsMenuType>div:nth-of-type(1)")
	private WebElement favoriteViewDetails;
	
	//locate the element inside favourite
	@FindAll(@FindBy(css="div#Favorites > div:nth-of-type(2) > div > label"))
	private List<WebElement> favouriteList;
	
	//locate favorite list dropdown
	@FindAll(@FindBy(css="div#Favorites > div:nth-of-type(2) > div > div > img"))
	private List<WebElement> dropdownFavourite;
	
	//locate options window
	@FindBy(css=".optionsMenuList.favoritesListsMenuType")
	private WebElement waitFavouriteOptions;
	
	//locate the favorite option dropdown list
	@FindAll(@FindBy(css=".favoritesListsMenuType>ul>li:not([style]),div[style*='inline-block']>.viewDetails"))
	private List<WebElement> favouriteDropdownElements;
	
	//locate remove favourite option
	@FindBy(css=".smartListsMenuType>ul>li:nth-of-type(2)")
	private WebElement removeFavorite;
	
	//locate sharing option
	@FindBy(css=".myListMenuType>ul>li:nth-of-type(5)")
	private WebElement sharingOption;
	
	//locate sharelist title
	@FindBy(css="div#ModalPanel > div.popUpCommonView.screenShareView.ui-draggable > div:nth-of-type(1)")
	private WebElement shareListWindow;
	
	//locate share with specific member radio button
	@FindBy(css=" div.popUpCommonView.screenShareView.ui-draggable>div:nth-of-type(3) > div:nth-of-type(4) > div > input")
	private WebElement shareWithSpecificRadio;
	
	//locate contact from my contact
	@FindBy(css="div.myContacts > div.myContactsGroups > ul:nth-of-type(2) > li:nth-of-type(3) > input")
	private WebElement selectContact;
	
	//locate share button
	@FindBy(css=".shareButton")
	private WebElement sharebutton;
	
	//locate shared members
	@FindBy(css=".membersShowText")
	private WebElement sharedMember;
	
	//locate apply button
	@FindBy(css=".shareApplyButton")
	private WebElement applybutton;
	
	//locate share with everyone radio button
	@FindBy(css="div.popUpCommonView.screenShareView.ui-draggable>div:nth-of-type(3) > div:nth-of-type(3)>input")
	private WebElement shareWithEveryone;
	
	//locate shared  icon
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(1) > span:nth-of-type(2)")
	private WebElement sharedIcon;
	
	//locate 3rd list shred Icon
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(3) > span:nth-of-type(2)")
	private WebElement thirdSharedIcon;
	
	//locate shared icon inside favorite
	@FindBy(css="div#Favorites > div:nth-of-type(2) > div > span:nth-of-type(2)")
	private WebElement favSharedIcon;
	
	//locate view details
	@FindBy(css=".myListMenuType>div:nth-of-type(1)")
	private WebElement viewDetailsOption;
	
	//locate view details window
	@FindBy(css=".listManagerCommunityActivityView.ui-draggable.ui-droppable>div:nth-of-type(1)")
	private WebElement viewDetailsWindow;
	
	//locate sharing status
	@FindBy(css=".listManagerCommunityActivityView.ui-draggable.ui-droppable>div:nth-of-type(2)>div:nth-of-type(3)>span:nth-of-type(2)")
	private WebElement sharingstatus;
	
	//locate change link
	@FindBy(css=".listManagerCommunityActivityLeftPannel.listManagerSharingStatusPanel>span>a")
	private WebElement statusChangeLink;
	
	//locate do not share radio button
	@FindBy(css="div#ModalPanel > div> div:nth-of-type(3) > div:nth-of-type(2)>input")
	private WebElement doNotShareButton;
	
	//locate delete option
	@FindBy(css=".myListMenuType>ul>li:nth-of-type(6)")
	private WebElement deleteListOption;
	
	//locate delete window
	@FindBy(css=".deleteConfirmTitle")
	private WebElement deleteWindow;
	
	//locate delete confirmation checkbox
	@FindBy(css=".deleteConfirmInfo>input")
	private WebElement doNotShowCheckbox;
	
	//locate yes in confirm delete window
	@FindBy(css=".deleteConfirmBtn.deleteConfirmSave")
	private WebElement confirmationDelete;
	
	//locate folder dropdown
	@FindBy(css="div#MyLists > div:nth-of-type(2)>div:nth-of-type(1)>div:nth-of-type(1)>div>img")
	private WebElement dropdownCreatedFolder;
	
	//locate folder delete option
	@FindBy(css=".optionsFileDelete")
	private WebElement folderDeleteOption;
	
	//locate wait for folder delete options
	@FindBy(css=".optionsMenuList.myListMenuFileType")
	private WebElement waitFolderDeleteWindow;
	
	//locate text area of View Details
	@FindBy(css="div#ModalPanel > div > div:nth-of-type(3) > div:nth-of-type(2) > textarea")
	private WebElement textArea;
	
	//locate submitText
	@FindBy(css="div#ModalPanel > div> div:nth-of-type(3) > div:nth-of-type(2) > button:nth-of-type(1)")
	private WebElement commentSubmit;
	
	//locate added comment
	@FindBy(css="div#ModalPanel > div> div:nth-of-type(3) > div:nth-of-type(1) > div:nth-of-type(2) > div:nth-of-type(1) > div:nth-of-type(2)")
	private WebElement showComments;
	
	//locate rating
	@FindBy(css="div#ModalPanel > div> div:nth-of-type(2) > div:nth-of-type(4) > div:nth-of-type(2) > span:nth-of-type(1)")
	private WebElement ratingSection;
	
	//locate comparison chart option
	@FindBy(css=".myListMenuType>ul>li:nth-of-type(8)")
	private WebElement comparisonChartOption;
	
	//locate comparison chart window
	@FindBy(css=".comparisonLabel")
	private WebElement comparisonChartWindow;
	
	//locate close button
	@FindBy(css="div#ModalPanel > div.listManagerCommunityActivityView > span")
	private WebElement closeBtn;
	
	//second list
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(3) > label")
	private WebElement secondList;
	
	//get second list dropdown
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(3) > div > img")
	private WebElement secondDropdown;
	
	
	
	//locate cancel button
	@FindBy(css=".popUpNewElemBtn.newElemCancel")
	private WebElement copyCancel;
	
	//locate dest loc to drop the list
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(4)")
	private WebElement  destLocToListDrop;
	
	//locate 4th list in MyLists folder
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(4)>label")
	private WebElement fourthUserList;
	
	//locate 1st list of favorite folder
	@FindBy(css="div#Favorites> div:nth-of-type(2) > div:nth-of-type(1)")
	private WebElement favoriteFirstLoc;
	
	//locate 2nd list in favorite folder
	@FindBy(css="div#Favorites> div:nth-of-type(2) > div:nth-of-type(2)")
	private WebElement favoriteSecLoc;
	
	//locate 1st favorite List
	@FindBy(css="div#Favorites> div:nth-of-type(2) > div:nth-of-type(1)>label")
	private WebElement favoriteFirstList;
	
	//locate 2nd FavoriteList
	@FindBy(css="div#Favorites> div:nth-of-type(2) > div:nth-of-type(2)>label")
	private WebElement favoriteSecList;
	
	//locate all favorite elements
	@FindAll(@FindBy(css="div#Favorites > div:nth-of-type(2)>div"))
	private List<WebElement> allFavoriteFolderLists;
	
	//locate selected list
	@FindBy(css="div#MyLists > div:nth-of-type(2)>div[class*=itemActive]")
	private WebElement highlightedList;
	
	//locate all tags to be applied
	@FindAll(@FindBy(css="div.tagsList > div:nth-of-type(2) > button"))
	private List<WebElement> allTagsList;
	
	//locate applied tags
	@FindBy(css=".tagsApplied")
	private WebElement tagsApplied;
	
	//locate additional tag text area
	@FindBy(css=".additionalTagsText.textArea")
	private WebElement tagTextArea; 
	
	//locate cancel delete list button
	@FindBy(css=".deleteConfirmBtn.deleteConfirmCancel")
	private WebElement cancelDeleteList;
	
	//locate all columns
	@FindAll(@FindBy(css="div.listManagerFlexibleHeaderCellInner>span.listManagerFlexibleHeaderCellText"))
	private List<WebElement> columnNames;
	/*************************************GETTERS******************************
	 **********************************************/
	public List<WebElement> getFolderlist(){
		return foldersList;
	}
	
	public WebElement getScreenResultList(){
		return screenResultList;
	}
	
	public WebElement getMyListsLink(){
		return myListsLink;
	}
	public WebElement getMyListName(){
		return myListName;
	}
	public WebElement getUserCreatedList(){
		return createdList;
	}
	public WebElement getSecondList(){
    	return secondList;
    }
	public WebElement getCurrentListName(){
		return currentListName;
	}
	public WebElement getMyListElements(){
		return MyListelements;
	}
	public WebElement getDropdown(){
		return dropdown;
	}
	public WebElement getWaitOptions(){
		return waitOptions;
	}
	
	public List<WebElement> getDropdownElements(){
		return dropdownElements;
	}
	public WebElement getMarket197IndustryGroup() {
		return market197IndustryGroup;
	}
	public WebElement getMarket197IGname(){
		return market197IGname;
	}
	public WebElement getM197IndustrygroupList() {
		return m197Industrygroups;
	}
	public WebElement getMsDropdown(){
		return msDropdown;
	}
	public WebElement getWaitDropdownOptions(){
		return waitForDropdownOptions;
	}
    public List<WebElement> getMsDropDownElements(){
    	return msDropDownElements;
    }
    public List<WebElement> getNewAndBrowseButtons(){
    	return newAndBrowseButtons;
    }
    public WebElement getNewButton(){
    	return newButton;
    }
    public WebElement getNewWindow(){
    	return newWindow;
    }
    public List<WebElement> getNewOptions(){
    	return newOptions;
    }
    public WebElement getListMenu(){
    	return listMenu;
    }
    public WebElement getFolderMenu(){
    	return folderMenu;
    }
    public WebElement getCreatedFolder(){
    	return createdFolder;
    }
    public WebElement getFolderstatus(){
    	return folderstatus;
    }
    public WebElement getNewListWindow(){
    	return newListWindow;
    }
    public WebElement getListNameField(){
    	return listNameField;
    }
    public WebElement getListNamesave(){
    	return listNamesave;
    }
    public List<WebElement> getListSymbols(){
    	return listSymbols;
    }
    public WebElement getCopyCreatedList(){
    	return copyCreatedList;
    }
    public WebElement getRenameList(){
    	return renameList;
    }
    public WebElement getSmartList(){
    	return smartList;
    }
    public WebElement getRecentSymbols(){
    	return recentSymbols;
    }
    public WebElement getDropdownRecent(){
    	return dropdownRecent;
    }
    public WebElement getWaitRecentOptions(){
    	return waitRecentOptions;
    }
    public WebElement getAddToFavourite(){
    	return addToFavourite;
    }
    public WebElement getFavouriteFolder(){
    	return favouriteFolder;
    }
    public List<WebElement> getFavouriteList(){
    	return favouriteList;
    }
    public List<WebElement> getDropdownFavourite(){
    	return dropdownFavourite;
    }
    public WebElement getWaitFavouriteOptions(){
    	return waitFavouriteOptions;
    }
    public List<WebElement> getFavoriteDropdownElements(){
    	return favouriteDropdownElements;
    }
    public WebElement getRemoveFavorite(){
    	return removeFavorite;
    }
    public WebElement getSharingOption()
    {
    	return sharingOption;
    }
    public WebElement getShareListWindow(){
    	return shareListWindow;
    }
    public WebElement getShareWithSpecificRadio(){
    	return shareWithSpecificRadio;
    }
    public WebElement getselectContact(){
    	return selectContact;
    }
    public WebElement getSharebutton(){
    	return sharebutton;
    }
    public WebElement getSharedMember(){
    	return sharedMember;
    }
    public WebElement getApplyButton(){
    	return applybutton;
    }
    public WebElement getShareWithEveryone(){
    	return shareWithEveryone;
    }
    public WebElement getSharedIcon(){
    	return sharedIcon;
    }
    public WebElement getViewDetailsOption(){
    	return viewDetailsOption;
    }
    public WebElement getViewDetailsWindow(){
    	return viewDetailsWindow;
    }
    public WebElement getsharingstatus(){
    	return sharingstatus;
    }
    public WebElement getstatusChangeLink(){
    	return statusChangeLink;
    }
    public WebElement getDoNotShareButton(){
    	return doNotShareButton;
    }
    public WebElement getDeleteListOption(){
    	return deleteListOption;
    }
    public WebElement getdeleteWindow(){
    	return deleteWindow;
    }
    public WebElement getdoNotShowCheckbox(){
    	return doNotShowCheckbox;
    }
    public WebElement getConfirmationDelete(){
    	return confirmationDelete;
    }
    public WebElement getDropdownCreatedFolder(){
    	return dropdownCreatedFolder;
    }
    public WebElement getFolderDeleteOption(){
    	return folderDeleteOption;
    }
    public WebElement getWaitFolderDeleteWindow(){
    	return waitFolderDeleteWindow;
    }
    public WebElement getTextArea(){
    	return textArea;
    }
    public WebElement getcommentSubmit(){
    	return commentSubmit;
    }
    public WebElement getShowComments(){
    	return showComments;
    }
    public WebElement getRatingSection(){
    	return ratingSection;
    }
    public WebElement getComparisonChartOption(){
    	return comparisonChartOption;
    }
    public WebElement getcomparisonChartWindow(){
    	return comparisonChartWindow;
    }
    public WebElement getCloseBtn(){
    	return closeBtn;
    }
    public WebElement getsecondDropdown(){
    	return secondDropdown;
    }
    public WebElement getcopyCancel(){
    	return copyCancel;
    }
    public WebElement getdestLocToListDrop(){
    	return destLocToListDrop;
    }
    public WebElement getfourthUserList(){
    	return fourthUserList;
    }
    public WebElement getfavoriteFirstLoc(){
    	return favoriteFirstLoc;
    }
    public WebElement getfavoriteSecLoc(){
    	return favoriteSecLoc;
    }
    public WebElement getfavoriteFirstList(){
    	return favoriteFirstList;
    }
    public WebElement getfavoriteSecList(){
    	return favoriteSecList;
    }
    public List<WebElement> getallFavoriteFolderLists(){
    	return allFavoriteFolderLists;
    }
    public WebElement getscreenResults(){
    	return screenResults;
    }
    public List<WebElement> getallCreatedLists(){
    	return allCreatedLists;
    }
    public WebElement gethighlightedList(){
    	return highlightedList;
    }
    public List<WebElement> getallTagsList(){
    	return allTagsList;
    }
    public WebElement gettagsApplied(){
    	return tagsApplied;
    }
    public WebElement gettagTextArea(){
    	return tagTextArea;
    }
    public WebElement getcancelDeleteList(){
    	return cancelDeleteList;
    }
    public List<WebElement> getColumnNames(){
    	return columnNames;
    }
    public WebElement getaddToFavoriteMyList(){
    	return addToFavoriteMyList;
    }
    public WebElement getfavSharedIcon(){
    	return favSharedIcon;
    }
    public WebElement getfavoriteViewDetails(){
    	return favoriteViewDetails;
    }
    
    public List<WebElement> getflaggedSymbolsDropDownOptions(){
    	return flaggedSymbolsDropDownOptions;
    }
    public WebElement getthirdSharedIcon(){
    	return thirdSharedIcon;
    }
}
	
	 