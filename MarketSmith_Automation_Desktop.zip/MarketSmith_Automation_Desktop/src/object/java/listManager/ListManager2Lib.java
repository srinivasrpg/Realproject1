package listManager;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.events.WebDriverEventListener;

public class ListManager2Lib {
	
	@FindBy(css="div#MyLists > div:nth-of-type(1) > span")
	private WebElement myListsLink;
	
	@FindBy(css="div#MyLists > div:nth-of-type(1) > label")
	private WebElement  myListName;
	
	//user created list or folder
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(1) > label")
	private WebElement createdList;
    
	//user created folder
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(1)>div:nth-of-type(1) > label")
	private WebElement createdFolder;
	//list header
	@FindBy(css="div.listCategory > div:nth-of-type(1) > span:nth-of-type(3)")
	private WebElement currentListName;
	
	//locate user created list or folder
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(1)")
	private WebElement MyListelements;
	
	//locate no of items
	@FindBy(css=".itemsNum")
	private WebElement itemNum;
	
	//user created 2nd list or folder
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(2)")
	private WebElement myListElements;
	
	//second list
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(2) > label")
	private WebElement secondList;
	
	//user created third list or folder
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(3)")
	private WebElement myListThirdListLoc;
	
	//user created third list or folder
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(3)>label")
	private WebElement thirdList;
	
	//locate stocks from list panel
	@FindBy(css="div.freezeVirtualizedPanel > div:nth-of-type(1)> div:nth-of-type(5) > div:nth-of-type(1) > span")
	private WebElement selectedStock;
	
	//locate second stock
	@FindBy(css="div.freezeVirtualizedPanel > div:nth-of-type(2)> div:nth-of-type(5) > div > span")
	private WebElement secondStock;
	
	//get chart information
	@FindBy(css=".symbolInformation")
	private WebElement chartSymbol;
	
	//get all the tickers
	@FindAll(@FindBy(css="div.freezeVirtualizedPanel > div > div:nth-of-type(4)>div>span"))
	private List<WebElement> symbolList;
	
	//locate hash numbers
	@FindAll(@FindBy(css="div.freezeVirtualizedPanel > div > div:nth-of-type(3)>div>span"))
	private List<WebElement> hashNumberList;
	
	//locate flag
	@FindBy(css="div.freezeVirtualizedPanel>div[class*=cellClicked] > div:nth-of-type(2) > div > span")
	private WebElement flagElement;
	
	//locate thrash can
	@FindBy(css="div.freezeVirtualizedPanel>div[class*=cellClicked] > div:nth-of-type(1) > div > span")
	private WebElement thrashCan;
	
	//locate all columns
	@FindAll(@FindBy(css="div.listManagerFlexibleHeaderCellInner>span.listManagerFlexibleHeaderCellText"))
	private List<WebElement> columnNames;
	
	//locate all columns to check display
	@FindAll(@FindBy(css="div.listManagerFlexibleHeaderCell"))
	private List<WebElement> columnNamesAfter;
	
	//locate black arroww
	@FindBy(css=".nameToggleLeft.toolTip-help.LMImgs")
	private WebElement blackArrow;
	
	//locate blackarrow in symbol field
	@FindBy(css=".nameToggleRight.toolTip-help.LMImgs")
	private WebElement symbolBlackArrow;
	
    //locate symbol column name
	@FindBy(css="div.listManagerGridFreeze > div.listManagerGridHeaderFreeze > div:nth-of-type(4) > div > span:nth-of-type(2)")
	private WebElement symbolColumn;
	
	//locate symbol loc
	@FindBy(css="div.listManagerGridFreeze > div.listManagerGridHeaderFreeze> div:nth-of-type(4)")
	private WebElement symbolLoc;
	
	//locate Name loc
	@FindBy(css="div.listManagerGridFreeze > div.listManagerGridHeaderFreeze> div:nth-of-type(5)")
	private WebElement nameLoc;
	
	//locate 7 th column
	@FindBy(css=".listManagerFlexibleHeaderBody>div:nth-of-type(1)>div:nth-of-type(1)")
	private WebElement seventhcolumn;
	
	//locate hash column
	@FindBy(css="div.listManagerGridFreeze > div:nth-of-type(2) > div:nth-of-type(3)")
	private WebElement hashLoc;
	
	//locate clicked row
	@FindBy(css="div.freezeVirtualizedPanel>div[class*=cellClicked]")
	private WebElement selectedRow;
	
	//locate symbol names
	@FindAll(@FindBy(css="div.freezeVirtualizedPanel > div > div:nth-of-type(5)>div>span"))
	private List<WebElement> tickerNameList;
	
	//locate rightclick options
	@FindBy(css=".popUpListManagerRowRightClickContent>ul")
	private WebElement rowRightClickWindow; 
	
	//locate all elements on rightclick options
	@FindAll(@FindBy(css=".popUpListManagerRowRightClickContent>ul>li"))
	private List<WebElement> rightClickOptions;
	
	//locate delete option
	@FindBy(css=".popUpListManagerRowRightClickContent>ul>li:nth-of-type(1)")
	private WebElement deleteOption;
	
	//locate flag items
	@FindBy(css="div.freezeVirtualizedPanel > div:nth-of-type(1)>div:nth-of-type(2)>div:nth-of-type(1)>span")
	private WebElement firstFlagELement;
	
	//locate smartlists
	@FindBy(css="div#ActivityLists>div:nth-of-type(1)>span")
	private WebElement smartList;
	
	//locate flagged Symbols list
	@FindBy(css="div#ActivityLists> div:nth-of-type(2) > div:nth-of-type(2) > label")
	private WebElement flaggedSymbolsList;
	
	//wait for flagged list items
	@FindBy(xpath="//div[@class='listCategory']/div[@class='navbar']/span[contains(text(),'Flagged Symbols')]")
	private WebElement waitFlaggedList;
	
	//locate flag in chart
	@FindBy(css="div.symbolBasicInformation > div:nth-of-type(2)")
	private WebElement flagSymbol;
	
	//locate view comparison chart
	@FindBy(css=".popUpListManagerRowRightClickContent>ul>li:nth-of-type(3)")
	private WebElement viewComparisonChart;
	
	//locate symbol in comparison chart window
	@FindBy(css="div.sidebar.stockCharts > ul > li > span:nth-of-type(3)")
	private WebElement comparisonChartSymbol; 
	
	//locate set alert option
	@FindBy(css=".popUpListManagerRowRightClickContent>ul>li:nth-of-type(4)")
	private WebElement setAlertOption;
	
	//locate set price alert window
	@FindBy(css="div#PriceAlertModalPanel > div > div:nth-of-type(1)")
	private WebElement setAlertWindow;
	
	//close alert
	@FindBy(css="div#PriceAlertModalPanel >div:nth-of-type(1)>span")
	private WebElement closeAlert; 
	
	//locate Browse buttons
	@FindBy(css=".buttonBar > div:nth-of-type(2)>button")
	private WebElement browseButton;
	
	//locate browse list window
	@FindBy(css=".listManagerBrowseTop")
	private WebElement browseListWindow;
	
	//locate all share button
	@FindBy(css=".listManagerBrowseMiddleLeftSharingAllRadio")
	private WebElement sharedWithAllButton;
	
	//locate list count
	@FindBy(css=".listManagerBrowseMiddleRightAllCounts")
	private WebElement noOfLists;
	
	//locate Public share button
	@FindBy(css=".listManagerBrowseMiddleLeftSharingPublicRadio")
	private WebElement sharedWithPublic;
	
	//locate private share button
	@FindBy(css=".listManagerBrowseMiddleLeftSharingPrivateRadio")
	private WebElement sharedWithPrivate;
	
	//locate Author row
	@FindAll(@FindBy(css="div#ModalPanel > div.listManagerBrowse.ui-draggable> div:nth-of-type(3) > table > tbody > tr > td:nth-of-type(4)"))
	private List<WebElement> authorRow;
	
	//locate author entry field
	@FindBy(css=".listManagerBrowseMiddleLeftSearchBox")
	private WebElement authorEntryField;
	
	//locate shared list
	@FindBy(css="div.listManagerBrowseMiddleRight > table > tbody > tr:nth-of-type(1) > td:nth-of-type(2) > span:nth-of-type(1)")
	private WebElement sharedList;
	
	//locate community activity window
	@FindBy(css=".listManagerCommunityActivityLeftName")
	private WebElement communityActivity;
	
	//locate all tags
	@FindAll(@FindBy(css=".listManagerBrowseTags"))
	private List<WebElement> allTags;
	
	//locate all tags names
	@FindAll(@FindBy(css=".inputChk"))
	private List<WebElement> allTagsNames;
	
	//locate applied tags
	@FindAll(@FindBy(css=".listManagerCommunityActivityLeftEachTags"))
	private List<WebElement> appliedTags;
	
	//locate second shared list
	@FindBy(css="div.listManagerBrowseMiddleRight > table > tbody > tr:nth-of-type(2) > td:nth-of-type(2) > span:nth-of-type(1)")
	private WebElement secondSharedList;
	
	//locate close button
	@FindBy(css="div#ModalPanel > div.listManagerCommunityActivityView > span")
	private WebElement closeButton;
	
	//Locate clear button
	@FindBy(css=".listManagerBrowseMiddleLeftTitle.listManagerBrowseMiddleLeftTagsClean")
	private WebElement clearButton;
	
	//locate  browse list close window
	@FindBy(css="div#ModalPanel > div.listManagerBrowse.ui-draggable > span")
	private WebElement browseListWindowClose;
	
	//locate view List button
	@FindBy(css=".listManagerCommunityActivityLeftPannelViewScreen")
	private WebElement viewListButton;
	
	//title of community Activity
	@FindBy(css=".listManagerCommunityActivityTop")
	private WebElement communitWindowTop;
	
	//locate track button
	@FindBy(css="div.listManagerCommunityActivityView.ui-draggable.ui-droppable>div:nth-of-type(2)>div:nth-of-type(2)>button:nth-of-type(2)")
	private WebElement trackButton;
	
	//locate un track button
	@FindBy(css="div.listManagerCommunityActivityView.ui-draggable.ui-droppable>div:nth-of-type(2)>div:nth-of-type(2)>button:nth-of-type(3)")
	private WebElement untrackButton;
	
	//locate rating
	@FindBy(css=".listManagerCommunityActivityLeftRatingName")
	private WebElement ratingName;
	
	//locate tracked by
	@FindBy(css=".listManagerCommunityActivityLeftTrackedHead")
	private WebElement trackedByLabel;
	
	//author field
	@FindBy(css=".listManagerCommunityActivityLeftAuthorHead")
	private WebElement authorLabel;
	
	//last Updated
	@FindBy(css=".listManagerCommunityActivityLeftUpdatedHead")
	private WebElement lastUpdatedField;
	
	//no of items or results
	@FindBy(css=".listManagerCommunityActivityLeftResultsHead")
	private WebElement noOfResults;
	
	//Description label
	@FindBy(css=".listManagerCommunityActivityLeftDescriptionHead")
	private WebElement descriptionLabel;
	
	//tags section
	@FindBy(css=".listManagerCommunityActivityLeftTagsHead")
	private WebElement tagsSection;
	
	//locate show comments
	@FindBy(css=".listManagerCommunityActivityRightCommentShowContent")
	private WebElement showComments;
	
	//locate add a comment
	@FindBy(css=".listManagerCommunityActivityRightCommentAddContent")
	private WebElement addCommentSection;
	
	//locate submit button
	@FindBy(css=".listManagerCommunityActivityRightCommentAddUnableSubmit")
	private WebElement submitButton;
	
	//locate enabled submit
	@FindBy(css=".listManagerCommunityActivityRightCommentAddAbleSubmit")
	private WebElement enabledSubmit;
	
	//locate rating stars
	@FindBy(css="div#ModalPanel > div > div:nth-of-type(2) > div:nth-of-type(4) > div:nth-of-type(2) > span:nth-of-type(1)")
	private WebElement ratingStars;
	
	//locate author name
	@FindBy(css=".listManagerCommunityActivityLeftAuthorFoot>a")
	private WebElement authorLink;
	
	//locate tracked folder
	@FindBy(css="div#Tracked > div:nth-of-type(1) > label")
	private WebElement trackedFolder;
	
	//tracked downlink
	@FindBy(css="div#Tracked > div:nth-of-type(1) > span")
	private WebElement trackedDownLink;
	
	//locate tracked list
	@FindAll(@FindBy(css="div#Tracked > div:nth-of-type(2) > div >label"))
	private List<WebElement> trackedList;
	
	//locate tracked lists location
	@FindAll(@FindBy(css="div#Tracked > div:nth-of-type(2) > div"))
	private List<WebElement> trackedListsLoc;
	
	//locate track list drop down img
	@FindBy(css="div#Tracked > div:nth-of-type(2) > div > div > img")
	private WebElement trackedListDropdown;
	
	//locate tracked list drop down
	@FindBy(css=".optionsMenuList.trackedListsMenuType")
	private WebElement trackedListDropdownOptions; 
	
	//locate list untrack option
	@FindBy(css=".optionsUnTracked")
	private WebElement unTrackOption;
	
	//locate smart list text
	@FindBy(css="div#ActivityLists > div:nth-of-type(1)>label")
	private WebElement smartListLabel;
	
	//locate recent symbols
	@FindBy(css="div#ActivityLists > div:nth-of-type(2) > div:nth-of-type(1) > label")
	private WebElement recentSymbols;
		
	//locate drop down of recent symbol
	@FindBy(css="div#ActivityLists > div:nth-of-type(2) > div:nth-of-type(1) > div > img")
	private WebElement dropdownRecent;
		
	//locate options window
	@FindBy(css=".optionsMenuList.smartListsMenuType")
	private WebElement waitRecentOptions;
	
	//locate disabled view details 
	@FindBy(css="div.optionsMenuList.smartListsMenuType > div:nth-of-type(1)")
	private WebElement smartListViewDetails;
	
	//locate Screen Results list
	@FindBy(css="div#ScreenResults > div > label")
	private WebElement screenResultList;
	
	//locate screen result dropdown
	@FindBy(css="div#ScreenResults > div > div > img")
	private WebElement dropdownScreenResults;
	
	//locate screen Results option window
	@FindBy(css=".optionsMenuList.resultListsMenuType")
	private WebElement waitScreenResultOption;
	
	//locate view details of screenresults
	@FindBy(css="div.optionsMenuList.resultListsMenuType > div:nth-of-type(1)")
	private WebElement screenResultViewDetails;
	
	//locate the delete msg 
	@FindBy(css="#navbarTips>span")
	private WebElement deleteMsg;
	
	//locate dropdown
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(4) > div > img")
	private WebElement dropdown;
	
	//locate 1st dropdown
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(1) > div > img")
	private WebElement firstDropdown;
	
	//locate view details
	@FindBy(css=".myListMenuType>div:nth-of-type(1)")
	private WebElement viewDetailsOption;
	
	//wait for listwindow
	@FindBy(css=".optionsMenuList.myListMenuType")
	private WebElement waitOptions;
	
	//locate view details window
	@FindBy(css=".listManagerCommunityActivityView.ui-draggable.ui-droppable>div:nth-of-type(1)")
	private WebElement viewDetailsWindow;
	
	//user created list or folder
	@FindBy(css="div#MyLists > div:nth-of-type(2) > div:nth-of-type(4) > label")
	private WebElement lastCreatedList;
	
	//locate list View button
	@FindBy(css="div.navbar > div:nth-of-type(12) > div:nth-of-type(3)")
	private WebElement listViewButton; 
	
	//Click on symbol entry field
	@FindBy(css="body > div.MST > div.header > input")
	private WebElement symbolEntryField;
	
	//locate symbol information
	@FindBy(css=".companySymbol")
	private WebElement symbolInformation;
	
	//locate default button 
	@FindBy(css="div.navbar > div:nth-of-type(12) > div:nth-of-type(2)")
	private WebElement defaultViewButton;
	
	//locate second flexible column
	@FindBy(css="div.listManagerGridFlexible> div:nth-of-type(1)>div:nth-of-type(1)>div:nth-of-type(2)")
	private WebElement secondFlexibleColumnLoc;
	
	//locate second flexible column Name
	@FindBy(css="div.listManagerGridFlexible> div:nth-of-type(1)>div:nth-of-type(1)>div:nth-of-type(2)>div>span")
	private WebElement secondFlexibleColName;
	
	//locate third flexible column
	@FindBy(css="div.listManagerGridFlexible> div:nth-of-type(1)>div:nth-of-type(1)>div:nth-of-type(3)")
	private WebElement thirdFlexibleColumnLoc;
	
	//locate third column name 
	@FindBy(css="div.listManagerGridFlexible> div:nth-of-type(1)>div:nth-of-type(1)>div:nth-of-type(3)>div>span")
	private WebElement thirdFlexibleColName; 
	
	//locate unlock symbol
	@FindBy(css="div.listManagerGridFreeze > div:nth-of-type(2) > div:nth-of-type(4)>div > span:nth-of-type(1)")
	private WebElement unLockSymbol;
	
	//locate name unlock symbol
	@FindBy(css="div.listManagerGridFreeze > div:nth-of-type(2) > div:nth-of-type(5)>div > span:nth-of-type(1)")
	private WebElement nameLockSymbol;
	
	//locate daily button
	@FindBy(css="div.MST > div:nth-of-type(1) > span:nth-of-type(1)")
	private WebElement dailyButton;
	
	//locate LM tool triangle
	@FindBy(css="div.LMBtn.tools > div:nth-of-type(2)")
	private WebElement lmTriangle;
	
	//locate tools window
	@FindBy(css="div.navbar > div:nth-of-type(12) > div:nth-of-type(4) > ul")
	private WebElement toolsWindow;
	
	//locate column width preferences option
	@FindBy(css="div.LMBtn.tools.click > ul>li:nth-of-type(8)")
	private WebElement columnWidthPreference;
	
	//locate column width preferences window
	@FindBy(css="div.popUpCommonView.popUpColumnWidthPreferenceView.ui-draggable.ui-droppable > div:nth-of-type(1)")
	private WebElement columnWidthPrefWindow;
	
	//locate columnwidth radio buttons
	@FindAll(@FindBy(css=".adjustColumn"))
	private List<WebElement> columnWidthButtons; 
	
	//locate accept button in column width
	@FindBy(css=".columnPreferenceAccept")
	private WebElement columnPrefAccept; 
	
	//locate 1st row of list panel
	@FindBy(css="div.freezeVirtualizedPanel > div:nth-of-type(1)")
	private WebElement listPanelFirstRow;
	
	//locate update within radio buttons
	@FindAll(@FindBy(css=".browseUpdatedWithTime>input"))
	private List<WebElement> updatedWithInRadio;
	
	//locate all radio button
	@FindBy(css=".listManagerBrowseMiddleLeftUpdatedWithinLastAllRadio")
    private WebElement updatedWithinAll;
	
	//locate all rows of list
	@FindBy(css="div.freezeVirtualizedPanel > div")
	private List<WebElement> allRowsOfList;
	
	//wait for set order
	@FindBy(css=".listManagerSetOrder")
	private WebElement waitSetOrder; 
	
	//locate set order
	@FindBy(css=".listManagerSetOrder>div>div:nth-of-type(2)")
	private WebElement setOrderOption;
	
	//Markets 197 industry group
	@FindBy(css="div[id='Markets/197IndustryGroups']> div:nth-of-type(1) > label")
	private WebElement market197IndustryGroup;
	
	//197 Industry group list
	@FindBy(css="div[id='Markets/197IndustryGroups']> div:nth-of-type(2) >div:nth-of-type(2)>label")
	private WebElement m197Industrygroups;
	
	//tickerType
	@FindBy(css="div.freezeVirtualizedPanel > div:nth-of-type(1) > div:nth-of-type(6) > div > span > span[type=IndustryGroup]")
	private WebElement waitIndustryGroup;
	
	@FindBy(css="div[id='Markets/197IndustryGroups']> div:nth-of-type(1) >span")
	private WebElement market197DownLink;
	
	//197 drop down
	@FindBy(css="div[id='Markets/197IndustryGroups']> div:nth-of-type(2) > div:nth-of-type(2)>div>img")
	private WebElement msDropdown;
		
	//wait for dr0p down options of ms list
	@FindBy(css=".optionsMenuList.marketIndustryListsMenuType")
	private WebElement waitForDropdownOptions;
		
	//get drop down elements of ms list
	@FindAll(@FindBy(css=".marketIndustryListsMenuType>ul>li:not([style]),div[style*='inline-block']>.viewDetails"))
	private List<WebElement> msDropDownElements;
	
	//locate  input symbol of list panel
	@FindBy(css=".inputSymbol")
	private WebElement lpInputSymbolBox;
	
	//locate error for invalid symbol
	@FindBy(css=".inputSymbolInfo")
	private WebElement invalidSymbolError;
	
	//All Comments Date
	@FindAll(@FindBy(css=".listManagerCommunityActivityRightCommentShowDate"))
	private List<WebElement> allCommentsDate;
	
	//list all elements on mouse over
	@FindAll(@FindBy(css=".myListMenuType>ul>li:not([style]),div[style*='inline-block']>.viewDetails"))
	private List<WebElement> dropdownElements;
	
	@FindAll(@FindBy(css=".optionsMenuList.smartListsMenuType>ul>li:not([style]),div[style*='inline-block']>.viewDetails"))
	private List<WebElement> flaggedSymbolsDropDownOptions;
	/*************************************GETTERS******************************
	 **************************************************************************/
	
	public WebElement getMyListsLink(){
		return myListsLink;
	}
	public WebElement getMyListName(){
		return myListName;
	}
	public WebElement getUserCreatedList(){
		return createdList;
	}
	public WebElement getCurrentListName(){
		return currentListName;
	}
	public WebElement getMyListElements(){
		return MyListelements;
	}
	public WebElement getitemNum(){
		return itemNum;
	}
    public WebElement  getmyListElements(){
    	return myListElements;
    }
    public WebElement getSecondList(){
    	return secondList;
    }
    public WebElement getselectedStock(){
    	return  selectedStock;
    }
    public WebElement getChartSymbol(){
    	return chartSymbol;
    }
    public List<WebElement> getsymbolList(){
    	return symbolList;
    }
    public WebElement getFlagElement(){
    	return flagElement;
    }
    public WebElement getThrashCan(){
    	return thrashCan;
    }
    public List<WebElement> getColumnNames(){
    	return columnNames;
    }
    public WebElement getBlackArrow(){
    	return blackArrow;
    }
    public List<WebElement> getColumnNamesAfter(){
    	return columnNamesAfter;
    }
    public WebElement getSymbolBlackArrow(){
    	return symbolBlackArrow;
    }
    public WebElement getsymbolColumn(){
    	return symbolColumn;
    }
    public WebElement getSelectedRow(){
    	return selectedRow;
    }
    public List<WebElement> getTickerNameList(){
    	return tickerNameList;
    }
    public WebElement getRowRightClickWindow(){
    	return rowRightClickWindow;
    }
    public List<WebElement> getRightClickOptions(){
    	return rightClickOptions;
    }
    public WebElement getdeleteOption(){
    	return deleteOption;
    }
    public WebElement getSecondStock(){
    	return secondStock;
    }
    public WebElement getFirstFlagELement(){
    	return firstFlagELement;
    }
    public WebElement getSmartList(){
    	return smartList;
    }
    public WebElement getFlaggedSymbolsList(){
    	return flaggedSymbolsList;
    }
    public WebElement getWaitFlaggedList(){
    	return waitFlaggedList;
    }
    public WebElement getFlagSymbol(){
    	return flagSymbol;
    }
    public WebElement getViewComparisonChart(){
    	return viewComparisonChart;
    }
    public WebElement getcomparisonChartSymbol(){
    	return comparisonChartSymbol;
    }
    public WebElement getsetAlertOption(){
    	return setAlertOption;
    }
    public WebElement getsetAlertWindow(){
    	return setAlertWindow;
    }
    public WebElement getCloseAlert(){
    	return closeAlert;
    }
    public WebElement getBrowseButton(){
    	return browseButton;
    }
    public WebElement getBrowseListWindow(){
    	return browseListWindow;
    }
    public WebElement getSharedWithAllButton(){
    	return sharedWithAllButton;
    }
    public WebElement getNoOfLists(){
    	return noOfLists;
    }
    public WebElement getSharedWithPublic(){
    	return sharedWithPublic;
    }
    public WebElement getsharedWithPrivate(){
    	return sharedWithPrivate;
    }
    public List<WebElement> getAuthorRow(){
    	return authorRow;
    }
    public WebElement getauthorEntryField(){
    	return authorEntryField;
    }
    public WebElement getSharedList(){
    	return sharedList;
    }
    public WebElement getCommunityActivity(){
    	return communityActivity;
    }
    public List<WebElement> getAllTags(){
    	return allTags;
    }
    public List<WebElement> getAppliedTags(){
    	return appliedTags;
    }
    public WebElement getsecondSharedList(){
    	return secondSharedList;
    }
    public WebElement getCloseButton(){
    	return closeButton;
    }
    public WebElement getclearButton(){
    	return clearButton;
    }
    public WebElement getbrowseListWindowClose(){
    	return browseListWindowClose;
    }
    public WebElement getViewListButton(){
    	return viewListButton;
    }
    public WebElement getcommunitWindowTop(){
    	return communitWindowTop;
    }
    public WebElement getTrackButton(){
    	return trackButton;
    }
    public WebElement getUnTrackButton(){
    	return untrackButton;
    }
    public WebElement getRatingName(){
    	return ratingName;
    }
    public WebElement getTrackedByLabel(){
    	return trackedByLabel;
    }
    public WebElement getAuthorLabel(){
    	return authorLabel;
    }
    public WebElement getLastUpdatedField(){
    	return lastUpdatedField;
    }
    public WebElement getnoOfResults(){
    	return noOfResults;
    }
    public WebElement getDescriptionLAbel(){
    	return descriptionLabel;
    }
    public WebElement getTagsSection(){
    	return tagsSection;
    }
    public WebElement getShowComments(){
    	return showComments;
    }
    public WebElement getAddCommentSection(){
    	return addCommentSection;
    }
    public WebElement getsubmitButton(){
    	return submitButton;
    }
    public WebElement getRatingStars(){
    	return ratingStars;
    }
    public WebElement getAuthorLink(){
    	return authorLink;
    }
    public WebElement getTrackedFolder(){
    	return trackedFolder;
    }
    public WebElement getTrackedDownLink(){
    	return trackedDownLink;
    }
    public List<WebElement> getTrackedList(){
    	return  trackedList;
    }
    public WebElement getTrackedListDropdown(){
    	return trackedListDropdown;
    }
    public WebElement getTrackedListDropdownOptions(){
    	return trackedListDropdownOptions;
    }
    public WebElement getUnTrackOption(){
    	return unTrackOption;
    }
    public WebElement getSmartListLabel(){
    	return smartListLabel;
    }
    public WebElement getRecentSymbols(){
    	return recentSymbols;
    }
    public WebElement getDropdownRecent(){
    	return dropdownRecent;
    }
    public WebElement getWaitRecentOptions(){
    	return waitRecentOptions;
    }
    public WebElement getsmartListViewDetails(){
    	return smartListViewDetails;
    }
    public WebElement getScreenResultList(){
		return screenResultList;
	}
    public WebElement getdropdownScreenResults(){
    	return dropdownScreenResults;
    }
    public WebElement getWaitScreenResultOption(){
    	return waitScreenResultOption;
    }
    public WebElement getScreenResultViewDetails(){
    	return screenResultViewDetails;
    }
    public WebElement getDeleteMsg(){
    	return deleteMsg;
    }
    public WebElement getDropdown(){
		return dropdown;
	}
    public WebElement getViewDetailsOption(){
    	return viewDetailsOption;
    }
    public WebElement getWaitOptions(){
		return waitOptions;
	}
    public WebElement getViewDetailsWindow(){
    	return viewDetailsWindow;
    }
    public WebElement getLastCreatedList(){
    	return lastCreatedList;
    }
    public WebElement getFirstDropdown(){
    	return firstDropdown;
    }
    public WebElement getlistViewButton(){
		return listViewButton;
	}
    public WebElement getSymbolEntryField(){
		return symbolEntryField;
	}
    public WebElement getsymbolInformation(){
    	return symbolInformation;
    }
    public WebElement getmyListThirdListLoc(){
    	return myListThirdListLoc;
    }
    public WebElement getthirdList(){
    	return thirdList;
    }
    public WebElement getsymbolLoc(){
    	return symbolLoc;
    }
    public WebElement getnameLoc(){
    	return nameLoc;
    }
    public WebElement getDefaultViewButton(){
		return defaultViewButton;
	}
    public WebElement getsecondFlexibleColumnLoc(){
    	return secondFlexibleColumnLoc;
    }
    public WebElement getsecondFlexibleColName(){
    	return secondFlexibleColName;
    }
    public WebElement getthirdFlexibleColumnLoc(){
    	return thirdFlexibleColumnLoc;
    }
    public WebElement getthirdFlexibleColName(){
    	return thirdFlexibleColName;
    }
    public WebElement getunLockSymbol(){
    	return unLockSymbol;
    }
    public WebElement getdailyButton(){
    	return dailyButton;
    }
    public WebElement getlmTriangle(){
    	return lmTriangle;
    }
    public WebElement gettoolsWindow(){
    	return toolsWindow;
    }
    public WebElement getcolumnWidthPreference(){
    	return columnWidthPreference;
    }
    public WebElement getcolumnWidthPrefWindow(){
    	return columnWidthPrefWindow;
    }
    public List<WebElement> getcolumnWidthButtons(){
    	return columnWidthButtons;
    }
    public WebElement getcolumnPrefAccept(){
    	return columnPrefAccept;
    }
    public WebElement getlistPanelFirstRow(){
    	return listPanelFirstRow;
    }
    public List<WebElement> getupdatedWithInRadio(){
    	return updatedWithInRadio;
    }
    public WebElement getupdatedWithinAll(){
    	return updatedWithinAll;
    }
    public List<WebElement> gettrackedListsLoc(){
    	return trackedListsLoc;
    }
    public List<WebElement> getallTagsNames(){
    	return allTagsNames;
    }
    public WebElement getenabledSubmit(){
    	return enabledSubmit;
    }
    public List<WebElement> getallRowsOfList(){
    	return allRowsOfList;
    }
    public WebElement getnameLockSymbol(){
    	return nameLockSymbol;
    }
    public WebElement getseventhcolumn(){
    	return seventhcolumn;
    }
    public WebElement gethashLoc(){
    	return hashLoc;
    }
    public WebElement getwaitSetOrder(){
    	return waitSetOrder;
    }
    public WebElement getsetOrderOption(){
    	return setOrderOption;
    }
    public List<WebElement> gethashNumberList(){
    	return hashNumberList;
    }
    public WebElement getmarket197IndustryGroup(){
		return market197IndustryGroup;
	}
    public WebElement getWaitIndustryGroup(){
		return waitIndustryGroup;
	}
	public WebElement get197IndustryGroups(){
		return  m197Industrygroups;
	}
	public WebElement getMarket197DownLink(){
		return market197DownLink;
	}
	public WebElement getMsDropdown(){
		return msDropdown;
	}
	public WebElement getWaitDropdownOptions(){
		return waitForDropdownOptions;
	}
    public List<WebElement> getMsDropDownElements(){
    	return msDropDownElements;
    }
    public WebElement getlpInputSymbolBox(){
    	return lpInputSymbolBox;
    }
    public WebElement getinvalidSymbolError(){
    	return invalidSymbolError;
    }
    public List<WebElement> getallCommentsDate(){
    	return allCommentsDate;
    }
    
    public List<WebElement> getDropdownElements(){
		return dropdownElements;
	}
    
    public List<WebElement> getflaggedSymbolsDropDownOptions(){
    	return flaggedSymbolsDropDownOptions;
    }
  }
