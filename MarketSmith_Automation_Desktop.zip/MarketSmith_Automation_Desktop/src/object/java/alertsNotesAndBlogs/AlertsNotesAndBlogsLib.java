package alertsNotesAndBlogs;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class AlertsNotesAndBlogsLib {
    //locate screener tab
	@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.label.communityImg.label_arrowHV > div > div")
	private WebElement leftPanelScreenerButton;
	
	//locate all tabs of screensAlertsNotes
	@FindAll(@FindBy(css=".sidebar.screenerAlertsAndNotes>div:nth-of-type(1)>div:nth-of-type(1)>div:not([style])"))
	private List<WebElement> screenALertNoteTabs; 
	
	//locate alert section
	@FindAll(@FindBy(css="div.AlertsContent.comContent.contentShow > div:nth-of-type(3)>div"))
	private List<WebElement> alertSection;
	
	//locate dropdown text (All)
	@FindBy(css=".alertSel>div:nth-of-type(1)")
	private WebElement alertDropdownText;
	
	//locate all alerts
	@FindAll(@FindBy(css="div.AlertsContent.comContent.contentShow > div:nth-of-type(3)>div"))
	private List<WebElement> allAlerts;
	
	//locate set alert link
	@FindBy(css=".setAlert.communitySetAlert")
	private WebElement setAlertLink;
	
	//set alert window
	@FindBy(css="div#PriceAlertModalPanel > div")
	private WebElement setPriceAlertWindow;
	
	//locate input symbol
	@FindBy(css=".commonCompanyInfo>div:nth-of-type(1)>div:nth-of-type(1)>div")
	private WebElement symbolsInputField;
	
	//locate alert symbol
	@FindBy(css="div.popUpPriceAlertsView.ui-draggable:nth-of-type(1)>div:nth-of-type(2)>div:nth-of-type(1)>span:nth-of-type(2)")
	private WebElement alertSymbolText;
	
	//locate price text field
	@FindBy(css="div.popUpPriceAlertsView.ui-draggable:nth-of-type(1)>div:nth-of-type(2)>div:nth-of-type(2)>input")
	private WebElement priceEntryField;
	
	//locate emailNotificationcontrol buttons
	@FindAll(@FindBy(css="div.popUpPriceAlertsView.ui-draggable:nth-of-type(1) >div:nth-of-type(2)>div:nth-of-type(5)>input"))
	private List<WebElement> emailNotificationControl;
	
	//locate note link 
	@FindBy(css="div.popUpPriceAlertsView.ui-draggable:nth-of-type(1) >div:nth-of-type(2)>div:nth-of-type(6)>span")
	private WebElement noteLink;
	
	//locate note textArea
	@FindBy(css="div.popUpPriceAlertsView.ui-draggable:nth-of-type(1) >div:nth-of-type(2)>div:nth-of-type(7)>div>textarea")
	private WebElement noteTextArea;
	
	//locate done button
	@FindBy(css="#setPriceDoneButton")
	private WebElement setpriceDoneButton;
	
	//locate manage alert link
	@FindBy(css=".setAlert.communityManageAlert")
	private WebElement manageAlertLink;
	
	//locate manage alert window
	@FindBy(css="div.popUpCommonView.popUpManagerAlertsView")
	private WebElement manageAlertWindow;
	
	//locate manage alert tabs
	@FindAll(@FindBy(css=".alertsTab"))
	private List<WebElement> manageAlertWindowTabs;
	
	//locate notes section
	@FindBy(css=".JournalsContent.comContent.contentShow")
	private WebElement notesSection;
	
	//locate all the notes
	@FindAll(@FindBy(css=".journalsNote"))
	private List<WebElement> allNotes; 
	
	//locate text area for firstnote
	@FindBy(css=".JournalsContent.comContent.contentShow>div>div>textarea")
	private WebElement firstNoteTextArea;
	
	//locate new note link
	@FindBy(css=".JournalsContent.comContent.contentShow>div:nth-of-type(3)>div:nth-of-type(1)")
	private WebElement newNoteLink;
	
	//locate manage alert close button
	@FindBy(css=".popUpCommonView.popUpManagerAlertsView>span")
	private WebElement manageAlertCloseButton;
	
	//locate all blogs dates
	@FindAll(@FindBy(css=".blogContentTextDate"))
	private List<WebElement> allBlogsDate;
	
	//locate blogs contents
	@FindBy(css=".BlogsContent.comContent.contentShow")
	private WebElement blogsSection;
	
	//locate create post tab
	@FindBy(css=".BlogsContent.comContent.contentShow>div:nth-of-type(2)")
	private WebElement createPostTab;
	
	//locate blogpost check boxes
	@FindAll(@FindBy(css=".prepareChart>div>input[type='checkbox']"))
	private List<WebElement> createBlogCheckbox; 
	
	//locate create message button
	@FindBy(css=".createMsgBtn")
	private WebElement createMessageButton;
	
	//locate note save button
	@FindBy(css=".saveJour")
	private WebElement noteSaveButton;
	
	//Click on symbol entry field
	@FindBy(css="body > div.MST > div.header > input")
	private WebElement symbolEntryField;
	
	//all alerts price
	@FindAll(@FindBy(css="div.AlertsContent.comContent.contentShow > div:nth-of-type(3)>div.communityAlertsContentList>table>tbody>tr:nth-of-type(1)>td:nth-of-type(2)"))
	private List<WebElement> allAlertPrice;
	
	//alerts dropdown elements
	@FindAll(@FindBy(css=".alertSel>div:nth-of-type(3)>ul>li"))
	private List<WebElement> alertDropdownElements;
	
	//alert dropdown selection
	@FindBy(css=".alertSel")
	private WebElement alertDropdownSelection;
	
	//alert selection Triangle
	@FindBy(css=".alertSel>div:nth-of-type(2)")
	private WebElement alertSelTringle;
	
	//first alert all details
	@FindAll(@FindBy(css="div.AlertsContent.comContent.contentShow > div:nth-of-type(3)>div:nth-of-type(1)>table>tbody>tr>td:nth-of-type(2)"))
	private List<WebElement> firstAlertDetails;
	
	//all alerts
	@FindAll(@FindBy(css="div.AlertsContent.comContent.contentShow > div:nth-of-type(3)>div>div.priceBelow"))
	private List<WebElement> allAlertsDetails;
	
	//locate smartlists
	@FindBy(css="div#ActivityLists> div:nth-of-type(1)>span")
	private WebElement ActivityList;
		
	//locate recent symbols
	@FindBy(css="div#ActivityLists > div:nth-of-type(2) > div:nth-of-type(3) > label")
	private WebElement alertsActive;
	
	//set price warning message
	@FindBy(css=".setPriceWarn")
	private WebElement priceErrorMsg; 
	
	//symbol filter text
	@FindBy(css=".symbolFilterText")
	private WebElement symbolFilterTextField;
	
	//close alert
	@FindBy(css="div#PriceAlertModalPanel >div:nth-of-type(1)>span")
	private WebElement closeAlert; 
	
	//alert price in manage alertwindow
	@FindAll(@FindBy(css="div.popUpCommonView.popUpManagerAlertsView > div:nth-of-type(7) > div:nth-of-type(2)>table>tbody>tr>td:nth-of-type(3)"))
	private List<WebElement> alertPriceManageAlert;
	
	//all checkboxes
	@FindAll(@FindBy(css="div.popUpCommonView.popUpManagerAlertsView > div:nth-of-type(7) > div:nth-of-type(2)>table>tbody>tr>td:nth-of-type(1)>input"))
	private List<WebElement> chekboxesManageAlert;
	
	//all check boxes in triggred alert manage alert window
	@FindAll(@FindBy(css="div.popUpCommonView.popUpManagerAlertsView > div:nth-of-type(9) > div:nth-of-type(2)>table>tbody>tr>td:nth-of-type(1)>input"))
	private List<WebElement> triggredAlertCheckboxes;
	//alert audio radio buttons
	@FindAll(@FindBy(css=".alertAudioRadio"))
	private List<WebElement> alertAudioRadioButtons;
	
	//alert window radio buttons
	@FindAll(@FindBy(css=".alertWindowRadio"))
	private List<WebElement> alertWindowRadioButtons;
	
	//alert email notification
	@FindAll(@FindBy(css="div.popUpCommonView.popUpManagerAlertsView > div:nth-of-type(7) > div:nth-of-type(2)>table>tbody>tr>td:nth-of-type(5)>button"))
	private List<WebElement> allEmailButtons;
	
	//alert delete button
	@FindBy(css="#activeAlertsDeleteButton")
	private WebElement alertsDeleteButton;
	
	//alert edit delete links
	@FindAll(@FindBy(css="div.alertCnt>div:nth-of-type(1)>div.priceBelowEditDelete>a"))
	private List<WebElement> alertEditDeleteLinks;
	
	//all triggered alerts in All option
	@FindAll(@FindBy(css="div.AlertsContent.comContent.contentShow > div:nth-of-type(3)>div>div.priceBelow>samp"))
	private List<WebElement> allTriggeredAlertsInAllOption;
	
	//note entering text area
	@FindBy(css=".journalsTxt")
	private WebElement noteEntryTextArea;
	
	//older and newer buttons
	@FindAll(@FindBy(css=".newJournalsContentBottom.comJournals>div:nth-of-type(2)>div"))
	private List<WebElement> olderNewerButtons;
	
	//locate Search button
	@FindBy(css=".newJournalsContentBottom.comJournals>a")
	private WebElement searchNotesLink;
	
	//search key entry field
	@FindBy(css=".keyword")
	private WebElement searchKeyEntryTextField;
	
	//show results in List manager
	@FindBy(css=".newSearchJournalsShowResult")
	private WebElement showResultsinLM;
	
	//list item name
	@FindBy(css=".listItemName")
	private WebElement listItemName;
	
	//search button
	@FindBy(css=".newSearchJournalsContentClick")
	private WebElement searchButton;
	
	//all search results
	@FindAll(@FindBy(css=".newSearchJournalsResultsContents"))
	private List<WebElement> allSearchResults; 
	
	//get all the tickers
	@FindAll(@FindBy(css="div.freezeVirtualizedPanel > div > div:nth-of-type(4)>div>span"))
	private List<WebElement> symbolList;
	
	//get the edit button
	@FindBy(css=".newJournalsTxt>div:nth-of-type(1)>div:nth-of-type(3)")
	private WebElement noteEditButon;
	
	//get delete button
	@FindBy(css=".newJournalsTxt>div:nth-of-type(1)>div:nth-of-type(4)")
	private WebElement noteDeleteButon;
	
	//my post check box
	@FindBy(css=".myPostsChkBox")
	private WebElement myPostCheckBox;
	
	//autor name
	@FindAll(@FindBy(css=".blogContentTextAuthor"))
	private List<WebElement> blogAuthors;
	
	//blogs name
	@FindAll(@FindBy(css=".blogContentTitle"))
	private List<WebElement> blogsNames;
	
	//comments
	@FindAll(@FindBy(css=".blogContentTextComments"))
	private  List<WebElement> allComments;
	
	//star ratings
	@FindAll(@FindBy(css=".blogContentTextRaStar"))
	private List<WebElement> allStarRatings;
	
	//all bogs
	@FindAll(@FindBy(css=".blogCenterContent"))
	private List<WebElement> allBlogs;
	
	//blog title in New page
	@FindBy(css=".blogPostTile")
	private WebElement blogTitleInNewPage;
	
	//auhtor name in new page
	@FindBy(css=".pageTitle")
	private WebElement authorNameInNewPage;
	
	//wait for journal search
	@FindBy(xpath="//div[@class='listCategory']/div[@class='navbar']/span[contains(text(),'Journal Search')]")
	private WebElement waitJournalSearch;
	/*******************************************************Getters*****************************************************
	******************************************************************************************************************************/
	public WebElement getLeftPanelScreenerButton(){
		return leftPanelScreenerButton;
	}
	public List<WebElement> getscreenALertNoteTabs(){
		return screenALertNoteTabs;
	}
	public WebElement getalertDropdownText(){
		return alertDropdownText;
	}
	public List<WebElement> getallAlerts(){
		return allAlerts;
	}
	public List<WebElement> getalertSection(){
		return alertSection;
	}
	public WebElement getsetAlertLink(){
		return setAlertLink;
	}
	public WebElement getsetPriceAlertWindow(){
		return setPriceAlertWindow;
	}
	public WebElement getsymbolsInputField(){
		return symbolsInputField;
	}
	public WebElement getalertSymbolText(){
		return alertSymbolText;
	}
	public WebElement getpriceEntryField(){
		return priceEntryField;
	}
	public List<WebElement> getemailNotificationControl(){
		return emailNotificationControl;
	}
	public WebElement getnoteLink(){
		return noteLink;
	}
	public WebElement getnoteTextArea(){
		return noteTextArea;
	}
	public WebElement getsetpriceDoneButton(){
		return setpriceDoneButton;
	}
	public WebElement getmanageAlertLink(){
		return manageAlertLink;
	}
	public WebElement getmanageAlertWindow(){
		return manageAlertWindow;
	}
	public List<WebElement> getmanageAlertWindowTabs(){
		return manageAlertWindowTabs;
	}
	public List<WebElement> getallNotes(){
		return allNotes;
	}
	public WebElement getnotesSection(){
		return notesSection;
	}
	public WebElement getfirstNoteTextArea(){
		return firstNoteTextArea;
	}
	public WebElement getnewNoteLink(){
		return newNoteLink;
	}
	public WebElement getmanageAlertCloseButton(){
		return manageAlertCloseButton;
	}
	public List<WebElement> getallBlogsDate(){
		return allBlogsDate;
	}
	public WebElement getblogsSection(){
		return blogsSection;
	}
	public WebElement getcreatePostTab(){
		return createPostTab;
	}
	public List<WebElement> getcreateBlogCheckbox(){
		return createBlogCheckbox;
	}
	public WebElement getcreateMessageButton(){
		return createMessageButton;
	}
	public WebElement getnoteSaveButton(){
		return noteSaveButton;
	}
	public WebElement getSymbolEntryField(){
		return symbolEntryField;
	}
	public List<WebElement>  getAllAlertPrice(){
		return allAlertPrice;
	}
	public List<WebElement> getAlertDropdownElements(){
		return alertDropdownElements;
	}
	public WebElement getalertDropdownSelection(){
		return alertDropdownSelection;
	}
	public List<WebElement> getfirstAlertDetails(){
		return firstAlertDetails;
	}
	public List< WebElement> getallAlertsDetails(){
		 return allAlertsDetails;
	}
	public WebElement getActivityList(){
	   	return ActivityList;
	}
	public WebElement getalertsActive(){
	  	return alertsActive;
	}
	public WebElement getpriceErrorMsg(){
		return priceErrorMsg;
	}
	public WebElement getsymbolFilterTextField(){
		return symbolFilterTextField;
	}
	public WebElement getCloseAlert(){
    	return closeAlert;
    }
	public List<WebElement> getalertPriceManageAlert(){
		return alertPriceManageAlert;
	}
	public List<WebElement> getchekboxesManageAlert(){
		return chekboxesManageAlert;
	}
	public List<WebElement> getalertAudioRadioButtons(){
		return alertAudioRadioButtons;
	}
	public List<WebElement> getalertWindowRadioButtons(){
		return alertWindowRadioButtons;
	}
	public List<WebElement> getallEmailButtons(){
		return allEmailButtons;
	}
	public WebElement getAlertsDeleteButton(){
		return alertsDeleteButton;
	}
	public List<WebElement> getalertEditDeleteLinks(){
		return alertEditDeleteLinks;
	}
	public List<WebElement> getallTriggeredAlertsInAllOption(){
		return allTriggeredAlertsInAllOption;
	}
	public WebElement getnoteEntryTextArea(){
		return noteEntryTextArea;
	}
	public List<WebElement> getolderNewerButtons(){
		return olderNewerButtons;
	}
	public WebElement getsearchNotesLink(){
		return searchNotesLink;
	}
	public WebElement getsearchKeyEntryTextField(){
		return searchKeyEntryTextField;
	}
	public WebElement getshowResultsinLM(){
	   return showResultsinLM;
	}
	public WebElement getlistItemName(){
		return listItemName;
	}
	public WebElement getsearchButton(){
		return searchButton;
	}
	public List<WebElement> getallSearchResults(){
		return allSearchResults;
	}
	
	public List<WebElement> getsymbolList(){
	    	return symbolList;
	}
	public WebElement getnoteEditButon(){
		return noteEditButon;
	}
	public WebElement getnotedeleteButon(){
		return noteDeleteButon;
	}
	public WebElement getmyPostCheckBox(){
		return myPostCheckBox;
	}
	public List<WebElement> getblogAuhtors(){
		return blogAuthors;
	}
	public List<WebElement> getblogsNames(){
		return blogsNames;
	}
	public List<WebElement> getallComments(){
		return allComments;
	}
	public List<WebElement> getallStarRatings(){
		return allStarRatings;
	}
	public List<WebElement> getallBlogs(){
		return allBlogs;
	}
	public WebElement getblogTitleInNewPage(){
		return blogTitleInNewPage;
	}
	public WebElement getauthorNameInNewPage(){
		return authorNameInNewPage;
	}
	public WebElement getalertSelTringle(){
		return alertSelTringle;
	}
	public WebElement getwaitJournalSearch(){
		return waitJournalSearch;
	}
	public List<WebElement> gettriggredAlertCheckboxes(){
		return triggredAlertCheckboxes;
	}
}
