package charts;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TopButtons2PageLib {

	//Tool Options (Setting icon)
	@FindBy(css=".settingMenumenubtn")
	private WebElement settingIcon;

	//Setting links
	@FindBy(css=".settingItem>span, .settingItem>a")
	private List<WebElement> settingLinks;

	//Tool Options pop up
	@FindBy(css=".menuShowSettinglist")
	private WebElement toolOptionPopup;

	//Show hover help checkbox
	@FindBy(css=".tooltipSetting")
	private WebElement hoverCheckbox;

	//MarketSmith Tutorial popup
	@FindBy(css=".popUpShowTutorialsView")
	private WebElement msTutorialPopup;

	//Contact my coach button
	@FindBy(css=".contactButton")
	private WebElement contactCoachBtn;

	//Contact MarketSmith popup
	@FindBy(css=".popUpShowContactView")
	private WebElement contactMSPopup;

	//Email textbox on Contact MarketSmith popup
	@FindBy(css=".addEmailTextBox")
	private WebElement emailMSPopup;

	//Subject textbox on Contact MarketSmith popup
	@FindBy(css=".addSubjectTextBox")
	private WebElement subjectMSPopup;

	//Message textarea on Contact MarketSmith popup
	@FindBy(id="messageTextarea")
	private WebElement messageMSPopup;

	//Submit Support Request button on Contact MarketSmith popup
	@FindBy(css=".SubmitContentButton")
	private WebElement submitRequestBtn;

	//Contact MarketSmith popup close button
	@FindBy(css=".popUpShowContactView>.btn-close")
	private WebElement contactMSPopupClose;

	//Self Guided Tour Tab on MarketSmith Tutorial popup
	@FindBy(css=".selfGuidedTourTab")
	private WebElement selfGuidedTab;

	//Text Bubbles on Self Guided Tour Tab of MarketSmith Tutorial popup
	@FindBy(css=".majorAreaItem,.relatedInformationItem")
	private List<WebElement> selfGuidedBubbles;

	//Links on Self Guided Tour Tab of MarketSmith Tutorial popup
	@FindBy(css=".selfGuidedTourPanelThreeContent")
	private List<WebElement> selfGuidedLinks;

	//Chart View help window
	@FindBy(css=".StockChartHelp")
	private WebElement chartHelpWindow;

	//Chart View help window close
	@FindBy(css=".StockChartHelp>.btn-close")
	private WebElement chartHelpWindowClose;

	//Screener help window
	@FindBy(css=".ScreenerHelp")
	private WebElement screenerHelpWindow;

	//Screener help window close
	@FindBy(css=".ScreenerHelp>.btn-close")
	private WebElement screenerHelpWindowClose;

	//List Panel help window
	@FindBy(css=".ListManagerHelp")
	private WebElement listPanelHelpWindow;

	//List Panel help window close
	@FindBy(css=".ListManagerHelp>.btn-close")
	private WebElement listPanelHelpWindowClose;

	//MarketSmith Tutorial off button
	@FindBy(css=".offButton")
	private WebElement msTutorialOff;

	//MarketSmith Tutorial off pop up
	@FindBy(css=".tutorialBubbleClosedMenuCollapsed")
	private WebElement msTutorialOffPopup;

	//MarketSmith Tutorial off pop up close
	@FindBy(css=".tutorialBubbleClosedMenuCollapsed>.tutorialBubbleClosedMenuOffButton")
	private WebElement msTutorialOffPopupClose;

	//MarketSmith Tutorial off pop up text
	@FindBy(css=".tutorialBubbleClosedMenuCollapsed>div>.tutorialBubbleClosedMenuContent")
	private WebElement msTutorialOffPopupText;

	//Notification Management window
	@FindBy(css=".popUpSharedAlertsView")
	private WebElement notfMgmtWindow;

	//Notification Management window close
	@FindBy(css=".popUpSharedAlertsView>.btn-close")
	private WebElement notfMgmtWindowClose;

	//Notify me radio button
	@FindBy(css=".sharedAlertNotifyStatusFirst>div>.sharedAlertNotifyRadio")
	private WebElement notifyRadioBtn;

	//Notify me check box
	@FindBy(css=".sharedAlertNotifyCheckboxFirst")
	private WebElement notifyCheckbox;

	//Do not Notify me radio button
	@FindBy(css=".sharedAlertNotifyStatusSecond>div>.sharedAlertNotifyRadio")
	private WebElement noNotifyRadioBtn;

	//Do not notify me check box
	@FindBy(css=".sharedAlertNotifyCheckboxSecond")
	private WebElement noNotifyCheckbox;

	//As They Occur radio button
	@FindBy(css=".occurNow>input")
	private WebElement asTheyOccurRB;

	//Only Once Per day radio button
	@FindBy(css=".alertPerDayRadio")
	private WebElement onceADayRB;

	//Only Once Per day dropdown
	@FindBy(css=".alertPerDay>select")
	private WebElement onceADaySelect;

	//AM radio button
	@FindBy(css=".alertPerDayTimeAm")
	private WebElement amRadioBtn;

	//PM radio button
	@FindBy(css=".alertPerDayTimePm")
	private WebElement pmRadioBtn;

	//Apply button
	@FindBy(css=".SharedAlertOccursApply")
	private WebElement applyButton;	

	//View all Screens shared with me link
	@FindBy(css=".ViewSharedScreenLinks")
	private WebElement allSharedScreenLink;

	//Browse Screens window
	@FindBy(css=".screenBrowseView")
	private WebElement browseScreenWindow;

	//Browse Screens window close button
	@FindBy(css=".screenBrowseView>.btn-close")
	private WebElement browseScreenClose;

	//All Type radio button
	@FindBy(css=".screenBrowseMiddleLeftTitleTypeAllRadio")
	private WebElement allTypeRadio;

	//All Sharing radio button
	@FindBy(css=".screenBrowseMiddleLeftSharingAllRadio")
	private WebElement allSharingRadio;

	//All Updated within last radio button
	@FindBy(css=".screenBrowseMiddleLeftUpdatedWithinLastAllRadio")
	private WebElement allUpdatedRadio;

	//Shared screens list
	@FindBy(css=".screenBrowseMiddleRightTableContentTr")
	private List<WebElement> sharedScreensList;

	//Shared screen count
	@FindBy(css=".screenBrowseMiddleLeftTitleTypeAll>.radioInput")
	private WebElement sharedScreenCount;

	//Shared screens
	@FindBy(css=".ListSpan")
	private WebElement sharedScreens;

	//Community Activity window
	@FindBy(css=".communityActivityView")
	private WebElement communityActivityWindow;	

	//Community Activity window Close button
	@FindBy(css=".communityActivityView>.btn-close")
	private WebElement communityActivityClose;					

	//Track Screen button
	@FindBy(css=".communityActivityLeftPannelTrackScreen")
	private WebElement trackScreenBtn;	

	//Tracked Screens list on Screener
	@FindBy(css="#TrackedScreens>div>div>label")
	private List<WebElement> trackedScreenList;	

	//View all Lists shared with me link
	@FindBy(css=".ViewSharedListLinks")
	private WebElement allSharedListsLink;

	//Browse Lists window
	@FindBy(css=".listManagerBrowse")
	private WebElement browseListWindow;

	//Browse Lists window close button
	@FindBy(css=".listManagerBrowse>.btn-close")
	private WebElement browseListClose;

	//Delayed Data radio button
	@FindBy(css=".delayedData")
	private WebElement delayedData;

	//BATS Data radio button
	@FindBy(css=".BATSData")
	private WebElement batsData;

	//Real time indicator button
	@FindBy(css=".realTimeButton")
	private WebElement realTimeIndicator;

	//MarketSmith logo
	@FindBy(css=".msLogo>img")
	private WebElement msLogo;
	
	/******************************************************************************************************
	 ********************************************* GETTERS ************************************************
	 ******************************************************************************************************/

	public WebElement getSettingIcon() {
		return settingIcon;
	}

	public List<WebElement> getSettingLinks() {
		return settingLinks;
	}

	public WebElement getToolOptionPopup() {
		return toolOptionPopup;
	}

	public WebElement getHoverCheckbox() {
		return hoverCheckbox;
	}

	public WebElement getMsTutorialPopup() {
		return msTutorialPopup;
	}

	public WebElement getContactCoachBtn() {
		return contactCoachBtn;
	}

	public WebElement getContactMSPopup() {
		return contactMSPopup;
	}

	public WebElement getEmailMSPopup() {
		return emailMSPopup;
	}

	public WebElement getSubjectMSPopup() {
		return subjectMSPopup;
	}

	public WebElement getMessageMSPopup() {
		return messageMSPopup;
	}

	public WebElement getSubmitRequestBtn() {
		return submitRequestBtn;
	}

	public WebElement getContactMSPopupClose() {
		return contactMSPopupClose;
	}

	public WebElement getSelfGuidedTab() {
		return selfGuidedTab;
	}

	public List<WebElement> getSelfGuidedBubbles() {
		return selfGuidedBubbles;
	}

	public List<WebElement> getSelfGuidedLinks() {
		return selfGuidedLinks;
	}

	public WebElement getChartHelpWindow() {
		return chartHelpWindow;
	}

	public WebElement getChartHelpWindowClose() {
		return chartHelpWindowClose;
	}

	public WebElement getScreenerHelpWindow() {
		return screenerHelpWindow;
	}

	public WebElement getScreenerHelpWindowClose() {
		return screenerHelpWindowClose;
	}

	public WebElement getListPanelHelpWindow() {
		return listPanelHelpWindow;
	}

	public WebElement getListPanelHelpWindowClose() {
		return listPanelHelpWindowClose;
	}

	public WebElement getMsTutorialOff() {
		return msTutorialOff;
	}

	public WebElement getMsTutorialOffPopup() {
		return msTutorialOffPopup;
	}

	public WebElement getMsTutorialOffPopupClose() {
		return msTutorialOffPopupClose;
	}

	public WebElement getMsTutorialOffPopupText() {
		return msTutorialOffPopupText;
	}

	public WebElement getNotfMgmtWindow() {
		return notfMgmtWindow;
	}

	public WebElement getNotfMgmtWindowClose() {
		return notfMgmtWindowClose;
	}

	public WebElement getNotifyRadioBtn() {
		return notifyRadioBtn;
	}

	public WebElement getNotifyCheckbox() {
		return notifyCheckbox;
	}

	public WebElement getNoNotifyRadioBtn() {
		return noNotifyRadioBtn;
	}

	public WebElement getNoNotifyCheckbox() {
		return noNotifyCheckbox;
	}

	public WebElement getAsTheyOccurRB() {
		return asTheyOccurRB;
	}

	public WebElement getOnceADayRB() {
		return onceADayRB;
	}

	public WebElement getOnceADaySelect() {
		return onceADaySelect;
	}

	public WebElement getApplyButton() {
		return applyButton;
	}

	public WebElement getAmRadioBtn() {
		return amRadioBtn;
	}

	public WebElement getPmRadioBtn() {
		return pmRadioBtn;
	}

	public WebElement getAllSharedScreenLink() {
		return allSharedScreenLink;
	}

	public WebElement getBrowseScreenWindow() {
		return browseScreenWindow;
	}

	public WebElement getAllTypeRadio() {
		return allTypeRadio;
	}

	public WebElement getAllSharingRadio() {
		return allSharingRadio;
	}

	public WebElement getAllUpdatedRadio() {
		return allUpdatedRadio;
	}

	public List<WebElement> getSharedScreensList() {
		return sharedScreensList;
	}

	public WebElement getSharedScreenCount() {
		return sharedScreenCount;
	}

	public WebElement getBrowseScreenClose() {
		return browseScreenClose;
	}

	public WebElement getSharedScreens() {
		return sharedScreens;
	}

	public WebElement getCommunityActivityWindow() {
		return communityActivityWindow;
	}

	public WebElement getCommunityActivityClose() {
		return communityActivityClose;
	}

	public WebElement getTrackScreenBtn() {
		return trackScreenBtn;
	}

	public List<WebElement> getTrackedScreenList() {
		return trackedScreenList;
	}

	public WebElement getAllSharedListsLink() {
		return allSharedListsLink;
	}

	public WebElement getBrowseListWindow() {
		return browseListWindow;
	}

	public WebElement getBrowseListClose() {
		return browseListClose;
	}

	public WebElement getDelayedData() {
		return delayedData;
	}

	public WebElement getBatsData() {
		return batsData;
	}

	public WebElement getRealTimeIndicator() {
		return realTimeIndicator;
	}

	public WebElement getMsLogo() {
		return msLogo;
	}
}
