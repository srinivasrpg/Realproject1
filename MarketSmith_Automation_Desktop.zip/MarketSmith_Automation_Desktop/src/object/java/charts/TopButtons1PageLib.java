package charts;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TopButtons1PageLib {

	//Search Box
	@FindBy(css=".symbolsInput")
	private WebElement searchBox;

	//Symbol not recognized box
	@FindBy(css=".unavailableSymbol")
	private WebElement unavailableSymbolBox;

	//Symbol not recognized box close button
	@FindBy(css=".closeButton")
	private WebElement unavailableSymbolClose;

	//Auto suggest list container
	@FindBy(css=".comparisonCompanyList")
	private WebElement autoListBox;

	//Auto suggest list options
	@FindBy(css=".listItem>td>span>strong")
	private List<WebElement> autoListOptions;

	//Symbol dropdown button (small button to right of Search Field)
	@FindBy(css=".expendRecentSymbol")
	private WebElement symbolDropdown;

	//Recent symbol container
	@FindBy(css=".expendRecentSymbolDropDownMenu")
	private WebElement recentBox;

	//Recent symbol Rows 
	@FindBy(css=".expendRecentSymbolDropDownMenu>div>table:nth-of-type(1)>tbody>tr.listItem")
	private List<WebElement> recentSymbolRows;

	//Popular Indices Rows 
	@FindBy(css=".expendRecentSymbolDropDownMenu>div>table:nth-of-type(1)>tbody>tr.listItem")
	private List<WebElement> popularIndicesRows;

	//View Recent Symbols List link
	@FindBy(linkText="View Recent Symbols List")
	private WebElement viewRecentLink;

	//Symbol count on List Manager
	@FindBy(css=".itemsNum")
	private WebElement symbolCountLM;

	//BATS indicator
	@FindBy(css=".realTimeButton")
	private WebElement batsIndicator;

	//Top Date box
	@FindBy(css=".timeInput")
	private WebElement dateBox;

	//Bats Date
	@FindBy(css=".stockChartsText>div>.chartLegendTime")
	private WebElement batsDate;

	//Date Left Arrow
	@FindBy(css=".leftArrow")
	private WebElement dateLeftArrow;

	//Date Right Arrow
	@FindBy(css=".rightArrow")
	private WebElement dateRightArrow;

	//Daily button
	@FindBy(css=".dailyButton")
	private WebElement dailyButton;

	//Weekly button
	@FindBy(css=".weeklyButton")
	private WebElement weeklyButton;

	//Monthly button
	@FindBy(css=".monthlyButton")
	private WebElement monthlyButton;

	//Calendar box
	@FindBy(css=".tabTimeRange")
	private WebElement calendarBox;

	//Calendar box tabs
	@FindBy(css=".tabBtn")
	private List<WebElement> calendarBoxTabs;

	//Calendar box tabs
	@FindBy(css=".calendarExpendButton")
	private WebElement calendarExpandBtn;

	//Stock Ideas
	@FindBy(css=".link-StockIdeas")
	private WebElement stockIdeas;

	//Stock Ideas pop up
	@FindBy(css=".popUpStockIdeasView")
	private WebElement stockIdeasPopup;

	//Report links on Stock Ideas pop up
	@FindBy(css=".reportsTable>div[name]")
	private List<WebElement> reportLinks;

	//View buttons on Report links on Stock Ideas pop up
	@FindBy(css=".reportsTable>div[name]>.cellButton")
	private List<WebElement> viewBtnReport;

	//Screen links on Stock Ideas pop up
	@FindBy(css=".screensTable>div")
	private List<WebElement> screenLinks;

	//View buttons on Screen links on Stock Ideas pop up
	@FindBy(css=".screensTable>div>.showScreen")
	private List<WebElement> viewBtnScreen;

	//Market Analysis links on Stock Ideas pop up
	@FindBy(css=".marketAnalysisTable>div")
	private List<WebElement> marketAnalysisLinks;		

	//Clickable links on Market Analysis links on Stock Ideas pop up
	@FindBy(css=".marketAnalysisTable>div>a")
	private List<WebElement> maClickableLinks;	

	//Daily Chart
	@FindBy(xpath="//*[text()='Dec' and @text-anchor='start']")
	private WebElement dailyChart;	

	//Weekly Chart
	@FindBy(xpath="//*[text()='Mar 17' and @text-anchor='middle']")
	private WebElement weeklyChart;	

	//Monthly Chart
	@FindBy(xpath="//*[text()='2017' and @text-anchor='middle']")
	private WebElement monthlyChart;	

	//Monthly Chart
	@FindBy(css=".companySymbol")
	private WebElement companyNameOnChart;	

	//List name on list manager
	@FindBy(css=".listItemName")
	private WebElement listNameLM;

	//Price Alert button
	@FindBy(css=".priceAlertButtonmenubtn")
	private WebElement priceAlertBtn;

	//Price Alert pop up
	@FindBy(css=".priceAlert")
	private WebElement priceAlertPopup;

	//Price Alert links
	@FindBy(css=".dropdownButtonPallet>ul>li")
	private List<WebElement> priceAlertLinks;	

	//Price Alert pop up Dragger
	@FindBy(css=".dragHandle")
	private WebElement priceAlertDragger;

	//Set Alert pop up
	@FindBy(css=".popUpPriceAlertsView")
	private WebElement setAlertPopup;

	//Set Alert symbol
	@FindBy(css=".setAlertSymbolText")
	private WebElement setAlertSymbol;

	//Set Alert price
	@FindBy(css=".setAlertpriceText")
	private WebElement setAlertPrice;

	//Set Alert done button
	@FindBy(id="setPriceDoneButton")
	private WebElement setAlertDoneBtn;

	//Alerts - Active
	@FindBy(css="#ActivityLists>div>div:nth-of-type(3)>label")
	private WebElement alertsActive;

	//Symbol names on list manager
	@FindBy(css=".freezeVirtualizedPanel>div>div:nth-of-type(4)>div>span")
	private List<WebElement> symbolNamesLM;

	//Alert prices on list manager
	@FindBy(css=".listManagerGridFlexible>div>div>div>div:nth-of-type(1)>div>span")
	private List<WebElement> alertPricesLM;

	//Symbol names on Manage Alerts window
	@FindBy(css=".alertsContentTable>table>tbody>tr>td:nth-of-type(2)")
	private List<WebElement> symbolNamesMA;

	//Prices on Manage Alerts window
	@FindBy(css=".alertsContentTable>table>tbody>tr>td:nth-of-type(2)")
	private List<WebElement> alertPricesMA;

	//Checkboxes on Manage Alerts window
	@FindBy(css=".alertsContentTable>table>tbody>tr>td:nth-of-type(1)>input")
	private List<WebElement> checkBoxesMA;

	//Email buttons on Manage Alerts window
	@FindBy(css=".alertsContentTable>table>tbody>tr>td:nth-of-type(5)>button")
	private List<WebElement> emailButtonsMA;

	//Delete button on Manage Alerts window
	@FindBy(id="activeAlertsDeleteButton")
	private WebElement deleteButtonMA;

	//Triggered Alerts tab on Manage Alerts window
	@FindBy(css=".triggeredAlerts")
	private WebElement triggeredAlertsTabMA;
	
	/******************************************************************************************************
	 ********************************************* GETTERS ************************************************
	 ******************************************************************************************************/

	public WebElement getSearchBox() {
		return searchBox;
	}

	public WebElement getUnavailableSymbolBox() {
		return unavailableSymbolBox;
	}

	public WebElement getUnavailableSymbolClose() {
		return unavailableSymbolClose;
	}

	public WebElement getAutoListBox() {
		return autoListBox;
	}

	public List<WebElement> getAutoListOptions() {
		return autoListOptions;
	}

	public WebElement getSymbolDropdown() {
		return symbolDropdown;
	}

	public WebElement getRecentBox() {
		return recentBox;
	}

	public List<WebElement> getRecentSymbolRows() {
		return recentSymbolRows;
	}

	public List<WebElement> getPopularIndicesRows() {
		return popularIndicesRows;
	}

	public WebElement getViewRecentLink() {
		return viewRecentLink;
	}

	public WebElement getSymbolCountLM() {
		return symbolCountLM;
	}

	public WebElement getBatsIndicator() {
		return batsIndicator;
	}

	public WebElement getDateBox() {
		return dateBox;
	}

	public WebElement getBatsDate() {
		return batsDate;
	}

	public WebElement getDateLeftArrow() {
		return dateLeftArrow;
	}

	public WebElement getDateRightArrow() {
		return dateRightArrow;
	}

	public WebElement getDailyButton() {
		return dailyButton;
	}

	public WebElement getWeeklyButton() {
		return weeklyButton;
	}

	public WebElement getMonthlyButton() {
		return monthlyButton;
	}

	public WebElement getCalendarBox() {
		return calendarBox;
	}

	public List<WebElement> getCalendarBoxTabs() {
		return calendarBoxTabs;
	}

	public WebElement getCalendarExpandBtn() {
		return calendarExpandBtn;
	}

	public WebElement getStockIdeas() {
		return stockIdeas;
	}

	public WebElement getStockIdeasPopup() {
		return stockIdeasPopup;
	}

	public List<WebElement> getReportLinks() {
		return reportLinks;
	}

	public List<WebElement> getViewBtnReport() {
		return viewBtnReport;
	}

	public List<WebElement> getScreenLinks() {
		return screenLinks;
	}

	public List<WebElement> getViewBtnScreen() {
		return viewBtnScreen;
	}

	public List<WebElement> getMarketAnalysisLinks() {
		return marketAnalysisLinks;
	}

	public List<WebElement> getMaClickableLinks() {
		return maClickableLinks;
	}

	public WebElement getDailyChart() {
		return dailyChart;
	}

	public WebElement getWeeklyChart() {
		return weeklyChart;
	}

	public WebElement getMonthlyChart() {
		return monthlyChart;
	}

	public WebElement getCompanyNameOnChart() {
		return companyNameOnChart;
	}

	public WebElement getListNameLM() {
		return listNameLM;
	}

	public WebElement getPriceAlertBtn() {
		return priceAlertBtn;
	}

	public WebElement getPriceAlertPopup() {
		return priceAlertPopup;
	}

	public List<WebElement> getPriceAlertLinks() {
		return priceAlertLinks;
	}

	public WebElement getPriceAlertDragger() {
		return priceAlertDragger;
	}

	public WebElement getSetAlertPopup() {
		return setAlertPopup;
	}

	public WebElement getSetAlertSymbol() {
		return setAlertSymbol;
	}

	public WebElement getSetAlertPrice() {
		return setAlertPrice;
	}

	public WebElement getSetAlertDoneBtn() {
		return setAlertDoneBtn;
	}

	public WebElement getAlertsActive() {
		return alertsActive;
	}

	public List<WebElement> getSymbolNamesLM() {
		return symbolNamesLM;
	}

	public List<WebElement> getAlertPricesLM() {
		return alertPricesLM;
	}

	public List<WebElement> getSymbolNamesMA() {
		return symbolNamesMA;
	}

	public List<WebElement> getAlertPricesMA() {
		return alertPricesMA;
	}

	public List<WebElement> getCheckBoxesMA() {
		return checkBoxesMA;
	}

	public List<WebElement> getEmailButtonsMA() {
		return emailButtonsMA;
	}

	public WebElement getDeleteButtonMA() {
		return deleteButtonMA;
	}

	public WebElement getTriggeredAlertsTabMA() {
		return triggeredAlertsTabMA;
	}

}
