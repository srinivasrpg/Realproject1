package charts;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class ChartPageLib {
    //Click on Open Charts
	@FindBy(css="#components>h3>a")
	private WebElement openChartButton;
	
	//symbol entry field
	@FindBy(css="body > div.MST > div.header > input")
	private WebElement symbolEntryField;
	
	//select symbol from predictive search window
	@FindBy(css="div.contentSym > table:nth-of-type(1) > tbody > tr:nth-of-type(1) > td:nth-of-type(1)")
	private WebElement selectSymbol;
	
	//Login form Login button
	@FindBy(css="#lnkSignIn")
	private WebElement loginButton;	
	
	//click on daily button
	//body > div.MST > div.header > span.chartButton.dailyButton.toolTip-help
	//body > div.MST > div.header > span.chartButton.dailyButton.toolTip-help.chartButtonActive
	@FindBy(xpath="/html/body/div[12]/div[1]/span[1]")
	private WebElement dailyButton;
	
	@FindAll(@FindBy(css="body > div.MST > div.header > span"))
	private List<WebElement> periodicitySelected;
	
	@FindAll(@FindBy(css="body > div.MST > div.sidebar.stockCharts > div.chartBtnsCnt > div"))
	private List<WebElement> headerChartButtons;
	
	//Use this ELEM to click on chart and focus on SYMBOL INPUT FIELD
	@FindBy(css="#chartCnt")
	private WebElement ChartCnt;
	
	@FindAll(@FindBy(css="body > div.MST > div.sidebar.stockCharts > div.contextmenu > ul.toosLst > li"))
	private List<WebElement> rightClickOptions;
	
	//search window
	@FindBy(css="div.comparisonCompanyList")
	private WebElement searchWindow;
	
	//get flag icon
	@FindBy(css="body > div.MST > div.sidebar.stockCharts > div.symbolBasicInformation > div.symbolFlag.chartBtnsImg.toolTip-help")
	private WebElement flagIcon;
	
	@FindBy(css="body > div.MST > div.listManager > div.listDetail > div.navbar > div:nth-child(13) > div.LMControlSizeBtn.defaultBtn.toolTip-help")
	private WebElement defaultLM_button;
	
	//#MyLists > div.listExplorerFather.listExplorerMarkItem.itemClicked
	@FindBy(xpath="//*[@id='MyLists']/div[1]")
	private WebElement getMyListRoot;
	
	//#MyLists > div.listExplorerChild
	//div.folderTreeContent > #MyLists > div.listExplorerChild > div:nth-child(1)
	@FindAll(@FindBy(css="div.folderTreeContent > #MyLists > div.listExplorerChild > div[nodetype='1']"))
	private List<WebElement> myListItems;
	
	@FindAll(@FindBy(css="div.freezeVirtualizedPanel > div > div:nth-of-type(4)>div>span"))
	private List<WebElement> curr_LMList_symbols;
	
	//body > div.MST > div.sidebar.stockCharts > div.chartBtnsCnt > div.chartStockBtn.chartButton.expend.toolTip-help
	@FindBy(css="body > div.MST > div.sidebar.stockCharts > div.chartBtnsCnt > div.chartStockBtn.chartButton.expend.toolTip-help")
	private WebElement AddToListDD_button;
	
	//body > div.MST > div.sidebar.stockCharts > div.chartBtnsCnt > div.chartStockBtn.chartButton.addToListBtn > ul
	@FindAll(@FindBy(css="body > div.MST > div.sidebar.stockCharts > div.chartBtnsCnt > div.chartStockBtn.chartButton.addToListBtn > ul > li[class*='myListsItem']"))
	private List<WebElement> AddToListItemContent;
	
	@FindBy(css="body > div.MST > div.sidebar.stockCharts > div.chartBtnsCnt > div.chartStockBtn.chartButton.addToListBtn > ul > li.newInAddtoList > span")
	private WebElement addToNewList_option;
	
	@FindBy(id="navbarTips")
	private WebElement LMToolTip;
	
	@FindBy(className="navbarTipsUndo")
	private WebElement LMToolTip_Undo;
	
	@FindBy(css="#ModalPanel > div.popUpListManagerNewElementView.ui-droppable > div")
	private WebElement newListPopUp;
	
	@FindBy(css="#ModalPanel > div.popUpListManagerNewElementView.ui-droppable > div > div.popUpNewElementContent > div.contentText > input")
	private WebElement newListPopUp_Input;
	
	@FindBy(css="#ModalPanel > div.popUpListManagerNewElementView.ui-droppable > div > div.popUpNewElementConfirm > button.popUpNewElemBtn.newElemSave")
	private WebElement buttonSaveToClick;

	//Finds symbol with/out Data Boxes enabled
	@FindBy(css="#chartCnt > div.chartbox > div.companyInformation")
	private WebElement companyInfo_symbol;
	
	@FindBy(css="body > div.MST > div.sidebar.stockCharts > div.chartBtnsCnt > div.chartStockBtn.chartPopout.chartBtnsImg.toolTip-help")
	private WebElement NewChartButton;
	            // body > div.MST > div.sidebar.stockCharts > div.chartBtnsCnt > div.receiveSymbolBox > input
	@FindBy(css="body > div.MST > div.sidebar.stockCharts > div.chartBtnsCnt > div.receiveSymbolBox > input")
	private WebElement ReceiveSymbolsFromMain;
	
	@FindBy(css="body > div.MST > div.sidebar.stockCharts > div.chartBtnsCnt > div.chartStockBtn.chartComparison.chartBtnsImg.toolTip-help")
	private WebElement ComparisonChart;
	
	@FindAll(@FindBy(css="body > div.MST > div.sidebar.stockCharts > ul > li"))
	private List<WebElement> ComparisonChartSymbols;
	
	@FindAll(@FindBy(css="body > div.MST > div.header > *"))
	private List<WebElement> comparisonChart_buttons;
	
	@FindAll(@FindBy(css="#chartCnt > svg"))
	private List<WebElement> comparisonChartedSymbols;
	
	
	@FindBy(css="html body div.MST div.sidebar.stockCharts div.comparisonIntro")
	private WebElement comparisonChart_keyScale;
	
	//.expendRecentSymbol
	@FindBy(css="body > div.MST > div.header > div.expendRecentSymbol.toolTip-help")
	private WebElement comparisonChart_symbolDropDown;
	
	//Comparison Charts Drop Down
	//Comparison Charts Recent Symbols
	@FindAll(@FindBy(css="body > div.expendRecentSymbolDropDownMenu.comparisonDropDownMenu > table:nth-child(1) > tbody > tr"))
	private List<WebElement> comparisonChart_recentSymbols;
	//Comparison Charts Popular Indices
	@FindAll(@FindBy(css="body > div.expendRecentSymbolDropDownMenu.comparisonDropDownMenu > table.popularIndices > tbody > tr"))
	private List<WebElement> comparisonChart_popularIndices;
	//Comparison Charts All Indices
	@FindAll(@FindBy(css="body > div.expendRecentSymbolDropDownMenu.comparisonDropDownMenu > table.allIndices > tbody > tr"))
	private List<WebElement> comparisonChart_allIndices;
	
	@FindBy(css="body > div.MST > div.header > div.comparisonListCnt > div.comparisonDelete")
	private WebElement comparisonChart_trashButton;
	
	@FindAll(@FindBy(css="body > div.MST > div.header > div.comparisonListCnt > div.comparisonDelete > ul > li:nth-child(2) > ul > li"))
	private List<WebElement> comparisonChart_deleteSymbolsContent;
	
	@FindBy(css="#chartCnt > svg:nth-child(15) > g:nth-child(1)")
	private WebElement chartBlueNodeData;
	
	@FindBy(css="#chartCnt > svg:nth-child(15) > g:nth-child(1) > path")
	private WebElement chartBlueNodeData2;
	
	//get Reports folder
	@FindBy(css="div#Reports > div:nth-of-type(1) > label")
	private WebElement reportsLink;
	
	//check reports closed or open
	@FindBy(css="div#Reports > div:nth-of-type(1) > span")
	private WebElement reportClass;
	
	//get  MSGrowth250 folder
	@FindBy(css="div#Reports > div:nth-of-type(2) > div:nth-of-type(1) > div:nth-of-type(1) > label")
    private WebElement msgrowthFolderLink;
	
	// check msGrowth folder closed or open
	@FindBy(css="div#Reports > div:nth-of-type(2) > div:nth-of-type(1) > div:nth-of-type(1)>span:nth-of-type(1)")
	private WebElement msGrowthDownLink;
	
	//check g250 pattern rec folder is opened or not
	@FindBy(css="div#Reports > div:nth-of-type(2) > div:nth-of-type(1)>div:nth-of-type(2)>div:nth-of-type(2)>div:nth-of-type(1)>span:nth-of-type(1)")
	private WebElement g250PatternRecDownLink;
	
	//g250 pattern recognition link
	@FindBy(css="div#Reports > div:nth-of-type(2) > div:nth-of-type(1)>div:nth-of-type(2)>div:nth-of-type(2)>div:nth-of-type(1)>label")
	private WebElement g250PatternRecFolder;
	
	//recent break out list link
	@FindBy(css="div#Reports > div:nth-of-type(2) > div:nth-of-type(1)>div:nth-of-type(2)>div:nth-of-type(2)>div:nth-of-type(2)>div:nth-of-type(2)>label")
	private WebElement recentBreakOutsList;
	
	//current viewing List name
	@FindBy(css="div.listCategory > div:nth-of-type(1) > span:nth-of-type(3)")
	private WebElement currentListName;
	
	//select first ticker
	@FindBy(css="div.freezeVirtualizedPanel > div:nth-of-type(1)> div:nth-of-type(5) > div > span")
	private WebElement selectFirstTickerFromLM;
	
	//get chart symbol
	@FindBy(css=".symbolInformation")
	private WebElement chartSymbol;
	
	//locate pivot text
	@FindBy(css=".KeyPricePatternRecognitionMarkups.powerFromPivotText")
	private WebElement pivotText;
	
	//locate chartTool option
	@FindBy(css="div.tools.chartBtnsImg.chartToolContainerBtn")
	private WebElement chartToolButton;
	
	//locate tools option window
	@FindBy(css=".chartBtnsCnt>div>.toolsLst")
	private WebElement waitForChartToolOptions;
	
	//locate all elements present in too options
	@FindAll(@FindBy(css=".chartBtnsCnt>div>.toolsLst>li[value]"))
	private List<WebElement> allToolOptions;
	
	//locate all alert img on chart
	@FindAll(@FindBy(css="div#chartCnt > div:nth-of-type(11) > a > img"))
	private List<WebElement> allAlertImgonChart;
	
	//locate mark up tool bar
	@FindBy(css=".sidebar.stockCharts>.drawingPallet.ui-draggable.ui-droppable")
	private WebElement markUpToolBar;
	
	//locate weekly button
	@FindBy(css=".chartButton.weeklyButton.toolTip-help")
	private WebElement weeklyButton;
	
	//locate open Calendar
	@FindBy(css="div.header > div:nth-of-type(6) > div:nth-of-type(2)")
	private WebElement openCalendar;
	
	//check cal is opened or not
	@FindBy(css="div.header > div:nth-of-type(6) > div:nth-of-type(2)>div")
	private WebElement calendarStatus;
	
	//locate reset to today
	@FindBy(css=".resetToToday")
	private WebElement resetToToday; 
	
	//locate current date
	@FindBy(css=".dayCell.currentDayItem")
	private WebElement currentDate;
	
	//locate last trading date
	@FindBy(css="div.stockChartsText > div:nth-of-type(3) > span:nth-of-type(3)")
	private WebElement lastTradingDate;
	
	//locate monthly button
	@FindBy(css=".chartButton.monthlyButton.toolTip-help")
	private WebElement monthlyButton;
	
	//locate company information like symbol,group,exchange
	@FindBy(css="div.companyInfoLeft>div:nth-of-type(1)>div:nth-of-type(1)")
	private WebElement symbolExchangeGroupInfo;
	
	//locate company url
	@FindBy(css="div.companyInfoLeft>div:nth-of-type(2)>div>a")
	private WebElement urlLink;
	
	//market capitalization
	@FindBy(css="div.companyInfoLeft>div:nth-of-type(2)>div:nth-of-type(2)")
	private WebElement marketCap;
	
	//company left information
	@FindAll(@FindBy(css="div.companyInfoLeft>div>div"))
	private List<WebElement> companyLeftInfo; 
	
	//company info center
	@FindAll(@FindBy(css="div.companyInfoCenter>div"))
	private List<WebElement> companyCenterInfo; 
	
	//company info right side
	@FindAll(@FindBy(css="div.companyPriceChange>div"))
	private List<WebElement> companyRightInfo;
	
	//locate intra day button
	@FindBy(css=".chartButton.intradayButton.toolTip-help")
	private WebElement intraDayButton;
	
	//locate intraDay dropdown
	@FindBy(css="div.header > div:nth-of-type(4)")
	private WebElement intraDayDropdown;
	
	//locate intraday options
	@FindAll(@FindBy(css="div.header > div:nth-of-type(4)>ul>li"))
	private List<WebElement> intradayMinOptions;
	
	//Company information
	@FindBy(css=".commonCompanyInfo")
	private WebElement companyInformation;
	
	//DailyBox information
	@FindBy(css="#chartCnt>div.chartbox>.dailyBox")
	private WebElement dailyBoxInfo;
	/*************************************GETTERS******************************************************************************
	 ************************************************************************************************************************/
	public WebElement getOpenChartButton(){
		return openChartButton;
	}
	
	public WebElement getSymbolEntryField(){
		return symbolEntryField;
	}
	
	public WebElement getSelectSymbol(){
		return selectSymbol;
	}
	
	public WebElement getLoginButton() {
		return loginButton;
	}
	
	public WebElement getDailyButton(){
		return dailyButton;
	}
	
	public List<WebElement> getPeriodicitySelected(){
		return periodicitySelected;
	}
	
	public List<WebElement> getHeaderChartButtons(){
		return headerChartButtons;
	}
	
	public WebElement getChartCnt(){
		return ChartCnt;
	}
	
	public List<WebElement> getRightClickOptions(){
		return rightClickOptions;
	}
	
	public WebElement getSearchWindow(){
		return searchWindow;
	}
	
	public WebElement getFlagIcon(){
		return flagIcon;
	}
	
	public WebElement getDefaultLM_button(){
		return defaultLM_button;
	}
	
	public WebElement getMyListRoot_button(){
		return getMyListRoot;
	}
	
	public List<WebElement> getMyLists(){
		return myListItems;
	}
	
	public List<WebElement> getCurr_LMList_symbols(){
		return curr_LMList_symbols;
	}
	
	public WebElement getAddToListDDbutton(){
		return AddToListDD_button;
	}
	
	public List<WebElement> getAddToListContent(){
		return AddToListItemContent;
	}

	public WebElement getAddToNewList_option(){
		return addToNewList_option;
	}
	
	public WebElement getLMToolTip(){
		return LMToolTip;
	}
	
	public WebElement getLMToolTip_Undo(){
		return LMToolTip_Undo;
	}
	
	public WebElement getNewListPopUp(){
		return newListPopUp;
	}
	
	public WebElement getNewListPopUp_Input(){
		return newListPopUp_Input;
	}
	
	public WebElement getClickSaveForNewList(){
		return buttonSaveToClick;
	}
	
	public WebElement getCompanyInfo_symbol(){
		return companyInfo_symbol;
	}
	
	public WebElement getNewChartButton(){
		return NewChartButton;
	}
	
	public WebElement getReceiveSymbolsFromMain(){
		return ReceiveSymbolsFromMain;
	}
	
	public WebElement getComparisonChart(){
		return ComparisonChart;
	}
	
	public List<WebElement> getComparisonChart_dataBlockSymbols(){
		return ComparisonChartSymbols;
	}
	
	public List<WebElement> getComparisonChart_buttons(){
		return comparisonChart_buttons;
	}
	
	public WebElement getComparisonChart_keyScale(){
		return comparisonChart_keyScale;
	}
	
	public List<WebElement> getComparisonChart_chartedSymbols(){
		return comparisonChartedSymbols;
	}
	
	public WebElement getComparisonChart_symbolDropDown(){
		return comparisonChart_symbolDropDown;
	}
	
	//Comparison Charts Recent Symbols
	public List<WebElement> getComparisonChart_recentSymbols(){
		return comparisonChart_recentSymbols;
	}
	
	//Comparison Charts Popular Indices
	public List<WebElement> getComparisonChart_popularIndices(){
		return comparisonChart_popularIndices;
	}
	
	//Comparison Charts All Indices
	public List<WebElement> getComparisonChart_allIndices(){
		return comparisonChart_allIndices;
	}
	
	public WebElement getComparisonChart_trashButton(){
		return comparisonChart_trashButton;
	}
	
	public List<WebElement> getComparisonChart_deleteSymbolsContent(){
		return comparisonChart_deleteSymbolsContent;
	}
	
	public WebElement getChartBlueNodeData(){
		return chartBlueNodeData;
	}
	
	public WebElement getChartBlueNodeData2(){
		return chartBlueNodeData2;
	}
	public WebElement getReportsLink(){
		return reportsLink;
	}
	public WebElement getReportClass(){
		return reportClass;
	}
	public WebElement getMSGrowthFoderLink(){
		return msgrowthFolderLink;
	}
	public WebElement getMsGrowthDownLink(){
		return msGrowthDownLink;
	}
	public WebElement getg250PatternRecDownLink(){
		return g250PatternRecDownLink;
	}
	public WebElement getg250PatternRecFolder(){
		return g250PatternRecFolder;
	}
	public WebElement getrecentBreakOutsList(){
		return recentBreakOutsList;
	}
	public WebElement getCurrentListName(){
		return currentListName;
	}
	public WebElement getselectFirstTickerFromLM(){
		return selectFirstTickerFromLM;
	}
	public WebElement getChartSymbol(){
		return chartSymbol;
	}
	public WebElement getpivotText(){
		return pivotText;
	}
	public WebElement getchartToolButton(){
		return chartToolButton;
	}
	public WebElement getwaitForChartToolOptions(){
		return waitForChartToolOptions;
	}
	public List<WebElement> getallToolOptions(){
		return allToolOptions;
	}
	public List<WebElement> getallAlertImgonChart(){
		return allAlertImgonChart;
	}
	public WebElement getmarkUpToolBar(){
		return markUpToolBar;
	}
	public WebElement getweeklyButton(){
		return weeklyButton;
	}
	public WebElement getresetToToday(){
		return resetToToday;
	}
	public WebElement getopenCalendar(){
		return openCalendar;
	}
	public WebElement getcurrentDate(){
		return currentDate;
	}
	public WebElement getlastTradingDate(){
		return lastTradingDate;
	}
	public WebElement getmonthlyButton(){
		return monthlyButton;
	}
	public WebElement getsymbolExchangeGroupInfo(){
		return symbolExchangeGroupInfo;
	}
	public WebElement getcalendarStatus(){
		return calendarStatus;
	}
	public WebElement geturlLink(){
		return urlLink;
	}
	public WebElement getmarketCap(){
		return marketCap;
	}
	public List<WebElement> getcompanyCenterInfo(){
		return companyCenterInfo;
	}
	public List<WebElement> getcompanyRightInfo(){
		return companyRightInfo;
	}
	public WebElement getintraDayButton(){
		return intraDayButton;
	}
	public WebElement getintraDayDropdown(){
		return intraDayDropdown;
	}
	public List<WebElement> getintradayMinOptions(){
		return intradayMinOptions;
	}
	public List<WebElement> getcompanyLeftInfo(){
		return companyLeftInfo;
	}
	
	public WebElement getcompanyInformation(){
		return companyInformation;
	}
	
	public WebElement getdailyBoxInfo(){
		return dailyBoxInfo;
	}
	
	@FindBy(css="#chartCnt > div.chart_container > div.chart_priceChart > div.chart_priceChart_chart")
	private WebElement MainPriceChart;
	
	public WebElement getMainPriceChart(){
		return MainPriceChart;
	}
	
	@FindBy(css="#chartCnt > div.chart_container > div.chart_stochasticChart")
	private WebElement StochasticDataBox;
	
	public WebElement getStochasticDataBox(){
		return StochasticDataBox;
	}

	@FindBy(css="#chartCnt > div.chartbox > div.dailyBox")
	private WebElement DailyDataBoxes;
	
	public WebElement getDailyDataBoxes()
	{
		return DailyDataBoxes;
	}
	
	@FindBy(css="#chartCnt > div.chartbox > div.weeklyBox")
	private WebElement WeeklyDataBoxes;
	
	public WebElement getWeeklyDataBoxes()
	{
		return WeeklyDataBoxes;
	}
	
	@FindBy(css="#chartCnt > svg:nth-child(20)")
	private WebElement CorporateEvents;
	
	public WebElement getCorporateEvents()
	{
		return CorporateEvents;
	}
	
	@FindBy(css="#chartCnt > svg:nth-child(19)")
	private WebElement IndexLine;
	
	public WebElement getIndexLine()
	{
		return IndexLine;
	}
	
	@FindBy(css="#ModelessPanel > div.popUpCustomMovingAveragesView.ui-draggable.ui-droppable")
	private WebElement MovingAvgsModalWindow;
	
	public WebElement getMovingAvgsModalWindow()
	{
		return MovingAvgsModalWindow;
	}
	
	@FindBy(css="#ModelessPanel > div.popUpCustomMovingAveragesView.ui-draggable.ui-droppable > span.btn-close")
	private WebElement CloseButton_MovingAvgsWindow;
	
	public WebElement getCloseButton_MovingAvgsWindow()
	{
		return CloseButton_MovingAvgsWindow;
	}
	
	
	@FindBy(css="#ModalPanel > div.StockChartHelp_wide > div.stockChartHelpWideFramePeriphery.stockChartHelpWideFramePeripheryLinePen")
	private WebElement LinePenWindow;
	
	public WebElement getLinePenWindow()
	{
		return LinePenWindow;
	}
	
	@FindBy(css="#ModalPanel > div.StockChartHelp_wide > span.btn-close")
	private WebElement CloseButton_LinePenWindow;
	
	public WebElement getCloseButton_LinePenWindow()
	{
		return CloseButton_LinePenWindow;
	}
	
	//Chart tool options - STOCHASTICS
	@FindBy(css="div.tools.chartBtnsImg.chartToolContainerBtn > ul > li.stochastics")
	private WebElement Stochastics_chartToolOptions;
	
	public WebElement getStochastics_chartToolOptions()
	{
		return Stochastics_chartToolOptions;
	}
	
	//Chart tool options - DataBoxes
	@FindBy(css="div.tools.chartBtnsImg.chartToolContainerBtn > ul > li.dataBoxes")
	private WebElement DataBoxes_chartToolOptions;
	
	public WebElement getDataBoxes_chartToolOptions()
	{
		return DataBoxes_chartToolOptions;
	}
	
	//Chart tool options - Corporate Events
	@FindBy(css="div.tools.chartBtnsImg.chartToolContainerBtn > ul > li.events")
	private WebElement CorporateEvents_chartToolOptions;
	
	public WebElement getCorporateEvents_chartToolOptions()
	{
		return CorporateEvents_chartToolOptions;
	}
	
	//Chart tool options - Index Line
	@FindBy(css="div.tools.chartBtnsImg.chartToolContainerBtn > ul > li.indexLine")
	private WebElement IndexLine_chartToolOptions;
	
	public WebElement getIndexLine_chartToolOptions()
	{
		return IndexLine_chartToolOptions;
	}
	
	//Chart tool options - Chart Legend
	@FindBy(css="div.tools.chartBtnsImg.chartToolContainerBtn > ul > li.chartLegends")
	private WebElement ChartLegend_chartToolOptions;
	
	public WebElement getChartLegend_chartToolOptions()
	{
		return ChartLegend_chartToolOptions;
	}
	
	//Chart tool options - Moving Averages
	@FindBy(css="div.tools.chartBtnsImg.chartToolContainerBtn > ul > li.customMovingAverages")
	private WebElement MvgAvgs_chartToolOptions;
	
	public WebElement getMvgAvgs_chartToolOptions()
	{
		return MvgAvgs_chartToolOptions;
	}
	
	//Chart tool options - Line Pen
	@FindBy(css="div.tools.chartBtnsImg.chartToolContainerBtn > ul > li.linePen")
	private WebElement LinePen_chartToolOptions;
	
	public WebElement getLinePen_chartToolOptions()
	{
		return LinePen_chartToolOptions;
	}
	
	//Chart tool options - Tight Areas
	@FindBy(css="div.tools.chartBtnsImg.chartToolContainerBtn > ul > li.tightAreas")
	private WebElement TightAreas_chartToolOptions;
	
	public WebElement getTightAreas_chartToolOptions()
	{
		return TightAreas_chartToolOptions;
	}
	
	//#chartCnt > div.chart_patternRecognitionContainer > svg > g > ellipse:nth-child(38)
	//All Price Tight Areas
	@FindAll(@FindBy(css="#chartCnt > div.chart_patternRecognitionContainer > svg > g > ellipse"))
	private List<WebElement> PriceTightAreas;
	
	public List<WebElement> getPriceTightAreas()
	{
		return PriceTightAreas;
	}
	
	//Chart tool options - Tight Areas
	@FindBy(css="div.tools.chartBtnsImg.chartToolContainerBtn > ul > li.keyPriceRanges")
	private WebElement KeyPriceRanges_chartToolOptions;
	
	public WebElement getKeyPriceRanges_chartToolOptions()
	{
		return KeyPriceRanges_chartToolOptions;
	}
	
	//#chartCnt > div.chart_annotationContainer > svg > rect.patternProfitMarkups.patternRecognitionMarkups.KeyPricePatternRecognitionMarkups
	//Get All chart Key Prices Area - Pivot/Blue, Profit/Green, & Loss/Red -> All have related class Name
	//#chartCnt > div.chart_annotationContainer > svg > rect[class*='patternRecognitionMarkups KeyPricePatternRecognitionMarkups']
	@FindAll(@FindBy(css="rect[class*='KeyPricePatternRecognitionMarkups']"))
	private List<WebElement> KeyPriceAreas;
	
	public List<WebElement> getKeyPriceAreas()
	{
		return KeyPriceAreas;
	}
	
	//Get All chart key prices text - pivot, profit, loss
	@FindAll(@FindBy(css="text[class*='KeyPricePatternRecognitionMarkups']"))
	private List<WebElement> KeyPriceAreasText;
	
	public List<WebElement> getKeyPriceAreasText()
	{
		return KeyPriceAreasText;
	}
	
	//#chartCnt > div.chart_annotationContainer > div.KeyPricePatternRecognitionMarkups.powerFromPivotText.disableClick
	@FindBy(css="div.KeyPricePatternRecognitionMarkups.powerFromPivotText.disableClick")
	private WebElement PercentFromPivotText;
	
	public WebElement getPercentFromPivotText()
	{
		return PercentFromPivotText;
	}
	
	//Get all PR base pattern rects on DOM -> #chartCnt > div.chart_patternRecognitionContainer > svg > g > rect:nth-child(11)
	@FindAll(@FindBy(css="#chartCnt > div.chart_patternRecognitionContainer > svg > g > rect[class='patternRecognitionMarkups']"))
	private List<WebElement> AllBasePatternsOnChart;
	
	public List<WebElement> getAllBasePatternsOnChart()
	{
		return AllBasePatternsOnChart;
	}
	
	//Get all PR base pattern rect for HOVEROVER boxes
	//#chartCnt > div.chart_annotationContainer > svg > rect.textBackground.patternRecognitionHideItem
	@FindAll(@FindBy(css="rect.textBackground.patternRecognitionHideItem"))
	private List<WebElement> Recent_PR_HoverBoxes;
	
	public List<WebElement> getRecent_PR_HoverBoxes()
	{
		return Recent_PR_HoverBoxes;
	}
	
	//Get all PR base text for HOVEROVER boxes
	@FindAll(@FindBy(css="text.patternRecognitionHideItem"))
	private List<WebElement> Recent_PR_HoverBoxes_text;
	
	public List<WebElement> getRecent_PR_HoverBoxes_text()
	{
		return Recent_PR_HoverBoxes_text;
	}
	
	//#chartCnt > div.chart_patternRecognitionContainer > svg > line:nth-child(5)
	//Get all PR base BLUE LINE for HOVEROVER boxes
	@FindAll(@FindBy(css="line.patternRecognitionHideItem"))
	private List<WebElement> Recent_PR_HoverBoxes_line;
	
	public List<WebElement> getRecent_PR_HoverBoxes_line()
	{
		return Recent_PR_HoverBoxes_line;
	}
	
	//BLANK CHART NECESSARY OBJECTS
	@FindAll(@FindBy(css="#chartCnt > svg > text"))
	private List<WebElement> BlankChart;
	
	public List<WebElement> getBlankChart()
	{
		return BlankChart;
	}
	
	//body > div.MST > div.header > div.timeRangeCon.toolTip-help.timeRangeConClicked > input
	//body > div.MST > div.header > div.timeRangeCon.toolTip-help > input
	@FindBy(css="body > div.MST > div.header > div.timeRangeCon.toolTip-help > input")
	private WebElement ChangeDateInput;
	
	public WebElement getChangeDateInput()
	{
		return ChangeDateInput;
	}
	
	@FindBy(css="path.patternRecognitionMarkups.largestVolumePattern")
	private WebElement largestVolumeIcon;
	
	public WebElement getlargestVolumeIcon()
	{
		return largestVolumeIcon;
	}
	
	//Comparison Charts remove all symbols link
	@FindBy(css="body > div.MST > div.header > div.comparisonListCnt > div.comparisonDelete > ul > li:nth-child(1) > ul > li.removeAll")
	private WebElement deleteAllSymbolsCompChartsLINK;
	
	public WebElement getdeleteAllSymbolsCompChartsLINK()
	{
		return deleteAllSymbolsCompChartsLINK;
	}
	
	//Remove COMPARISON CHARTS modal box
	@FindBy(css="#ModalPanel > div.popUpCommonView.popUpRemoveListView")
	private WebElement ModalBoxConfirm_compChart;
	
	public WebElement getModalBoxConfirm_compChart()
	{
		return ModalBoxConfirm_compChart;
	}
	
	//CANCEL option modal box
	@FindBy(css="#ModalPanel > div.popUpCommonView.popUpRemoveListView > div:nth-child(2) > button.okBtn.cancleComparisonBtn")
	private WebElement CancelButtonModalBox;
	
	public WebElement getCancelButtonModalBox()
	{
		return CancelButtonModalBox;
	}
	
	//REMOVE option modal box
	@FindBy(css="#ModalPanel > div.popUpCommonView.popUpRemoveListView > div:nth-child(2) > button.okBtn.okComparisonBtn")
	private WebElement RemoveButtonModalBox;
	
	public WebElement getRemoveButtonModalBox()
	{
		return RemoveButtonModalBox;
	}
	
	
	//ModalPanel
	@FindBy(css="#ModalPanel")
	private WebElement ModalPanel;
	
	public WebElement getModalPanel()
	{
		return ModalPanel;
	}
	
	//COMPARISON CHARTS add list button
	@FindBy(css="body > div.MST > div.header > div.comparisonListCnt > div.comparisonAdd")
	private WebElement AddListButton_CompCharts;
	
	public WebElement getAddListButton_CompCharts()
	{
		return AddListButton_CompCharts;
	}
	
	//COMPARISON CHARTS add to list modal box
	@FindBy(css="#ModalPanel > div.popUpCommonView.popUpAddToListView")
	private WebElement AddList_modalBox;
	
	public WebElement getAddList_modalBox()
	{
		return AddList_modalBox;
	}
	
	//COMPARISON list NOTE
	@FindBy(css="#ModalPanel > div.popUpCommonView.popUpAddToListView > div.note.comparisonNote")
	private WebElement AddList_comparisonFooterNote;
	
	public WebElement getAddList_comparisonFooterNote()
	{
		return AddList_comparisonFooterNote;
	}
	
	//COMPARISON CHART My List section
	@FindBy(css="div.folderTreeContent.addToListPopupFolderTree > #MyLists > div:nth-child(1)")
	private WebElement MyListSection_CompCharts;
	
	public WebElement getMyListSection_CompCharts()
	{
		return MyListSection_CompCharts;
	}
	
	//COMPARISON CHART My List tree content
	@FindBy(css="div.folderTreeContent.addToListPopupFolderTree > #MyLists > div.listExplorerChild")
	private WebElement MyListSectionTree_CompCharts;
	
	public WebElement getMyListSectionTree_CompCharts()
	{
		return MyListSectionTree_CompCharts;
	}
	
	//COMPARISON CHART My List tree content
	@FindAll(@FindBy(css="div.folderTreeContent.addToListPopupFolderTree > #MyLists > div.listExplorerChild > div[nodetype='1']"))
	private List<WebElement> MyListSectionTreeCONTENT_CompCharts;
	
	public List<WebElement> getMyListSectionTreeCONTENT_CompCharts()
	{
		return MyListSectionTreeCONTENT_CompCharts;
	}
}

//popUPAjaxErrorHandleView
//https://williamoneil.atlassian.net/wiki/display/IBDPROG/MarketSmith_Queries+on+MS++Integration+testing
//https://williamoneil.atlassian.net/wiki/display/IBDPROG/MS+Integration
//https://williamoneil.atlassian.net/wiki/display/IBDPROG/MS-IBD+integration+Implementation+Notes
//https://williamoneil.atlassian.net/wiki/display/IBDPROG/Test+Plan