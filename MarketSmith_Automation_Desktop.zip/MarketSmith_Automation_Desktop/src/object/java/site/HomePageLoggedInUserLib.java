package site;

import java.nio.channels.InterruptedByTimeoutException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class HomePageLoggedInUserLib {
	//login button
	@FindBy(css="#lnkSignIn")
	private WebElement loginButton;	
	
	//locate set up an appointment link
	@FindBy(css="ctl00_ctl00_Content_SideBar_ScheduleCoachingModule1_lnkSchedule")
	private WebElement setUpAppointment;
	
	//locate contact us link
	@FindBy(css="a#ctl00_ctl00_Footer1_rptItems_ctl03_lnkItem")
	private WebElement contactUsLink;
	
	//locate contacts page tabs
	@FindAll(@FindBy(css=".ui-tabs-nav>li>a>span"))
	private List<WebElement> contactPageTabs;
	
	//locate all footers under learn more investing section
	@FindAll(@FindBy(css="div#footer-main>div:nth-of-type(1)>div:nth-of-type(2)>div:nth-of-type(3)>div>a"))
	private List<WebElement> learnMoreInvestingAllLinks;
	
	//Community tab
	@FindBy(css="#ctl00_ctl00_Menu1_rptItems_ctl02_lnkItem")
    private WebElement communityTab;
	
	//mouse Over elements for community
	@FindAll(@FindBy(css="#topnavPopupMiddle>div>div>p>a"))
	private List<WebElement> communityElements;
	
	//locate Products tab
	@FindBy(css="#ctl00_ctl00_Menu1_rptItems_ctl01_lnkItem")
	private WebElement productsTab; 
	
	@FindAll(@FindBy(css="#topnavPopupMiddle>div>div>div>p>a,#topnavPopupMiddle>div>div>div>a"))
	private List<WebElement> productElements;
	
	//learn tab
	 @FindBy(css="#ctl00_ctl00_Menu1_rptItems_ctl03_lnkItem")
     private WebElement learnTab;
	 
	 //locate learn hover elements
	 @FindAll(@FindBy(css="#topnavPopupMiddle>div>div>p>a"))
	 private List<WebElement> learnElements;
	 
	 //locate learn page tabs
	 @FindAll(@FindBy(css="ul>li>a>span"))
	 private List<WebElement> learnPageTabs;
	 
	//SupportMenu button on Market Smith page
	@FindBy(css="#ctl00_ctl00_Menu1_rptItems_ctl04_lnkItem")
	private WebElement SupportMenu;
	
	//general Support in Support page
	@FindBy(css="ul#troubleShootingNav > li:nth-of-type(1) > a")
	private WebElement generalSupport;
	
	//blogs tab in communityPage
	@FindBy(css="#__tab_ctl00_content_ctl00_fragment_2539_ctl00_MyTabContainer_ctl00")
	private WebElement blogsTabInCommPage;
	
	//locate MyAcoount Tab
	@FindBy(css="#ctl00_ctl00_Menu1_rptItems_ctl05_lnkItem")
	private WebElement myAccountTab;
	
	//locate header Image in account tab
	@FindBy(css="#ctl00_ctl00_headerImg")
	private WebElement headerImageInIBD; 
	/*************************************************************************************************
	GETTERS
**************************************************************************************************/
	public WebElement getLoginButton() {
		return loginButton;
	}
	public WebElement getSetUpAppointment(){
		return setUpAppointment;
	}
	public WebElement getcontactUsLink(){
		return contactUsLink;
	}
	public List<WebElement> getcontactPageTabs(){
		return contactPageTabs;
	}
    public List<WebElement> getlearnMoreInvestingAllLinks(){
    	return learnMoreInvestingAllLinks;
    }
    public WebElement getCommunityTab (){
		return communityTab;
	}
    public List<WebElement> getcommunityElements(){
		return communityElements;
	}
    public WebElement getproductsTab(){
    	return productsTab;
    }
    public List<WebElement> getproductElements(){
    	return productElements;
    }
    public WebElement getLearnTab(){
		return learnTab;
	}
    public List<WebElement> getlearnElements(){
    	return learnElements;
    }
    public List<WebElement> getlearnPageTabs(){
    	return learnPageTabs;
    }
    public WebElement SupportMenu(){
		 return SupportMenu;
	}
    public  WebElement getmyAccountTab(){
    	return myAccountTab;
    }
    public WebElement getgeneralSupport(){
    	return generalSupport;
    }
    public WebElement getblogsTabInCommPage(){
    	return blogsTabInCommPage;
    }
    public WebElement getheaderImageInIBD(){
    	return headerImageInIBD;
    }
}
