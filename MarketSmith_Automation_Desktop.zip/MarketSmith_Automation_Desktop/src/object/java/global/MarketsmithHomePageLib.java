package global;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MarketsmithHomePageLib {
	    //Login form username text box
		//input#txtUserName - OLD PAGE
		@FindBy(css="#txtquickLoginEmail")
		private WebElement userNameTextbox;

		//Login form password text box
		//#txtFakePassword - OLD PAGE
		@FindBy(css="#txtquickLoginPassword")
		private WebElement passwordTextbox;
				
		//Login form Login button
		//#lnkSignIn - OLD PAGE
		@FindBy(css="#btnquickLoginSubmit")
		private WebElement loginButton;	
				
		//Login form iframe
		@FindBy(css="iframe")
		private WebElement loginFrame;
		
		//Logout button on Menu strip
		@FindBy(css="a[class='imgText signout']")
		private WebElement logoutButton;
		
			
		/*************************************************************************************************
		GETTERS
**************************************************************************************************/
				
		public WebElement getUserNameTextbox() {
			return userNameTextbox;
		}

		public WebElement getPasswordTextbox() {
			return passwordTextbox;
		}

		public WebElement getLoginButton() {
			return loginButton;
		}
				
		public WebElement getLoginFrame() {
			return loginFrame;
		}
		
		public WebElement getLogoutButton() {
			return logoutButton;
		}
		
		//Logout button on Menu strip
		@FindBy(css="#member-onlys")
		private WebElement MainSignInButton;
				
		public WebElement getMainSignInButton(){
			return MainSignInButton;
		}
		
		@FindBy(css="#jqmQuickLogin")
		private WebElement SignInModalBox;
		
		public WebElement getSignInModalBox(){
			return SignInModalBox;
		}
		
		@FindBy(css="#ModelessPanel > div.popUpAjaxErrorHandleView.popUpCommonView")
		private WebElement ErrorPopUp;
		
		public WebElement getErrorPopUp()
		{
			return ErrorPopUp;
		}
		
		@FindBy(css="#ModelessPanel > div.popUpAjaxErrorHandleView.popUpCommonView > div.ajaxErrorShowClose > button")
		private WebElement ErrorCloseButton;
		
		public WebElement getErrorCloseButton()
		{
			return ErrorCloseButton;
		}
}