package relatedInformation;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class RelatedInformation3Lib {
	//get Reports folder
	@FindBy(css="div#Reports > div:nth-of-type(1) > label")
	private WebElement reportsLink;
	
	//check reports closed or open
	@FindBy(css="div#Reports > div:nth-of-type(1) > span")
	private WebElement reportClass;
	
	//locate mutual fund folder
	@FindBy(css="div#Reports > div:nth-of-type(2)>div:nth-of-type(4)>div>label")
	private WebElement mutualFundFolder;
	
	//locate mutual fund open or close
	@FindBy(css="div#Reports > div:nth-of-type(2)>div:nth-of-type(4)>div>span:nth-of-type(1)")
	private WebElement mutualFundSpan;
	
	//locate mutual fund list
	@FindBy(css="div#Reports > div:nth-of-type(2)>div:nth-of-type(4)>div:nth-of-type(2)>div:nth-of-type(1)>label")
	private WebElement mutualFundList;
	
	//tickerType
	@FindBy(css="div.freezeVirtualizedPanel > div:nth-of-type(1) > div:nth-of-type(6) > div > span > span[type=MutualFund]")
	private WebElement waitMutualFund;
	
	//Select industry group
	@FindBy(css="div.freezeVirtualizedPanel > div:nth-of-type(2)> div:nth-of-type(5) > div > span")
	private WebElement selectMutualFund;
	
	//get chart information
	@FindBy(css=".symbolInformation")
	private WebElement chartSymbol;
	
	//locate RI options 
	@FindAll(@FindBy(xpath="//div[@class='optionPanel']/div[@style='' or @style='display: block;']"))
	private List<WebElement> riOptions;
	
	//locate arrow of related information
	@FindBy(css="div.sidebar.relatedInformation > div:nth-of-type(2) > div > div")
	private WebElement riArrow;
	
	//locate RI tab
	@FindBy(css="div.sidebar.relatedInformation > div:nth-of-type(2) > div > span")
	private WebElement relatedInfoTab;
	
	//locate profile tables
	@FindAll(@FindBy(css=".profileContentTable>tbody>tr>th"))
	private List<WebElement> profileTables;
	
	//locate fund overview table information
	@FindAll(@FindBy(css=".profileContentTable:nth-of-type(1)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> fundOverviewTabInfo;
	
	//locate expenses table information
	@FindAll(@FindBy(css=".profileContentTable:nth-of-type(2)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> expensesTableInfo;
	
	//locate tax efficiency
	@FindAll(@FindBy(css=".profileContentTable:nth-of-type(3)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> taxEfficiency;
	
	//locate purchase details table info
	@FindAll(@FindBy(css=".profileContentTable:nth-of-type(4)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> purchaseDetails;
	
	//locate url field
	@FindBy(css=".profileLink")
	private WebElement urlField;
	
	//locate show all fund in Family 
	@FindBy(css=".showAllProfile>span")
	private WebElement showAllFundsInFamily;
	
	//locate side bar
	@FindBy(css=".sidebar.relatedInformation>div.content>div:nth-of-type(2)")
	private WebElement sideBarRI;
	
	//locate list manager  right side
	@FindBy(css=".listDetail>div:nth-of-type(2)")
	private WebElement listPanel;
	
	//locate ownership  list
	@FindBy(css="div#listSpecial > div:nth-of-type(1)")
	private WebElement specialList;
	
	//locate symbol information
	@FindBy(css=".companySymbol")
	private WebElement symbolInformation;
	
	//locate all the table names of Returns
	@FindAll(@FindBy(css=".PerformancePanel.subPanel.subPanelShow>table>tbody>tr>th"))
	private List<WebElement> returnsTableNames;
	
	//locate current table columns
	@FindAll(@FindBy(css=".PerformancePanel.subPanel.subPanelShow>table:nth-of-type(2)>tbody:nth-of-type(1)>tr:nth-of-type(2)>td[align='right']"))
	private List<WebElement> currentTableColumns;
	
	//locate prior month table columns
	@FindAll(@FindBy(css=".PerformancePanel.subPanel.subPanelShow>table:nth-of-type(3)>tbody:nth-of-type(1)>tr:nth-of-type(2)>td[align='right']"))
	private List<WebElement> priorMonthTableColumns;
	
	//Click on symbol entry field
	@FindBy(css="body > div.MST > div.header > input")
	private WebElement symbolEntryField;
	
	//current table rows
	@FindAll(@FindBy(css=".PerformancePanel.subPanel.subPanelShow>table:nth-of-type(2)>tbody:nth-of-type(1)>tr>td[align='left']"))
	private List<WebElement> currentTableRows;
	
	//locate prior month rows
	@FindAll(@FindBy(css=".PerformancePanel.subPanel.subPanelShow>table:nth-of-type(3)>tbody:nth-of-type(1)>tr>td[align='left']"))
	private List<WebElement> priorMonthTableRows;
	
	//locate no name table rows
	@FindAll(@FindBy(css=".PerformanceTableFirst>tbody>tr>td[align='left']"))
	private List<WebElement> noNameTableRows;
	
	//table headers in risk tab
	@FindAll(@FindBy(css=".riskContentTable>tbody>tr>th>div"))
	private List<WebElement> tableHeadersRiskTab;
	
	//std deviation table columns
	@FindAll(@FindBy(css=".RiskPanel.subPanel.subPanelShow>table:nth-of-type(1)>tbody>tr:nth-of-type(2)>td"))
	private List<WebElement> stdDevTableColumns;
	
	//coeff Variation  table columns
	@FindAll(@FindBy(css=".RiskPanel.subPanel.subPanelShow>table:nth-of-type(2)>tbody>tr:nth-of-type(2)>td"))
	private List<WebElement> coeffVarTableColumns;
	
	//sharpe ratio
	@FindAll(@FindBy(css=".RiskPanel.subPanel.subPanelShow>table:nth-of-type(3)>tbody>tr:nth-of-type(2)>td"))
	private List<WebElement> sharpRatioTableColumns;
	
	//std deviation table rows
	@FindAll(@FindBy(css=".RiskPanel.subPanel.subPanelShow>table:nth-of-type(1)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> stdDeviationTableRows;
	
	//coeff variation table rows
	@FindAll(@FindBy(css=".RiskPanel.subPanel.subPanelShow>table:nth-of-type(1)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> coefficientVarRows;
	
	//sharp ratio
	@FindAll(@FindBy(css=".RiskPanel.subPanel.subPanelShow>table:nth-of-type(3)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> sharpeRatioRows;
	
	/*************************************************************************************************
    GETTERS
**************************************************************************************************/
	
	public WebElement getReportsLink(){
		return reportsLink;
	}
	public WebElement getReportClass(){
		return reportClass;
	}
	public WebElement getmutualFundSpan(){
		return mutualFundSpan;
	}
	public WebElement getmutualFundFolder(){
		return mutualFundFolder;
	}
	public WebElement getwaitMutualFund(){
		return waitMutualFund;
	}
	public WebElement getmutualFundList(){
		return mutualFundList;
	}
	public WebElement getselectMutualFund(){
		return selectMutualFund;
	}
	public WebElement getChartSymbol(){
		return chartSymbol;
	}
	public List<WebElement> getriOptions(){
		return riOptions;
	}
	public WebElement getRiArrow(){
		return riArrow;
	}
	public WebElement getRelatedInfoTab(){
		return relatedInfoTab;
	}
	public List<WebElement> getprofileTables(){
		return profileTables;
	}
	public List<WebElement> getfundOverviewTabInfo(){
		return fundOverviewTabInfo;
	}
	public List<WebElement> getexpensesTableInfo(){
		return expensesTableInfo;
	}
	public List<WebElement> gettaxEfficiency(){
		return taxEfficiency;
	}
	public List<WebElement> getpurchaseDetails(){
		return purchaseDetails;
	}
	public WebElement geturlField(){
		return urlField;
	}
	public WebElement getshowAllFundsInFamily(){
		return showAllFundsInFamily;
	}
	public WebElement getsideBarRI(){
		return sideBarRI;
	}
	public WebElement getlistPanel(){
		return listPanel;
	}
	public WebElement getspecialList(){
		return specialList;
	}
	public WebElement getsymbolInformation(){
	   	return symbolInformation;
	}
	public List<WebElement> getreturnsTableNames(){
		return returnsTableNames;
	}
	public List<WebElement> getcurrentTableColumns(){
		return currentTableColumns;
	}
	public List<WebElement> getpriorMonthTableColumns(){
		return priorMonthTableColumns;
	}
	public WebElement getSymbolEntryField(){
		return symbolEntryField;
	}
	
	public List<WebElement> getcurrentTableRows(){
		return currentTableRows;
	}
	
	public List<WebElement> getpriorMonthTableRows(){
		return priorMonthTableRows;
	}
	
	public List<WebElement> getnoNameTableRows(){
		return noNameTableRows;
	}
	
	public List<WebElement> gettableHeadersRiskTab(){
		return tableHeadersRiskTab;
	}
	
	public List<WebElement> getstdDevTableColumns(){
		return stdDevTableColumns;
	}
	
	public List<WebElement> getcoeffVarTableColumns(){
		return coeffVarTableColumns;
	}
	
	public List<WebElement> getsharpRatioTableColumns(){
		return sharpRatioTableColumns;
	}
	
	public List<WebElement> getstdDeviationTableRows(){
		return stdDeviationTableRows;
	}
	
	public List<WebElement> getCoefficientVarRows(){
		return coefficientVarRows;
	}
	
	public List<WebElement> getsharpeRatioRows(){
		return sharpeRatioRows;
	}
}
