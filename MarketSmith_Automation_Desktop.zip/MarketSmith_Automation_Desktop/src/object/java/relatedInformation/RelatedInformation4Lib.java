package relatedInformation;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class RelatedInformation4Lib {
	
	// Symbol
	@FindBy(css = "div.symbolInformation")
	private WebElement symbol;
	
	// gets text box
	@FindBy(css = "input.symbolsInput")
	private WebElement textbox;
	
	// get S&P5
	@FindBy(css = ".listItem>td>span>strong")
	//@FindBy(xpath = "//strong[text()='0S&P5']")
	private WebElement SP5link;
	
	// Right Sidebar
	@FindBy(css = "div.sidebar.relatedInformation > div.label.communityImg.label_arrowHV")
	private WebElement rightsidebar;
	
	// Climate Tab
	@FindBy(css ="div.infoOption.climateOp.toolTip-help")
	private WebElement climateTab ;
	
	// News Tab
	@FindBy(css = "div.infoOption.newsOp.toolTip-help")
	private WebElement newstab;
	
	// Economic Table under Climate
	@FindBy(css = "div.EconDataTitle")
	private WebElement economic_Calander;

	// Psychological Indicators under Climate
	@FindBy(css = "div.PsyDataMoreTitle")
	private WebElement psychological_Indicator;
	
	
	// Name of Column of Economic Calander
	@FindAll(@FindBy(css = "table.EconDataTable > tbody > tr:nth-of-type(3) > td"))
	private List<WebElement> column_EconomicCalander;
	
	@FindBy(css = "input.rd12month")
	private WebElement psycological_12monthRDbutton;
	
	@FindBy(css = "input.rd5year")
	private WebElement psycological_5yearRDbutton;
	
	// Name of Column of Psycological Indicator
	@FindAll(@FindBy(css = "table.PsyDataTable > tbody > tr:nth-of-type(1) > td"))
	private List<WebElement> column_PsycologicalIndiator;
	
	// Name of Index in Psycological Indicator
	@FindAll(@FindBy(css = "table.PsyDataTable>tbody>tr>td>div"))
	private List<WebElement> index_PsycologicalIndicator;
	
	// Show More Information Button
	@FindBy(css = "div.showMoreClimateInformation.chartButton.toolTip-help")
	private WebElement showMoreInfo;

	// Get Released Column in Economic Calendar
	@FindBy(css = "div.EconTableDiv>table.EconTable > tbody > tr > td:nth-of-type(2)")
	private WebElement released_EconomicCalendar;
	
	// Get Prior Column in Economic Calendar
	@FindBy(css = "div.EconTableDiv>table.EconTable > tbody > tr > td:nth-of-type(6)")
	private WebElement prior_EconomicCalendar;
	
	// Table in Psycological Indicator
	@FindBy(css = "div.PsyTableScroll")
	private WebElement table_PyscologicalIndicator;
	
	// Graph in Psycological Indicator
	@FindBy(css = "div.chartLabelCnt")
	private WebElement graph_PyscologicalIndicator;
	
	// Date in Economic Calendar
	@FindAll(@FindBy(css = "table.EconDataTable > tbody > tr > td[colspan='4']"))
	private List<WebElement> date_EconomicCalendar;
	
	// Scroll in Economic Calendar
	@FindBy(css = "div.EconTableScroll")
	private WebElement scroll_EconomicCal;
	
	// Scroll in Psycological Indicator
	@FindBy(css = "div.PsyTableScroll")
	private WebElement scroll_PsycologicalCal;
	
	// 1st Heading of Graph in Psycological Graph
	@FindBy(css = "div.chartLabelCnt>div.chartTitles1")
	private WebElement graph1title_PsycologicalIndex;
	
	// 1st Heading of Graph in Psycological Graph
	@FindBy(css = "div.chartLabelCnt>div.chartTitles2")
	private WebElement graph2title_PsycologicalIndex;
		
	// Show Less Information Button
	@FindBy(css = "div.showLessClimateInformation.chartButton")
	private WebElement showLessinfo;
	
	// Get Window Button
	@FindBy(css = "input.popUpPanel.toolTip-help")
	private WebElement windowbutton;
	
	// Get Heading of ne Pop-up
	@FindBy(css = "h2.tableHeader")
	private WebElement heading_Popup;
	
	// Get Print Button
	@FindBy(css = "span.printBtn")
	private WebElement print_Button;
	
	// Get CSV Buttun
	@FindBy(css = "input.exportPanel.toolTip-help")
	private WebElement csv_Button;
	
	// Close Button on right sidebar
	@FindBy(css = "div:nth-of-type(2)>div.closePanel.toolTip-help")
	private WebElement closeButton_RideSidebar;
	
	// News Content in News Tab
	@FindBy(css = "div.newsContent")
	private WebElement newscontent_NewsTab;
	
	// News in News Content in News Tab
	@FindAll(@FindBy(css = "div.newsContent>div"))
	private List<WebElement> news_newsContent;
	
	// Refresh News Link
	@FindBy(css = "div.newsRefresh.toolTip-help")
	private WebElement refresh_news;
	
	// Edit News Box
	@FindBy(css = "div.editNews")
	private WebElement editNews_NewsTab;
	
	// Edit News content
	@FindAll(@FindBy(css = "div.newsOption>div>span"))
	private List<WebElement> editNews_Content;
	
	// Check Google News checkbox
	@FindBy(css = "input.googleChk")
	private WebElement google_chkbox;
	
	// Window Icon in News 
	@FindBy(css = "input.popUpPanel.toolTip-help")
	private WebElement window_News;
	
	// New News Window Haeding
	@FindBy(css = "div.newsTitle")
	private WebElement news_Heading;
	
	// Refresh Button in News Section
	@FindBy(css = "div.newsRefresh.toolTip-help")
	private WebElement refresh_Button;
	
/*************************************************************************************************
    									GETTERS
**************************************************************************************************/
	
	public WebElement getTextbox() {
		return textbox;
	}

	
	public WebElement getSP5link() {
		return SP5link;
	}

	public WebElement getSymbol() {
		return symbol;
	}

	public WebElement getRightsidebar() {
		return rightsidebar;
	}


	public WebElement getClimateTab() {
		return climateTab;
	}


	public WebElement getEconomic_Calander() {
		return economic_Calander;
	}


	public WebElement getPsychological_Indicator() {
		return psychological_Indicator;
	}


	public List<WebElement> getColumn_EconomicCalander() {
		return column_EconomicCalander;
	}


	public WebElement getNewstab() {
		return newstab;
	}


	public WebElement getPsycological_12monthRDbutton() {
		return psycological_12monthRDbutton;
	}


	public WebElement getPsycological_5yearRDbutton() {
		return psycological_5yearRDbutton;
	}

	
	public List<WebElement> getColumn_PsycologicalIndiator() {
		return column_PsycologicalIndiator;
	}

	public List<WebElement> getIndex_PsycologicalIndicator() {
		return index_PsycologicalIndicator;
	}

	public WebElement getShowMoreInfo() {
		return showMoreInfo;
	}

	public WebElement getReleased_EconomicCalendar() {
		return released_EconomicCalendar;
	}

	public WebElement getPrior_EconomicCalendar() {
		return prior_EconomicCalendar;
	}

	public WebElement getTable_PyscologicalIndicator() {
		return table_PyscologicalIndicator;
	}

	public WebElement getGraph_PyscologicalIndicator() {
		return graph_PyscologicalIndicator;
	}

	public List<WebElement> getDate_EconomicCalendar() {
		return date_EconomicCalendar;
	}

	public WebElement getScroll_EconomicCal() {
		return scroll_EconomicCal;
	}

	public WebElement getScroll_PsycologicalCal() {
		return scroll_PsycologicalCal;
	}

	public WebElement getGraph1title_PsycologicalIndex() {
		return graph1title_PsycologicalIndex;
	}

	public WebElement getGraph2title_PsycologicalIndex() {
		return graph2title_PsycologicalIndex;
	}

	public WebElement getShowLessinfo() {
		return showLessinfo;
	}

	public WebElement getWindowbutton() {
		return windowbutton;
	}

	public WebElement getHeading_Popup() {
		return heading_Popup;
	}

	public WebElement getPrint_Button() {
		return print_Button;
	}

	public WebElement getCsv_Button() {
		return csv_Button;
	}

	public WebElement getCloseButton_RideSidebar() {
		return closeButton_RideSidebar;
	}

	public WebElement getNewscontent_NewsTab() {
		return newscontent_NewsTab;
	}

	public List<WebElement> getNews_newsContent() {
		return news_newsContent;
	}

	public WebElement getRefresh_news() {
		return refresh_news;
	}

	public WebElement getEditNews_NewsTab() {
		return editNews_NewsTab;
	}

	public List<WebElement> getEditNews_Content() {
		return editNews_Content;
	}

	public WebElement getGoogle_chkbox() {
		return google_chkbox;
	}

	public WebElement getWindow_News() {
		return window_News;
	}

	public WebElement getNews_Heading() {
		return news_Heading;
	}

	public WebElement getRefresh_Button() {
		return refresh_Button;
	}
	

	//Related Infor Left Arrow Icon
	@FindBy(css=".labelAfter.communityImg.label_arrow.label_arrowHV.toLeftArrow")
	private WebElement relatedInfoArrowIcon;
	
	//Related Info Right Arrow Icon
	@FindBy(css=".labelAfter.communityImg.label_arrow.label_arrowHV.labelAfterSmall")
	private WebElement relatedInfoRightArrow;
		
	//std deviation table rows
	@FindAll(@FindBy(css=".RiskPanel.subPanel.subPanelShow>table:nth-of-type(1)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> stdDeviationTableRows;
	
	//coeff variation table rows
	@FindAll(@FindBy(css=".RiskPanel.subPanel.subPanelShow>table:nth-of-type(2)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> coefficientVarRows;
	
	//sharp ratio
	@FindAll(@FindBy(css=".RiskPanel.subPanel.subPanelShow>table:nth-of-type(3)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> sharpeRatioRows;
	
	//Risk Last Table Headers
	@FindAll(@FindBy(css=".riskContentTable2>tbody>tr>th"))
	private List<WebElement> lastTableHeaders;
	
	//Last Table
	@FindBy(css=".RiskPanel.subPanel.subPanelShow>table:nth-of-type(4)>tbody>tr>td:nth-of-type(1):not([class='underlineWords'])")
	private List<WebElement> lastTableData;
	
	//Holding Tab
	@FindBy(css=".infoOption.holdingsOp.toolTip-help")
	private WebElement holdingButton;
	
	//Holding Tab Tables 
	@FindBy(css="div.holdingsContent>table>tbody>tr>th.header")
	private List<WebElement> holdingsTable;
	
	//summery Table rows
	@FindBy(css="table.holdingsContentTableFirst>tbody>tr>td:nth-of-type(1)")
	private List<WebElement> summeryTableContent;
	
	//Asset Allocation Table content
	@FindBy(css="table.holdingsContentTableSecond>tbody>tr>td:nth-of-type(1)")
	private List<WebElement> columnOneContent;
	
	//Asset Allocation Table content
	@FindBy(css="table.holdingsContentTableSecond>tbody>tr>td:nth-of-type(3)")
	private List<WebElement> columnThreeContent;
	
	//Asset Allocation Table content
	@FindBy(xpath="//table[contains(@class,'holdingsContentTableSecond')]/tbody/tr/td[contains(text(),'%')]")
	private List<WebElement> percentageData;
	
	//Percentage Assets Table content
	@FindBy(css="table.holdingsContentTableFourth>tbody>tr:nth-of-type(2)>td")
	private List<WebElement> percentAssetsColumn;
	
	//percentage Assets Values
	@FindBy(css="table.holdingsContentTableFourth>tbody>tr>td:nth-of-type(3)")
	private List<WebElement> percentAssetsValues;
	
	//show holdings Button
	@FindBy(css=".showAllHoldings>span")
	private WebElement showAllHoldingsLink;
	
	//Relative Information sideBar Background
	@FindBy(css=".infoPanel.infoPanelActive")
	private WebElement sideBarBackGround;
	
	@FindBy(css=".infoPanel")
	private WebElement sideBarPanel;
	
	//List manager Cover Higlighted
	@FindBy(css="div[class='listManagerCover'][style='display: block;']")
	private WebElement listManagerCover;
			
	//List Manager Symbols
	@FindBy(css="div:nth-of-type(8) > div:nth-of-type(2) > div > div > div:nth-of-type(4) > div > span")
	private List<WebElement> listManagerSymbols;
	
	//Symbol INPUT Search Text Box
	@FindBy(css=".symbolsInput.symbolsInput")
	private WebElement searchSymbol;
	
	//Tool tip window icon
	@FindBy(css=".popUpPanel.toolTip-help")
	private WebElement windowTooltipIcon;
	
	//Print Tool Tip
	@FindBy(css=".printPanel.toolTip-help")
	private WebElement printToolTip;
	
	//Down load Tool Tip
	@FindBy(css=".exportPanel.toolTip-help")
	private WebElement downloadToolTip;
	
	//holdings Window popup title
	@FindBy(css=".holdingsTitle")
	private WebElement holdingsTitle;
	
	//11 Sectors List
	@FindBy(xpath="//table[contains(@class,'holdingsContentTableThird')]/tbody/tr/td[not(contains(text(),'%'))]")
	private List<WebElement> sectorsList;
	
	//11 sectors Percentage List
	@FindBy(xpath="//table[contains(@class,'holdingsContentTableThird')]/tbody/tr/td[contains(text(),'%')]")
	private List<WebElement> sectorListPercent;
			
	//List Name in List Manager 
	@FindBy(css=".listItemName")
	private WebElement listName;
	
	//Print Button
	@FindBy(css=".printBtn")
	private WebElement printButton;
	
	//Close Icon
	@FindBy(css=".infoPanel>div:nth-of-type(10)")
	private WebElement closeIcon;
			
	/*******************************************************************************************************
	 *                                       Getters                                                       *
	********************************************************************************************************/
	
	public WebElement getrelatedInfoArrowIcon() {
		return relatedInfoArrowIcon;
	}
	
	public WebElement getrelatedInfoRightArrow() {
		return relatedInfoRightArrow;
	}
	
	public List<WebElement> getstdDeviationTableRows(){
		return stdDeviationTableRows;
	}
	
	public List<WebElement> getCoefficientVarRows(){
		return coefficientVarRows;
	}
	
	public List<WebElement> getsharpeRatioRows(){
		return sharpeRatioRows;
	}
	
	public List<WebElement> getlastTableHeaders() {
		return lastTableHeaders;
	}
	
	public List<WebElement> getlastTableData() {
		return lastTableData;
	}
	
	public WebElement getholdingButton() {
		return holdingButton;
	}
	
	public List<WebElement> getholdingsTable() {
		return holdingsTable;
	}
	
	public List<WebElement> getsummeryTableContent() {
		return summeryTableContent;
	}
	
	public List<WebElement> getcolumnOneContent() {
		return columnOneContent;
	}
	
	public List<WebElement> getcolumnThreeContent() {
		return columnThreeContent;
	}
	 
	public List<WebElement> getpercentageData() {
		return percentageData;
	}
	
	public List<WebElement> getpercentAssetsColumn() {
		return percentAssetsColumn;
	}
	
	public List<WebElement> getpercentAssetsValues() {
		return percentAssetsValues;
	}
	
	public WebElement getshowAllHoldingsLink() {
		return showAllHoldingsLink;
	}
	
	public WebElement getsideBarBackGround() {
		return sideBarBackGround;
	}
	
	public WebElement getsideBarPanel() {
		return sideBarPanel;
	}
	
	public WebElement getlistManagerCover() {
		return listManagerCover;
	}
	
	public List<WebElement> getlistManagerSymbols() {
		return listManagerSymbols;
	}
		
	public WebElement getsearchSymbol() {
		return searchSymbol;
	}
	
	public WebElement getwindowTooltipIcon() {
		return windowTooltipIcon;
	}
	
	public WebElement getprintToolTip() {
		return printToolTip;
	}
	
	public WebElement getdownloadToolTip() {
		return downloadToolTip;
	}
	
	public WebElement getholdingsTitle() {
		return holdingsTitle;
	}
	
	public List<WebElement> getsectorsList() {
		return sectorsList;
	}
	
	public List<WebElement> getsectorListPercent() {
		return sectorListPercent;
	}
	
	public WebElement getlistName() {
		return listName;
	}
	
	public WebElement getprintButton() {
		return printButton;
	}
	
	public WebElement getcloseIcon() {
		return closeIcon;
	}

	
}
