package relatedInformation;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class RelatedInformation1Lib {
    //locate arrow of related information
	@FindBy(css="div.sidebar.relatedInformation > div:nth-of-type(2) > div > div")
	private WebElement riArrow;
	
	//locate RI tab
	@FindBy(css="div.sidebar.relatedInformation > div:nth-of-type(2) > div > span")
	private WebElement relatedInfoTab;
	
	//Click on symbol entry field
	@FindBy(css="body > div.MST > div.header > input")
	private WebElement symbolEntryField;
	
	//get chart information
	@FindBy(css=".symbolInformation")
	private WebElement chartSymbol;
	
	//locate symbol information
	@FindBy(css=".companySymbol")
	private WebElement symbolInformation;
	
	//locate RI options for MF
	@FindAll(@FindBy(xpath="//div[@class='optionPanel']/div[@style='' or @style='display: block;']"))
	private List<WebElement> riOptions;
	
	//locate owners and Funds tables
	@FindAll(@FindBy(css=".ownershipContentTable>tbody>tr:nth-of-type(1)>th>div"))
	private List<WebElement> ownersAndFundsTables;
	
	//locate institutional ownership table content
	@FindAll(@FindBy(css=".ownershipContentTable:nth-of-type(1)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> institutionalTableContent;
	
	//locate management ownership table content
	@FindAll(@FindBy(css=".ownershipContentTable:nth-of-type(2)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> managementTableContent;
	
	//locate fund ownership headers
	@FindAll(@FindBy(css=".ownershipContentTable:nth-of-type(3)>tbody>tr>td:nth-of-type(1)>div>div"))
	private List<WebElement> fundOwnershipTableHeader;
	
	//locate contents of fund ownership headers
	@FindAll(@FindBy(css=".ownershipContentTable:nth-of-type(3)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> fundOwnwershipTableContent;
	
	//locate  show fund ownership  button
	@FindBy(css="div.infoPanel > div:nth-of-type(12) > div>span")
	private WebElement showFundOwnership;
	
	//locate list manager  right side
	@FindBy(css=".listDetail>div:nth-of-type(2)")
	private WebElement listPanel;
	
	//locate side bar
	@FindBy(css=".sidebar.relatedInformation>div.content>div:nth-of-type(2)")
	private WebElement sideBarRI;
	
	//locate ownership  list
	@FindBy(css="div#listSpecial > div:nth-of-type(1)")
    private WebElement specialList;
	
	//locate show all funds in Family button
	@FindBy(css="div.infoPanel > div:nth-of-type(22) > div:nth-of-type(3)>span")
	private WebElement showAllFundsInFamily; 
	
	//locate contents of Industry and ownership contents
	@FindAll(@FindBy(css=".IsPanel.subPanel.subPanelShow>div>div.Ish1"))
	private List<WebElement> industryAndSectorContents;
	
	//locate industry group in industry and sector
	@FindBy(css=".IsPanel.subPanel.subPanelShow>div:nth-of-type(1)>div.Ish2")
	private WebElement industryGroupName;
	
	//locate today 
	@FindBy(css=".IsPanel.subPanel.subPanelShow>div:nth-of-type(1)>div.Ish3Left")
	private WebElement todayLabel;
	
	//locate %change
	@FindBy(css=".IsPanel.subPanel.subPanelShow>div:nth-of-type(1)>div.Ish3Left>font")
	private WebElement percentageChange;
	
	//locate YTD:
	@FindBy(css=".IsPanel.subPanel.subPanelShow>div:nth-of-type(1)>div.Ish3Right")
	private WebElement ytdLabel;
	
	//locate performance change
	@FindBy(css=".IsPanel.subPanel.subPanelShow>div:nth-of-type(1)>div.Ish3Right>font")
	private WebElement performanceChange;
	
	//locate chart icon
	@FindBy(css=".IsPanel.subPanel.subPanelShow>div:nth-of-type(1)>div.Ish2>div")
	private WebElement chartIcon;
	
	//locate industry group table names
	@FindAll(@FindBy(css=".IsPanel.subPanel.subPanelShow>div>table>tbody>tr>th"))
	private List<WebElement> industryGroupTables; 
	
	//locate industry summary table contents
	@FindAll(@FindBy(css=".IsPanel.subPanel.subPanelShow>div>table:nth-of-type(1)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> industrySummaryTableContents;
	
	//locate stock rank table contents
	@FindAll(@FindBy(css=".IsPanel.subPanel.subPanelShow>div>table:nth-of-type(2)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> stockRankTableContents;
	
	//locate  view stocks in industry button
	@FindBy(css=".IsPanel.subPanel.subPanelShow>div:nth-of-type(1)>div:nth-of-type(5)>span")
	private WebElement viewStocksinIndustryButton;
	
	//locate sector name
	@FindBy(css=".IsPanel.subPanel.subPanelShow>div:nth-of-type(2)>div:nth-of-type(2)")
	private WebElement sectorName;
	
	//locate industry in sector table
	@FindBy(css=".IsPanel.subPanel.subPanelShow>div:nth-of-type(2)>div:nth-of-type(3)>div>table>tbody>tr>th")
	private WebElement topIndustriesinSectorsTable;
	
	//locate top industries table data 
	@FindAll(@FindBy(css=".IsPanel.subPanel.subPanelShow>div:nth-of-type(2)>div:nth-of-type(3)>div>table>tbody>tr>td.right"))
	private List<WebElement> rsRatingsOfAllIndustryGroups;
	
	//locate view more details link
	@FindBy(css=".IsPanel.subPanel.subPanelShow>div:nth-of-type(2)>div:nth-of-type(3)>div:nth-of-type(2)>a")
	private WebElement viewMoreDetailsLink;
	
	//get all the tickers
	@FindAll(@FindBy(css="div.freezeVirtualizedPanel > div > div:nth-of-type(5)>div>span"))
	private List<WebElement> symbolList;
	
	//locate view stocks in sector
	@FindBy(css=".IsPanel.subPanel.subPanelShow>div:nth-of-type(2)>div:nth-of-type(4)>span")
	private WebElement viewStocksinSector;
	
	//locate RI close button
	@FindBy(css=".infoPanel>div:nth-of-type(10)")
	private WebElement riCloseButton;
	
	//locate information panel
	@FindBy(css=".infoPanel")
	private WebElement informationPanel;
	
	//locate list of news
	@FindAll(@FindBy(css="div.newsContent > div > a"))
	private List<WebElement> newsList; 
	
	//locate edit news drop down
	@FindBy(css=".editNews")
	private WebElement editNewsDropDown;
	
	//locate options window
	@FindBy(css=".newsOption")
	private WebElement newsOptionWindow;

	//locate all options
	@FindAll(@FindBy(css=".newsOption>div>span"))
	private List<WebElement> allNewsOptions;
	
	//locate options tables
	@FindAll(@FindBy(css=".OptionsPanel.subPanel.subPanelShow>div>div:nth-of-type(2)>div"))
	private List<WebElement> optionsTables;
	
	//locate stockData labels
	@FindAll(@FindBy(css=".stockDataTablDiveCnt>.stockDataTable>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> stockDataLabels;
	
	//locate stock data table values
	@FindAll(@FindBy(css=".stockDataTablDiveCnt>.stockDataTable>tbody>tr>td:nth-of-type(2)"))
	private List<WebElement> stockDataTableData;
	
	//locate calls table header
	@FindAll(@FindBy(css=".callsTable>tbody>tr>th"))
	private List<WebElement> callsTableHeader;
	
	//locate puts table header
	@FindAll(@FindBy(css=".putsTable>tbody>tr>th"))
	private List<WebElement> putsTableHeader;
	
	//locate disclaimer message
	@FindBy(css=".optionsBottomCnt>span")
	private WebElement disclaimerMessage;
	
	//locate show more information
	@FindBy(css=".optionsBottomCnt>div")
	private WebElement showMoreInfo;
	
	//locate more info panel
	@FindBy(css=".optionsMoreInfoPanel")
	private WebElement optionsMoreInfoPanel;
	
	//locate options information
	@FindAll(@FindBy(css=".viewSymbolInfoTitle>span"))
	private List<WebElement> optionsInformation;
	
	//locate viewBy radio Buttons
	@FindAll(@FindBy(css="div.viewPreferenceCnt > input"))
	private List<WebElement> viewByRadioButtons;
	
	//locate view by 
	@FindBy(css="div.viewPreferenceCnt > span:nth-of-type(1)")
	private WebElement viewByInfo;
	
	//locate preference link
	@FindBy(css=".viewPreferenceCnt>a")
	private WebElement preferenceLink;
	
	//locate change preference window
	@FindBy(css=".changePreferenceCnt")
	private WebElement changePreferencewindow;
	
	//locate expiration month 
	@FindBy(css=".expirationMonthSel")
	private WebElement expirationMonthDropDown;
	
	//locate strikes options
	@FindBy(css=".showOptionsSel")
	private WebElement strikeOptionDropdown;
	
	//locate expiration details extend button
	@FindBy(css=".expirationViewTab>div:nth-of-type(1)>div>span")
	private WebElement expirationDateDetails;
	
	//locate calls puts and strike
	@FindAll(@FindBy(css=".expirationTable>tbody>tr:nth-of-type(1)>th"))
	private List<WebElement> callsPutsStrikeHeader;
	
	//locate strike prices
	@FindAll(@FindBy(css=".strikeViewTab>div>div:nth-of-type(1)>div"))
	private List<WebElement> strikePricesList;
	
	//locate all labels of strike price
	@FindAll(@FindBy(css="div:nth-of-type(1)>div.child>.strikePriceTable>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> strikePriceLabels;
	
	//locate checkList  content
	@FindBy(css=".chkListContent")
	private WebElement checkListContent;
	
	//locate checkList dropdown
	@FindBy(css=".chkSelectText")
	private WebElement checkListDropdown;
	
	//locate text above the dropdown
	@FindBy(css=".stateBase")
	private WebElement textAboveDropdown;
	
	//locate screener Panel
	@FindBy(css="body > div.MST > div.sidebar.screenerAlertsAndNotes > div.label.communityImg.label_arrowHV > div > div")
	private WebElement leftPanelScreenerButton;
	
	//locate MY Screens List folder
	@FindBy(css="div#MyScreens > div:nth-of-type(1)")
	private WebElement myScreensFolder;
	
	//locate marketsmith Stock screens Folder
	@FindBy(css="div#MarketSmithStockScreens > div:nth-of-type(1)")
	private WebElement msScreensFolder;
	
	//locate all screens span to get stock screen
	@FindAll(@FindBy(xpath="//div[@id='MyScreens']/div/div/span[contains(@class,'stock')]/following-sibling::label"))
	private List<WebElement> myScreensSpan;
	
	//locate marketsmith stock all  screens
	@FindAll(@FindBy(css="div#MarketSmithStockScreens > div:nth-of-type(2) > div > label"))
	private List<WebElement> msStockScreens;
	
	//locate all checkListScreens
	@FindAll(@FindBy(css=".chkListSelOption>li"))
	private List<WebElement> allCheckListScreens;
	
	//wait for all screen options
	@FindBy(css=".chkListSelOption")
	private WebElement waitForChecklistDoptions;
	
	//locate calls data
	@FindAll(@FindBy(css=".callsTable>tbody>tr:nth-of-type(2)>td"))
	private List<WebElement> callsData;
	
	//locate puts data
	@FindAll(@FindBy(css=".putsTable>tbody>tr:nth-of-type(2)>td"))
	private List<WebElement> putsData;
	
	//locate stockdata tabel data
	@FindBy(css=".stockDataTablDiveCnt > table > tbody > tr:nth-of-type(1) > td:nth-of-type(2)")
	private WebElement stockTableData;
	
	//locate all expiration Details
	@FindAll(@FindBy(css=".expirationViewTab>div>div>.cellExtendButton"))
	private List<WebElement> expirationDates;
	
	//Locate selected screen
	@FindBy(css=".chkSelectText")
	private WebElement selectedScreenList;
	
	//locate all passFail criteria
	@FindAll(@FindBy(css=".chkListContent>div>table>tbody>tr>td:nth-of-type(2)"))
	private List<WebElement> passFailCriteria;
	
	//locate checklist %
	@FindBy(css=".chkListDetailTitle")
	private WebElement checListPercentage;
	
	//locate failed criteria
	@FindAll(@FindBy(xpath="//div[@class='chkListContent']/div/table/tbody/tr[contains(@style,'color: rgb(255, 0, 0);')]/td[2]"))
	private List<WebElement> redCriteria;
	
	//locate all the newsdates
	@FindAll(@FindBy(css="div.newsItem.yahooFinanceNewsItem>div:nth-of-type(1)"))
	private List<WebElement> allNewsDates;
	/*************************************GETTERS******************************
	 **********************************************/
	public WebElement getRiArrow(){
		return riArrow;
	}
	public WebElement getRelatedInfoTab(){
		return relatedInfoTab;
	}
	public WebElement getSymbolEntryField(){
		return symbolEntryField;
	}
	public WebElement getChartSymbol(){
	    	return chartSymbol;
	}
	public WebElement getsymbolInformation(){
	   	return symbolInformation;
	}
	public List<WebElement> getriOptions(){
		return riOptions;
	}
	public List<WebElement> getownersAndFundsTables(){
		return ownersAndFundsTables;
	}
	public List<WebElement> getinstitutionalTableContent(){
		return institutionalTableContent;
	}
	public List<WebElement> getmanagementTableContent(){
		return managementTableContent;
	}
	public List<WebElement> getfundOwnershipTableHeader(){
		return fundOwnershipTableHeader;
	}
	public List<WebElement> getfundOwnwershipTableContent(){
		return fundOwnwershipTableContent;
	}
	public WebElement getshowFundOwnership(){
		return showFundOwnership;
	}
	public WebElement getlistPanel(){
		return listPanel;
	}
	public WebElement getsideBarRI(){
		return sideBarRI;
	}
	public WebElement getspecialList(){
		return specialList;
	}
	public WebElement getshowAllFundsInFamily(){
		return showAllFundsInFamily;
	}
	public List<WebElement> getindustryAndSectorContents(){
		return industryAndSectorContents;
	}
	public WebElement getindustryGroupName(){
		return industryGroupName;
	}
	public WebElement gettodayLabel(){
		return todayLabel;
	}
	public WebElement getpercentageChange(){
		return percentageChange;
	}
	public WebElement getytdLabel(){
		return ytdLabel;
	}
	public WebElement getperformanceChange(){
		return performanceChange;
	}
	public WebElement getchartIcon(){
		return chartIcon;
	}
	public List<WebElement> getindustryGroupTables(){
		return industryGroupTables;
	}
	public List<WebElement> getindustrySummaryTableContents(){
		return industrySummaryTableContents;
	}
	public List<WebElement> getstockRankTableContents(){
		return stockRankTableContents;
	}
	public WebElement getviewStocksinIndustryButton(){
		return viewStocksinIndustryButton;
	}
	public WebElement getsectorName(){
		return sectorName;
	}
	public WebElement gettopIndustriesinSectorsTable(){
		return topIndustriesinSectorsTable;
	}
	public List<WebElement> getrsRatingsOfAllIndustryGroups(){
		return rsRatingsOfAllIndustryGroups;
	}
	public WebElement getviewMoreDetailsLink(){
		return viewMoreDetailsLink;
	}
	public List<WebElement> getsymbolList(){
	 	return symbolList;
	}
	public WebElement getviewStocksinSector(){
	    return viewStocksinSector;
	}
	public WebElement getriCloseButton(){
		return riCloseButton;
	}
	public WebElement getinformationPanel(){
		return informationPanel;
	}
	public List<WebElement> getnewsList(){
		return newsList;
	}
	public WebElement geteditNewsDropDown(){
		return editNewsDropDown;
	}
	public WebElement getnewsOptionWindow(){
		return newsOptionWindow;
	}
	public List<WebElement> getallNewsOptions(){
		return allNewsOptions;
	}
	public List<WebElement> getoptionsTables(){
		return optionsTables;
	}
	public List<WebElement> getstockDataLabels(){
		return stockDataLabels;
	}
	public List<WebElement> getstockDataTableData(){
		return stockDataTableData;
	}
	public List<WebElement> getcallsTableHeader(){
		return callsTableHeader;
	}
	public List<WebElement> getputsTableHeader(){
		return putsTableHeader;
	}
	public WebElement getdisclaimerMessage(){
		return disclaimerMessage;
	}
	public WebElement getshowMoreInfo(){
		return showMoreInfo;
	}
	public WebElement getoptionsMoreInfoPanel(){
		return optionsMoreInfoPanel;
	}
	public List<WebElement> getoptionsInformation(){
		return optionsInformation;
	}
	public List<WebElement> getviewByRadioButtons(){
		return viewByRadioButtons;
	}
	public WebElement getviewByInfo(){
		return viewByInfo;
	}
	public WebElement getpreferenceLink(){
		return preferenceLink;
	}
	public WebElement getchangePreferencewindow(){
		return changePreferencewindow;
	}
	public WebElement getexpirationMonthDropDown(){
		return expirationMonthDropDown;
	}
	public WebElement getstrikeOptionDropdown(){
		return strikeOptionDropdown;
	}
	public WebElement getexpirationDateDetails(){
		return expirationDateDetails;
	}
	public List<WebElement> getcallsPutsStrikeHeader(){
		return callsPutsStrikeHeader;
	}
	public List<WebElement> getstrikePricesList(){
		return strikePricesList;
	}
	public List<WebElement> getstrikePriceLabels(){
		return strikePriceLabels;
	}
	public WebElement getcheckListContent(){
		return checkListContent;
	}
	public WebElement getcheckListDropdown(){
		return checkListDropdown;
	}
	public WebElement gettextAboveDropdown(){
		return textAboveDropdown;
	}
	public WebElement getLeftPanelScreenerButton(){
		return leftPanelScreenerButton;
	}
	public WebElement getmyScreensFolder(){
		return myScreensFolder;
	}
	public WebElement getmsScreensFolder(){
		return msScreensFolder;
	}
	public List<WebElement> getmyScreensSpan(){
		return myScreensSpan;
	}
	public List<WebElement> getallCheckListScreens(){
		return allCheckListScreens;
	}
	public WebElement getwaitForChecklistDoptions(){
		return waitForChecklistDoptions;
	}
	public List<WebElement> getmsStockScreens(){
		return msStockScreens;
	}
	public List<WebElement> getcallsData(){
		return callsData;
	}
	public List<WebElement> getputsData(){
		return putsData;
	}
	public WebElement getstockTableData(){
		return stockTableData;
	}
	public List<WebElement> getexpirationDates(){
		return expirationDates;
	}
	public WebElement getselectedScreenList(){
		return selectedScreenList;
	}
	public List<WebElement> getpassFailCriteria(){
		return passFailCriteria;
	}
	public WebElement getchecListPercentage(){
		return checListPercentage;
	}
	public List<WebElement> getredCriteria(){
		return redCriteria;
	}
	public List<WebElement> getallNewsDates(){
		return allNewsDates;
	}
}
