package relatedInformation;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class RelatedInformation2Lib {
	//Markets 197 industry group
	@FindBy(css="div[id='Markets/197IndustryGroups']> div:nth-of-type(1) > label")
	private WebElement market197IndustryGroup;
	
	//locate span
	@FindBy(css="div[id='Markets/197IndustryGroups']> div:nth-of-type(1) >span")
	private WebElement market197DownLink;
	
	//197 Industry group list
	@FindBy(css="div[id='Markets/197IndustryGroups']> div:nth-of-type(2) >div:nth-of-type(2)>label")
	private WebElement m197Industrygroups;
	
	//tickerType
	@FindBy(css="div.freezeVirtualizedPanel > div:nth-of-type(1) > div:nth-of-type(6) > div > span > span[type=IndustryGroup]")
	private WebElement waitIndustryGroup;
	
	//get chart information
	@FindBy(css=".symbolInformation")
	private WebElement chartSymbol;
	
	//Select industry group
	@FindBy(css="div.freezeVirtualizedPanel > div:nth-of-type(1)> div:nth-of-type(5) > div > span")
	private WebElement selectIndustryGroup;
	
	//locate arrow of related information
	@FindBy(css="div.sidebar.relatedInformation > div:nth-of-type(2) > div > div")
	private WebElement riArrow;
	
	//locate RI tab
	@FindBy(css="div.sidebar.relatedInformation > div:nth-of-type(2) > div > span")
	private WebElement relatedInfoTab;
	
	//locate RI options
	@FindAll(@FindBy(xpath="//div[@class='optionPanel']/div[@style='' or @style='display: block;']"))
	private List<WebElement> riOptions;
	
	//locate Overview table headers
	@FindAll(@FindBy(css=".OverViewPanel>table>tbody>tr>th>div"))
	private List<WebElement> overviewTableHeaders;
	
	//locate industry summary table information
	@FindAll(@FindBy(css=".OverViewPanel>table:nth-of-type(1)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> industrySummaryInformation; 
	
	//locate relative strength table info
	@FindAll(@FindBy(css=".OverViewPanel>table:nth-of-type(2)>tbody>tr>td:nth-of-type(1)"))
	private List<WebElement> relativeStrengthInfo;
	
	//locate 197 ranking table info
	@FindAll(@FindBy(css=".OverViewPanel>table:nth-of-type(3)>tbody>tr>td:nth-of-type(1)")) 
	private List<WebElement> r197RankingInfo;
	
	//locate show IndustryGroup button
	@FindBy(css="div.infoPanel > div:nth-of-type(19) > div:nth-of-type(3) > span")
	private WebElement show197IndustryGroupButtton;
	
	//locate side bar
	@FindBy(css=".sidebar.relatedInformation>div.content>div:nth-of-type(2)")
	private WebElement sideBarRI;
		
	//locate ownership  list
	@FindBy(css="div#listSpecial > div:nth-of-type(1)")
	private WebElement specialList;
	
	//locate list manager  right side
	@FindBy(css=".listDetail>div:nth-of-type(2)")
	private WebElement listPanel;
	
	//locate stockList in stocks in Group tab
	@FindAll(@FindBy(css=".componentsSysbolName"))
	private List<WebElement> stocksList;
	
	//locate group title
	@FindBy(css=".componentsSectionSubTitle") 
	private WebElement stocksInGrpTitle;
	
	//locate table headers
	@FindAll(@FindBy(css=".componentsGroupView>tbody>tr>th"))
	private List<WebElement> stocksInGrpTableInfo;
	
	//locate market cap values
	@FindAll(@FindBy(css=".componentsGroupView>tbody>tr>td:nth-of-type(3)"))
	private List<WebElement> marketCapValues; 
	
	//locate show all component data button
	@FindBy(css=".showAllComponent.toolTip-help>span")
	private WebElement showAllComponentData;
	
	//locate symbol information
	@FindBy(css=".companySymbol")
	private WebElement symbolInformation;
	
	//locate top stocks tables
	@FindAll(@FindBy(css=".topStocksTableTitle.header"))
	private List<WebElement> topStocksTable;
		
	//locate table header of top RS+EPS stocks
	@FindAll(@FindBy(css=".topStocksTableOne>tbody>tr.topStockTableNameRow>th"))
	private List<WebElement> rsEpsTableHeader; 
	
	//locate table header of % off High
	@FindAll(@FindBy(css=".topStocksTableTwo>tbody>tr.topStockTableNameRow>th"))
	private List<WebElement> percentageOffHighTabInfo;
	
	//industry group name in sector section
	@FindBy(css=".sectorComputer")
	private WebElement industryGrpinSectorTab;
	
	//sector table info
	@FindBy(css=".sectorContentTable>tbody>tr>th")
	private WebElement sectorTabHeader;
	
	//sector table columns
	@FindAll(@FindBy(css=".sectorContentTable>tbody>tr:nth-of-type(2)>td"))
	private List<WebElement> sectorTabColumns;
	/*************************************************************************************************
	                GETTERS
**************************************************************************************************/
	public WebElement getmarket197IndustryGroup(){
		return market197IndustryGroup;
	}
	public WebElement getMarket197DownLink(){
		return market197DownLink;
	}
	public WebElement get197IndustryGroups(){
		return  m197Industrygroups;
	}
	public WebElement getWaitIndustryGroup(){
		return waitIndustryGroup;
	}
	public WebElement getChartSymbol(){
		return chartSymbol;
	}
	public WebElement getselectIndustryGroup(){
		return selectIndustryGroup;
	}
	public WebElement getRiArrow(){
		return riArrow;
	}
	public WebElement getRelatedInfoTab(){
		return relatedInfoTab;
	}
	public List<WebElement> getriOptions(){
		return riOptions;
	}
	public List<WebElement> getoverviewTableHeaders(){
		return overviewTableHeaders;
	}
	public List<WebElement> getindustrySummaryInformation(){
		return industrySummaryInformation;
	}
	public List<WebElement> getrelativeStrengthInfo(){
		return relativeStrengthInfo;
	}
	public List<WebElement> getr197RankingInfo(){
		return r197RankingInfo;
	}
	public WebElement getshow197IndustryGroupButtton(){
		return show197IndustryGroupButtton;
	}
	public WebElement getsideBarRI(){
		return sideBarRI;
	}
	public WebElement getlistPanel(){
		return listPanel;
	}
	public WebElement getspecialList(){
		return specialList;
	}
	public List<WebElement> getstocksList(){
		return stocksList;
	}
	public WebElement getstocksInGrpTitle(){
		return stocksInGrpTitle;
	}
	public List<WebElement> getstocksInGrpTableInfo(){
		return stocksInGrpTableInfo;
	}
	public List<WebElement> getmarketCapValues(){
		return marketCapValues;
	}
	public WebElement getshowAllComponentData(){
		return showAllComponentData;
	}
	public WebElement getsymbolInformation(){
	   	return symbolInformation;
	}
	public List<WebElement> gettopStocksTable(){
		return topStocksTable;
	}
	public List<WebElement> getrsEpsTableHeader(){
		return rsEpsTableHeader;
	}
	public List<WebElement> getpercentageOffHighTabInfo(){
		return percentageOffHighTabInfo;
	}
	public WebElement getindustryGrpinSectorTab(){
		return industryGrpinSectorTab;
	}
	public WebElement getsectorTabHeader(){
		return sectorTabHeader;
	}
	public List<WebElement> getsectorTabColumns(){
		return sectorTabColumns;
	}
}
