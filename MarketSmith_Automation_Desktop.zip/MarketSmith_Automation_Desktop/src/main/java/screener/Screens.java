package screener;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import genericLib.Utility;
import static genericLib.Utility.*;
import java.util.List;

import java.util.ArrayList;
import java.util.Arrays;

import listManager.ListManagerToolsLib;


public class Screens {
	ScreensPageLib pageLib = PageFactory.initElements(driver, ScreensPageLib.class);
	ListManagerToolsLib lmLib = PageFactory.initElements(driver, ListManagerToolsLib.class);
	
	/*
	* Method Description (screenerTestSetUp): SET UP Method to ensure Screen panel is displayed, LM view set to DEFAULT
	* Created By:- Michael D, Created On: 3/23/17
	* Changes made#1:
	*/
	public void screenerTestSetUp()
	{
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		//Wait for LM default view button and click
		waitUntilElementIsClickable(lmLib.getDefaultViewButton());
		if(!lmLib.getDefaultViewButton().getAttribute("class").contains("LMControlSizeBtnClicked"))
		{
			try
			{
				lmLib.getDefaultViewButton().click();
				Thread.sleep(1500);
			}catch(Exception e)
			{
				logger.info(e);
			}
		}
		else
			logger.info("LM view is set to DEFAULT.");
		//Assert that screener panel is displayed
		Assert.assertTrue(pageLib.getLeftPanelScreenerButton().isDisplayed(),"Screener left panel is NOT displayed. SET UP NOT COMPLETE");
		logger.info("SET UP COMPLETE");
	}
	
	/*
	* Method Description (selectSubPanelSetUp): Method to emphasize DRY in class methods
	* Created By:- Michael D, Created On: 3/24/17
	* Parameters:
	*   subPanel = Sub panel literal name, as in tool (ie Screens, Alerts, Notes, Blogs), being selected in current TC
	*   section = Screen section being selected for the case of SCREENS subpanel
	*   	possible values: 1=My Screens,2=Stock Screens,3=Fund Screens,4=Tracked,5=Favorite
	*
	*/
	public void selectSubPanelSetUp(String subPanel,int section)
	{
		//Select from --> Screens, Alerts, Notes, Blogs
		List<WebElement> allScreensSubPanelButtons=pageLib.getLeftScreenSubPanelButtons();
		String temp = "";
		String sp = subPanel.toLowerCase();
		
		if(!pageLib.getLeftPanelScreenerButton().getAttribute("class").contains("toLeftArrow"))
			pageLib.getLeftPanelScreenerButton().click();
		
		for(WebElement e:allScreensSubPanelButtons)
		{
			temp = e.getText().toLowerCase();
			if(temp.contains(sp))
			{
				waitUntilElementisVisible(e);
				//To NOT re-click subpanel tab in the case that it is already selected
				if(!e.getAttribute("class").contains("infoOptionClicked"))
					e.click();
				logger.info("Sub panel, "+e.getText().toUpperCase()+" was selected.");
			}
		}
		
		//If SCREENS, select from -> My Screens, MS Stock Screens, MS Fund Screens, Tracked Screens, Favorite Screens
		if(sp.contains("screens"))
		{
			switch(section)
			{
				case 1:
					if(pageLib.getmsMyScreens_SectionButton().getAttribute("class").contains("isFileOpen"))
					{
						pageLib.getmsMyScreens_SectionButton().click();
					}
					break;
				case 2:
					if(pageLib.getmsStockScreens_PresetSectionButton().getAttribute("class").contains("isFileOpen"))
					{
						pageLib.getmsStockScreens_PresetSectionButton().click();
					}
					break;
				case 3:
					if(pageLib.getmsFundScreens_PresetSectionButton().getAttribute("class").contains("isFileOpen"))
					{
						pageLib.getmsFundScreens_PresetSectionButton().click();
			
					}
					break;
				case 4:
					if(pageLib.getTrackedScreensSection_Button().getAttribute("class").contains("isFileOpen"))
					{
						pageLib.getTrackedScreensSection_Button().click();
					}
					break;
				case 5:
					if(pageLib.getFavoriteScreensSection_Button().getAttribute("class").contains("isFileOpen"))
					{
						pageLib.getFavoriteScreensSection_Button().click();
					}
					break;
				default:
					break;
			}
			Utility.waitUntilVisibilityOfElement();
		}
		
	}
	
	/*
	* Method Description (0744): Verifying screener panel is closed (includes tc0745)
	* Created By:- Michael D,
	* Changes made #1: Michael D. -  4/3/17 - updating TC name
	*/
	public void tc0744_VerifyScreenerPanelClosed(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getLeftPanelScreenerButton());
		boolean passed = false;
		String leftTabClosedText = "SCREENS, ALERTS & NOTES";
		if(pageLib.getLeftPanelScreenerButton().getAttribute("class").contains("toLeftArrow")){
			pageLib.getLeftPanelScreenerButton().click();
			logger.info("Screener is closed");
		}
		//closed: block & false
		if(leftTabClosedText.equals(pageLib.getLeftPanelScreenerText().getText())){
			logger.info("Screener tab text matches, " + leftTabClosedText );
			passed = true;
		}
		Assert.assertTrue(passed,"Closed screener text does not match, " + leftTabClosedText);
	}
	
	/*
	* Method Description (0746): Verifying screener panel is open (includes tc0747)
	* Created By:- Michael D,
	* Changes made #1: Michael D. -  4/3/17 - updating TC name
	*/
	public void tc0746_VerifyScreenerPanelOpen(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getLeftPanelScreenerButton());
		if(!pageLib.getLeftPanelScreenerButton().getAttribute("class").contains("toLeftArrow")){
			pageLib.getLeftPanelScreenerButton().click();
			logger.info("Screener is open");
		}
		
		if(pageLib.getLeftPanelScreenerText().getCssValue("display").equals("none") && pageLib.getLeftPanelScreenerButton().getAttribute("class").contains("toLeftArrow"))
			Assert.assertTrue(true);
	}
	
	/*
	* Method Description (0748): Verifying screener sub panels are displayed
	* Created By:- Michael D,
	* Changes made #1: Michael D. -  4/3/17 - updating TC name
	*/
	public void tc0748_VerifyScreenerSubPanels(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		boolean passed = false;
		List<String> screenerSubPanels = new ArrayList<String>(Arrays.asList("Screens","Alerts","Notes","Blogs"));
		waitUntilElementIsClickable(pageLib.getLeftPanelScreenerButton());
		if(!pageLib.getLeftPanelScreenerButton().getAttribute("class").contains("toLeftArrow"))
			pageLib.getLeftPanelScreenerButton().click();
		if(pageLib.getLeftScreenSubPanels().getAttribute("class").contains("expendToMedium"))
		{
			logger.info("Screener panel is expanded");
			for(WebElement e:pageLib.getLeftScreenSubPanelButtons())
			{
				logger.info("Getting screener sub panel, " + e.getText());
				if(screenerSubPanels.contains(e.getText())) passed = true;
				else passed = false;
			}
		}
		else
			logger.info("Screener panel is NOT expanded");
		
		Assert.assertTrue(passed, "Screener sub panels are NOT displayed correctly");
	}
	
	/*
	* Method Description (0749): Verify screen sub panel section headers
	* Created By:- Michael D,
	* Changes made #1: Michael D. -  4/3/17 - updating TC name
	*/
	public void tc0749_ScreenSubPanel_ScreeenSections(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		boolean passed = true;
		List<String> screenerSubPanels_Headers = new ArrayList<String>(Arrays.asList("MyScreens","MarketSmithStockScreens","MarketSmithFundScreens","TrackedScreens","FavoriteScreens"));
		waitUntilElementIsClickable(pageLib.getLeftPanelScreenerButton());
		if(!pageLib.getLeftPanelScreenerButton().getAttribute("class").contains("toLeftArrow"))
			pageLib.getLeftPanelScreenerButton().click();
		
		waitUntilElementIsClickable(pageLib.getLeftPanelScreenerButton());
		pageLib.getScreensSubPanel_button().click();
		waitUntilElementIsClickable(pageLib.getScreenNewScreen_button());

		for(WebElement e:pageLib.getSceenSubPanel_ScreenSections()){
			if(screenerSubPanels_Headers.contains(e.getAttribute("id")))
				logger.info("Screener section: "+screenerSubPanels_Headers.contains(e.getAttribute("id")));
			else
				passed = false;
		}
		Assert.assertTrue(passed,"Screener tab is missing header screen section");
	}

	/*
	* Method Description (0750): Verify preset MS STOCK screens
	* Created By:- Michael D,
	* Changes made #1: Michael D. -  4/3/17 - updating TC name & adding CLASS helper function
	*/
	public void tc0750_ScreenSubPanel_msStockScreens_Presets()
	{
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		boolean passed = true;
		List<String> screener_msPresetStockScreens = new ArrayList<String>(Arrays.asList("William J. O'Neil","Warren Buffett","Benjamin Graham","Peter Lynch","Martin Zweig","James P. O'Shaughnessy","Up on Volume","Down on Volume"));
		selectSubPanelSetUp("screens",2);
		try{
			Thread.sleep(1000);
			for(WebElement e:pageLib.getmsStockScreens_PresetScreens())
			{
				if(screener_msPresetStockScreens.contains(e.getText()))
					logger.info(e.getText()+" is in Preset Stock Screens");
				else{
					logger.info(e.getText()+" NOT in Preset Stock Screens");
					passed = false;
				}
			}
		}catch(Exception e){
			logger.info(e);
		}
		Assert.assertTrue(passed, "Preset stock screen is incorrect. Check LOG file");
	}
	
	/*
	* Method Description (0751): Verify preset MS FUND screens
	* Created By:- Michael D,
	* Changes made #1: Michael D. -  4/3/17 - updating TC name & adding CLASS helper function
	*/
	public void tc0751_ScreenSubPanel_msFundScreens_Presets(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		boolean passed = true;
		List<String> screener_msPresetFundScreens = new ArrayList<String>(Arrays.asList("Top Rated Growth Funds","Top Rated Value Funds"));

		selectSubPanelSetUp("screens",3);
		
		try{
			Thread.sleep(1000);
			for(WebElement e:pageLib.getmsFundScreens_PresetScreens())
			{
				if(screener_msPresetFundScreens.contains(e.getText()))
					logger.info(e.getText()+" is in Preset Fund Screens");
				else{
					logger.info(e.getText()+" NOT in Preset Fund Screens");
					passed = false;
				}
			}
		}catch(Exception e){
			logger.info(e);
		}
		Assert.assertTrue(passed, "Preset stock screen is incorrect. Check LOG file");
	}

	/*
	* Method Description (0753): Verify drop down for MS preset stock screens
	* Created By:- Michael D,
	* Changes made #1: Michael D. -  4/3/17 - updating TC name & adding CLASS helper function
	*/
	public void tc0753_HoverOverStock_DropDown(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		boolean passed = true;
		String curr_preset_stockScreen = "";
	
		selectSubPanelSetUp("screens",2);
		for(WebElement e:pageLib.getmsStockScreens_PresetScreens())
		{
			Actions action = new Actions(driver);
			action.moveToElement(e).build().perform();
			if(!e.findElement(By.cssSelector("div.screenMenuButtonImage")).getCssValue("display").equals("block"))
			{
				passed = false;
				curr_preset_stockScreen=e.getText();
			}
		}
		Assert.assertTrue(passed,curr_preset_stockScreen+" does NOT contain drop down when HOVERING OVER");
	}
	
	/*
	* Method Description (tc0754): My Screens Drop Down Menu Content
	* Created By:- Michael D,
	* Changes made #1: 3/24/17, completing assert check to verify TC
	*/
	public void tc0754_MyScreensDropDownMenuContent(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		boolean passed = true;
		List<String> MyScreens_dropDownMenuContent = new ArrayList<String>(Arrays.asList("Copy","Rename","Add to Favorites","Remove from Favorites","Sharing","Delete","View Details"));
		//Select screener sub panel, followed by Favorites section
		selectSubPanelSetUp("screens",1);
		//For All user created My Screens
		for(WebElement e:pageLib.getmsMyScreens_CreatedScreens())
		{
			performMouseHover(e);
			//Checking the corresponding hover over Screen is displaying Menu icon, if so Click it and check
			if(e.findElement(By.cssSelector("div.screenMenuButtonImage")).getCssValue("display").equals("block"))
			{
				e.findElement(By.cssSelector("div.screenMenuButtonImage")).click();
				logger.info("Current user screen is, "+e.getText());
				for(WebElement e2:pageLib.getScreenerGlobalMenu())
				{
					if(e2.getAttribute("class").contains("inMyScreen ")) //&& MyScreens_dropDownMenuContent.contains(e2.getText()))
					{
						passed = MyScreens_dropDownMenuContent.contains(e2.getText());
						logger.info(passed+"--> Current User screen MENU option is, "+e2.getText());
						Assert.assertTrue(passed,e2.getAttribute("class")+" --> is INCORRECT");
					}
				}
			}
		}
	}
	
	/*
	* Method Description (tc0768): VerifyMarketsmithScreensContent
	* Created By:
	* Changes made#1: Michael D - 3/24/17 - adding try/catch block to wait for modal window close
	*/
	//testCase:0768:Click on a MarketSmith Screen. The left of the edit screen should contain a description of the screen as well
	//as a message "This is a MarketSmith reference screen which cannot be altered. If you would like to modify this screen, 
	//create an editable copy from the dropdown(v) button.
    public void tc0768_VerifyMarketsmithScreensContent()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	//Select screener sub panel, followed by MS Preset Screens section
    	selectSubPanelSetUp("screens",2);
    	 //click on first MS preset stock screen, followed by clicking on Screen Edit button
    	 pageLib.getmsFirstStockScreen().click();
    	 if(pageLib.getopenEditButton().getText().contains("Open")){
    		 pageLib.getopenEditButton().click();
    	 }
    	 waitUntilElementisVisible(pageLib.getscreenDescription());
    	 Assert.assertTrue(pageLib.getscreenDescription().isDisplayed(), "Screen description is missing");
    	 String expectedMsg="This is a MarketSmith reference screen which cannot be altered.\n\nIf you would like to modify this screen, create an editable copy in your 'My Screens' folder."; 
    	 Assert.assertEquals(pageLib.getmsScreenMsg().getText().trim(),expectedMsg,"message not maatched");
    }
    
    //testCase:0775:Click on the New button. Do the options "New Stock Screen", "New Fund Screen" and "New Folder" appear?
    public void tc0775_VerifyNewButton(){
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getnewScreenButton());
		pageLib.getnewScreenButton().click();
		Actions action=new Actions(driver);
		action.moveToElement(pageLib.getscreenOptionsWindow()).build().perform();
		String allNewOptions[]={"New Stock Screen","New Fund Screen","New Folder"};
		List<WebElement> newOptions=pageLib.getnewScreenOptions();
		for(int i=0;i<newOptions.size();i++){
		 //drop down contains List and folder	
		 Assert.assertEquals(newOptions.get(i).getText().trim(), allNewOptions[i]," option not present");
		 }
		//Click to close 'New Screen' options, which was causing tc0779 to FAIL
		pageLib.getnewScreenButton().click();
    }
    
    /*
	* Method Description (0758): If a screen is shared, verify that the "Shared" symbol is displayed next to the screen name on the right.
	* Created By: Mamata M.
	* Changes made#1: Michael D - 3/24/17 - adding try/catch block to wait for modal window close
	*/
    public void tc0758_VerifyShareScreenOption()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	//Select screener sub panel, followed by My Screens section
    	selectSubPanelSetUp("screens",1);
    	
    	Utility.performMouseHover(pageLib.getmsMyScreens_CreatedScreens().get(0));
		pageLib.getfirstDropDownImg().click();
		List<WebElement> allDropDownOptions=pageLib.getScreenerGlobalMenu();
		allDropDownOptions.get(3).click();
		Utility.windowHandles();
		waitUntilElementIsClickable(pageLib.getshareScreenWindow());
		List<WebElement> sharingOptions=pageLib.getallSharingOptions();
		sharingOptions.get(1).click();
		try{
			pageLib.getShareApplyButton().click();
			Thread.sleep(15000);
		}catch(InterruptedException e){
			logger.info(e);
		}

		Assert.assertTrue(pageLib.getfirstSharedIcon().isDisplayed(), " screen not Shared");
    }
    
    /*
	* Method Description (tc0756): Verify Tracked Screens Menu Content
	* Created By: Michael D - 3/24/17
	* Changes made#1:
	*/
    public void tc0756_VerifyTrackedScreensMenuContent()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	List<String> TrackedScreens_dropDownMenuContent = new ArrayList<String>(Arrays.asList("Copy","Un-Track","Add to Favorites","Remove from Favorites","View Details"));
    	boolean passed = true;
    	//Select screener sub panel, followed by Favorites section
    	selectSubPanelSetUp("screens",4);
    	//If NO TRACKED screen, PASS the TC
    	if(pageLib.getAllTrackedScreens().size()==0)
    	{
    		Assert.assertTrue(passed);
    		logger.info("No tracked screens to check against");
    	}
    	else
    	{
    		//For ALL TRACKED screen, hover over each one
	    	for(WebElement e:pageLib.getAllTrackedScreens())
			{
				performMouseHover(e);
				//Checking the corresponding hover over Screen is displaying Menu icon, if so Click it and check
				if(e.findElement(By.cssSelector("div.screenMenuButtonImage")).getCssValue("display").equals("block"))
				{
					e.findElement(By.cssSelector("div.screenMenuButtonImage")).click();
					logger.info("Current TRACKED screen is, "+e.getText());
					for(WebElement e2:pageLib.getScreenerGlobalMenu())
					{
						if(e2.getAttribute("class").contains("inTrackedScreen"))// && TrackedScreens_dropDownMenuContent.contains(e2.getText()))
						{
							passed = TrackedScreens_dropDownMenuContent.contains(e2.getText());
							logger.info(passed+"-->Current screen MENU option is, "+e2.getText());
							Assert.assertTrue(passed,e2.getAttribute("class")+" --> is INCORRECT");
						}
					}
				}
			}
    	}
    }
    
    /*
	* Method Description (tc0757): Verify Favorite Screens Menu Content
	* Created By: Michael D - 3/24/17
	* Changes made#1:
	*/
    public void tc0757_VerifyFavoriteScreensMenuContent()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	List<String> FavoriteScreens_dropDownMenuContent = new ArrayList<String>(Arrays.asList("Copy","Go to Original","Remove from Favorites","View Details"));
    	boolean passed = true;
    	//Select screener sub panel, followed by Favorites section
    	selectSubPanelSetUp("screens",5);
    	//If NO FAVORITES screen, PASS the TC
    	if(pageLib.getAllFavoriteScreens().size()==0)
    	{
    		Assert.assertTrue(passed);
    		logger.info("No tracked screens to check against");
    	}
    	else
    	{
    		//For ALL FAVORITES screen, hover over each one
	    	for(WebElement e:pageLib.getAllFavoriteScreens())
			{
				performMouseHover(e);
				//Checking the corresponding hover over Screen is displaying Menu icon, if so Click it and check
				if(e.findElement(By.cssSelector("div.screenMenuButtonImage")).getCssValue("display").equals("block"))
				{
					e.findElement(By.cssSelector("div.screenMenuButtonImage")).click();
					logger.info("Current FAVORITE screen is, "+e.getText());
					for(WebElement e2:pageLib.getScreenerGlobalMenu())
					{
						//Check global menu for inFavoriteScreen class and execute the following code
						if(e2.getAttribute("class").contains("inFavoriteScreen")) // && FavoriteScreens_dropDownMenuContent.contains(e2.getText()))
						{
							passed = FavoriteScreens_dropDownMenuContent.contains(e2.getText());
							logger.info(passed+"-->Current screen MENU option is, "+e2.getText());
							Assert.assertTrue(passed,e2.getAttribute("class")+" --> is INCORRECT");
						}
					}
				}
			}
    	}
    }
    
    /*
	* Method Description (tc0759): Verify Screen loads in LM with correct Screen title
	* Created By: Michael D - 3/31/17
	* Changes made#1:
	*/
    public void tc0759_VerifyScreenLoadsInLM()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	//Select Screens subpanel, My Screens section, click on FIRST user created screen
    	selectSubPanelSetUp("screens",1);
    	pageLib.getmsMyScreens_CreatedScreens().get(0).click();
    	//Store FIRST screen name
    	String sFirstList=pageLib.getmsMyScreens_CreatedScreens().get(0).getText();
    	Utility.waitUntilVisibilityOfElement();
    	String LMTitle=pageLib.getLMNavBarTitle().getText();
    	//CHECK - verify LM title is equal to selected Screener title
    	Assert.assertTrue(LMTitle.contains(sFirstList));
    }
    
    /*
	* Method Description (tc0760): Verify Screener tab, Screens, top buttons
	* Created By: Michael D - 3/31/17
	* Changes made#1:
	*/
    public void tc0760_VerifyScreenTopButtons()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	selectSubPanelSetUp("screens",1);
    	//CHECK - ensure all 3 buttons are correctly displayed
    	boolean topScreenButtonsDisplayed = pageLib.getopenEditButton().isDisplayed() && pageLib.getnewScreenButton().isDisplayed() && pageLib.getBrowseScreensButton().isDisplayed();
    	Assert.assertTrue(topScreenButtonsDisplayed,"All 3 top Screener BUTTONS are NOT displayed.");
    }
    
    /*
	* Method Description: Verify Tracked Screens Menu Content
	* Created By: Michael D - 3/31/17
	* Changes made#1:
	*/
    /*
    public void tcCheckLMUpdatingContent()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	waitUntilElementIsClickable(lmLib.getLMMaxViewButton());
    	lmLib.getLMMaxViewButton().click();
    	Utility.waitUntilVisibilityOfElement();
    	System.out.println(lmLib.getListPanelFirstRow().isDisplayed());
    	for(WebElement r:lmLib.getAllLMPriceDollarChanges())
    	{
    		System.out.println(r.getText());
    	}
    	
    	for(WebElement r:lmLib.getAllLMPricePercChanges())
    	{
    		System.out.println(r.getText());
    	}
    	
    	
    	
    }
    */
    
    /*
	* Method Description (tc0761): Verify Screen Edit button correctly toggles (** Same function called for tc0762 in TEST.java) and has correct content
	* Created By: Michael D - 3/31/17
	* Changes made#1:
	*/
    public void tc0761_VerifyEditScreenButtonToggle()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	boolean passed = false;
    	selectSubPanelSetUp("screens",1);
    	waitUntilElementIsClickable(pageLib.getopenEditButton());
    	//Screener edit screen currently CLOSED
    	if(pageLib.getopenEditButton().getText().contains("Open"))
    	{
    		logger.info("Toggling screener edit button to EXPAND screener");
    		pageLib.getopenEditButton().click();
    		Utility.waitUntilVisibilityOfElement();
    		//CHECK - ensure fully expanding SCREENER tab has correct button text & screener details are displayed
    		passed = pageLib.getopenEditButton().getText().contains("Close") && pageLib.getEditScreenDetails().isDisplayed();
    		Assert.assertTrue(passed,"Screener edit button NOT toggled correctly");
    	}
    	else{
    		//Screener edit screen currently OPEN
    		logger.info("Toggling screener edit button to CLOSE");
    		pageLib.getopenEditButton().click();
    		Utility.waitUntilVisibilityOfElement();
    		//CHECK - ensure closing SCREENER tab has correct button text & screener tab half expanded (class element check)
    		passed = pageLib.getopenEditButton().getText().contains("Open") && pageLib.getLeftScreenSubPanels().getAttribute("class").contains("expendToMedium");
    		Assert.assertTrue(passed,"Screener edit button NOT toggled correctly");
    	}
    }
    
    /*
	* Method Description (tc0763): Verify Screen Edit content, screen being edited correct name and 'Screen From' correct link text (includes tc0764,tc0765)
	* Created By: Michael D - 4/3/17
	* Changes made#1:
	*/
    public void tc0763_VerifyEditScreenNameOfScreen()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	String sScreenFromList="";
    	selectSubPanelSetUp("screens",1);
    	
    	//Selecting first USER screen
    	pageLib.getmsMyScreens_CreatedScreens().get(0).click();
    	String sFirstScreen=pageLib.getmsMyScreens_CreatedScreens().get(0).getText();
    	Utility.waitUntilVisibilityOfElement();
    	
    	//Wait until Screen Edit button is clickable and execute following steps
    	waitUntilElementIsClickable(pageLib.getopenEditButton());
    	logger.info("Currently Screener edit button display, "+pageLib.getopenEditButton().getText());

    	//Screener edit screen currently CLOSED
    	if(pageLib.getopenEditButton().getText().contains("Open"))
    	{
    		pageLib.getopenEditButton().click();
    		Utility.waitUntilVisibilityOfElement();
    		logger.info("Toggling screener edit button to EXPAND screener");
    	}
    	
    	//CHECK - Edit Screen content has correct Screen title displayed 
    	Assert.assertTrue(pageLib.getScreenEditName().getText().contains(sFirstScreen),"Current screen selected, "+sFirstScreen+", NOT displayed in Screener edit");
    	//Store 'Screen From' link text and click on link, wait, and check for modal window to be displayed
    	sScreenFromList=pageLib.getScreenFromLink().getText(); 
    	pageLib.getScreenFromLink().click();
    	Utility.waitUntilVisibilityOfElement();
    	//CHECK - verify to ensure modal window for 'Screen From' feature is displayed
    	Assert.assertTrue(pageLib.getScreenerSelectAListModal().isDisplayed(),"Screen from List modal is NOT displayed");
    	logger.info("Modal box, Screen from List, content is displayed");
    	//Click on corresponding modal box 'X'/close button, wait, and check 'Screen From' link text has NOT changed
    	pageLib.getScreenerSelectAListModal().findElement(By.cssSelector("span.btn-close")).click();
    	Utility.waitUntilVisibilityOfElement();
    	//CHECK - 'Screen From' link text has NOT changed
    	Assert.assertTrue(pageLib.getScreenFromLink().getText().contains(sScreenFromList),"Screen from List link INCORRECT after closing modal window");
    	logger.info("Current Screen from List is still correctly selected after closing Modal box");
    }
    
    /*
  	* Method Description (tc0776): Verify New Screen Folder, NOT DONE YET
  	* Created By: Michael D - 4/3/17
  	* Changes made#1:
  	*/
    public void tc0776_VerifyScreenNewFolder()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	String sNewFolderName="tempNewFolder";
    	
    	selectSubPanelSetUp("screens",1);
    	waitUntilElementIsClickable(pageLib.getScreenNewScreen_button());
    	pageLib.getScreenNewScreen_button().click();
    	waitUntilElementIsClickable(pageLib.getScreenNewFolderOption());
    	pageLib.getScreenNewFolderOption().click();
    	Utility.waitUntilVisibilityOfElement();
    	//Execute this block if New Element modal box is DISPLAYED to enter Name
    	if(pageLib.getNewElementViewModal().getCssValue("display").contains("block"))
    	{
    		//Actions action1 = new Actions(driver);
			//action1.sendKeys(pageLib.getNewElementModalInput(),sNewFolderName).sendKeys(Keys.RETURN).build().perform();
    		pageLib.getNewElementModalInput().sendKeys(sNewFolderName);
    		pageLib.getNewElementModalInput().sendKeys(Keys.ENTER);
			Utility.waitUntilVisibilityOfElement();
			System.out.println(pageLib.getmsMyScreens_CreatedScreens().get(0).getText());
			System.out.println(pageLib.getmsMyScreens_CreatedScreens().get(0).getText().contains(sNewFolderName));
    	}
    	else
    	{
    		Assert.fail("Modal box to enter NEW element NAME is NOT displayed");
    	}
    	
    	//Utility.performMouseHover(pageLib.getmsMyScreens_CreatedScreens().get(0));
    	//pageLib.getmsMyScreens_CreatedScreens().get(0).findElement(By.cssSelector("screenMenuButtonImage")).click();
    	WebElement currFolder=null;
    	for(WebElement e:pageLib.getmsMyScreens_CreatedScreens())
    	{
    		if(e.getText().contains(sNewFolderName))
    		{
    			currFolder=e;
	    		/*performMouseHover(e);
	    		//Checking the corresponding hover over Screen is displaying Menu icon, if so Click it and check
	    		if(e.findElement(By.cssSelector("div.screenMenuButtonImage")).getCssValue("display").equals("block"))
	    		{
	    			e.findElement(By.cssSelector("div.screenMenuButtonImage")).click();
	    			logger.info("Current user screen is, "+e.getText());
	    			for(WebElement e2:pageLib.getScreenerGlobalMenu())
	    			{
	    				if(e2.getAttribute("class").contains("inMyScreenFolder ") && e2.getText().contains("Delete"))
	    				{
	    					e2.click();
	    					Utility.waitUntilVisibilityOfElement();
	    					pageLib.getConfirmDeleteButton().click();
	    					Utility.waitUntilVisibilityOfElement();
	    				}
	    			}
	    		}*/
    		}
    		else{
    			Actions action = new Actions(driver);
    			action.dragAndDrop(e,currFolder).build().perform();
    			//action1.sendKeys(pageLib.getNewElementModalInput(),sNewFolderName).sendKeys(Keys.RETURN).build().perform();
    		}
    	}
    	
    }
    
    /*
  	* Method Description (tc0779): Verify New Screen is created correctly (ie correct modal box, NAME, and EMPTY screen filters) (includes tc0780)
  	* Created By: Michael D - 4/3/17
  	* Changes made#1:
  	*/
    public void tc0779_VerifyScreenNewScreen()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	String sNewScreenName="tempNewScreen";
    	//Select Screener subpanel, My Screens section, & click on NEW SCREEN Button (NEW STOCK SCREEN)
    	selectSubPanelSetUp("screens",1);
    	waitUntilElementIsClickable(pageLib.getScreenNewScreen_button());
    	pageLib.getScreenNewScreen_button().click();
    	Utility.waitUntilVisibilityOfElement();
    	pageLib.getScreenNewScreenOption().click();
    	Utility.waitUntilVisibilityOfElement();
    	//Execute this block if New Element modal box is DISPLAYED to enter Name, first check
    	if(pageLib.getNewElementViewModal().getCssValue("display").contains("block"))
    	{
    		//Enter NEW screen name followed by ENTER
    		pageLib.getNewElementModalInput().sendKeys(sNewScreenName);
    		pageLib.getNewElementModalInput().sendKeys(Keys.ENTER);
			Utility.waitUntilVisibilityOfElement();
			//Check to see if NEW created screen matched input name
			Assert.assertTrue(pageLib.getmsMyScreens_CreatedScreens().get(0).getText().contains(sNewScreenName),"New user created screen title is NOT correct");
			logger.info("New user created screen title is correct, "+sNewScreenName);
    	}
    	else
    	{
    		Assert.fail("Modal box to enter NEW element NAME is NOT displayed");
    	}
    	//Check to see if NEW created screen has NO screen filters at initiation
    	Assert.assertTrue(pageLib.getScreenFilterViewEmpty().getCssValue("display").contains("block"),"Screen CRITERIA is NOT empty for a newly created screen");
    	
    	//DELETE newly created USER Screen
    	for(WebElement e:pageLib.getmsMyScreens_CreatedScreens())
    	{
    		//if USER screen contains NEWLY created USER screen name, HOVER, dropdown MENU, and DELETE
    		if(e.getText().contains(sNewScreenName))
    		{
	    		performMouseHover(e);
	    		//Checking the corresponding hover over Screen is displaying Menu icon, if so Click it and check
	    		if(e.findElement(By.cssSelector("div.screenMenuButtonImage")).getCssValue("display").equals("block"))
	    		{
	    			e.findElement(By.cssSelector("div.screenMenuButtonImage")).click();
	    			logger.info("Current user screen is, "+e.getText());
	    			for(WebElement e2:pageLib.getScreenerGlobalMenu())
	    			{
	    				if(e2.getAttribute("class").contains("inMyScreen ") && e2.getText().contains("Delete"))
	    				{
	    					e2.click();
	    					Utility.waitUntilVisibilityOfElement();
	    					pageLib.getConfirmDeleteButton().click();
	    					Utility.waitUntilVisibilityOfElement();
	    				}
	    			}
	    		}
    		}
    	}
    }
    
    /*
  	* Method Description (tc0781): Verify Browse Screens modal window opens with correct Shared Screens COLUMN HEADERS and shared screen content (includes tc0782)
  	* Created By: Michael D - 4/3/17
  	* Changes made#1:
  	*/
    public void tc0781_VerifyBrowseScreensWindow()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	List<String> browseScreensModalColHeaders = new ArrayList<String>(Arrays.asList("","Screen","Description","Author","Updated","Community","Discussion"));
    	//Select Screener subpanel, My Screens section, & click on BROWSE SCREENS Button
    	selectSubPanelSetUp("screens",1);
    	waitUntilElementIsClickable(pageLib.getBrowseScreensButton());
    	pageLib.getBrowseScreensButton().click();
    	Utility.waitUntilVisibilityOfElement();
    	//Conditional first check to see if Browse Window is displayed, otherwise FAIL TC
    	if(pageLib.getBrowseScreensModal().isDisplayed())
    	{
    		//Initial check to see if Shared Screens are being displayed, AT LEAST 1
    		Assert.assertTrue(pageLib.getAllSharedScreens().size()>0,"Shared Screens are NOT displayed in pop up window");
    		logger.info("Shared screens are displayed in Browse Screens window");
    		//Check Shared Screen column headers correct text
	    	for(WebElement e:pageLib.getAllColumnHeaders_BrowseScreen())
	    	{
	    		Assert.assertTrue(browseScreensModalColHeaders.contains(e.getText()),e.getText()+", NOT in Browse Screens HEADER COLUMNS");
	    		//System.out.println(browseScreensModalColHeaders.contains(e.getText()));
	    	}
	    	logger.info("All Browse screens HEADER COLUMNS are correctly displayed");
    	}
    	else
    	{
    		Assert.fail("Browse Screens modal window is NOT displayed");
    	}
    	//Close the corresponding BROWSE SCREENS modal
    	pageLib.getBrowseScreensModal().findElement(By.cssSelector("span.btn-close")).click();
    	
    }
    
    /*
  	* Method Description (tc0783): Verify Browse Screens selected screen has correct content in pop up and is loaded in LM when viewed (includes tc0784,tc0785,tc0788,tc0789)
  	* *** MULTIPLE checks are being done in this TC to prevent TC logic structure redundancy as in tc0781 ***
  	* Created By: Michael D - 4/4/17
  	* Changes made#1:
  	*/
    public void tc0783_VerifyBrowseScreensWindowLHSFilterContent()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	boolean passed = false;
    	List<String> browseScreensModalLHSSections= new ArrayList<String>(Arrays.asList("","Type","Sharing","Tags","Clear","Updated within Last","Keyword, Tag, or Author"));
    	List<String> browseScreensSelectedScreenSectionss= new ArrayList<String>(Arrays.asList("Rating","Type","Tracked by","Author","Last Updated","Criteria Groups","Number of Results","Description","Tags"));
    	List<String> browseScreensModalTopButtons= new ArrayList<String>(Arrays.asList("View Screen","Track Screen","Untrack Screen"));
    	selectSubPanelSetUp("screens",1);
    	//waitUntilElementIsClickable(pageLib.getBrowseScreensButton());
    	Utility.waitUntilVisibilityOfElement();
    	pageLib.getBrowseScreensButton().click();
    	Utility.waitUntilVisibilityOfElement();
    	//Conditional first check to see if Browse Window is displayed, otherwise FAIL TC (part of tc0783 check)
    	if(pageLib.getBrowseScreensModal().isDisplayed())
    	{
    		//BROWSE SCREEM PARENT MODAL
    		//CHECK - ensure all Left Hand Side filters/sections from Browse Screens modal are displayed (part of tc0783 check)
    		for(WebElement e:pageLib.getLHSSectionTitles_BrowseScreensModal())
    		{
    			Assert.assertTrue(browseScreensModalLHSSections.contains(e.getText()),e.getText()+", NOT found in Section titles");
    		}
    		try{
    			pageLib.getFirstFilterCheckBox_BrowseScreens().click();
    			Thread.sleep(5000);
    		}catch(InterruptedException e){
    			logger.info(e);
    		}
    		//Click on the first filter, wait for result set to update, CHECK there are 2 shared screens in the result set (part of tc0783 check)
    		//pageLib.getFirstFilterCheckBox_BrowseScreens().click();
    		//Utility.waitUntilVisibilityOfElement();
    		Assert.assertTrue(pageLib.getAllSharedScreens().size()==2,"Shared screens are NOT updated to reflect filter selection");
    		logger.info("Shared screens are updated to reflect filter selection. Selecting shared  screen after applying Filter");
    		//Click on first Shared Screen after applying filter. Need the following implementation to open the selected shared screen modal window
    		//Otherwise, pageLib.getAllSharedScreens().get(0).click(), opens up a new tab
    		pageLib.getAllSharedScreens().get(0).findElement(By.cssSelector("span.ListSpan")).click();
    		Utility.waitUntilVisibilityOfElement();
    		
    		//SELECTED SHARED SCREEM CHILD MODAL
    		//CHECK - ensure all sections are displayed for Selected Shared Screen modal window (part of tc0784 check)
    		for(WebElement e:pageLib.getSelectedSharedScreenSections())
    		{
    			Assert.assertTrue(browseScreensSelectedScreenSectionss.contains(e.getText()),e.getText()+", NOT found in Section titles");	
    		}
    		//individual CHECK for 'Rating' section in Selected Shared Screen modal window  (part of tc0784 check)
    		String sRatingText=pageLib.getSelectedSharedScreenRatingSection().getText();
    		sRatingText=sRatingText.substring(0,sRatingText.indexOf("\n")).trim();				
    		Assert.assertTrue(browseScreensSelectedScreenSectionss.contains(sRatingText),sRatingText+", NOT found in Section titles");
    		logger.info(sRatingText+", is found in Selected Shared Screen modal window");
    		
    		//CHECK-ensure both comment areas are displayed in Selected Shared Screen modal window  (part of tc0784 check)
    		for(WebElement e:pageLib.getCommentAreaSelectedSharedScreenModal())
    		{
    			Assert.assertTrue(e.isDisplayed(),e.getAttribute("class")+", comment section NOT displayed in Selected Shared Screen modal");
    		}
    		
    		WebElement viewScreenButton = null;
    		//CHECK-ensure top 2 buttons are displayed, VIEW/TRACK screen. Possible UNTRACK screen depending on Screen status (part of tc0788 check)
    		for(WebElement e:pageLib.getTopTwoButtonsSelectedSharedScreenModal())
    		{
    			if(e.isDisplayed())
    			{
    				Assert.assertTrue(browseScreensModalTopButtons.contains(e.getText()),e.getText()+", button is NOT displayed in Selected Share Screen modal");
    			}
    			
    			if(e.getText().contains("View Screen"))
    				viewScreenButton=e;
    		}
    		
    		//Get Selected Shared Screen NAME and Result set count to compare when list is VIEWED in LM
    		String sSharedScreenName=pageLib.getModalSharedScreenName().getText();
    		String sSharedSreenResults=pageLib.getModalSharedScreenResultNum().getText();
    		//Click to VIEW Shared Screen in LM. Wait until list is loaded in LM and CHECK name and result set count matches (part of tc0789 check)
    		viewScreenButton.click();
    		try{
    			Thread.sleep(7500);
    			passed = pageLib.getLMNavBarTitle().getText().contains(sSharedScreenName) && pageLib.getLMNavBarTitle().getText().contains(sSharedSreenResults);
        		Assert.assertTrue(passed,"Viewing of Shared Screen Name or Shared Screen result set count is NOT correct in LM");
        		logger.info("Both Shared Screen Name and Shared Screen result set count is displayed correctly in LM");
    		}catch(InterruptedException e){
    			System.out.println(e);
    			logger.info(e);
    		}	
    	}
    	else
    	{
    		Assert.fail("Browse Screens modal window is NOT displayed");
    	}
    }
    
    /*
  	* Method Description (tc0791): verify user scren view details modal has correct content and behaves as expected (includes tc0792,tc0793,tc0794,tc0795,tc0796)
  	* Created By: Michael D - 4/5/17
  	* Changes made#1:
  	*/
    public void tc0791_VerifyUserScreenViewDetails()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	selectSubPanelSetUp("screens",1);
    	//Loop through ALL user created Screen and perform a hover over
    	for(WebElement s:pageLib.getmsMyScreens_CreatedScreens())
    	{
    		performMouseHover(s);
			//Checking the corresponding hover over Screen is displaying Menu icon, if so Click it and check
			if(s.findElement(By.cssSelector("div.screenMenuButtonImage")).getCssValue("display").equals("block"))
			{
				s.findElement(By.cssSelector("div.screenMenuButtonImage")).click();
				logger.info("Current user screen is, "+s.getText());
				//Lopp through all MENU items for corresponding screens and click on View Details option
				for(WebElement s2:pageLib.getScreenerGlobalMenu())
				{
					if(s2.getAttribute("class").contains("inMyScreen ") && s2.getText().contains("View Details"))
					{
						s2.click();
						Utility.waitUntilVisibilityOfElement();
						logger.info("Clicking on, "+s2.getText()+", for current Screen, "+s.getText());
					}
				}
				
				//Conditional CHECK to ensure View Details modal has opened (pasrt of 0791 check) 
				if(pageLib.getScreenDetailsModal().isDisplayed())
				{
					Assert.assertTrue(true,"View Details modal for current user screen, "+s.getText()+", is NOT displayed");
					//TODO: Need to add logic for tc0792,tc0793,tc0794,tc0795,tc0796 once MSWEB-355 is fixed
					pageLib.getScreenDetailsModal().findElement(By.cssSelector("span.btn-close")).click();
		    		Utility.waitUntilVisibilityOfElement();
				}
				else
				{
					Assert.fail("View Details modal window for User Screens is NOT displayed");
				}
				
			}
    	}
    }
    
    /*
  	* Method Description (tc0800): verify user screen copy option behaves as expected, copies correct Screen, and content (includes tc0801,tc0802,tc0803,tc0804)
  	* *** ALSO incluing DELETE checks to remove copied screens created in this TC (tc0802,tc0803,tc0804)***
  	* Created By: Michael D - 4/5/17
  	* Changes made#1:
  	*/
    public void tc0800_VerifyUserScreenCopyOptionAndContent()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	String sCurrScreenName="";
    	String sCurrScreenCount="";
    	String sNewCopiedName="";
    	String sCopiedName="";
    	String sCopiedCount="";
    	selectSubPanelSetUp("screens",1);
    	int count=pageLib.getmsMyScreens_CreatedScreens().size();
    	List<String> deletedScreens = new ArrayList<String>();
    	//Loop through ALL user created Screen and perform a hover over
    	for(WebElement s:pageLib.getmsMyScreens_CreatedScreens())
    	{
    		//Click on current Screen to get Screen Name and Number of stocks in screen which will be used to compare after Copying the screen
    		s.click();
    		try{
    			Thread.sleep(6000);
    			String sTemp=pageLib.getLMNavBarTitle().getText();
    			sCurrScreenName=sTemp.substring(0,sTemp.indexOf(":"));
    			sCurrScreenCount=sTemp.substring(sTemp.indexOf(":")+2,sTemp.indexOf("i",sTemp.indexOf(":"))-1);
    		}catch(InterruptedException e){
    			logger.info(e);
    		}
    		
    		performMouseHover(s);
			//Checking the corresponding hover over Screen is displaying Menu icon, if so Click it and check
			if(s.findElement(By.cssSelector("div.screenMenuButtonImage")).getCssValue("display").equals("block"))
			{
				s.findElement(By.cssSelector("div.screenMenuButtonImage")).click();
				logger.info("Current user screen is, "+s.getText());
				//Lopp through all MENU items for corresponding screens and click on View Details option
				for(WebElement s2:pageLib.getScreenerGlobalMenu())
				{
					if(s2.getAttribute("class").contains("inMyScreen ") && s2.getText().contains("Copy"))
					{
						s2.click();
						Utility.waitUntilVisibilityOfElement();
						logger.info("Clicking on, "+s2.getText()+", for current Screen, "+s.getText());
					}
				}
				
				//First CHECK to ensure copy modal is displayed with correct initialized COPYING NAME
				if(pageLib.getNewElementViewModal().isDisplayed())
				{
					//Store copy modal preset NAME, compare, and save
					sNewCopiedName=pageLib.getNewElementModalInput().getAttribute("value");
					//CHECK - Screen being copied has correct initialized name (part of 0800 check)
					Assert.assertTrue(sNewCopiedName.contains(sCurrScreenName),"Screen being copied does NOT have correct name syntax");
					logger.info("Screen being copied, "+sCurrScreenName+", has CORRECT syntax of, "+sNewCopiedName);
					pageLib.getLMNewElementModalSaveButton().click();
					//Once new copied screen is saved, wait new screen is loaded in LM to get name and count
					try{
		    			Thread.sleep(6000);
		    			String sTemp2=pageLib.getLMNavBarTitle().getText();
		    			sCopiedName=sTemp2.substring(0,sTemp2.indexOf(":"));
		    			sCopiedCount=sTemp2.substring(sTemp2.indexOf(":")+2,sTemp2.indexOf("i",sTemp2.indexOf(":"))-1);
		    		}catch(InterruptedException e){
		    			logger.info(e);
		    		}
					
					//CHECK - Copied screen appears in LM and content matches original (part of 0801 check)
					if(pageLib.getmsMyScreens_CreatedScreens().get(0).getAttribute("name").contains(sCopiedName))
						Assert.assertTrue(sCopiedName.contains(sCurrScreenName) && sCopiedCount.contains(sCurrScreenCount),"Name or count of copied screen is INCORRECT");
				}
			}
    	}
 
    	//DELETING copied screens and performing DELETE checks (part of tc0802,tc0803)
    	String sTemp = "";
		for(int i=0;i<count;i++)
		{
			//Store name of screen being deleted and execute DELETE action
			sTemp = pageLib.getmsMyScreens_CreatedScreens().get(0).getAttribute("name");
			deletedScreens.add(sTemp);
			Actions action=new Actions(driver);
			action.sendKeys(pageLib.getmsMyScreens_CreatedScreens().get(0),Keys.DELETE).build().perform();
			Utility.waitUntilVisibilityOfElement();
			//Check IMPORTANT RED message is displayed when DELETING, click on Cancel, and check Screen still displayed in Screen explorer 
			verifyTextColor(pageLib.getImportantRedDeleteMsg(),"DarkRed");
			pageLib.getDeleteConfirmCancelButton().click();
			Utility.waitUntilVisibilityOfElement();
			Assert.assertTrue(pageLib.getmsMyScreens_CreatedScreens().get(0).getAttribute("name").contains(sTemp));
			//Perform DELETE action again and confirm deletion
			action.sendKeys(pageLib.getmsMyScreens_CreatedScreens().get(0),Keys.DELETE).build().perform();
			Utility.waitUntilVisibilityOfElement();
			pageLib.getConfirmDeleteButton().click();
			Utility.waitUntilVisibilityOfElement();
		}
		
		//Loop through all USER created screens and ensure deleted screens are NOT displayed
		for(WebElement e:pageLib.getmsMyScreens_CreatedScreens())
		{
			Assert.assertFalse(deletedScreens.contains(e.getAttribute("name")),e.getAttribute("name")+", was NOT deleted from Screener explorer");
		}
    }
    
    
    /*
  	* Method Description (tc0801): verify Screener panel closes when clicking on 'x'/close button
  	* Created By: Michael D - 4/7/17
  	* Changes made#1:
  	*/
    public void tc0801_VerifyScreenerCloseButton()
    {
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	selectSubPanelSetUp("screens",1);
    	waitUntilElementisVisible(pageLib.getScreenerCloseButton());
    	pageLib.getScreenerCloseButton().click();
    	Utility.waitUntilVisibilityOfElement();	
    	Assert.assertTrue(pageLib.getLeftScreenSubPanels().getCssValue("width").contains("85"),"Screener panel did NOT close after clicking on 'x'/close button");
    	logger.info("Screener panel is closed correctly");
    }

}