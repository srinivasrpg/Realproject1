package global;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import static genericLib.Utility.*;

public class MarketsmithHome {
	MarketsmithHomePageLib pageLib=PageFactory.initElements(driver, MarketsmithHomePageLib.class);

	//Test Case : 0829 : Login to the Marketsmith with valid credentials
	public void tc001_loginToMarketSmith(String userName, String password) {	
		try {
			WebElement settingIcon=pageLib.getLogoutButton();	
			if(settingIcon.isDisplayed()) {
				logger.info("Already Logged In");
			}
			else {
				throw new Exception();
			}
		}
		catch(Exception e) {
			driver.switchTo().frame(pageLib.getLoginFrame());
			waitUntilElementIsClickable(pageLib.getUserNameTextbox());
			pageLib.getUserNameTextbox().sendKeys(userName);
			logger.info(userName + " is entered as Username");
			pageLib.getPasswordTextbox().sendKeys(password);
			logger.info(password + " is entered as Password");
			WebElement loginButton=pageLib.getLoginButton();
			String loginButtonText=loginButton.getAttribute("title");
			loginButton.click();
			logger.info("Clicked on " + loginButtonText + " button");
			driver.switchTo().defaultContent();
		
			WebDriverWait wait=new WebDriverWait(driver, 60);
			if(driver.getCurrentUrl().contains(CONSTANTS.getProperty("CAMPAIGN_URL")))
				driver.navigate().back();
			try {
				wait.until(ExpectedConditions.visibilityOf(pageLib.getLogoutButton()));
				logger.info("User logged in successfully");
				logger.info("------------------------------------------------------------");
			}
			catch(TimeoutException ex) {
				if(driver.getCurrentUrl().contains(CONSTANTS.getProperty("CAMPAIGN_URL")))
					driver.navigate().back();
				try {
					wait.until(ExpectedConditions.visibilityOf(pageLib.getLogoutButton()));
					logger.info("User logged in successfully");
					logger.info("------------------------------------------------------------");
				}
				catch(TimeoutException exc) {
					ex.printStackTrace();
					Assert.fail("Unable to login");
				}
			}
		}
	}
	/**********************************************************************************************************************************
	 **********************************************************************************************************************************/
	//Test Case :0830 : Log out from marketsmith
	public void tc002_logoutFromMarketSmith()
	{
	  try{
			WebElement loginIcon=pageLib.getLoginButton();
		    if(loginIcon.isDisplayed()){
			logger.info("user already logged out");
		 }
	    }catch(Exception e) {
			waitUntilElementIsClickable(pageLib.getLogoutButton());
			pageLib.getLogoutButton().click();
			logger.info("user loggedout successfully");
		}
    }
}