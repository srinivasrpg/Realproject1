package alertsNotesAndBlogs;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import genericLib.Utility;

import static genericLib.Utility.*;


public class AlertsNotesAndBlogs {
	AlertsNotesAndBlogsLib alertPageLib = PageFactory.initElements(driver, AlertsNotesAndBlogsLib.class);
	
	WebDriverWait wait=new WebDriverWait(driver, 30);
	/**
	 * Method Description (testCase:0498):Click on the Alerts Tab. The dropdown list should default to "All" and display any alerts created by you for the current stock.
	 * Created By:- Mamata, Created Date:- 06/06/2016
	 * Changes made#1:
	**/
	//testCase:0498:Click on the Alerts Tab. The dropdown list should default to "All" and display any alerts created by you for the current stock.
	public void TC0498_AlertsNotesandBlogs(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		if(!(alertPageLib.getLeftPanelScreenerButton().getAttribute("class").contains("toLeftArrow"))){
			alertPageLib.getLeftPanelScreenerButton().click();
		  }
		List<WebElement> screenAlertsNotesTab=alertPageLib.getscreenALertNoteTabs();
		screenAlertsNotesTab.get(1).click();
		Utility.waitUntilVisibilityOfAllElements(alertPageLib.getalertSection());
		Assert.assertEquals(alertPageLib.getalertDropdownText().getText().trim(), "All","Default text is changed");
		List<WebElement> allAlerts=alertPageLib.getallAlerts(); 
		if(allAlerts.size()!=0){
			for(int i=0;i<allAlerts.size();i++){
				Assert.assertTrue(allAlerts.get(i).isDisplayed(), "Alerts not displayed");
			}
		}else{
			logger.info("currently No alerts present");
		}
	}
	
	/**
	 * Method Description (testCase:0499):Click on the dropdown button. Verify the options "All", "Active", and "Triggered" appear. 
	 * Created By:- Mamata, Created Date:- 30/03/2017
	 * Changes made#1:
	**/
	public void TC0499_AlertsNotesandBlogs(){
		String expectedAlertOptions[]={CONSTANTS.getProperty("ALL_TEXT"),CONSTANTS.getProperty("ACTIVE_TEXT"),CONSTANTS.getProperty("TRIGGERED_TEXT")};
		alertPageLib.getalertDropdownSelection().click();
		//locate all options
		List<WebElement> allAlertOptions=alertPageLib.getAlertDropdownElements();
		//verify all options
		for(int i=0;i<allAlertOptions.size();i++){
			Assert.assertEquals(allAlertOptions.get(i).getText().trim(), expectedAlertOptions[i],"option not present");
			logger.info("option present:"+allAlertOptions.get(i).getText());
		}
	}
	
	/**
	 * Method Description (testCase:0500):Verify the alerts appear in the proper options. Triggered alerts appear in All and Triggered but not Active. Active alerts appear in All and Active but not Triggered.
	 * Created By:- Mamata, Created Date:- 06/06/2016
	 * Changes made#1:
	**/
	public void TC0500_AlertsNotesandBlogs(){
		Utility.waitUntilVisibilityOfAllElements(alertPageLib.getAlertDropdownElements());
		List<WebElement> allAlertOptions=alertPageLib.getAlertDropdownElements();
		List<WebElement> allActiveAlerts=new ArrayList<WebElement>();
		
		//selecting active alerts
		logger.info("clicking on option:"+allAlertOptions.get(1).getText());
		allAlertOptions.get(1).click();
		try{
			Utility.waitUntilVisibilityOfAllElements(alertPageLib.getalertSection());
			 allActiveAlerts=alertPageLib.getalertSection();
		 }catch(Exception e){
			 try{
			  Utility.waitUntilVisibilityOfAllElements(alertPageLib.getalertSection());
			  allActiveAlerts=alertPageLib.getalertSection();
			 }catch(StaleElementReferenceException e1){
				 e1.printStackTrace();
			 }
		 }
		  
		//verifying active alerts present or not
		if(allActiveAlerts.size()!=0){
			int noOfActiveAlerts=allActiveAlerts.size();
			alertPageLib.getalertDropdownSelection().click();
			
			//selecting all alerts option
			allAlertOptions.get(0).click();
			List<WebElement> allAlertDetails=alertPageLib.getallAlertsDetails();
			List<Boolean> activeAlerts=new ArrayList<Boolean>();
			for(int i=0;i<allAlertDetails.size();i++){
			 boolean priceTextedAlert=allAlertDetails.get(i).getText().contains("Price");
			 activeAlerts.add(priceTextedAlert);
			}
			
			//get number of active alerts in ALL option
			List<Boolean> conditionPassed=new ArrayList<Boolean>();
			conditionPassed.addAll(activeAlerts);
			
			//verify active alerts in ALL dropdown
			Assert.assertEquals(conditionPassed.size(), noOfActiveAlerts,"no of active alert not matcing");
			logger.info(conditionPassed.size()+" is matiching with "+noOfActiveAlerts);
		 }else{
			logger.info("No alerts present");
		}
		
		//selecting triggered alerts
		List<WebElement> allTriggeredAlerts=new ArrayList<WebElement>();
		logger.info("clicking on option:"+allAlertOptions.get(2).getText());
		alertPageLib.getalertDropdownSelection().click();
		allAlertOptions.get(2).click();
		try{
		  Utility.waitUntilVisibilityOfAllElements(alertPageLib.getallTriggeredAlertsInAllOption());
		  allTriggeredAlerts=alertPageLib.getalertSection();
		 }catch(Exception e){
			try{
				Utility.waitUntilVisibilityOfAllElements(alertPageLib.getallTriggeredAlertsInAllOption());
			    allTriggeredAlerts=alertPageLib.getalertSection();
			   }catch(StaleElementReferenceException e1){
				e1.printStackTrace();
			}
		}
		//verifying triggered alerts present or not
		if(allTriggeredAlerts.size()!=0){
			int noOfTriggeredAlerts=allTriggeredAlerts.size();
			alertPageLib.getalertDropdownSelection().click();
			allAlertOptions.get(0).click();
			Utility.waitUntilVisibilityOfAllElements(alertPageLib.getallTriggeredAlertsInAllOption());
			List<WebElement> allTriggeredInALL=alertPageLib.getallTriggeredAlertsInAllOption();
			Assert.assertEquals(allTriggeredInALL.size(), noOfTriggeredAlerts,"triggered alert not matching");
			logger.info(allTriggeredInALL.size()+" is matiching with "+noOfTriggeredAlerts);
		 }else{
			logger.info("No alerts present");
		  }
	}
	
	/**
	 * Method Description (testCase:0501):Click SET ALERT select PRICE, EMAIL NOTIFICATION,and type a NOTE. 
	   Symbol should be prefilled with the current stock and should not be changeable.
	 * Created By:- Mamata, Created Date:- 06/06/2016
	 * Changes made#1:
	**/
	public void TC0501_AlertsNotesBlogs(String price){
		Utility.waitUntilVisibilityOfAllElements(alertPageLib.getalertSection());
		waitUntilElementIsClickable(alertPageLib.getSymbolEntryField());
		//get the ticker name
		String inputSymbol=alertPageLib.getSymbolEntryField().getAttribute("value");
		alertPageLib.getsetAlertLink().click();
		waitUntilElementisVisible(alertPageLib.getsetPriceAlertWindow());
		
		//verify alert window symbol
		Assert.assertEquals(alertPageLib.getalertSymbolText().getText(),inputSymbol, "Symbol field not prefilled with current ticker");
		alertPageLib.getpriceEntryField().sendKeys(price);
		alertPageLib.getemailNotificationControl().get(0).click();
		alertPageLib.getnoteLink().click();
		waitUntilElementIsClickable(alertPageLib.getnoteTextArea());
		alertPageLib.getnoteTextArea().sendKeys("ticker at this price");
		Utility.waitUntilElementIsClickable(alertPageLib.getsetpriceDoneButton());
		alertPageLib.getsetpriceDoneButton().click();
		
		//get the recently created alert price
		String cretedAlertText=alertPageLib.getAllAlertPrice().get(0).getText().trim().replace("$", "");
		System.out.println("alertprice:"+cretedAlertText);
		double alertPrice=Double.parseDouble(cretedAlertText);
		double expectedPrice=Double.parseDouble(price);
		Assert.assertEquals(alertPrice, expectedPrice,"Alert not created");
	}
	
	/**
	 * Method Description (testCase:0503):Verify that when you type in an invalid price (e.g. "abc"), you get the appropriate red error message, and the DONE button does not let you save the alert.
	   Symbol should be prefilled with the current stock and should not be changeable.
	 * Created By:- Mamata, Created Date:- 30/03/2017
	 * Changes made#1:
	**/
	
	public void TC0503_AlertsNotesBlogs(String invalidPrice){
		alertPageLib.getsetAlertLink().click();
		Utility.windowHandles();
		waitUntilElementisVisible(alertPageLib.getsetPriceAlertWindow());
		alertPageLib.getpriceEntryField().sendKeys(invalidPrice);
		alertPageLib.getsetpriceDoneButton().click();
		
		//verify the message
		Assert.assertEquals(alertPageLib.getpriceErrorMsg().getText(), CONSTANTS.getProperty("PRICE_ERROR_MSG"),"price error message not displayed");
		logger.info("alert price error displayed");
	}
	
	/**
	 * Method Description (testCase:0504):Verify that when you type in a price, a US "$" symbol automatically appears before the price.
	 * Created By:- Mamata, Created Date:- 30/03/2017
	 * Changes made#1:
	**/
	
	public void TC0504_AlertsNotesBlogs(String validPrice){
		alertPageLib.getpriceEntryField().clear();
		alertPageLib.getpriceEntryField().sendKeys(validPrice);
		//String priceEntered=alertPageLib.getpriceEntryField().getAttribute("Value").trim();
		 String priceEntered=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].value",alertPageLib.getpriceEntryField());
		
		//verify $ symbol
		System.out.println("entered price:"+priceEntered);
		Assert.assertTrue(priceEntered.contains(CONSTANTS.getProperty("DOLLAR_SYMBOL")),"Not contains $ symbol");
		logger.info("price value contains $ symbol");
		alertPageLib.getCloseAlert().click();
	}
	
	
	/**
	 * Method Description (testCase:0505):Click Manage Alerts. The MANAGE ALERTS WINDOW should open.
	 * Created By:- Mamata, Created Date:- 06/06/2016
	 * Changes made#1:
	**/
	
	public void TC0505_AlertsNotesBlogs(){
		alertPageLib.getmanageAlertLink().click();
		Utility.windowHandles();
		waitUntilElementisVisible(alertPageLib.getmanageAlertWindow());
		Assert.assertTrue(alertPageLib.getmanageAlertWindow().isDisplayed(),"Manage alert window not displayed");
		logger.info("Manage alert window opened");
	}
	
	
	/**
	 * Method Description (testCase:0506):Are the alerts you just created present in the MANAGE ALERTS window?
	 * Created By:- Mamata, Created Date:- 30/03/2017
	 * Changes made#1:
	**/
	public void TC0506_AlertsNotesandBlogs(){
		SoftAssert softAsserts=new SoftAssert();
		//get first alert price and ticker name
		String inputSymbol=alertPageLib.getSymbolEntryField().getAttribute("value");
		String firistAlertPrice=alertPageLib.getAllAlertPrice().get(0).getText().trim();
		
		//filter the active alerts
		alertPageLib.getsymbolFilterTextField().sendKeys(inputSymbol);
		
		//verify active alerts in manage alert window
		softAsserts.assertEquals(alertPageLib.getalertPriceManageAlert().get(0).getText().trim(), firistAlertPrice,"alerts just created  not present in the MANAGE ALERTS window");
		logger.info("alerts just created present in the MANAGE ALERTS window");
		
		//verify alert audio radio buttons
		List<WebElement> alertAudioRadBtns=alertPageLib.getalertAudioRadioButtons();
		for(int i=0;i<alertAudioRadBtns.size();i++){
			alertAudioRadBtns.get(i).click();
			softAsserts.assertTrue(alertAudioRadBtns.get(i).isSelected(), "alert audio buttons not clickabe");
			logger.info("alert audio button is clickable");
		}
		
		alertPageLib.getsymbolFilterTextField().clear();
		//verify alert window radio buttons
		List<WebElement> alertwindowRadBtns=alertPageLib.getalertWindowRadioButtons();
		for(int i=0;i<alertwindowRadBtns.size();i++){
			alertwindowRadBtns.get(i).click();
			softAsserts.assertTrue(alertwindowRadBtns.get(i).isSelected(), "alert window buttons not clickabe");
			logger.info("alert window button is clickable");
		}
		
		//verify all check boxes
		List<WebElement> allCheckBoxes=alertPageLib.getchekboxesManageAlert();
		for(int i=0;i<allCheckBoxes.size();i++){
			Utility.waitUntilElementIsClickable(allCheckBoxes.get(i));
			allCheckBoxes.get(i).click();
			softAsserts.assertTrue(allCheckBoxes.get(i).isSelected(), "check boxes not clickabe");
			logger.info("check boxes are  clickable");
			allCheckBoxes.get(i).click();
		}
		
		//verify email buttons
		List<WebElement> emailBtns=alertPageLib.getallEmailButtons();
		System.out.println("number of email buttons"+emailBtns.size());
		
		if((emailBtns.size()!=0) && (emailBtns.get(0).getText().trim().equals("ON"))){
		    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", emailBtns.get(0));
			softAsserts.assertEquals(emailBtns.get(0).getText().trim(),CONSTANTS.getProperty("OFF_BUTTON_TEXT"),"email button is not clickable");
			logger.info("email button is clickable");
		}
		softAsserts.assertAll();
	}
	
	/**
	 * Method Description (testCase:0507):Can you DELETE one or more of the alerts using the DELETE button?
	 * Created By:- Mamata, Created Date:- 31/03/2017
	 * Changes made#1:
	**/
	
	public void TC0507_AlertsNotesandBlogs(){
		//locate all check boxes
		List<WebElement> allCheckBoxes=alertPageLib.getchekboxesManageAlert();
		int noOfAlerts=allCheckBoxes.size();
		//select 1st check box and delete
		allCheckBoxes.get(0).click();
		Utility.waitUntilElementIsClickable(alertPageLib.getAlertsDeleteButton());
		alertPageLib.getAlertsDeleteButton().click();
		logger.info("alerts got deleted");
		Utility.waitUntilVisibilityOfElement();
		Utility.waitUntilVisibilityOfAllElements(alertPageLib.getchekboxesManageAlert());
		Assert.assertEquals(alertPageLib.getchekboxesManageAlert().size(), noOfAlerts-1,"Alert not deleted");
		logger.info("alert got deleted");
	}
	
	/**
	 * Method Description (testCase:0508):Verify tabs-Active Alerts, Triggered Alerts and List Alert present
       Do the various radio buttons, checkboxes, and EMAIL buttons function?
	 * Created By:- Mamata, Created Date:- 31/03/2017
	 * Changes made#1:
	**/
	//testCase:0508:
	public void TC508_AlertsNotesandBlogs(){
		Assert.assertTrue(alertPageLib.getmanageAlertWindow().isDisplayed(),"Manage alert window not displayed");
		String manageAlertsTabs[]={"Active Alerts","Triggered Alerts","Event Alerts","Smart Alerts"};
		List<WebElement> alertsTabs=alertPageLib.getmanageAlertWindowTabs();
		System.out.println("no of tabs:"+alertsTabs.size());
		for(int i=0;i<alertsTabs.size();i++){
			Assert.assertTrue(alertsTabs.get(i).getText().contains(manageAlertsTabs[i]), "Tab not present");
		}
	}
	
	/**
	 * Method Description (testCase:0509):Click over to the TRIGGERED ALERTS tab. Do the various radio buttons, checkboxes, and EMAIL buttons function?
       Do the various radio buttons, checkboxes?
	 * Created By:- Mamata, Created Date:- 31/03/2017
	 * Changes made#1:
	**/
	public void TC509_AlertsNotesandBlogs(){
		SoftAssert softAsserts=new SoftAssert();
		//locate all alerts 
		List<WebElement> alertsTabs=alertPageLib.getmanageAlertWindowTabs();
		//select triggered alerts tab
		alertsTabs.get(1).click();
		logger.info("selcted alert tab:"+alertsTabs.get(1).getText());
		
		
		//verify alert audio radio buttons
		List<WebElement> alertAudioRadBtns=alertPageLib.getalertAudioRadioButtons();
		for(int i=0;i<alertAudioRadBtns.size();i++){
			alertAudioRadBtns.get(i).click();
			softAsserts.assertTrue(alertAudioRadBtns.get(i).isSelected(), "alert audio buttons not clickabe");
			logger.info("alert audio button is clickable");
		}
				
		//verify alert window radio buttons
		List<WebElement> alertwindowRadBtns=alertPageLib.getalertWindowRadioButtons();
		for(int i=0;i<alertwindowRadBtns.size();i++){
		 alertwindowRadBtns.get(i).click();
		 softAsserts.assertTrue(alertwindowRadBtns.get(i).isSelected(), "alert window buttons not clickabe");
		 logger.info("alert window button is clickable");
		}
				
		//verify all check boxes
		  List<WebElement> allCheckBoxes=alertPageLib.gettriggredAlertCheckboxes();
		  for(int i=0;i<allCheckBoxes.size();i++){
		  allCheckBoxes.get(i).click();
		  softAsserts.assertTrue(allCheckBoxes.get(i).isSelected(), "check boxes not clickabe");
		  logger.info("check boxes are  clickable");
		  allCheckBoxes.get(i).click();
		}
		softAsserts.assertAll();
  }
	
	/**
	 * Method Description (testCase:0510):On the sidebar, hover over an alert. Verify the options edit and delete appear.
	 * Created By:- Mamata, Created Date:- 31/03/2017
	 * Changes made#1:
	**/
	public void TC510_AlertsNotesandBlogs(){
		alertPageLib.getmanageAlertCloseButton().click();
		//select active alerts from dropdown
		alertPageLib.getalertDropdownSelection().click();
		List<WebElement> allAlertsDropdownOption=alertPageLib.getAlertDropdownElements();
		allAlertsDropdownOption.get(1).click();
		
		//get all alerts details
		Utility.waitUntilVisibilityOfAllElements(alertPageLib.getallAlertsDetails());
		List<WebElement> allALertsDetails=alertPageLib.getallAlertsDetails();
		if(allALertsDetails.size()!=0){
		Actions action=new Actions(driver);
		action.moveToElement(allALertsDetails.get(0)).perform();
		Utility.waitUntilVisibilityOfAllElements(alertPageLib.getalertEditDeleteLinks());
		
		String editDeletLink[]={CONSTANTS.getProperty("EDIT_BTN_TEXT"),CONSTANTS.getProperty("DELETE_BTN_TEXT")};
		List<WebElement> editDeleteButton=alertPageLib.getalertEditDeleteLinks();
		
		for(int i=0;i<editDeleteButton.size();i++){
			Assert.assertEquals(editDeleteButton.get(i).getText().trim(), editDeletLink[i],"Edit/Delete link is not presnt");
			logger.info(editDeleteButton.get(i).getText()+":is displayed");
		}
		}else{
			Assert.fail("No alerts ceated for the current ticker");
		}
	}
	
	/**
	 * Method Description (testCase:0511):Edit an alert by changing the price or notes. Do the changes appear?
	 * Created By:- Mamata, Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	public void TC0511_AlertsNotesandBlogs(String validPrice){
		//get all alerts details
		List<WebElement> allALertsDetails=alertPageLib.getallAlertsDetails();
		if(allALertsDetails.size()!=0){
		 Actions action=new Actions(driver);
		 action.moveToElement(allALertsDetails.get(0)).perform();
		 Utility.waitUntilVisibilityOfAllElements(alertPageLib.getalertEditDeleteLinks());
		
		 List<WebElement> editDeleteButton=alertPageLib.getalertEditDeleteLinks();
		 Utility.waitUntilElementIsClickable(editDeleteButton.get(0));
		 editDeleteButton.get(0).click();
		 
		 //enter valid price to edit the alert
		 waitUntilElementisVisible(alertPageLib.getsetPriceAlertWindow());
		 alertPageLib.getpriceEntryField().clear();
		 alertPageLib.getpriceEntryField().sendKeys(validPrice);
		 alertPageLib.getsetpriceDoneButton().click();
		 
		 String cretedAlertText=alertPageLib.getAllAlertPrice().get(0).getText().trim().replace("$", "");
		 double alertPrice=Double.parseDouble(cretedAlertText);
		 double expectedPrice=Double.parseDouble(validPrice);
		 Assert.assertEquals(alertPrice, expectedPrice,"alert price not updated");
		 logger.info("alert price updated");
		}else{
		Assert.fail("No alerts ceated for the current ticker");
	 }
	}
	
	/**
	 * Method Description (testCase:0513):View a stock with no notes and verify that the new note menu appears with the "Enter journal notes here" text box.
	 * Created By:- Mamata, Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	
	public void TC0513_AlertsNotesandBlogs(){
		//selecting notes from side bar
		List<WebElement> screenAlertsNotesTab=alertPageLib.getscreenALertNoteTabs();
		screenAlertsNotesTab.get(2).click();
		waitUntilElementisVisible(alertPageLib.getnotesSection());

		Utility.waitUntilVisibilityOfAllElements(alertPageLib.getallNotes());
		List<WebElement> allNotes=alertPageLib.getallNotes();
		if(allNotes.size()==0){
			WebElement newNoteTextArea=alertPageLib.getnoteEntryTextArea();
			Assert.assertEquals(newNoteTextArea.getAttribute("placeholder").trim(), CONSTANTS.getProperty("ENTER_NOTE_DEFAULT_TEXT"),"default text is not matching");
			logger.info(newNoteTextArea.getAttribute("placeholder")+" deafult text displayed");
		 }
	}
	
	/**
	 * Method Description (testCase:0514):Create a new note. Verify the note appears in a list with the most recent on top. 
	 * Created By:- Mamata, Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	public void TC0514_AlertsNotesandBlogs(){
		//selecting notes tab from side bar
		List<WebElement> screenAlertsNotesTab=alertPageLib.getscreenALertNoteTabs();
		screenAlertsNotesTab.get(2).click();
		waitUntilElementisVisible(alertPageLib.getnotesSection());
		List<WebElement> allNotes=alertPageLib.getallNotes();
		
		//check some notes already there
		if(allNotes.size()!=0){
			Utility.waitUntilElementIsClickable(alertPageLib.getnewNoteLink());
			alertPageLib.getnewNoteLink().click();
		 }
		
		//enter new note
		 waitUntilElementIsClickable(alertPageLib.getfirstNoteTextArea());
		 alertPageLib.getfirstNoteTextArea().click();
		 String newNote="My note today";
		 alertPageLib.getfirstNoteTextArea().sendKeys(newNote);
		 alertPageLib.getnoteSaveButton().click();
		 try{
		  waitUntilElementisVisible(allNotes.get(0));
		  //Verify new Note created or not
		  Assert.assertEquals(allNotes.get(0).getText().trim(), newNote,"Recent note not updated");
		  logger.info("note created for the ticker");
		 }catch(Exception e){
			 try{
				 waitUntilElementisVisible(allNotes.get(0));
				  //Verify new Note created or not
				  Assert.assertEquals(allNotes.get(0).getText().trim(), newNote,"Recent note not updated");
				  logger.info("note created for the ticker");
			 }catch(StaleElementReferenceException e1){
				 e1.printStackTrace();
			 }
		 }
	  }

   /**
	 * Method Description (testCase:0512):Click on the Notes Tab. Verify that any previously created notes appear for the current stock with correct formatting.
	 * Created By:- Mamata, Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	public void TC0512_AlertsNotesandBlogs(){
		//locate all notes
		List<WebElement> allNotes=alertPageLib.getallNotes();
		if(allNotes.size()!=0){
			for(int i=0;i<allNotes.size();i++){
			Assert.assertTrue(allNotes.get(i).isDisplayed(),"Created notes not displayed");
			logger.info(allNotes.get(i).getText()+" is displayed");
			}
		}
	}
	
	/**
	 * Method Description (testCase:0516):Create more than 15 notes (max of 15 per page) in order to verify that the Older and Newer navigation buttons work.
	 * Created By:- Mamata, Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	
	public void TC0516_ALertNotesandBlogs(){
		//locate all notes
		List<WebElement> allNotes=alertPageLib.getallNotes();
		
		//verify whether it is having 15 or more notes
		if(allNotes.size()>=15){
		 String olderNewerText[]={CONSTANTS.getProperty("OLDER_TEXT"),CONSTANTS.getProperty("NEWER_TEXT")};
		 List<WebElement> olderNewerBtns=alertPageLib.getolderNewerButtons();
		 
		 for(int i=0;i<olderNewerBtns.size();i++){
			 Assert.assertEquals(olderNewerBtns.get(i).getText().trim(), olderNewerText[i],"older/newer text not present");
			 logger.info("older/newer buttons are present");
		 }
		}
	}
	
	/**
	 * Method Description (testCase:0517):Click on Search Journal and enter any text. Verify that the results of your search appear (will give results of notes in all stocks).
	 * Created By:- Mamata, Created Date:- 04/04/2017
	 * Changes made#1:
	**/
	
	public void TC0517_AlertsNotesandBlogs(String searchKey){
		//verify search note button
		logger.info("clicking on link:"+alertPageLib.getsearchNotesLink().getText());
		alertPageLib.getsearchNotesLink().click();
		
		//enter search key
		alertPageLib.getsearchKeyEntryTextField().clear();
		alertPageLib.getsearchKeyEntryTextField().sendKeys(searchKey);
		
		logger.info("clickin on button:"+alertPageLib.getsearchButton().getText());
		alertPageLib.getsearchButton().click();
		//verify search results
		Utility.waitUntilVisibilityOfAllElements(alertPageLib.getallSearchResults());
		List<WebElement> searchResults=alertPageLib.getallSearchResults();
		Assert.assertTrue(searchResults.size()>0,"Search results not displayed");
		logger.info("Search results displayed");
	}
	
	/**
	 * Method Description (testCase:0518):Create the same note for multiple stocks and search your journal for the note. Each stock should appear. Now click on "Show results in List Panel". Any stock in the results pane should appear in the List Panel.
	 * Created By:- Mamata, Created Date:- 04/04/2017
	 * Changes made#1:
	**/
	public void TC0518_AlertsNotesandBlogs(){
		//verify show results in List Panel
		logger.info("Clicking on link: "+alertPageLib.getshowResultsinLM().getText());
		Utility.waitUntilElementIsClickable(alertPageLib.getshowResultsinLM());
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", alertPageLib.getshowResultsinLM());
		
		
		//verify list manager
		waitUntilElementIsClickable(alertPageLib.getwaitJournalSearch());
		Assert.assertEquals(alertPageLib.getlistItemName().getText().trim(), CONSTANTS.getProperty("JOURNAL_NOTE_LIST"),"list manager not displayed");
		logger.info("list displyed:"+alertPageLib.getlistItemName().getText());
		
		/*//get all the ticker names from list manager compare it with the results
		List<WebElement> searchResults=alertPageLib.getallSearchResults();
		Set<String> uniqueSearchResults=new HashSet<String>();
		Utility.waitUntilVisibilityOfAllElements(alertPageLib.getsymbolList());
		List<WebElement> symbolList=alertPageLib.getsymbolList();
		for(int i=0;i<searchResults.size();i++){
		Assert.assertTrue(searchResults.get(i).getText().trim().contains(symbolList.get(i).getText()), "tickers not displayed in List manager");
		logger.info("all tickers displayed in LM");
		}*/
	}
	
	/**
	 * Method Description (testCase:0519):Hover over a note. Verify the Edit and Delete options appear.
	 * Created By:- Mamata, Created Date:- 04/04/2017
	 * Changes made#1:
	**/
	
	public void TC0519_AlertsNotesandBlogs(){
		//select note button
		List<WebElement> screenAlertsNotesTab=alertPageLib.getscreenALertNoteTabs();
		screenAlertsNotesTab.get(2).click();
		waitUntilElementisVisible(alertPageLib.getnotesSection());
		
		//locate all the note displayed
		List<WebElement> allNotes=alertPageLib.getallNotes();
		String editDeletLink[]={CONSTANTS.getProperty("EDIT_BTN_TEXT"),CONSTANTS.getProperty("DELETE_BTN_TEXT")};
		if(allNotes.size()!=0){
			//get the edit and delete button from first note
			Actions action=new Actions(driver);
			action.moveToElement(allNotes.get(0)).perform();
			Utility.waitUntilElementisVisible(alertPageLib.getnoteEditButon());
			Assert.assertEquals(alertPageLib.getnoteEditButon().getText().trim(), editDeletLink[0],"Edit button not appeared");
			Assert.assertEquals(alertPageLib.getnotedeleteButon().getText().trim(), editDeletLink[1],"delete button not appeared");
			logger.info("Edit/Delete button not appeared");
		}else{
			Assert.fail("No alerts to view Edit or delete");
		}
	}
	
	/**
	 * Method Description (testCase:0519):Edit a note. Verify that the changes are saved.
	 * Created By:- Mamata, Created Date:- 31/03/2017
	 * Changes made#1:
	**/
	
	public void TC0520_AlertsNotesandBlogs(String newNote){
		//get all the notes displayed
		List<WebElement> allNotes=alertPageLib.getallNotes();
		if(allNotes.size()!=0){
			Actions action=new Actions(driver);
			action.moveToElement(allNotes.get(0)).perform();
			Utility.waitUntilElementisVisible(alertPageLib.getnoteEditButon());
			
			//verify  note Edit button
			alertPageLib.getnoteEditButon().click();
			Utility.waitUntilElementisVisible(alertPageLib.getnoteEntryTextArea());
			alertPageLib.getnoteEntryTextArea().clear();
			alertPageLib.getnoteEntryTextArea().sendKeys(newNote);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", alertPageLib.getnoteSaveButton());
			try{
			  waitUntilElementisVisible(allNotes.get(0));
			  Assert.assertEquals(allNotes.get(0).getText().trim(), newNote,"Recent note not updated");
			  logger.info("note updated");
			 }catch(Exception e){
				try{
					waitUntilElementisVisible(allNotes.get(0));
					Assert.assertEquals(allNotes.get(0).getText().trim(), newNote,"Recent note not updated");
					logger.info("note updated");
				}catch(StaleElementReferenceException e1){
					e1.printStackTrace();
				}
			}
		}
		else{
			Assert.fail("no notes present to edit");
		}
	}
	
	/**
	 * Method Description (testCase:0521):Delete a note. Verify that the note is no longer visible on the list.
	 * Created By:- Mamata, Created Date:- 04/04/2017
	 * Changes made#1:
	**/
	public void TC0521_AlertsNotesandBlogs(){
		///get all the notes
		List<WebElement> allNotes=alertPageLib.getallNotes();
		if(allNotes.size()!=0){
			int noOfNotes=allNotes.size();
			Actions action=new Actions(driver);
			action.moveToElement(allNotes.get(0)).perform();
			Utility.waitUntilElementisVisible(alertPageLib.getnoteEditButon());
			
			//verify  note Edit button
			alertPageLib.getnotedeleteButon().click();
			Assert.assertEquals(alertPageLib.getallNotes().size(), noOfNotes,"Notes not deleted");
			logger.info("note deleted");
		}
		else{
			Assert.fail("no notes present to edit");
		}
	}
	
	/**
	 * Method Description (testCase:0522):Click on the Blogs tab. Verify a list of blogs appear related to the current stock with the newest on top.
	 * Created By:- Mamata, Created Date:- 04/04/2016
	 * Changes made#1:
	**/
	public void TC0522_AlertsNotesandBlogs(){
		//selecting blogs tab from side bar
		List<WebElement> screenAlertsNotesTab=alertPageLib.getscreenALertNoteTabs();
		screenAlertsNotesTab.get(3).click();
	    waitUntilElementisVisible(alertPageLib.getblogsSection());
	    
	    //getting all the blogs dates
	    List<WebElement> blogsDates=alertPageLib.getallBlogsDate();
	    List<String> actualDates=new ArrayList<String>();
	    for(int i=0;i<blogsDates.size();i++) {
	    	String dateText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",blogsDates.get(i));
			actualDates.add(dateText);
	    }
	    Date[] dates1=new Date[actualDates.size()];
	    DateFormat dateFormatter=new SimpleDateFormat("MM/dd/yyyy");
	    for(int i=0;i<actualDates.size();i++){
				try {
					dates1[i]=dateFormatter.parse(actualDates.get(i).toString());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    }
	    List<String> dateText=new ArrayList<String>();
	    for(int i=0;i<dates1.length;i++){
	    	dateText.add((String)new SimpleDateFormat("yyyy/MM/dd",Locale.ENGLISH).format(dates1[i]));
	    }
		
		List<String> ExpDateText=new ArrayList<String>();
		ExpDateText.addAll(dateText);
		Comparator<String> cmp=Collections.reverseOrder();
		Collections.sort(ExpDateText, cmp);
		System.out.println("actual array "+dateText);
		System.out.println("Expected array "+ExpDateText);
		Assert.assertEquals(dateText, ExpDateText," not matched");
	}
	/**
	 * Method Description (testCase:0523):Verify the My Posts radio button works correctly by showing only the blogs you created in the View Posts list. 
	 * Note: not able to create posts. currently there is no posts cre 
	 * Created By:- Mamata, Created Date:- 04/04/2017
	 * Changes made#1:
	**/
	public void TC0523_AlertsNotesandBlogs(){
		//locate my post radioButton;
		WebElement myPostsCheckBox=alertPageLib.getmyPostCheckBox();
		myPostsCheckBox.click();
		
		//verify it is displaying my posts
		Assert.assertTrue(myPostsCheckBox.isSelected(), "it is not displaying my posts");
		logger.info("it is displaying all posts created by current user");
		myPostsCheckBox.click();
	}
	
	/**
	 * Method Description (testCase:0524):Verify that each blog contains the name, posted date, blogger name, comments, and the star rating.
	 * Created By:- Mamata, Created Date:- 06/04/2017
	 * Changes made#1:
	**/
	public void TC0524_AlertsNotesandBlogs(){
		SoftAssert softAsserts=new SoftAssert();
		List<WebElement> allBlogs=alertPageLib.getallBlogs();
		List<WebElement> allBlogsName=alertPageLib.getblogsNames();
		List<WebElement> blogsDates=alertPageLib.getallBlogsDate();
		List<WebElement> bloggerNames=alertPageLib.getallComments();
		List<WebElement> starRatings=alertPageLib.getallStarRatings();
		
		//get the number of blogs
		int noOfBlogs=allBlogs.size();
		if(noOfBlogs!=0){
			//verify blogs name
			softAsserts.assertTrue(allBlogsName.get(0).isDisplayed(), "Blog name not displayed");
			softAsserts.assertEquals(allBlogsName.size(), noOfBlogs,"Blogs name not displyed for all blogs");
			logger.info("blogs name displayed");
			
			//verify blogs dates
			softAsserts.assertTrue(blogsDates.get(0).isDisplayed(), "Blog date not displayed");
			softAsserts.assertEquals(blogsDates.size(), noOfBlogs,"Blogs date not displyed for all blogs");
			logger.info("blogs Date displayed");
			
			//verify blogger names
			softAsserts.assertTrue(bloggerNames.get(0).isDisplayed(), "Blogger name not displayed");
			softAsserts.assertEquals(bloggerNames.size(), noOfBlogs,"Blogger name not displyed for all blogs");
			logger.info("blogger name displayed");
			
			//Verify star ratings
			softAsserts.assertTrue(starRatings.get(0).isDisplayed(), "star ratings not displayed");
			softAsserts.assertEquals(starRatings.size(), noOfBlogs,"star ratings not displyed for all blogs");
			logger.info("star rating displayed");
			
			softAsserts.assertAll();
		}else{
			Assert.fail("No blogs for current ticker");
		}
	}
	
	/**
	 * Method Description (testCase:0525):Click on the blog title. Verify the web page loads with the correct blog. 
	 * Created By:- Mamata, Created Date:- 06/04/2017
	 * Changes made#1:
	**/
	public void TC0525_AlertsNotesandBlogs(){
		List<WebElement> allBlogsName=alertPageLib.getblogsNames();
		//Verifying first blog name
		String firstBlogName=allBlogsName.get(0).getText().trim();
		allBlogsName.get(0).click();
		try{
			if(driver.getWindowHandles().size()>2){
				Utility.windowHandles();
				Utility.waitUntilElementisVisible(alertPageLib.getblogTitleInNewPage());
				Assert.assertEquals(alertPageLib.getblogTitleInNewPage().getText().trim(),firstBlogName,"web page not load with the correct blog");
				logger.info("web page loads with the correct blog");
			}else{
				Assert.fail("no new window opened");
			}
		}finally{
			driver.close();
			Utility.windowHandles();
		}
	}
	
	/**
	 * Method Description (testCase:0526):Go back to the MS tool and click on the blog author. Verify a web page loads with the user profile of the blog author. 
	 * Created By:- Mamata, Created Date:- 31/03/2017
	 * Changes made#1:
	**/
	public void TC0526_AlertsNotesandBlogs(){
		List<WebElement> allBlogsAuthor=alertPageLib.getblogAuhtors();
		//Verifying first blog name
		String firstBlogAuth=allBlogsAuthor.get(0).getText().trim();
		Utility.waitUntilElementIsClickable(allBlogsAuthor.get(0));
		allBlogsAuthor.get(0).click();
		try{
			if(driver.getWindowHandles().size()>2){
				Utility.windowHandles();
				Utility.waitUntilElementisVisible(alertPageLib.getblogTitleInNewPage());
				Assert.assertEquals(alertPageLib.getauthorNameInNewPage().getText().trim(),firstBlogAuth,"web page not load with the correct blogger name");
				logger.info("web page loads with the correct bloger name");
			}else{
				Assert.fail("no new window opened");
			}
		}finally{
			driver.close();
			Utility.windowHandles();
		}	
	}
	
	/**
	 * Method Description (testCase:0523):Go to the Create Post tab. Verify the two check buttons work correctly and that you are able to click the Create Message button which opens up a new page in the web browser. 
	 * Created By:- Mamata, Created Date:- 31/03/2017
	 * Changes made#1:
	**/
	public void TC0527_AlertsNotesandBlogs(){
		List<WebElement> screenAlertsNotesTab=alertPageLib.getscreenALertNoteTabs();
		screenAlertsNotesTab.get(3).click();
		waitUntilElementisVisible(alertPageLib.getblogsSection());
		alertPageLib.getcreatePostTab().click();
		List<WebElement> blogPostCheckBox=alertPageLib.getcreateBlogCheckbox();
		for(int i=0;i<blogPostCheckBox.size();i++){
		blogPostCheckBox.get(i).click();
		}
		alertPageLib.getcreateMessageButton().click();
		try{
			if(driver.getWindowHandles().size()>1){
		     Utility.windowHandles();
		     Utility.verifyPageUrl(CONSTANTS.getProperty("BLOGPOST_URL"));
		     driver.close();
		     Utility.windowHandles();
		     //Assert.fail("Existing bug:MSWEB-214");
			}else{
				Assert.fail("nno new window opened");
			}
		 }catch(Exception e){
			
				e.printStackTrace();
			}
	}
	
	
}
