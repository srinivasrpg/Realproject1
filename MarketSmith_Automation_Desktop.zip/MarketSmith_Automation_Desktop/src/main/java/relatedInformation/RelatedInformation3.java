package relatedInformation;

import static genericLib.Utility.*;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import genericLib.Utility;

public class RelatedInformation3 {
	RelatedInformation3Lib pageLib=PageFactory.initElements(driver, RelatedInformation3Lib.class);
	
	/**
	 * Method Description (testCase:0671):In List Manager, go to REPORTS > MUTUAL FUNDS, and click on one of the groups in the list to bring up the mutual fund in your CHARTS window
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0671:
	public void tc0671_ChartMutualFundTicker(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getReportsLink());
     	WebElement reportsLink=pageLib.getReportsLink();
     	if(!(pageLib.getReportClass().getAttribute("class").contains("down"))){
     	 reportsLink.click();
     	}
     	waitUntilElementIsClickable(pageLib.getmutualFundFolder());
     	pageLib.getmutualFundFolder().click();
     	if(!(pageLib.getmutualFundSpan().getAttribute("class").contains("down"))){
     		pageLib.getmutualFundSpan().click();
     	}
     	//pageLib.getmutualFundList().click();
     	((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getmutualFundList());
     	waitUntilElementisVisible(pageLib.getwaitMutualFund());
        waitUntilVisibilityOfElement();
    	WebElement mutualFund=pageLib.getselectMutualFund();
    	String mutualFundText=mutualFund.getText();
    	Actions action = new Actions(driver);
		action.doubleClick(mutualFund).build().perform();
    	waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), mutualFundText);
    	Assert.assertEquals(pageLib.getChartSymbol().getText(), mutualFundText,"Mutual fund not charted");
	}
	
	/**
	 * Method Description (testCase:0672):When opened, does the sidebar contain the four tabs Profile,Returns,Risk,and Holdings?
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0672:
	public void tc0672_VerifyRIForMutualFund(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		waitUntilVisibilityOfElement();
		String expectedResult[]={"Profile","Returns","Risk","Holdings"};
		List<WebElement> riOptions=pageLib.getriOptions();
		for(int i=0;i<riOptions.size();i++){
			Assert.assertEquals(riOptions.get(i).getText().trim(), expectedResult[i], "Not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0673):Open the Profile tab.Verify the following tables appear and load with information:Fund Overview,Expenses,Tax Efficiency,and Purchase Details.
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0673:
	public void tc0673_VerifyProfileTab(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(0));
		riOptions.get(0).click();
		waitUntilPresenceOfAllElements(".profileContentTable>tbody>tr>th");
		String profileTables[]={"Fund Overview","Expenses","Tax Efficiency","Purchase Details"};
		List<WebElement> profTables=pageLib.getprofileTables();
		for(int i=0;i<profTables.size();i++){
			Assert.assertEquals(profTables.get(i).getText().trim(), profileTables[i],"Table not present");
		}
	}
	
	/**
	 * Method Description (testCase:0674):Verify Fund Overview contains Net Assets,Objective,Family,O'Neil Ratings vs. Category and All Funds,Fund Manager,Start Date,and Policy Statement.
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0674:
	public void tc0674_VerifyFundOverviewTable(){
		waitUntilPresenceOfAllElements(".profileContentTable>tbody>tr>th");
		List<WebElement> profTables=pageLib.getprofileTables();
		Assert.assertTrue(profTables.get(0).isDisplayed(),"Table not present");
		String[] fundOverViewTabInfo={"Net Assets","Objective","Family","O'Neil Ratings","vs. Category","vs. All Funds","Fund Manager","Start Date","Policy Statement:"};
		List<WebElement> funoverTableInfo=pageLib.getfundOverviewTabInfo();
		for(int i=0;i<funoverTableInfo.size();i++){
			Assert.assertEquals(funoverTableInfo.get(i).getText().trim(), fundOverViewTabInfo[i],"Informatin is missing");
		}
	}
	
	/**
	 * Method Description (testCase:0675):Verify Expenses contains Front End Load,Expense Ratio,and 12B-1 Fee.
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0675:
	public void tc0675_VerifyExpensesTable(){
		List<WebElement> profTables=pageLib.getprofileTables();
		Assert.assertTrue(profTables.get(1).isDisplayed(),"Table not present");
		String[] expensesTabInfo={"Front End Load","Expense Ratio","12B-1 Fee"};
		List<WebElement> expensesTableInfo=pageLib.getexpensesTableInfo();
		for(int i=0;i<expensesTableInfo.size();i++){
			Assert.assertEquals(expensesTableInfo.get(i).getText(),expensesTabInfo[i],"Information not present");
		}
	}
	
	/**
	 * Method Description (testCase:0676):Verify Tax Efficiency contains Distribtuion Frequency,5-Year After Tax Return,Turnover,and Yield..
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0676:
	public void tc0676_VerifyTaxEfficiencyTable(){
		List<WebElement> profTables=pageLib.getprofileTables();
		Assert.assertTrue(profTables.get(2).isDisplayed(),"Table not present");
		String[] taxEfficiencyTabInfo={"Distribution Frequency","5-Year After Tax Return","Turnover","Yield"}; 
		List<WebElement> taxEfficiencyTable=pageLib.gettaxEfficiency(); 
		for(int i=0;i<taxEfficiencyTable.size();i++){
			Assert.assertEquals(taxEfficiencyTable.get(i).getText().trim(),taxEfficiencyTabInfo[i],"information not present");
		}
	}
	
	/**
	 * Method Description (testCase:0677):Verify Purchase Details contains a hyperlink to their website,Phone Number,New Investors, and Min Initial Investment.
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0677:
	public void tc0677_VerifyPurchaseDetailsTab(){
		List<WebElement> profTables=pageLib.getprofileTables();
		Assert.assertTrue(profTables.get(3).isDisplayed(),"Table not present");
		String[] purchaseDetailsTabInfo={"www","Phone Number","New Investors","Min Initial Investment"};
		List<WebElement> purchaseInfo=pageLib.getpurchaseDetails();
		for(int i=0;i<purchaseInfo.size();i++){
			Assert.assertTrue(purchaseInfo.get(i).getText().contains(purchaseDetailsTabInfo[i]),"Information not present");
		}
	}
	
	/**
	 * Method Description (testCase:0678):Does the hyperlink contained in Purchase Details work as expected?
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0678:
	public void tc0678_ValidateHyperLink(){
		List<WebElement> purchaseInfo=pageLib.getpurchaseDetails();
		Assert.assertTrue(purchaseInfo.get(0).isDisplayed(),"URL not present");
		waitUntilElementIsClickable(pageLib.geturlField());
		String hyperlink=pageLib.geturlField().getAttribute("href");
		System.out.println("expected url:"+hyperlink);
		pageLib.geturlField().click();
		Utility.windowHandles();
		String actualUrl = driver.getCurrentUrl();
		System.out.println("actual url:"+actualUrl);
		Assert.assertTrue(actualUrl.contains(hyperlink), "Page url not matched");
		Utility.closeWindow();
	}
	
	/**
	 * Method Description (testCase:0679):At the bottom, is there a button labeled Show All Funds in Family?
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0679:
	public void tc0679_VerifyShowAllFundsInFamily(){
		waitUntilVisibilityOfAllElements(pageLib.getprofileTables());
		String showFundsFamilyText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllFundsInFamily());
		Assert.assertEquals(showFundsFamilyText,"Show All Funds In Family","Not Matched");
	}
	
	/**
	 * Method Description (testCase:0680):When clicked, does the button change to Hide All Funds in Family?
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0680:
	public void tc0680_VerifyHideAllFundsFamily(){
		String showFundsFamilyText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllFundsInFamily());
		Assert.assertEquals(showFundsFamilyText,"Show All Funds In Family","Not Matched");
		
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getshowAllFundsInFamily());
		String hideFundFamilyText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllFundsInFamily());
		Assert.assertEquals(hideFundFamilyText,"Hide All Funds In Family","Not Matched");
	}
	
	/**
	 * Method Description (testCase:0681):Does the list manager and sidebar become highlighted and display all Mutual Funds in the family?
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0681:
	public void tc0681_ValidateHideAllFundsFamily(){
		String hideFundFamilyText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllFundsInFamily());
		Assert.assertEquals(hideFundFamilyText,"Hide All Funds In Family","Not Matched");
		//validate side bar high lighted
		Assert.assertTrue(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar not highlighted");
		//validate list manager highlighted
		Utility.verifyBackgroundColor(pageLib.getlistPanel(), "Soft blue");
		//Validate LM displays the funds holdings 
		waitUntilVisibilityOfElement();
		waitUntilElementisVisible(pageLib.getspecialList());
		Assert.assertTrue(pageLib.getspecialList().isDisplayed(),"It has not shown funds in family");
	}
	
	/**
	 * Method Description (testCase:0682):When entering a new mutual fund symbol from a different family, does the list manager display the funds of the new family?
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0682:
	public void tc0682_EnterNewMFWhenLMinHighLightedState(String symbol){
		Assert.assertTrue(pageLib.getspecialList().isDisplayed(),"It has not shown funds in family");
		Utility.EnterStockSymbol(symbol);
		waitUntilElementisVisible(pageLib.getsymbolInformation());
		waitUntilVisibilityOfElement();
		Assert.assertTrue(pageLib.getspecialList().getText().contains(symbol), "It is not display the fund ownership list for new ticker");
	}
	
	/**
	 * Method Description (testCase:0683):When clicking Hide All Funds in Family, does the button change back to Show All Funds in Family?
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0683:
	public void tc0683_VerifyHideAllFundsFamilyText(){
		String hideFundFamilyText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllFundsInFamily());
		Assert.assertEquals(hideFundFamilyText,"Hide All Funds In Family","Not Matched");
		//waitUntilElementIsClickable(pageLib.getshowAllFundsInFamily());
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getshowAllFundsInFamily());
		String showFundsFamilyText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllFundsInFamily());
		Assert.assertEquals(showFundsFamilyText,"Show All Funds In Family","Not Matched");
	}
	
	/**
	 * Method Description (testCase:0684):Is the list manager and sidebar no longer highlighted?
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0684:
	public void tc0684_ValidateShowAllFundsInFamily(){
		String showFundsFamilyText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllFundsInFamily());
		Assert.assertEquals(showFundsFamilyText,"Show All Funds In Family","Not Matched");
		//Validate LM is not highlighted
		Assert.assertTrue(pageLib.getlistPanel().getAttribute("style").contains("display: none;"),"still in highlighted state");
		//validate side bar is not high lighted
		Assert.assertFalse(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar highlighted");
	}
	
	/**
	 * Method Description (testCase:0685):When entering a new mutual fund symbol from a different family, do the items in the list manager remain the same?
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0685:
	public void tc0685_EnterNewMFWhenLMnotHighlighted(String symbol){
		Assert.assertFalse(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar highlighted");
		Utility.EnterStockSymbol(symbol);
		waitUntilElementisVisible(pageLib.getsymbolInformation());
		waitUntilVisibilityOfElement();
		Assert.assertFalse(pageLib.getspecialList().getText().contains(symbol), "It is not display the fund ownership list for new ticker");
	}
	
	/**
	 * Method Description (testCase:0686):Open the Returns tab. Verify three tables appear and load with information:Current,Prior Month,and a performance table with no name.
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0686:
	public void tc0686_VerifyReturnsTab(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(1));
		riOptions.get(1).click();
		waitUntilPresenceOfAllElements(".PerformancePanel.subPanel.subPanelShow>table>tbody>tr>th");
		String profileTables[]={"","Current","Prior Month"};
		List<WebElement> profTables=pageLib.getreturnsTableNames();
		for(int i=0;i<profTables.size();i++){
			Assert.assertEquals(profTables.get(i).getText().trim(), profileTables[i],"Table not present");
		}
	}
	
	/**
	 * Method Description (testCase:0687):Verify the Current and Prior Month Tables have three columns. The first being the name of the current mutual fund and the next two of two stock exchanges.
	 * Created By:- Mamata, Created Date:- 06/05/2016
	 * Changes made#1:
	**/
	//testCase:0687:
	public void tc0687_VerifyCurrentAndPriorMonthTabColumns(){
		List<WebElement> profTables=pageLib.getreturnsTableNames();
		Assert.assertTrue(profTables.get(1).isDisplayed(),"Table not present");
		String symbolEntered=pageLib.getSymbolEntryField().getAttribute("value");
		String[] currentTableColumns={symbolEntered,"S&P 500","Russ2000"};
		List<WebElement> curretnTableInfo=pageLib.getcurrentTableColumns();
		for(int i=0;i<curretnTableInfo.size();i++){
			Assert.assertEquals(curretnTableInfo.get(i).getText().trim(), currentTableColumns[i],"Information not present");
		}
		
		String[] priorMonthTableColumns={symbolEntered,"S&P 500","Russ2000"};
		List<WebElement> priorMonthTableInfo=pageLib.getpriorMonthTableColumns();
		for(int i=0;i<priorMonthTableInfo.size();i++){
			Assert.assertEquals(priorMonthTableInfo.get(i).getText().trim(), priorMonthTableColumns[i],"Information not present");
		}
	}
	
	/**
   	 * Method Description (testCase:0671): Verify the Current table has "YTD", "1 Day", "1 Week", "4 Weeks", "12 Weeks", "26 Weeks", "Since Mkt Low 3/9/09", and "Since Mkt High 10/9/07".
   	 * Created By:- Mamata, Created Date:- 21/03/2017
   	 * Changes made#1:
   	**/
	
	public void TC0688_RelatedInformation(){
		//current table all rows
		String currentTableRows[]={CONSTANTS.getProperty("YTD_TEXT"),CONSTANTS.getProperty("1DAY_TEXT"),CONSTANTS.getProperty("1WEEK_TEXT"),CONSTANTS.getProperty("4WEEKS"),CONSTANTS.getProperty("12WEEKS_TEXT"),CONSTANTS.getProperty("26WEEKS_TEXT"),CONSTANTS.getProperty("52WEEKS_TEXT"),CONSTANTS.getProperty("MKT_LOW_TEXT"),CONSTANTS.getProperty("MKT_HIGH_TEXT")};
		
		List<WebElement> currentTabLabels=pageLib.getcurrentTableRows();
		
		for(int i=1;i<currentTabLabels.size();i++){
			Assert.assertEquals(currentTabLabels.get(i).getText().trim(), currentTableRows[i-1],"Curent table label is not present");
			logger.info(currentTabLabels.get(i).getText()+" label present");
		}
	}
	
	/**
   	 * Method Description: Verify the Prior Month table has "4 Weeks", "12 Weeks", "26 Weeks", "52 Weeks", "3 Years", "5 Years", "5 Years After Tax", "10 Years".
   	 * Created By:- Mamata, Created Date:- 21/03/2017
   	 * Changes made#1:
   	**/
	public void TC0689_RelatedInformation(){
		//prior month table all rows
		String priorMonthTableRows[]={CONSTANTS.getProperty("4WEEKS_TEXT"),CONSTANTS.getProperty("12WEEKS_TEXT"),CONSTANTS.getProperty("26WEEKS_TEXT"),CONSTANTS.getProperty("52WEEKS_TEXT"),CONSTANTS.getProperty("THREE_YEARS_TEXT"),CONSTANTS.getProperty("FIVE_YEARS_TEXT"),CONSTANTS.getProperty("FIVE_YEARS_AFTER_TAX"),CONSTANTS.getProperty("TEN_YEARS_TEXT")};
				
		List<WebElement> priorTabLabels=pageLib.getpriorMonthTableRows();
				
		for(int i=1;i<priorTabLabels.size();i++){
		  Assert.assertEquals(priorTabLabels.get(i).getText().trim(), priorMonthTableRows[i-1],"prior month table label is not present");
		  logger.info(priorTabLabels.get(i).getText()+" label present");
		}
	}
	
	/**
   	 * Method Description: The last table should have percentage data for "Best 1-Yr", "Worst 1-Yr", "Best 3-Yr" and "Worst 3-Yr" as well as their End Year.
   	 * Created By:- Mamata, Created Date:- 21/03/2017
   	 * Changes made#1:
   	**/
	
	public void TC0690_RelatedInformation(){
		//prior month table all rows
		String NoNameTableRows[]={CONSTANTS.getProperty("BEST_1YEAR_TEXT"),CONSTANTS.getProperty("WORST_1YEAR_TEXT"),CONSTANTS.getProperty("BEST_3YEARS_TEXT"),CONSTANTS.getProperty("WORST_3YEARS_TEXT")};
						
		List<WebElement> noNameTabLabels=pageLib.getnoNameTableRows();
						
		for(int i=1;i<noNameTabLabels.size();i++){
		  Assert.assertEquals(noNameTabLabels.get(i).getText().trim(), NoNameTableRows[i-1],"No Name table label is not present");
		  logger.info(noNameTabLabels.get(i).getText()+" label present");
		}
	}
	
	/**
   	 * Method Description: Open the "Risk" tab. Verify four tables appear and load with information: "Standard Deviation", "Coefficient of Variation", "Sharpe Ratio", and a table with no name.
   	 * Created By:- Mamata, Created Date:- 21/03/2017
   	 * Changes made#1:
   	**/
	
	public void TC0691_RelatedInformation(){
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(2));
		logger.info("Clicking on tab:"+riOptions.get(2).getText());
		riOptions.get(2).click();
		Utility.waitUntilVisibilityOfAllElements(pageLib.gettableHeadersRiskTab());
		String RiskTables[]={CONSTANTS.getProperty("STD_DEVIATION_TEXT"),CONSTANTS.getProperty("COEFFICIENT_VARIATION"),CONSTANTS.getProperty("SHARP_RATIO")};
		List<WebElement> riskTables=pageLib.gettableHeadersRiskTab();
		
		//verify all the table names
		for(int i=0;i<riskTables.size();i++){
			Assert.assertEquals(riskTables.get(i).getText().trim(), RiskTables[i],"Table not present");
			logger.info(riskTables.get(i).getText().trim()+"table not present");
		}
	}
	
	/**
   	 * Method Description: Verify each table has "1-Year","3-Year", and "5-Year" columns.
   	 * Created By:- Mamata, Created Date:- 21/03/2017
   	 * Changes made#1:
   	**/
	
	public void TC0692_RelatedInformation(){
		String tableColumns[]={CONSTANTS.getProperty("ONE_YR_TEXT"),CONSTANTS.getProperty("THREE_YR_TEXT"),CONSTANTS.getProperty("FIVE_YR_TEXT")};
		List<WebElement> stdColumns=pageLib.getstdDevTableColumns();
		
		//Verify std Columns
		for(int i=1;i<stdColumns.size();i++){
			Assert.assertEquals(stdColumns.get(i).getText().trim(), tableColumns[i-1]);
			logger.info("column name present:"+stdColumns.get(i).getText());
		}
		
        List<WebElement> CoeffVarColumns=pageLib.getcoeffVarTableColumns();
		//Verify coefficient Var Columns
		for(int i=1;i<CoeffVarColumns.size();i++){
			Assert.assertEquals(CoeffVarColumns.get(i).getText().trim(), tableColumns[i-1]);
			logger.info("column name present:"+CoeffVarColumns.get(i).getText());
		}
		
        List<WebElement> sharpRatioColumns=pageLib.getsharpRatioTableColumns();
		//Verify sharp Ratio Columns
		for(int i=1;i<sharpRatioColumns.size();i++){
			Assert.assertEquals(sharpRatioColumns.get(i).getText().trim(), tableColumns[i-1]);
			logger.info("column name present:"+sharpRatioColumns.get(i).getText());
		}
	}
	
	/**
   	 * Method Description: Verify the first three tables have data for the current mutual fund, "S&P 500", and "Best Fit"
   	 * Created By:- Mamata, Created Date:- 21/03/2017
   	 * Changes made#1:
   	**/
	
	public void TC0693_RelatedInforation(){
		//current mutual fund
		String mutualFundText=pageLib.getSymbolEntryField().getAttribute("value");
		String allRowsFields[]={mutualFundText,CONSTANTS.getProperty("S&P500_TEXT"),CONSTANTS.getProperty("BESTFIT_TEXT")};
		
      List<WebElement> stdColumnsROws=pageLib.getstdDeviationTableRows();
		
		//Verify std Columns
		for(int i=1;i<stdColumnsROws.size();i++){
			Assert.assertEquals(stdColumnsROws.get(i).getText().trim(), allRowsFields[i-1]);
			logger.info("column name present:"+stdColumnsROws.get(i).getText());
		}
		
		List<WebElement> CoeffVarColumnsROws=pageLib.getCoefficientVarRows();
		//Verify coeff var Columns
		for(int i=1;i<CoeffVarColumnsROws.size();i++){
			Assert.assertEquals(CoeffVarColumnsROws.get(i).getText().trim(), allRowsFields[i-1]);
			logger.info("column name present:"+CoeffVarColumnsROws.get(i).getText());
		}
		
		List<WebElement> sharpRationColumnsROws=pageLib.getsharpeRatioRows();
		//Verify sharp ratio Columns
		for(int i=1;i<sharpRationColumnsROws.size();i++){
			Assert.assertEquals(sharpRationColumnsROws.get(i).getText().trim(), allRowsFields[i-1]);
			logger.info("column name present:"+sharpRationColumnsROws.get(i).getText());
		}
	}
}
