package relatedInformation;


import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import genericLib.Utility;

import static genericLib.Utility.*;

public class RelatedInformation4 {
	
	RelatedInformation4Lib oRelatedInformation4Lib=PageFactory.initElements(driver, RelatedInformation4Lib.class);
	RelatedInformation3Lib oRelatedInfo3Lib=PageFactory.initElements(driver, RelatedInformation3Lib.class);
	RelatedInformation4Lib oRelatedInfo4Lib=PageFactory.initElements(driver, RelatedInformation4Lib.class);
	WebDriverWait wait=new WebDriverWait(driver, 30);
	SoftAssert osoftassert = new SoftAssert();
	
	/************************************************************************************************************
   	 * Method Description: Open the "Risk" tab. Verify four tables appear and load with information: "Standard Deviation", "Coefficient of Variation", "Sharpe Ratio", and a table with no name.
   	 * Created By:- Venkat, Created Date:- 03/04/2017
   	 * Changes made#
	 * @throws InterruptedException 
   	************************************************************************************************************/
	
	public void tc0691_RelatedInformation() throws InterruptedException{
		
		driver.navigate().refresh();
		
		wait.until(ExpectedConditions.visibilityOf(oRelatedInfo3Lib.getSymbolEntryField()));	
		oRelatedInfo3Lib.getSymbolEntryField().clear();
		oRelatedInfo3Lib.getSymbolEntryField().sendKeys("PRRSX");
		logger.info("Entering Text in search field");
		oRelatedInfo3Lib.getSymbolEntryField().sendKeys(Keys.ENTER);
		Thread.sleep(3000);
		try{
		wait.until(ExpectedConditions.visibilityOf(oRelatedInfo4Lib.getrelatedInfoArrowIcon()));
		oRelatedInfo4Lib.getrelatedInfoArrowIcon().click();
		logger.info("Clicking on Left Arrow Icon");
		}
		catch(TimeoutException te){
			logger.info("Related info is already opened");
		}
		
		List<WebElement> riOptions=oRelatedInfo3Lib.getriOptions();
		Utility.waitUntilElementIsClickable(riOptions.get(2));
		logger.info("Clicking on tab:"+riOptions.get(2).getText());
		riOptions.get(2).click();
		Utility.waitUntilVisibilityOfAllElements(oRelatedInfo3Lib.gettableHeadersRiskTab());
		String RiskTables[]={CONSTANTS.getProperty("STD_DEVIATION_TEXT"),CONSTANTS.getProperty("COEFFICIENT_VARIATION"),CONSTANTS.getProperty("SHARP_RATIO")};
		List<WebElement> riskTables=oRelatedInfo3Lib.gettableHeadersRiskTab();
		
		//verify all the table names
		for(int i=0;i<riskTables.size();i++){
			Assert.assertEquals(riskTables.get(i).getText().trim(), RiskTables[i],"Table not present");
			logger.info(riskTables.get(i).getText().trim()+"table not present");
		}
	}
	
	/**********************************************************************************
   	 * Method Description: Verify each table has "1-Year","3-Year", and "5-Year" columns.
   	 * Created By:- Venkat, Created Date:- 03/04/2017
   	 * Changes made#1:
   	************************************************************************************/
	
	public void tc0692_RelatedInformation(){
		String tableColumns[]={CONSTANTS.getProperty("ONE_YR_TEXT"),CONSTANTS.getProperty("THREE_YR_TEXT"),CONSTANTS.getProperty("FIVE_YR_TEXT")};
		List<WebElement> stdColumns=oRelatedInfo3Lib.getstdDevTableColumns();
		
		//Verify std Columns
		for(int i=1;i<stdColumns.size();i++){
			Assert.assertEquals(stdColumns.get(i).getText().trim(), tableColumns[i-1]);
			logger.info("column name present:"+stdColumns.get(i).getText());
		}
		
        List<WebElement> CoeffVarColumns=oRelatedInfo3Lib.getcoeffVarTableColumns();
		//Verify coefficient Var Columns
		for(int i=1;i<CoeffVarColumns.size();i++){
			Assert.assertEquals(CoeffVarColumns.get(i).getText().trim(), tableColumns[i-1]);
			logger.info("column name present:"+CoeffVarColumns.get(i).getText());
		}
		
        List<WebElement> sharpRatioColumns=oRelatedInfo3Lib.getsharpRatioTableColumns();
		//Verify sharp Ratio Columns
		for(int i=1;i<sharpRatioColumns.size();i++){
			Assert.assertEquals(sharpRatioColumns.get(i).getText().trim(), tableColumns[i-1]);
			logger.info("column name present:"+sharpRatioColumns.get(i).getText());
		}
	}
	
	/********************************************************************************************************
   	 * Method Description: Verify the first three tables have data for the current mutual fund, "S&P 500", and "Best Fit"
   	 * Created By:- venkat, Created Date:- 03/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0693_RelatedInformation(){
		//current mutual fund
		String mutualFundText=oRelatedInfo3Lib.getSymbolEntryField().getAttribute("value");
		String allRowsFields[]={mutualFundText,CONSTANTS.getProperty("S&P_TEXT"),CONSTANTS.getProperty("BEST_FIT_TEXT")};
		
        List<WebElement> stdColumnsROws=oRelatedInfo4Lib.getstdDeviationTableRows();
		
		//Verify std Columns
		for(int i=1;i<stdColumnsROws.size();i++){
			Assert.assertEquals(stdColumnsROws.get(i).getText().trim(), allRowsFields[i-1]);
			logger.info("column name present:"+stdColumnsROws.get(i).getText());
		}
		
		List<WebElement> CoeffVarColumnsROws=oRelatedInfo4Lib.getCoefficientVarRows();
		//Verify coeff var Columns
		for(int i=1;i<CoeffVarColumnsROws.size();i++){
			Assert.assertEquals(CoeffVarColumnsROws.get(i).getText().trim(), allRowsFields[i-1]);
			logger.info("column name present:"+CoeffVarColumnsROws.get(i).getText());
		}
		
		List<WebElement> sharpRationColumnsROws=oRelatedInfo4Lib.getsharpeRatioRows();
		//Verify coeff var Columns
		for(int i=1;i<sharpRationColumnsROws.size();i++){
			Assert.assertEquals(sharpRationColumnsROws.get(i).getText().trim(), allRowsFields[i-1]);
			logger.info("column name present:"+sharpRationColumnsROws.get(i).getText());
		}
	}
	
	/********************************************************************************************************
   	 * Method Description: Verify the last table has "vs. S&P 500" and "vs. Best Fit" data for Beta, R-Squared, Alpha, and Treynor
   	 * Created By:- venkat, Created Date:- 03/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0694_RelatedInformation() {
		
		String rowHeaders[]={CONSTANTS.getProperty("BETA_HEADER"),CONSTANTS.getProperty("R_SQUARED_HEADER"),CONSTANTS.getProperty("ALPHA_HEADER"),CONSTANTS.getProperty("TREYNOR_HEADER")};
		String rowdata[]={CONSTANTS.getProperty("VS_S&P"),CONSTANTS.getProperty("VS_BESTFIT"),CONSTANTS.getProperty("VS_S&P"),CONSTANTS.getProperty("VS_BESTFIT"),CONSTANTS.getProperty("VS_S&P"),CONSTANTS.getProperty("VS_BESTFIT"),CONSTANTS.getProperty("VS_S&P"),CONSTANTS.getProperty("VS_BESTFIT")};
		SoftAssert softAssert=new SoftAssert();
		List<WebElement> headerText=oRelatedInfo4Lib.getlastTableHeaders();
		
		//verifying row Header Text
		for(int i=0;i<headerText.size();i++){
			softAssert.assertEquals(headerText.get(i).getText(), rowHeaders[i]);
			logger.info("Row Headers verified");
		}
		
		List<WebElement> rowFields=oRelatedInfo4Lib.getlastTableData();
		
		//verfiying Row data Text
		for(int i=0;i<rowFields.size();i++){
			softAssert.assertEquals(rowFields.get(i).getText(), rowdata[i]);
		}
		
		softAssert.assertAll();
		
	}
	
	/********************************************************************************************************
   	 * Method Description: Open the "Holdings" tab. Verify four tables appear and load with information: "Summary", "Asset Allocation", "Sector", and "Top Holdings by % Assets".
   	 * Created By:- venkat, Created Date:- 03/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0695_RelatedInformation() {
		SoftAssert softAssert=new SoftAssert();
		String tableHeadings[]={CONSTANTS.getProperty("SUMMARY_TABLE"),CONSTANTS.getProperty("ASSET_ALLOCATION_TABLE"),CONSTANTS.getProperty("SECTOR_TABLE"),CONSTANTS.getProperty("TOP_HOLDINGS_TABLE")};
		
		//clicking on Holdings link
		oRelatedInfo4Lib.getholdingButton().click();
		logger.info("Clicking on Holdings Link");
				
		//verifying Table Headings
		List<WebElement> holdingsHeading=wait.until(ExpectedConditions.visibilityOfAllElements(oRelatedInfo4Lib.getholdingsTable()));
		int i;
		for(i=0;i<holdingsHeading.size();i++){
			softAssert.assertEquals(holdingsHeading.get(i).getText(), tableHeadings[i]);
		}
				
		if(4==i){
			logger.info("4 tables displayed");
		}
		else
		{
			Assert.fail("4 tables are not displayed");
		}
		
		softAssert.assertAll();
	
	}
	
	/********************************************************************************************************
   	 * Method Description: Verify Summary has data for "Total Number of Holdings", "Percentage of Assets in Top 10 Holdings", and "Turnover Percentage".
   	 * Created By:- venkat, Created Date:- 03/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0696_RelatedInformation() {
		SoftAssert softAssert=new SoftAssert();
		String tableContent[]={CONSTANTS.getProperty("TOTAL_NO_OF_HOLDINGS"),CONSTANTS.getProperty("PER_ASSETS_TOP_10"),CONSTANTS.getProperty("TURN_OVER_PER")};
		
		List<WebElement> summeryTablecontent=oRelatedInfo4Lib.getsummeryTableContent();
		
		for(int i=0;i<summeryTablecontent.size();i++){
			softAssert.assertEquals(summeryTablecontent.get(i).getText(), tableContent[i],"Table content is not matching in Summery Table:"+i);
		}
		softAssert.assertAll();
	}
	

	/********************************************************************************************************
   	 * Method Description: Verify Asset Allocation has data for "Stocks" and "Bonds", "Other" and "Cash". The percentages should add up to 100%
   	 * Created By:- venkat, Created Date:- 04/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0697_RelatedInformation() {
		
		SoftAssert softAssert=new SoftAssert();
		String tableContent[]={CONSTANTS.getProperty("STOCKS"),CONSTANTS.getProperty("BONDS")};
		//validating Column one Data
		List<WebElement> columnTablecontent=oRelatedInfo4Lib.getcolumnOneContent();
		
		for(int i=0;i<columnTablecontent.size();i++){
			softAssert.assertEquals(columnTablecontent.get(i).getText(), tableContent[i],"Column 1 content is not matching in Asset Allocation Table:"+i);
		}
		String tableContent1[]={CONSTANTS.getProperty("OTHER"),CONSTANTS.getProperty("CASH")};
		//validating Column three data
		List<WebElement> column3content=oRelatedInfo4Lib.getcolumnThreeContent();
		
		for(int i=0;i<column3content.size();i++){
			softAssert.assertEquals(column3content.get(i).getText(), tableContent1[i],"Column 3 content is not matching in Asset Allocation Table:"+i);
		}
		
		//Validating Total Percentage
		List<WebElement> percentageValues=oRelatedInfo4Lib.getpercentageData();
		//List<Double> pricePercentInt = new ArrayList<Double>();
		double sum = 0;
		
		for(int i=0;i<percentageValues.size();i++) {
		
			String values=percentageValues.get(i).getText().replace("%", "");
			Double total = new Double(values);
			sum += total;	
			System.out.println("Price values"+sum);
	    }   
		if(sum==100){
			logger.info("total sum is equals to 100");
		}
		else{
			softAssert.fail("Total sum is not equal to 100");
		}		
		softAssert.assertAll();		
	}
	
	/********************************************************************************************************
   	 * Method Description: Verify Sector has data for the 11 Sectors as well as the stocks that are retired. The percentage should add up to 100%. 
   	 * Created By:- venkat, Created Date:- 04/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0698_RelatedInformation() {
		
		SoftAssert softAssert=new SoftAssert();
		
		List<WebElement> sectorList=oRelatedInfo4Lib.getsectorsList();
		
		if(sectorList.size()==11){
			logger.info("11 sectors Displayed");
		}
		
		else{
			softAssert.fail("11 Sectors not Displayed");
		}
		
		//Validating Total Percentage
		List<WebElement> percentageValues=oRelatedInfo4Lib.getsectorListPercent();
		//List<Double> pricePercentInt = new ArrayList<Double>();
		double sum = 0;
		
		for(int i=0;i<percentageValues.size();i++) {
		
			String values=percentageValues.get(i).getText().replace("%", "");
			Double total = new Double(values);
			sum += total;	
			System.out.println("Price values"+sum);
	    }   
		if(sum>=100 && sum<=100.5){
			logger.info("total sum is equals to 100");
		}
		else{
			softAssert.fail("Total sum is not equal to 100");
		}		
		softAssert.assertAll();	
				
	}
	
	
	/********************************************************************************************************
   	 * Method Description: Verify Top Holdings by % Assets has three columns: "Symbol", "Company", and "% Assets". 
   	 * Created By:- venkat, Created Date:- 04/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0699_RelatedInformation() {
		
		SoftAssert softAssert=new SoftAssert();
	    String tableContent[]={CONSTANTS.getProperty("SYMBOL"),CONSTANTS.getProperty("COMPANY"),CONSTANTS.getProperty("PERCENT_ASSETS")};
		
		List<WebElement> percentAssetsColumns=oRelatedInfo4Lib.getpercentAssetsColumn();
		
		for(int i=0;i<percentAssetsColumns.size();i++){
			softAssert.assertEquals(percentAssetsColumns.get(i).getText(), tableContent[i],"Percent Assets Column Headers are not matchinge:"+i);
		}
		softAssert.assertAll();		
		
	}
	
	/********************************************************************************************************
   	 * Method Description: Verify the table contains a list of stocks held by the mutual fund sorted high to low by % Assets
   	 * Created By:- venkat, Created Date:- 04/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0700_RelatedInformation() {
		
		SoftAssert softAssert=new SoftAssert();
	   
		List<WebElement> percentAssetsValues=oRelatedInfo4Lib.getpercentAssetsValues();
		List<Double> percentInt = new ArrayList<Double>();
		for(int i=1;i<percentAssetsValues.size();i++){
			//String listText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",strikeprice.get(i));
			String percentValue=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",percentAssetsValues.get(i));
			
			System.out.println("Val:"+percentValue);
			percentInt.add(Double.parseDouble(percentValue)); 
			
		}
				
		List<Double> listInteger=new ArrayList<Double>();
		listInteger.addAll(percentInt);
		System.out.println("List Int::"+listInteger);
		Collections.sort(listInteger);
		Collections.reverse(listInteger);
		
		for(int index=0;index<percentInt.size();index++) {
			System.out.println("PercentInt::"+percentInt.get(index));
            System.out.println("ListInt::"+listInteger.get(index));
			softAssert.assertEquals(percentInt.get(index), listInteger.get(index), "percent Values list is not sorted in descending order. List : " + percentInt);
		}
		
		softAssert.assertAll();		
		
	}
	
	/********************************************************************************************************
   	 * Method Description: At the bottom, is there a button labeled "Show All Holdings"
   	 * Created By:- venkat, Created Date:- 04/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0701_RelatedInformation() {
		
		//Verifying Show All HoldingsLink
		WebElement showHoldingsLinke=wait.until(ExpectedConditions.visibilityOf(oRelatedInfo4Lib.getshowAllHoldingsLink()));
		Assert.assertTrue(showHoldingsLinke.isDisplayed(),"Show All Holdings not Displayed");
		logger.info("Show All Holdings Link");;
		//Verifying Show All Holdings Label Text
		Assert.assertEquals(showHoldingsLinke.getText(), CONSTANTS.getProperty("SHOW_ALL_HOLDINS"),"Show All Holdings Text Not Matched");
		logger.info("Show All Holdings Text Matched");
	}
	

	/********************************************************************************************************
   	 * Method Description: When clicked, does the button change to "Hide All Holdings"
   	 * Created By:- venkat, Created Date:- 04/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0702_RelatedInformation() {
		
		//Clicking on Show All Holdings Link
		WebElement showHoldingsLink=wait.until(ExpectedConditions.visibilityOf(oRelatedInfo4Lib.getshowAllHoldingsLink()));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", showHoldingsLink);
		//showHoldingsLink.click();
		logger.info("Clicking on Show All Holdings link");
		
		String showHoldingsText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",showHoldingsLink);
		System.out.println("Hide Text::"+showHoldingsText);
		//Verifying Hide All Holding Label Text
		Assert.assertEquals(showHoldingsText, CONSTANTS.getProperty("HIDE_ALL_HOLDINGS"),"Hide All Holdings Text Not Matched");
		logger.info("Hide All Holdings Text Matched");
	}
	
	
	/********************************************************************************************************
   	 * Method Description:Does the list manager and sidebar become highlighted and display the list of stocks held by the current mutual fund?
   	 * Created By:- venkat, Created Date:- 04/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0703_RelatedInformation() {
		
		SoftAssert softAssert=new SoftAssert();
		WebElement sideBarBackground=oRelatedInfo4Lib.getsideBarBackGround();
		//verifying Side Bar Back ground color
		String actualColor=sideBarBackground.getCssValue("background-color");
		softAssert.assertEquals(actualColor, CONSTANTS.getProperty("SIDEBAR_COLOR"),"Side bar Back Ground color not Matching");
		
		//verifying List manager Back Ground color
		WebElement listmanagerCover=oRelatedInfo4Lib.getlistManagerCover();
		softAssert.assertTrue(listmanagerCover.isDisplayed(),"Back ground color not highlighted");
		
		//verifying List of stocks in list manager
		List<WebElement> listofStocks=oRelatedInfo4Lib.getlistManagerSymbols();
		softAssert.assertTrue(listofStocks.get(3).isDisplayed(),"Stock Symbols not Displayed");		
		softAssert.assertAll();
		
	}
	
	/********************************************************************************************************
   	 * Method Description:When entering a new mutual fund symbol, does the list manager display the stocks held by the new mutual fund?
   	 * Created By:- venkat, Created Date:- 04/04/2017
   	 * Changes made#1:
	 * @throws InterruptedException 
   	********************************************************************************************************/
	
	public void tc0704_RelatedInformation() throws InterruptedException {
		
		WebElement searchBox=oRelatedInfo4Lib.getsearchSymbol();
		//clearing Search Box
		searchBox.clear();
		logger.info("Clearing Symbols from Search box");
		//entering Mutual Symbols
		searchBox.sendKeys(CONSTANTS.getProperty("NEW_STOCK"));
		logger.info("Entering Fund Symbol");
		searchBox.sendKeys(Keys.RETURN);
		Thread.sleep(5000);
		Assert.assertTrue(oRelatedInfo4Lib.getlistName().getText().contains(CONSTANTS.getProperty("NEW_STOCK")),"New Stock Name not matches with List Manager name::Found:"+oRelatedInfo4Lib.getlistName().getText());
		logger.info("New Stock Name Matches with List manager Name");
	
	}	
	
	/********************************************************************************************************
   	 * Method Description:When clicking "Hide All Holdings", does the button change back to "Show All Holdings"?
   	 * Created By:- venkat, Created Date:- 05/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0705_RelatedInformation() {
		
		//Clicking on Show All Holdings Link
		WebElement showHoldingsLink=oRelatedInfo4Lib.getshowAllHoldingsLink();
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", showHoldingsLink);	
		//showHoldingsLink.click();
		logger.info("Clicking on Hide All Holdings link");
		
		String showHoldingsText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",showHoldingsLink);
		System.out.println("Hide Text1::"+showHoldingsText);
		//Verifying Show All Holdings Label Text
		Assert.assertEquals(showHoldingsText, CONSTANTS.getProperty("SHOW_ALL_HOLDINS"),"Show All Holdings Text Not Matched");
		logger.info("Show All Holdings Text Matched");
		
	}
	
	/********************************************************************************************************
   	 * Method Description:Is the list manager and sidebar no longer highlighted?
   	 * Created By:- venkat, Created Date:- 05/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0706_RelatedInformation() {
		
		SoftAssert softAssert=new SoftAssert();
		WebElement sideBarBackground=oRelatedInfo4Lib.getsideBarPanel();
		//verifying Side Bar Back ground color
		String actualColor=sideBarBackground.getCssValue("background-color");
		softAssert.assertEquals(actualColor, CONSTANTS.getProperty("SIDEBAR_COLOR_WHITE"),"Side bar Back Ground color not Matching");
		
		//verifying List manager Back Ground color
		WebElement listmanagerCover=oRelatedInfo4Lib.getlistManagerCover();
		try{
			wait.until(ExpectedConditions.visibilityOf(listmanagerCover));
			softAssert.fail("list manager tool not displayed in white");
		}
		catch(TimeoutException te){
			logger.info("List Manager tool displayed in white color");
		}
		
		softAssert.assertAll();
		
	}
	

	/********************************************************************************************************
   	 * Method Description:Enter a new mutual fund symbol. Verify that the items in the list manager remain the same. The LM is not supposed to change when not highlighted (show all holdings is not selected).
   	 * Created By:- venkat, Created Date:- 05/04/2017
   	 * Changes made#1:
   	********************************************************************************************************/
	
	public void tc0707_RelatedInformation() {
		
		SoftAssert softAssert=new SoftAssert();
		List<WebElement> stockSymbols=oRelatedInfo4Lib.getlistManagerSymbols();
		
		List<String> symbols = new ArrayList<String>();
		for(int i=0;i<stockSymbols.size();i++){
			String symbolsText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",stockSymbols.get(i));
			symbols.add(symbolsText); 
		}
        System.out.println("AddedList:"+symbols);		
		/*List<String> list=new ArrayList<String>();
		list.addAll(symbols);*/
		
		oRelatedInfo4Lib.getsearchSymbol().clear();
		logger.info("Clearing Symbols from Search box");
		//entering Mutual Symbols
		oRelatedInfo4Lib.getsearchSymbol().sendKeys(CONSTANTS.getProperty("MUTUALFUND_STOCK"));
		logger.info("Entering Fund Symbol");	
		oRelatedInfo4Lib.getsearchSymbol().sendKeys(Keys.RETURN);
		for(int index=0;index<symbols.size();index++) {
			System.out.println("List::"+symbols.get(index));
			String symbolsText2=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",stockSymbols.get(index));
			System.out.println("ActualSym::"+symbolsText2);
			softAssert.assertEquals(symbols.get(index), symbolsText2, "Symbols list is changed its not same as previous list  : " + symbols.get(index));
		}
		softAssert.assertAll();
	}
	
	/********************************************************************************************************
   	 * Method Description:Click the window button. Does a new window appear with the "Holdings" Information?
   	 * Created By:- venkat, Created Date:- 05/04/2017
   	 * Changes made#1:
	 * @throws InterruptedException 
   	********************************************************************************************************/
	
	public void tc0708_RelatedInformation() throws InterruptedException {
		//clicking on window icon
		oRelatedInfo4Lib.getwindowTooltipIcon().click();
		Thread.sleep(3000);
		//handling window
		Utility.windowHandles();
		
		Assert.assertEquals(oRelatedInfo4Lib.getholdingsTitle().getText(), CONSTANTS.getProperty("HOLDINGS_POPUP_TITLE"),"Holdings Title not Displayed");
		logger.info("Holdings title Displayed");
	}
	
	/********************************************************************************************************
   	 * Method Description:Click the print button. For printer, select ADOBE PDF or any other PDF printer available on your PC. Click PRINT, and when prompted, save the file to your desktop.
   	 * Created By:- venkat, Created Date:- 05/04/2017
   	 * Changes made#1:
	 * @throws InterruptedException 
   	********************************************************************************************************/
	
	/*public void tc0709_RelatedInformation() throws InterruptedException {
		//clicking on window icon
		oRelatedInfo4Lib.getprintButton().click();
		logger.info("Clicking on Print Icon");
		
		File file = new File("lib", "jacob-1.18-x64.dll");
   		System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());
	
   		AutoItX upld = new AutoItX();
   		upld.winWait("Print");
   		upld.controlFocus("Print","","");
   		System.out.println("Entering print Window");
   		upld.controlClick("Print", "", "10");
   		System.out.println("print window Closed");
   		System.out.println("Closing Print Window");
		Thread.sleep(3000);
		
		//if(driver.getWindowHandle())
	}*/
	
	/********************************************************************************************************
   	 * Method Description:Perform the window, print, export, and close button check on all tabs (Profile, Returns, Risk and Holdings)
   	 * Created By:- venkat, Created Date:- 05/04/2017
   	 * Changes made#1:
	 * @throws InterruptedException 
   	********************************************************************************************************/
	
	public void tc0715_RelatedInformation() throws InterruptedException {
		SoftAssert softAssert=new SoftAssert();
		
		if(driver.getWindowHandles().size()>2)
		{
			
			driver.close();
			Utility.windowHandles();
		}
		
		WebElement windowButton=oRelatedInfo4Lib.getwindowTooltipIcon();
		WebElement printButton=oRelatedInfo4Lib.getprintToolTip();
		WebElement downLoadButton=oRelatedInfo4Lib.getdownloadToolTip();
		WebElement closeicon=oRelatedInfo4Lib.getcloseIcon();

		//Verifying Buttons Displayed or not
		softAssert.assertTrue(windowButton.isDisplayed(),"Window Button not Displayed");
		softAssert.assertTrue(printButton.isDisplayed(),"Print Button not Displayed");
		softAssert.assertTrue(downLoadButton.isDisplayed(),"Down Load Button not Displayed");
		softAssert.assertTrue(closeicon.isDisplayed(),"Close Icon not displayed");
		softAssert.assertAll();
	}
	
	/********************************************************************************************************
   	 * Method Description:Click the export button. Does a .CSV file download?
   	 * Created By:- venkat, Created Date:- 05/04/2017
   	 * Changes made#1:
	 * @throws InterruptedException 
   	********************************************************************************************************/
	
	public void tc0714_RelatedInformation() throws InterruptedException {
		if(driver.getWindowHandles().size()>2)
		{
			
			driver.close();
			Utility.windowHandles();
		}
		try{
			Assert.assertTrue(oRelatedInfo4Lib.getcloseIcon().isDisplayed(),"close Icon not displayed");
			logger.info("Close icon displayed");
			
			oRelatedInfo4Lib.getcloseIcon().click();
			logger.info("Clicking on Close Icon");
			
			Assert.assertFalse(oRelatedInfo4Lib.getcloseIcon().isDisplayed(),"Close Icon Displayed");
			logger.info("Close icon dissapeared");
		}
		
		finally{
			//clicking on right side bar
			oRelatedInformation4Lib.getRightsidebar().click();
			logger.info("Clicking on Right side bar");
			
			
		}
		

	}
	
	
	
	
	
	//_____________________Test Cases Related to Related Informations 4 Sheet > Indices ________________________
	
	
	/**
	 * Method Description (testCase:0716): In MS-Tool get the text box type 0S&P5
	 * Created By:- Rohit , Created Date:- 03/04/2017
	 * Changes made#1:
	 * @throws InterruptedException 
	**/
	
	// Test Case : 0716
	public void TC0716_RelatedInformation4() throws InterruptedException {
		System.out.println(CONSTANTS.getProperty("SEARCH"));
		oRelatedInformation4Lib.getTextbox().sendKeys(CONSTANTS.getProperty("SEARCH"));
			Utility.waitUntilVisibilityOfElement();
		oRelatedInformation4Lib.getTextbox().sendKeys(Keys.ENTER);
		Utility.waitUntilVisibilityOfElement();
		/*Utility.performMouseHover(oRelatedInformation4Lib.getSP5link());
		oRelatedInformation4Lib.getSP5link().click();*/
		/*Actions act = new Actions(driver);
		act.moveToElement(oRelatedInformation4Lib.getSP5link()).click().perform();*/
		Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getSymbol());
		Assert.assertTrue(oRelatedInformation4Lib.getSymbol().isDisplayed(), "Expected Symbol not Present");
		
	}

	
	/**
	 * Method Description (testCase:0717): In MS-Tool open Right Sidebar
	 * Created By:- Rohit , Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0717
	public void TC0717_RelatedInformation4() {
		oRelatedInformation4Lib.getRightsidebar().click();
		Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getNewstab());
		//oRelatedInformation4Lib.getClimateTab().click();
		osoftassert.assertEquals(oRelatedInformation4Lib.getNewstab().getText(),CONSTANTS.getProperty("NEWS_TAB") ,"News Tab not present");
		osoftassert.assertEquals(oRelatedInformation4Lib.getClimateTab().getText(), CONSTANTS.getProperty("CLIMATE_TAB"),"Climate Tab not Present");
		osoftassert.assertAll();
	}

	/**
	 * Method Description (testCase:0718): In MS-Tool verify 2 table under Climate Tab
	 * Created By:- Rohit , Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0718
	public void TC0718_RelatedInformation4() {
		Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getEconomic_Calander());
		osoftassert.assertTrue(oRelatedInformation4Lib.getEconomic_Calander().isDisplayed(), "Economic Calander is not displayed in RightBar");
		osoftassert.assertTrue(oRelatedInformation4Lib.getPsychological_Indicator().isDisplayed(), "Psychological Indicator is not displayed");
		osoftassert.assertAll();
	}
	
	/**
	 * Method Description (testCase:0719): In MS-Tool verify column name 
	 * Created By:- Rohit , Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0719
	public void TC0719_RelatedInformation4() {
		List<WebElement> cal=oRelatedInformation4Lib.getColumn_EconomicCalander();
		String[] expectedCal = { CONSTANTS.getProperty("EC_NEWS"), CONSTANTS.getProperty("EC_PERIOD"),
				CONSTANTS.getProperty("EC_CONS"), CONSTANTS.getProperty("EC_ACTUAL") };
		
		
		for(int i=0;i<cal.size();i++) {
			osoftassert.assertEquals(cal.get(i).getText(), expectedCal[i], "Column Name not Matched");
		}
		osoftassert.assertAll();
				
	}
	
	/**
	 * Method Description (testCase:0720): In MS-Tool verify dates in column
	 * Created By:- Rohit , Created Date:- 03/04/2017
	 * Changes made#1:
	 * @throws InterruptedException 
	 * @throws ParseException 
	**/
	
	// Test Case : 0720
	public void TC0720_RelatedInformation4() throws Exception{
		SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		List<WebElement> date = oRelatedInformation4Lib.getDate_EconomicCalendar();
		System.out.println(date.size());
		List<Date> date1 = new ArrayList<Date>();
	
		for(WebElement d : date){
			if(!d.getText().equals("")){
				System.out.println(df.parse(d.getText()));
				date1.add(df.parse(d.getText()));
			}
		}
		
		for(int i=0;i<date1.size();i++){
			if(!date1.get(i+1).equals(null)){
				osoftassert.assertTrue(date1.get(i).before(date1.get(++i)), "Date is not in assending Order");
			}
			
		}
		osoftassert.assertAll();

		
	}
	
	/**
	 * Method Description (testCase:0721): In MS-Tool verify Psychological Indicators table has two radio buttons
	 * Created By:- Rohit , Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0721
	public void TC0721_RelatedInformation4(){
		Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getPsycological_12monthRDbutton());
		osoftassert.assertTrue(oRelatedInformation4Lib.getPsycological_12monthRDbutton().isEnabled(), "Psycological Indicator 12 month radiobutton not dispalyed");
		osoftassert.assertTrue(oRelatedInformation4Lib.getPsycological_5yearRDbutton().isEnabled(), "Psycological Indicator 5 year radiobutton not dispalyed");
		osoftassert.assertAll();
	}

	
	/**
	 * Method Description (testCase:0722): In MS-Tool verify column name of Psycological Indicator
	 * Created By:- Rohit , Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0722
	public void TC0722_RelatedInformation4() {
		List<WebElement> cal=oRelatedInformation4Lib.getColumn_PsycologicalIndiator();
		String[] expectedCal = { CONSTANTS.getProperty("PI_DATE1"), CONSTANTS.getProperty("PI_LOW"),
				CONSTANTS.getProperty("PI_DATE2"), CONSTANTS.getProperty("PI_HIGH"), CONSTANTS.getProperty("PI_NOW") };
		
		
		for(int i=0;i<cal.size();i++) {
			
			osoftassert.assertEquals(cal.get(i).getText(), expectedCal[i], "Column Name not Matched");
		}
		osoftassert.assertAll();
				
	}
	
	/**
	 * Method Description (testCase:0723): In MS-Tool verify index name of Psycological Indicator
	 * Created By:- Rohit , Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0723
	public void TC0723_RelatedInformation4(){
		List<WebElement> cal=oRelatedInformation4Lib.getIndex_PsycologicalIndicator();
		String[] expectedCal = { CONSTANTS.getProperty("PI_Index1"), CONSTANTS.getProperty("PI_Index2"),
				CONSTANTS.getProperty("PI_Index3"), CONSTANTS.getProperty("PI_Index4"), CONSTANTS.getProperty("PI_Index5"),
				CONSTANTS.getProperty("PI_Index6"), CONSTANTS.getProperty("PI_Index7") };
		

		for(int i=0;i<cal.size();i++) {
			
			osoftassert.assertEquals(cal.get(i).getText(), expectedCal[i], "Column Name not Matched");
		}
		osoftassert.assertAll();	
	}
	
	/**
	 * Method Description (testCase:0724): In MS-Tool verify Show More Info Button
	 * Created By:- Rohit , Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0724
	public void TC0724_RelatedInformation4(){
		Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getShowMoreInfo());
		Assert.assertTrue(oRelatedInformation4Lib.getShowMoreInfo().isEnabled(), "Show More Information button is not Visiable");
		
	}

	/**
	 * Method Description (testCase:0725): In MS-Tool verify Column in Economic Calander and Graph in Psycological indicator
	 * Created By:- Rohit , Created Date:- 03/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0725
	public void TC0725_RelatedInformation4(){
		Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getShowMoreInfo());
		oRelatedInformation4Lib.getShowMoreInfo().click();
		Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getReleased_EconomicCalendar());
		osoftassert.assertTrue(oRelatedInformation4Lib.getReleased_EconomicCalendar().isDisplayed(), "Released Column is not Displayed");
		osoftassert.assertTrue(oRelatedInformation4Lib.getPrior_EconomicCalendar().isDisplayed(), "Prior Column is not Displayed");
		
		osoftassert.assertTrue(oRelatedInformation4Lib.getTable_PyscologicalIndicator().isDisplayed(), "Table under psycological Section not Displayed");
		osoftassert.assertTrue(oRelatedInformation4Lib.getGraph_PyscologicalIndicator().isDisplayed(), "Graph is displayed under psycological Section");
		osoftassert.assertAll();
	}
	
	/**
	 * Method Description (testCase:0726): In MS-Tool verify scroll
	 * Created By:- Rohit , Created Date:- 04/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0726
	public void TC0726_RelatedInformation4(){
		Actions act = new Actions(driver);
		act.moveByOffset(driver.manage().window().getSize().getWidth()/2, driver.manage().window().getSize().getHeight()/2).build().perform();
		JavascriptExecutor je = (JavascriptExecutor)driver;
		je.executeScript("window.scrollBy(0, 50)");
		Utility.waitUntilVisibilityOfElement();
		osoftassert.assertTrue(oRelatedInformation4Lib.getScroll_EconomicCal().isEnabled(), "Scroll in economic Calender is not Enabled");
		osoftassert.assertTrue(oRelatedInformation4Lib.getScroll_PsycologicalCal().isEnabled(), "Scroll in Psycological Indicator is no Enabled");
		osoftassert.assertAll();
	}
	
	/**
	 * Method Description (testCase:0727): In MS-Tool verify 2 Graphs Headings
	 * Created By:- Rohit , Created Date:- 04/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0727
	public void TC0727_RelatedInformation4(){
		System.out.println("Actual headings = "+oRelatedInformation4Lib.getGraph1title_PsycologicalIndex().getText()+" , "+oRelatedInformation4Lib.getGraph2title_PsycologicalIndex().getText());
		System.out.println("Expeted headings = "+CONSTANTS.getProperty("PI_CHART1")+" , "+CONSTANTS.getProperty("PI_CHART2"));
		osoftassert.assertEquals(oRelatedInformation4Lib.getGraph1title_PsycologicalIndex().getText(), CONSTANTS.getProperty("PI_CHART1"),"1st Graph Chart Title doesn't Match");
		osoftassert.assertEquals(oRelatedInformation4Lib.getGraph2title_PsycologicalIndex().getText(), CONSTANTS.getProperty("PI_CHART2"),"2nd Graph Chart Title doesn't Match");
		osoftassert.assertAll();
	}
	
	/**
	 * Method Description (testCase:0728): In MS-Tool verify Show More information after clicking Show Less information
	 * Created By:- Rohit , Created Date:- 04/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0728
	public void TC0728_RelatedInformation4(){
		oRelatedInformation4Lib.getShowLessinfo().click();
		Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getShowMoreInfo());
		Assert.assertTrue(oRelatedInformation4Lib.getShowMoreInfo().isEnabled(), "Show More Information is not Viasiable after Clicking Show Less Info");
	}
	
	/**
	 * Method Description (testCase:0729): In MS-Tool verify New Pop after clicking New Window
	 * Created By:- Rohit , Created Date:- 04/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0729
	public void TC0729_RelatedInformation4(){
		Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getWindowbutton());
		oRelatedInformation4Lib.getWindowbutton().click();
		Utility.windowHandles();
		//System.out.println(oRelatedInformation4Lib.getHeading_Popup().getText());
		Assert.assertEquals(oRelatedInformation4Lib.getHeading_Popup().getText(), CONSTANTS.getProperty("CLIMATE_POPUP"),"Climatr POP-Up didn't Open");
		//driver.manage().window().maximize();
		
	}
	
	/**
	 * Method Description (testCase:0730): In MS-Tool verify Download Pop-Up opened after clicking Print button
	 * Created By:- Rohit , Created Date:- 04/04/2017
	 * Changes made#1:
	 * @throws InterruptedException 
	**/
	
	// Test Case : 0730
	public void TC0730_RelatedInformation4() throws InterruptedException{
		oRelatedInformation4Lib.getPrint_Button().click();
		
		try {
			Runtime.getRuntime().exec("C:\\Users\\rsharma\\Desktop\\PrintDownload.exe");
			Utility.waitUntilVisibilityOfElement();
			Assert.assertTrue(true, "File Download PopUp Not Generaed");
			
		} catch (IOException e) {
			Assert.assertTrue(false, "File Download PopUp Not Generaed");
			
		}

		driver.close();
		Utility.windowHandles();
	}
	
	/**
	 * Method Description (testCase:0733): In MS-Tool verify Download Pop-Up opened after clicking CSV buttun
	 * Created By:- Rohit , Created Date:- 04/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0733
	public void TC0733_RelatedInformation4(){
		Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getCsv_Button());
		oRelatedInformation4Lib.getCsv_Button().click();
		Utility.waitUntilVisibilityOfElement();
		//driver.switchTo().alert().dismiss();
		try {
			Runtime.getRuntime().exec("C:\\Users\\rsharma\\Desktop\\CSVDownloadPopUp.exe");
			Assert.assertTrue(true, "CSV Download PopUp Not Generaed");
		} catch (IOException e) {
			Assert.assertTrue(false, "CSV Download PopUp Not Generaed");
		}
		
		
	}

	/**
	 * Method Description (testCase:0735): In MS-Tool Right-SideBar verify Close Button
	 * Created By:- Rohit , Created Date:- 04/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0735
	public void TC0735_RelatedInformation4(){
		driver.close();
		Utility.windowHandles();
		Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getCloseButton_RideSidebar());
		oRelatedInformation4Lib.getCloseButton_RideSidebar().click();
		Assert.assertFalse(oRelatedInformation4Lib.getCloseButton_RideSidebar().isDisplayed(), "Right Side Bar Not closed");
	}
	
	/**
	 * Method Description (testCase:0736): In MS-Tool Right-SideBar verify News Section
	 * Created By:- Rohit , Created Date:- 05/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0736
	public void TC0736_RelatedInformation4(){
		oRelatedInformation4Lib.getNewstab().click();
		Utility.waitUntilVisibilityOfElement();
		if(Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getNewscontent_NewsTab())){
			System.out.println("Total Number of News = "+oRelatedInformation4Lib.getNews_newsContent().size());
			Assert.assertTrue(oRelatedInformation4Lib.getNews_newsContent().size()>0, "No News in News Content of News Tab");
		}
		else {
			Assert.assertTrue(oRelatedInformation4Lib.getNewscontent_NewsTab().isDisplayed(),"No News Content in News Tab");
		}
	}
	
	/**
	 * Method Description (testCase:0737): In MS-Tool Right-SideBar verify Edit News 
	 * Created By:- Rohit , Created Date:- 05/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0737
	public void TC0737_RelatedInformation4(){
		Assert.assertTrue(oRelatedInformation4Lib.getEditNews_NewsTab().isEnabled(),"Edit News Link is Disabled");
	}
	
	/**
	 * Method Description (testCase:0738): In MS-Tool Right-SideBar verify Content in Edit News 
	 * Created By:- Rohit , Created Date:- 05/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0738
	public void TC0738_RelatedInformation4(){
		
		Utility.performMouseHover(oRelatedInformation4Lib.getEditNews_NewsTab());
		Utility.waitUntilVisibilityOfElement();
		String[] expectedList = { CONSTANTS.getProperty("EDITNEWS_LIST2"),
				CONSTANTS.getProperty("EDITNEWS_LIST3") };
		List<WebElement> L1=oRelatedInformation4Lib.getEditNews_Content();


		for(int i=0;i<L1.size();i++) {
			System.out.println("Actual = "+L1.get(i).getText());
			System.out.println("Expected = "+expectedList[i]);
			osoftassert.assertEquals(L1.get(i).getText(), expectedList[i], "List "+i+" not matched");
		}
		osoftassert.assertAll();
	}
	
	/**
	 * Method Description (testCase:0739): In MS-Tool Right-SideBar verify Content in Edit News after selecting check box
	 * Created By:- Rohit , Created Date:- 05/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0739
	public void TC0739_RelatedInformation4(){
		oRelatedInformation4Lib.getGoogle_chkbox().click();
		
		
	}
	
	/**
	 * Method Description (testCase:0741): In MS-Tool Right-SideBar verify new window open after clicking new window button
	 * Created By:- Rohit , Created Date:- 05/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0741
	public void TC0741_RelatedInformation4(){
		Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getWindow_News());
		oRelatedInformation4Lib.getWindow_News().click();
		Utility.windowHandles();
		driver.manage().window().maximize();
		Assert.assertEquals(oRelatedInformation4Lib.getNews_Heading().getText(), CONSTANTS.getProperty("NEWS_POPUP"),"News Pop-Up not Opened");
		driver.close();
		Utility.windowHandles();
	}

	/**
	 * Method Description (testCase:0742): In MS-Tool Right-SideBar verify Refresh Button
	 * Created By:- Rohit , Created Date:- 05/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0742
	public void TC0742_RelatedInformation4(){
		Utility.waitUntilVisibilityOfElement();
		Assert.assertTrue(oRelatedInformation4Lib.getRefresh_Button().isEnabled(), "Refresh Button is no Enabled");
	}
	
	/**
	 * Method Description (testCase:0743): In MS-Tool Right-SideBar verify Refresh Button
	 * Created By:- Rohit , Created Date:- 05/04/2017
	 * Changes made#1:
	**/
	
	// Test Case : 0743
	public void TC0743_RelatedInformation4(){
		if(	Utility.waitUntilElementisVisible(oRelatedInformation4Lib.getCloseButton_RideSidebar())){
			oRelatedInformation4Lib.getCloseButton_RideSidebar().click();
			Assert.assertFalse(oRelatedInformation4Lib.getCloseButton_RideSidebar().isDisplayed(), "Right Side Bar Not closed");
		}
		else{
			Assert.assertTrue(oRelatedInformation4Lib.getCloseButton_RideSidebar().isDisplayed(), "close Button not avaliable");
		}
	}
		
}
