package relatedInformation;
import static genericLib.Utility.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import genericLib.Utility;

public class RelatedInformation2 {
	RelatedInformation2Lib pageLib=PageFactory.initElements(driver, RelatedInformation2Lib.class);
	
	/**
	 * Method Description (testCase:0636):select IndustryGroup ticker from 197IndustryGroupsList
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0636:
	public void tc0636_ChartAIndustryGroupTicker(){
		 Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		 waitUntilElementIsClickable(pageLib.getmarket197IndustryGroup());
	     WebElement market197IndustryLink=pageLib.getmarket197IndustryGroup();
	     if(!(pageLib.getMarket197DownLink().getAttribute("class").contains("down"))){
	     	market197IndustryLink.click();
		  }
	     	waitUntilElementIsClickable(pageLib.get197IndustryGroups());
	     	WebElement m197IndustryLink=pageLib.get197IndustryGroups();
	     	m197IndustryLink.click();
	     	Utility.waitUntilElementisVisible(pageLib.getWaitIndustryGroup());
	        waitUntilVisibilityOfElement();
	    	WebElement industryGroup=pageLib.getselectIndustryGroup();
	    	String industryGroupText=industryGroup.getText();
	    	Actions action = new Actions(driver);
			action.doubleClick(industryGroup).build().perform();
	    	logger.info("selected "+industryGroupText +" stock");
	    	waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), industryGroupText);
	}
	
	/**
	 * Method Description (testCase:0637):the Related Information sidebar contain the four tabs Overview,Stocks in Fund,Top Stocks, and Sector?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0637:
	public void tc0637_VerifyRIforIndustryGroups(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		waitUntilVisibilityOfElement();
		String expectedResult[]={"Over-\nview","Stocks\nin\nGroup","Top\nStocks","Sector"};
		List<WebElement> riOptions=pageLib.getriOptions();
		for(int i=0;i<riOptions.size();i++){
			Assert.assertEquals(riOptions.get(i).getText().trim(), expectedResult[i], "option Not present");
		}
	}
	
	/**
	 * Method Description (testCase:0638):Verify the sections of overview tab;
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0638:
	public void tc0638_VerifyOverviewTabSections(){
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(0));
		riOptions.get(0).click();
		waitUntilPresenceOfAllElements(".OverViewPanel>table>tbody>tr>th");
		List<WebElement> overViewTableHeaders=pageLib.getoverviewTableHeaders();
		String tableHeaders[]={"Industry Summary","Relative Strength","197 Ranking"};
		for(int i=0;i<overViewTableHeaders.size();i++){
			Assert.assertEquals(overViewTableHeaders.get(i).getText().trim(), tableHeaders[i],"Table not present");
		}
	}
	
	/**
	 * Method Description (testCase:0639):Verify Industry summary table information
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0639:
	public void tc0639_VerifyIndustrySummaryTable(){
		List<WebElement> overViewTableHeaders=pageLib.getoverviewTableHeaders();
		Assert.assertTrue(overViewTableHeaders.get(0).isDisplayed(),"Table not present");
		String industrySummaryInfo[]={"RS Rating","Group Rank","Group Market Value","Number of Stocks","New High Stocks","New Low Stocks","Sector"};
		List<WebElement> industrySummaryTableInfo=pageLib.getindustrySummaryInformation();
		for(int i=0;i<industrySummaryTableInfo.size();i++){
			Assert.assertEquals(industrySummaryTableInfo.get(i).getText(), industrySummaryInfo[i],"Inforamtion not present");
		}
	}
	
	/**
	 * Method Description (testCase:0640):Relative Strength contain relevant information for Today,1 Week Ago,4 Weeks Ago,3 Months Ago,6 Months Ago, and 1 Year Ago?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0640: 
	public void tc0640_VerifyRelativeStrengthTable(){
		List<WebElement> overViewTableHeaders=pageLib.getoverviewTableHeaders();
		Assert.assertTrue(overViewTableHeaders.get(1).isDisplayed(),"Table not present");
		String relativeStrengthInfo[]={"Today","1 Week Ago","4 Weeks Ago","3 Months Ago","6 Months Ago","1 Year Ago"};
		List<WebElement> relativeStrengthTabInfo=pageLib.getrelativeStrengthInfo();
		for(int i=0;i<relativeStrengthTabInfo.size();i++){
			Assert.assertEquals(relativeStrengthTabInfo.get(i).getText().trim(), relativeStrengthInfo[i],"Info not present");
		}
	}
	
	/**
	 * Method Description (testCase:0641):Does 197 Ranking contain relevant information for Today,1 Week Ago,4 Weeks Ago,3 Months Ago,6 Months Ago,and 1 Year Ago?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0641:
	public void tc0641_Verify197RankingTable(){
		List<WebElement> overViewTableHeaders=pageLib.getoverviewTableHeaders();
		Assert.assertTrue(overViewTableHeaders.get(2).isDisplayed(),"Table not present");
		String r197TableInfo[]={"Today","1 Week Ago","4 Weeks Ago","3 Months Ago","6 Months Ago","1 Year Ago"};
		List<WebElement> r197RankingTabInfo=pageLib.getr197RankingInfo();
		for(int i=0;i<r197RankingTabInfo.size();i++){
			Assert.assertEquals(r197RankingTabInfo.get(i).getText().trim(), r197TableInfo[i],"Info not present");
		}
	}
	
	/**
	 * Method Description (testCase:0643):At the bottom, is there a button labeled "Show 197 Industry Groups"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0643:
	public void tc0643_VerifyShow197IndustryGroups(){
		waitUntilPresenceOfAllElements(".OverViewPanel>table>tbody>tr>th");
		String showIndustryGrpText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshow197IndustryGroupButtton());
		Assert.assertEquals(showIndustryGrpText,"Show 197 Industry Groups","Text not matched");
	}
	
	/**
	 * Method Description (testCase:0644):When clicked, does the button change to "Hide 197 Industry Groups"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0644:When clicked, does the button change to "Hide 197 Industry Groups"?
	public void tc0644_VerifyHide197IndustryGroups(){
		String showIndustryGrpText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshow197IndustryGroupButtton());
		Assert.assertEquals(showIndustryGrpText,"Show 197 Industry Groups","Text not matched");
		waitUntilElementIsClickable(pageLib.getshow197IndustryGroupButtton());
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getshow197IndustryGroupButtton());
		String hideIndustryGrpText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshow197IndustryGroupButtton());
		Assert.assertEquals(hideIndustryGrpText,"Hide 197 Industry Groups","Text Not Matched");
	}
	
	/**
	 * Method Description (testCase:0645):Does the list manager and sidebar become highlighted and display all 197 Industry Groups?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0645:
	public void tc0645_ValidateHide197IndustryGrp(){
		String hideIndustryGrpText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshow197IndustryGroupButtton());
		Assert.assertEquals(hideIndustryGrpText,"Hide 197 Industry Groups","Text Not Matched");
		Assert.assertTrue(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar not highlighted");
		//validate list manager highlighted
		Utility.verifyBackgroundColor(pageLib.getlistPanel(), "Soft blue");
		//Validate LM displays all 197 industry groups list
		waitUntilVisibilityOfElement();
		waitUntilElementisVisible(pageLib.getspecialList());
		Assert.assertTrue(pageLib.getspecialList().isDisplayed(),"It has not shown all 197 industry groups list");
	}
	
	/**
	 * Method Description (testCase:0646):When clicking "Hide 197 Industry Groups", does the button change back to "Show 197 Industry Groups"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0646:
	public void tc0646_VerifyHide197IndustryGrptext(){
		String hideIndustryGrpText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshow197IndustryGroupButtton());
		Assert.assertEquals(hideIndustryGrpText,"Hide 197 Industry Groups","Text Not Matched");
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getshow197IndustryGroupButtton());
		String showIndustryGrpText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshow197IndustryGroupButtton());
		Assert.assertEquals(showIndustryGrpText,"Show 197 Industry Groups","Not Matched");
	}
	
	/**
	 * Method Description (testCase:0647):Is the list manager and sidebar no longer highlighted?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0647:
	public void tc0647_ValidateShow197IndustryGrp(){
		String showIndustryGrpText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshow197IndustryGroupButtton());
		Assert.assertEquals(showIndustryGrpText,"Show 197 Industry Groups","Not Matched");
		//Validate LM is not highlighted
		Assert.assertTrue(pageLib.getlistPanel().getAttribute("style").contains("display: none;"),"still in highlighted state");
		//validate side bar is not high lighted
		Assert.assertFalse(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar highlighted");
	}
	
	/**
	 * Method Description (testCase:0648):Open the "Stocks in Group" tab. Verify that a list of stocks appears and are loaded with information.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0648:
	public void tc0648_VerifyStockInGrpTab(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(1));
		riOptions.get(1).click();
		waitUntilPresenceOfAllElements(".componentsSysbolName");
		List<WebElement> listOfStocks=pageLib.getstocksList();
		List<String> stocksList=new ArrayList<String>(); 
		for(int i=0;i<listOfStocks.size();i++){
			String allStocks=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",listOfStocks.get(i));
			stocksList.add(allStocks);
		}
		Assert.assertTrue(listOfStocks.get(0).isDisplayed(), "not showing list of stocks");
	}
	
	/**
	 * Method Description (testCase:0649):Verify the list name is the current industry group and contains "Symbol", "Company", and "Mkt Cap (mil)" columns.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0649_VerifyStocksInGrpSection(){
		waitUntilPresenceOfAllElements(".componentsSysbolName");
		String ChartSymbol=pageLib.getChartSymbol().getText().trim();
		Assert.assertEquals(pageLib.getstocksInGrpTitle().getText().trim(), ChartSymbol,"List name is not Current industry");
		String tablHeaders[]={"Symbol","Company","Mkt Cap (mil)"};
		List<WebElement> stocksInGrpTable=pageLib.getstocksInGrpTableInfo();
		for(int i=0;i<stocksInGrpTable.size();i++){
			Assert.assertEquals(stocksInGrpTable.get(i).getText().trim(), tablHeaders[i],"TAble info not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0650):Verify the list is organized high to low by Mkt Cap (mil).
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0650_VerifyMarketCapColumn(){
		waitUntilPresenceOfAllElements(".componentsSysbolName");
		List<WebElement> marketCap=pageLib.getmarketCapValues();
		List<Integer> mktCapInt=new ArrayList<Integer>();
		for(int i=0;i<marketCap.size();i++){
			String mktCapVal=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",marketCap.get(i));
			String newMktCapVal=mktCapVal.replace(",","");
			mktCapInt.add(Integer.parseInt(newMktCapVal));
		}
		List<Integer> actualMktCap=new ArrayList<Integer>();
		actualMktCap.addAll(mktCapInt);
		Comparator<Integer> cmp=Collections.reverseOrder();
		Collections.sort(mktCapInt,cmp);
		Assert.assertEquals(actualMktCap, mktCapInt,"Not oredered based on mkt cap");
	}
	
	/**
	 * Method Description (testCase:0651):At the bottom, is there a button labeled "Show All Component Data"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0651_VerifyShowAllComponentData(){
		waitUntilPresenceOfAllElements(".componentsSysbolName");
		String showAllComponentText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllComponentData());
		Assert.assertEquals(showAllComponentText,"Show All Component Data","Text not matched");
	}
	
	/**
	 * Method Description (testCase:0652):When clicked, does the button change to "Hide All Component Data"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0652_VerifyHideAllComponentData(){
		String showAllComponentText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllComponentData());
		Assert.assertEquals(showAllComponentText,"Show All Component Data","Text not matched");
		waitUntilElementIsClickable(pageLib.getshowAllComponentData());
		((JavascriptExecutor) driver).executeScript("arguments[0].click();",pageLib.getshowAllComponentData());
		String hideComponetDataText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllComponentData());
		Assert.assertEquals(hideComponetDataText,"Hide All Component Data","Text Not Matched");
	}
	
	/**
	 * Method Description (testCase:0653):Does the list manager and sidebar become highlighted and display the list of stocks in the industry group?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0653_ValidateHideAllcomponentData(){
		String hideComponetDataText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllComponentData());
		Assert.assertEquals(hideComponetDataText,"Hide All Component Data","Text Not Matched");
		//Side bar highlighted
		Assert.assertTrue(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar not highlighted");
		//validate list manager highlighted
		Utility.verifyBackgroundColor(pageLib.getlistPanel(), "Soft blue");
		//Validate LM displays List of stocks in industry groups 
		waitUntilVisibilityOfElement();
		waitUntilElementisVisible(pageLib.getspecialList());
		Assert.assertTrue(pageLib.getspecialList().isDisplayed(),"It has not shown List of stocks in industry groups");
	}
	
	/**
	 * Method Description (testCase:0654):When entering a new industry group, does the list manager display the stocks in the newly selected industry group?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0654_EnterNewIGWhenLMinHighLightedState(String symbol){
		Assert.assertTrue(pageLib.getspecialList().isDisplayed(),"It has not shown  stocks in the newly selected industry group?");
		Utility.EnterStockSymbol(symbol);
		waitUntilElementisVisible(pageLib.getsymbolInformation());
		waitUntilVisibilityOfElement();
		Assert.assertTrue(pageLib.getspecialList().getText().contains(symbol), "It is not display the fund ownership list for new ticker");
	}
	
	/**
	 * Method Description (testCase:0655):When clicking "Hide All Component Data", does the button change back to "Show All Component Data"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0655_VerifyHideAllcomponentData(){
		String hideAllcomponenText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllComponentData());
		Assert.assertEquals(hideAllcomponenText,"Hide All Component Data","Text Not Matched");
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getshowAllComponentData());
		String showAllcomponentText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllComponentData());
		Assert.assertEquals(showAllcomponentText,"Show All Component Data","Not Matched");
	}
	
	/**
	 * Method Description (testCase:0656):Is the list manager and sidebar no longer highlighted?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0656:
	public void tc0656_ValidateShowAllComponentData(){
		String showAllcomponentText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowAllComponentData());
		Assert.assertEquals(showAllcomponentText,"Show All Component Data","Not Matched");
		//Validate LM is not highlighted
		Assert.assertTrue(pageLib.getlistPanel().getAttribute("style").contains("display: none;"),"still in highlighted state");
		//validate side bar is not high lighted
		Assert.assertFalse(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar highlighted");
	}
	
	/**
	 * Method Description (testCase:0657):When entering a new industry group, does the list manager contain the same items in the list?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0657:
	public void tc0657_EnterNewIGWhenLMnotHighlighted(String symbol){
		Assert.assertTrue(pageLib.getlistPanel().getAttribute("style").contains("display: none;"),"still in highlighted state");
		Utility.EnterStockSymbol(symbol);
		waitUntilElementisVisible(pageLib.getsymbolInformation());
		waitUntilVisibilityOfElement();
		Assert.assertFalse(pageLib.getspecialList().getText().contains(symbol), "It is not display the fund ownership list for new ticker");
	}
	
	/**
	 * Method Description (testCase:0658):Open the Top Stocks tab. Verify that the following tables appear and are loaded with information:Top RS + EPS Stocks and % Off High.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0658:
	public void tc0658_VerifyTopStocksTab(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(2));
		riOptions.get(2).click();
		waitUntilPresenceOfAllElements(".topStocksTableTitle.header");
		List<WebElement> topStocksTables=pageLib.gettopStocksTable();
		String topStocksTabInfo[]={"Top RS + EPS Stocks","% Off High"};
		for(int i=0;i<topStocksTables.size();i++){
			Assert.assertEquals(topStocksTables.get(i).getText().trim(), topStocksTabInfo[i],"Table not present");
		}
	}
	
	/**
	 * Method Description (testCase:0659):Verify Top RS + EPS Stocks contains "Symbol", "Company", "RS", and "EPS" columns.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0659:
	public void tc0659_VerifyTopRSEPSStocks(){
		List<WebElement> topStocksTables=pageLib.gettopStocksTable();
		Assert.assertTrue(topStocksTables.get(0).isDisplayed(),"Table not present");
		String[] topRsEpsStocksTable={"Symbol","Company","RS","EPS"};
		List<WebElement> topRSEPSTabInfo=pageLib.getrsEpsTableHeader();
		for(int i=0;i<topRSEPSTabInfo.size();i++){
			Assert.assertEquals(topRSEPSTabInfo.get(i).getText().trim(), topRsEpsStocksTable[i],"column is missing");
		}
	}
	
	/**
	 * Method Description (testCase:0660):Verify % Off High contains "Symbol", "Company", and "% Off High" columns.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0660:
	public void tc0660_VerifyPercentageOffHigh(){
		List<WebElement> topStocksTables=pageLib.gettopStocksTable();
		Assert.assertTrue(topStocksTables.get(1).isDisplayed(),"Table not present");
		String[] percentOffHighTable={"Symbol","Company","% Off High"};
		List<WebElement> percentOffHighTabInfo=pageLib.getpercentageOffHighTabInfo();
		for(int i=0;i<percentOffHighTabInfo.size();i++){
			Assert.assertEquals(percentOffHighTabInfo.get(i).getText().trim(), percentOffHighTable[i],"column is missing");
		}
	}
	
	/**
	 * Method Description (testCase:0661):Open the Sectors tab. Verify the sector name the industry group belongs to appears on top as well as the Top Industries in Sector table.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0661:
	public void tc0661_VerifySectors(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(3));
		riOptions.get(3).click();
		waitUntilElementisVisible(pageLib.getindustryGrpinSectorTab());
		String igNameTxt=pageLib.getindustryGrpinSectorTab().getText().trim();
		String chartSymbolTxt=pageLib.getChartSymbol().getText().trim().toUpperCase();
		Assert.assertTrue(chartSymbolTxt.contains(igNameTxt), "Industry group name not matching");
		Assert.assertEquals(pageLib.getsectorTabHeader().getText().trim(), "Top Industries In Sector","Text not matched");
	}
	
	/**
	 * Method Description (testCase:0662):Verify the table contains Industry Group and Group Rank columns and are filled with 4 rows of data
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0662:.
	public void tc0662_VerifyTableColumns(){
		Assert.assertEquals(pageLib.getsectorTabHeader().getText().trim(), "Top Industries In Sector","Text not matched");
		String sectorTabColumn[]={"Industry Group","Group Rank"};
		List<WebElement> indSecorTabCols=pageLib.getsectorTabColumns();
		for(int i=0;i<indSecorTabCols.size();i++){
			Assert.assertEquals(indSecorTabCols.get(i).getText().trim(), sectorTabColumn[i],"Column not present");
		}
	}
}
