package relatedInformation;

import static genericLib.Utility.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import genericLib.Utility;



public class RelatedInformation1 {
	RelatedInformation1Lib pageLib=PageFactory.initElements(driver, RelatedInformation1Lib.class);
	
	/**
	 * Method Description (testCase:0533):Does the right sidebar open and close?. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:
	public void tc0533_VerifyRIOpenAndClose(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			waitUntilElementIsClickable(pageLib.getRelatedInfoTab());
			pageLib.getRelatedInfoTab().click();
			logger.info("clicked on tab "+pageLib.getRelatedInfoTab().getText());
			Assert.assertTrue(pageLib.getRiArrow().getAttribute("class").contains("labelAfterSmall"), "RI panel Not opened");
		}
		else{
			pageLib.getRiArrow().click();
			Assert.assertTrue(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow"), "RI panel is not closed");
	   }
	}
	
	/**
	 * Method Description (testCase:0534):When closed, does the side bar contain the words "RELATED INFORMATION"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0534:
	public void tc0534_VerifyRightSidebarName(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			waitUntilElementisVisible(pageLib.getRelatedInfoTab());
			Assert.assertEquals(pageLib.getRelatedInfoTab().getText(), "RELATED INFORMATION","Right side bar name not matched");
		}
		else{
			pageLib.getRiArrow().click();
			waitUntilElementisVisible(pageLib.getRelatedInfoTab());
			Assert.assertEquals(pageLib.getRelatedInfoTab().getText(), "RELATED INFORMATION","Right side bar name not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0535):When opened, do the arrows change direction to point towards the right side of the screen?. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0535:
	public void tc0535_VerifyArrowDirectionWhenOpened(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			waitUntilElementIsClickable(pageLib.getRelatedInfoTab());
			pageLib.getRelatedInfoTab().click();
			logger.info("clicked on tab "+pageLib.getRelatedInfoTab().getText());
		}
		Assert.assertFalse(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow"), "It is showing left arrow");
	}
	
	/**
	 * Method Description (testCase:0536):Are the words "RELATED INFORMATION" no longer visible?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0536:
	public void tc0536_VerifyRelatedInformationWordWhenOpened(){
	   if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
		 pageLib.getRelatedInfoTab().click();  
	   }
		   Assert.assertTrue(pageLib.getRelatedInfoTab().getAttribute("style").contains("display: none;"), "Related Information word is visible");  
	   
	}
	
	/**
	 * Method Description (testCase:0463):Enter a stock symbol such as "AAPL" (Apple Inc).
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0537:
	public void tc0537_EnterStockSymbol(String symbol){
		waitUntilElementIsClickable(pageLib.getSymbolEntryField());
		pageLib.getSymbolEntryField().clear();
		pageLib.getSymbolEntryField().sendKeys(symbol);
		Actions actions =new Actions(driver);
		actions.sendKeys(Keys.ENTER).build().perform();
		waitUntilVisibilityOfElement();
		waitUntilElementisVisible(pageLib.getChartSymbol());
		Assert.assertTrue(pageLib.getsymbolInformation().isDisplayed(), "Not charted for entered symbol");
	}
	
	/**
	 * Method Description (testCase:0538):When opened for a STOCK the sidebar contain the five tabs "Owners & Funds", "Industry & Sector", "News", "Options", and "Checklist"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0538:
	public void tc0538_ValidateRIPanelForStockSymbol(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		waitUntilVisibilityOfElement();
		String expectedResult[]={"Owners\n&\nFunds","Industry\n&\nSector","News","Options","Checklist"};
		List<WebElement> riOptions=pageLib.getriOptions();
		for(int i=0;i<riOptions.size();i++){
			Assert.assertTrue(riOptions.get(i).getText().contains(expectedResult[i]), "Option not present");
		}
	}
	
	/**
	 * Method Description (testCase:0539):Open the "Owners & Funds" tab. Does the following tables appear with information:
	//"Institutional Ownership", "Management Ownership", "Fund Ownership Summary"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0539:
	public void tc0539_VerifyOwnersAndFundsTab(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(0));
		riOptions.get(0).click();
		String ownerAndFundstables[]={"Institutional Ownership","Management Ownership","Fund Ownership Summary"}; 
		List<WebElement> ownersAndFundsTables=pageLib.getownersAndFundsTables();
		for(int i=0;i<ownersAndFundsTables.size();i++){
			Assert.assertEquals(ownersAndFundsTables.get(i).getText().trim(), ownerAndFundstables[i],"Not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0540):Does Institutional Ownership contain percentages for "Funds", Banks", and "Insurance Co."? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0540:
	public void tc0540_VerifyInstitutionalTableContent(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		String institutionalContents[]={"Funds","Banks","Insurance Co."};
		List<WebElement> institutionalTableContent=pageLib.getinstitutionalTableContent();
		for(int i=0;i<institutionalTableContent.size();i++){
		 Assert.assertEquals(institutionalTableContent.get(i).getText().trim(), institutionalContents[i],"Not matched");	
		}
	}
	
	/**
	 * Method Description (testCase:0541):Does Management Ownership contain "Percentage Held" by management and the current "Outstanding Shares" in Millions?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0541:
	public void tc0541_VerifyManagementTableContent(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		String managementContents[]={"Percentage Held","Outstanding Shares"};
		List<WebElement> managementTableContent=pageLib.getmanagementTableContent();
		for(int i=0;i<managementTableContent.size();i++){
			Assert.assertEquals(managementTableContent.get(i).getText().trim(), managementContents[i],"Not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0542):Does Fund Ownership Summary display the "Date" and "No of Funds" for the eight most recent quarters? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0542:
	public void tc0542_VerifyFundOwnershipContent(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		String fundTableHeaders[]={"Date","No of Funds"};
		List<WebElement> fundOwnershipHeaders=pageLib.getfundOwnershipTableHeader();
		for(int i=0;i<fundOwnershipHeaders.size()-1;i++){
			Assert.assertEquals(fundOwnershipHeaders.get(i).getText().trim(), fundTableHeaders[i],"not matched");
		}
		List<WebElement> fundTableContents=pageLib.getfundOwnwershipTableContent();
		Assert.assertEquals(fundTableContents.size()-1, 8,"It is not displayed eight recent quarters");
	}
	
	/**
	 * Method Description (testCase:0543):At the bottom, is there a button labeled "Show Fund Ownership"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0543:
	public void tc0543_VerifyShowFundButton(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		String showFundText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowFundOwnership());
		Assert.assertEquals(showFundText,"Show Fund Ownership","Not Matched");
	}

	/**
	 * Method Description (testCase:0544):When clicked, does the button change to "Hide Fund Ownership"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    //testCase:0544:
	public void tc0544_VerifyHideFundOwnership(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		waitUntilElementIsClickable(pageLib.getshowFundOwnership());
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getshowFundOwnership());
		String hideFundText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowFundOwnership());
		Assert.assertEquals(hideFundText,"Hide Fund Ownership","Not Matched");
	}
	
	/**
	 * Method Description (testCase:0545):Does the list manager and side bar become highlighted and display the funds currently holding shares of the stock?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0545:
	public void tc0545_ValidateHideFundOwnerShip(){
		String hideFundText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowFundOwnership());
		Assert.assertEquals(hideFundText,"Hide Fund Ownership","Not Matched");
		//validate side bar high lighted
		Assert.assertTrue(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar not highlighted");
		//validate list manager highlighted
		Utility.verifyBackgroundColor(pageLib.getlistPanel(), "Soft blue");
		//Validate LM displays the funds holdings 
		waitUntilVisibilityOfElement();
		waitUntilElementisVisible(pageLib.getspecialList());
		Assert.assertTrue(pageLib.getspecialList().isDisplayed(),"It has not shown shares holdings");
	}
	
	/**
	 * Method Description (testCase:0546):When entering a new stock symbol, does the list manager display the funds holding the newly selected stock? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0546:
	public void tc0546_ValidateOwnerShipForNewTicker(String symbol){
		Assert.assertTrue(pageLib.getspecialList().isDisplayed(),"It has not shown shares holdings");
		Utility.EnterStockSymbol(symbol);
		waitUntilElementisVisible(pageLib.getsymbolInformation());
		waitUntilVisibilityOfElement();
		Assert.assertTrue(pageLib.getspecialList().getText().contains(symbol), "It is not display the fund ownership list for new ticker");
	}
	
	/**
	 * Method Description (testCase:0547):When clicking "Hide Fund Ownership", does the button change back to "Show Fund Ownership"? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0547:
	public void tc0547_VerifyHideFundOwnershipText(){
		String hideFundText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowFundOwnership());
		Assert.assertEquals(hideFundText,"Hide Fund Ownership","Not Matched");
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getshowFundOwnership());
		String showFundText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowFundOwnership());
		Assert.assertEquals(showFundText,"Show Fund Ownership","Not Matched");
	}
	
	/**
	 * Method Description (testCase:0548):Is the list manager and side bar no longer highlighted? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0548:
	public void tc0548_ValidateShowFundOwnership(){
		String showFundText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getshowFundOwnership());
		Assert.assertEquals(showFundText,"Show Fund Ownership","Not Matched");
		//Validate LM is not highlighted
		Assert.assertTrue(pageLib.getlistPanel().getAttribute("style").contains("display: none;"),"still in highlighted state");
		//validate side bar is not high lighted
		Assert.assertFalse(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar highlighted");
	}
	
	/**
	 * Method Description (testCase:0549):Entering a new stock symbol. Verify the list manager contains the same items in the list should not change.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0549:
	public void tc0549_ValidateOwnerShipForNewStock(String symbol){
		Assert.assertTrue(pageLib.getlistPanel().getAttribute("style").contains("display: none;"),"still in highlighted state");
		Utility.EnterStockSymbol(symbol);
		waitUntilElementisVisible(pageLib.getsymbolInformation());
		Assert.assertFalse(pageLib.getspecialList().getText().contains(symbol), "It is displaying the fund ownership list for new ticker");
	}
	
	/**
	 * Method Description (testCase:0550):Enter a mutual fund into the ticker field (e.g., FDVLX). Does the RI tab change options to the following fund options? Profile, Returns, Risk, Holdings.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0550:
	public void tc0550_VerifyRIForMutualFund(String symbol){
		Utility.EnterStockSymbol(symbol);
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		waitUntilVisibilityOfElement();
		String expectedResult[]={"Profile","Returns","Risk","Holdings"};
		List<WebElement> riOptions=pageLib.getriOptions();
		for(int i=0;i<riOptions.size();i++){
			Assert.assertEquals(riOptions.get(i).getText().trim(), expectedResult[i], "Not matched");
		}
		riOptions.get(0).click();
	}
	
	/**
	 * Method Description (testCase:0551):Under Profile, if you click the Show All Funds In Family button, does the List Manager show all funds investing this fund? Is the List Manager highlighted blue?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0551:
	public void tc0551_ValidateShowAllFundsButton(){
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementisVisible(riOptions.get(0));
		riOptions.get(0).click();
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getshowAllFundsInFamily());
		waitUntilVisibilityOfElement();
		waitUntilElementisVisible(pageLib.getspecialList());
		//Validate LM displays the funds family list
		Assert.assertTrue(pageLib.getspecialList().isDisplayed(),"It has not shown fund family list");
		//validate list manager highlighted
		Utility.verifyBackgroundColor(pageLib.getlistPanel(), "Soft blue");
	}
	
	/**
	 * Method Description (testCase:0552):regular stock ticker when the LM is in highlighted state,validate highlight disappeared
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0552:
	public void  tc0552_EnterTickerWhenLMHighlighted(String symbol){
		Utility.verifyBackgroundColor(pageLib.getlistPanel(), "Soft blue");
		Utility.EnterStockSymbol(symbol);
		waitUntilElementisVisible(pageLib.getChartSymbol());
		Assert.assertTrue(pageLib.getsymbolInformation().isDisplayed(), "Not charted for entered symbol");
		//Validate highlight disappeared
		Assert.assertTrue(pageLib.getlistPanel().getAttribute("style").contains("display: none;"),"still in highlighted state");
	}
	
	/**
	 * Method Description (testCase:0559):Click on the close button (x). Does the side bar close? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0559:
	public void tc0559_ValidateCloseButton(){
		Assert.assertTrue(pageLib.getinformationPanel().getAttribute("style").contains("display: block;"), "Info Panel not displayed");
		waitUntilElementIsClickable(pageLib.getriCloseButton());
		pageLib.getriCloseButton().click();
		Assert.assertTrue(pageLib.getinformationPanel().getAttribute("style").contains("display: none;"), "Info Panel not closed");
	}
	
	/**
	 * Method Description (testCase:0560):Open the "Industry & Sector" tab. Does information load? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0560:
	public void tc0560_VerifyIndustryAndSectorTab(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(1));
		riOptions.get(1).click();
		waitUntilPresenceOfAllElements(".IsPanel.subPanel.subPanelShow>div>div.Ish1");
		List<WebElement> industryAndSectorContents=pageLib.getindustryAndSectorContents();
		for(int i=0;i<industryAndSectorContents.size();i++){
			Assert.assertTrue(industryAndSectorContents.get(i).isDisplayed(),"information not loaded");
		}
	}
	
	/**
	 * Method Description (testCase:0561):Are there two sections, "Industry Group" and "Sector"? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0561:
	public void tc0561_VerifySectionsOfIndustryAndSector(){
		String industryAndSectorSections[]={"Industry Group","Sector"}; 
		List<WebElement> industryAndSectorContents=pageLib.getindustryAndSectorContents();
		for(int i=0;i<industryAndSectorContents.size();i++){
			Assert.assertEquals(industryAndSectorContents.get(i).getText().trim(), industryAndSectorSections[i],"Not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0562):Does Industry Group contain the industry group name, "Today: " change and the "YTD: " performance? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0562:
	public void tc0562_VerifyIndustryGroupSection(){
		Assert.assertTrue(pageLib.getindustryGroupName().isDisplayed(), "Industry group name is missing");
		Assert.assertTrue(pageLib.gettodayLabel().getText().contains("Today:"),"text not matched");
		Assert.assertTrue(pageLib.getpercentageChange().isDisplayed(), "Is not displayed");
		Assert.assertTrue(pageLib.getytdLabel().getText().contains("YTD:"),"Text not matched");
		Assert.assertTrue(pageLib.getperformanceChange().isDisplayed(), "is not displayed");
	}
	
	/**
	 * Method Description (testCase:0463):Is there a chart icon next to the industry group name? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0463:
	public void tc0563_VerifyCharticon(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		Assert.assertTrue(pageLib.getindustryGroupName().isDisplayed(), "Industry group name is missing");
		Assert.assertTrue(pageLib.getchartIcon().isDisplayed(),"chartIcon not displayed");
	}
	
	/**
	 * Method Description (testCase:0564):Click on the chart icon. Does the chart load for the industry group?  
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0564:
	public void tc0564_ValidateChartIcon(){
		Assert.assertTrue(pageLib.getchartIcon().isDisplayed(),"chartIcon not displayed");
		String industryGroupText=pageLib.getindustryGroupName().getText();
		waitUntilElementIsClickable(pageLib.getchartIcon());
		pageLib.getchartIcon().click();
		waitUntilTextTobePresentInElement(pageLib.getChartSymbol(),industryGroupText);
		Assert.assertEquals(pageLib.getChartSymbol().getText(), industryGroupText,"It has not displayed chart for industry group");
	}
	
	/**
	 * Method Description (testCase:0565):Go back to the side bar for the stock. Does Industry Group contain two tables, "Industry Summary" and "Stock Rank in Industry Group"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0565:
	public void tc0565_VerifyIndustryGroupSection(){
		String symbol="AAPL";
		Utility.EnterStockSymbol(symbol);
		waitUntilElementisVisible(pageLib.getsymbolInformation());
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(1));
		riOptions.get(1).click();
		waitUntilPresenceOfAllElements(".IsPanel.subPanel.subPanelShow>div>div.Ish1");
		String industryGroupTables[]={"Industry Summary","Stock Rank In Industry Group"};
		List<WebElement> industyGrptable=pageLib.getindustryGroupTables();
		for(int i=0;i<industyGrptable.size();i++){
			Assert.assertEquals(industyGrptable.get(i).getText().trim(), industryGroupTables[i],"not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0566):Does Industry Summary contain Industry 197 Rank,Industry Market Value,Number of Stocks,New High Stocks,and New Low Stocks?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0566:
	public void tc0566_VerifyIndustrySummaryTable(){
		List<WebElement> industyGrptable=pageLib.getindustryGroupTables();
		Assert.assertTrue(industyGrptable.get(0).isDisplayed(), "Industry Summary table is not present");
		String industrySummaryTablelables[]={"Industry 197 Rank","Industry Market Value","Number of Stocks","New High Stocks","New Low Stocks"};
		List<WebElement> industrySummaryContents=pageLib.getindustrySummaryTableContents();
		for(int i=0;i<industrySummaryContents.size();i++){
			Assert.assertEquals(industrySummaryContents.get(i).getText().trim(), industrySummaryTablelables[i],"not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0463):Does Stock Rank in Industry Group contain EPS Rating, RS Rating,Acc/Dis Rating,SMR Rating,and Comp Rating
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0567:
	public void tc0567_VerifyStockRankTable(){
		List<WebElement> industyGrptable=pageLib.getindustryGroupTables();
		Assert.assertTrue(industyGrptable.get(1).isDisplayed(), "Stock Rank In Industry Group table is not present");
		String stockRankTablelables[]={"EPS Rating","RS Rating","Acc/Dis Rating","SMR Rating","Comp Rating"};
		List<WebElement> stockrankContents=pageLib.getstockRankTableContents();
		for(int i=0;i<stockrankContents.size();i++){
			Assert.assertEquals(stockrankContents.get(i).getText().trim(), stockRankTablelables[i],"not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0568):Is there a button labeled "View Stocks in Industry" below the Stock Rank in Industry Group table?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0568:
	public void tc0568_VerifyViewStocksinIndustry(){
		List<WebElement> industryAndSectorContents=pageLib.getindustryAndSectorContents();
		Assert.assertTrue(industryAndSectorContents.get(0).isDisplayed(),"is Not displayed");
		String viewStocksinIndustryText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinIndustryButton());
		Assert.assertEquals(viewStocksinIndustryText, "View Stocks in Industry","Text not matched");
	}
	
	/**
	 * Method Description (testCase:0569):When clicked, does the button change to "Hide Stocks in Industry"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0569:
	public void tc0569_ValidateViewStocksinIndustry(){
		String viewStocksinIndustryText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinIndustryButton());
		Assert.assertEquals(viewStocksinIndustryText, "View Stocks in Industry","Text not matched");
		pageLib.getviewStocksinIndustryButton().click();
		String hideStocksinIndustryText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinIndustryButton());
		Assert.assertEquals(hideStocksinIndustryText, "Hide Stocks in Industry","Text not matched");
	}
	
	/**
	 * Method Description (testCase:0570):Does the list manager and side bar become highlighted and display a list of stocks in the industry?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0570:
	public void tc0570_ValidateHideStocksinIndustry(){
		String hideStocksinIndustryText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinIndustryButton());
		Assert.assertEquals(hideStocksinIndustryText, "Hide Stocks in Industry","Text not matched");
		//Validate list manager highlighted
		Utility.verifyBackgroundColor(pageLib.getlistPanel(), "Soft blue");
		//validate side bar high lighted
		Assert.assertTrue(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar not highlighted");
		//Validate LM displays the funds holdings 
		waitUntilVisibilityOfElement();
		waitUntilElementisVisible(pageLib.getspecialList());
		Assert.assertTrue(pageLib.getspecialList().isDisplayed(),"It has not not displayed stocks in industry list");
	}
	
	/**
	 * Method Description (testCase:0571):When entering a new stock symbol in a different industry, does the list manager display a new list showing the stocks in the industry of the new stock symbol?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0571:
	public void tc0571_EnterNewTickerWhenLMHighlighted(String symbol){
	   Utility.verifyBackgroundColor(pageLib.getlistPanel(), "Soft blue");
	   Utility.EnterStockSymbol(symbol);
	   waitUntilElementisVisible(pageLib.getsymbolInformation());
	   waitUntilVisibilityOfElement();
	   String industryGroupName=pageLib.getindustryGroupName().getText();
	   Assert.assertTrue(pageLib.getspecialList().getText().contains(industryGroupName), "It is not display the stocks in industry list for new ticker");
	}
	
	/**
	 * Method Description (testCase:0572):When clicking Hide Stocks in Industry,does the button change back to View Stocks in Industry?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0572:
	public void tc0572_VerifyHideStocksinIndustryText(){
		String hideStocksinIndustryText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinIndustryButton());
		Assert.assertEquals(hideStocksinIndustryText, "Hide Stocks in Industry","Text not matched");
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getviewStocksinIndustryButton());
		String viewStocksinIndustryText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinIndustryButton());
		Assert.assertEquals(viewStocksinIndustryText,"View Stocks in Industry","Not Matched");
	}
	
	/**
	 * Method Description (testCase:0573):Is the list manager and side bar no longer highlighted? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0573:
	public void tc0573_ValidateViewStocksinIndustry(){
		String viewStocksinIndustryText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinIndustryButton());
		Assert.assertEquals(viewStocksinIndustryText,"View Stocks in Industry","Not Matched");
		//Validate LM is not highlighted
		Assert.assertTrue(pageLib.getlistPanel().getAttribute("style").contains("display: none;"),"still in highlighted state");
		//validate side bar is not high lighted
		Assert.assertFalse(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar highlighted");
	}
	
	/**
	 * Method Description (testCase:0574):Enter a new stock symbol in a different industry. Verify the list manager contains the same items in the list should not change
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0574:
	public void tc0574_EnterNewTickerWhenLMnotHighlighted(String symbol){
		Assert.assertTrue(pageLib.getlistPanel().getAttribute("style").contains("display: none;"),"still in highlighted state");
		Utility.EnterStockSymbol(symbol);
		waitUntilElementisVisible(pageLib.getsymbolInformation());
		String industryGroupName=pageLib.getindustryGroupName().getText();
		waitUntilVisibilityOfElement();
		Assert.assertFalse(pageLib.getspecialList().getText().contains(industryGroupName), "It is display the stocks in industry list for new ticker");
	}
	
	/**
	 * Method Description (testCase:0575):Does Sector contain the name of the Sector and the table "Top Industries in Sector"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//tesCase:0575:
	public void tc0575_VerifySectorSection(){
		Assert.assertTrue(pageLib.getsectorName().isDisplayed(), "Sector name not displayed");
		Assert.assertEquals(pageLib.gettopIndustriesinSectorsTable().getText(), "Top Industries in Sector","Text not matched");
	}
	
	/**
	 * Method Description (testCase:0576):Does the table Top Industries in Sector contain a list of Industry Groups contained within the sector sorted high to low by their RS Rating?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0576:
	public void tc0576_ValidateTopIndustriesTableData(){
		Assert.assertEquals(pageLib.gettopIndustriesinSectorsTable().getText(), "Top Industries in Sector","Text not matched");
		List<WebElement> rsRatingList=pageLib.getrsRatingsOfAllIndustryGroups();
		List<Integer> rsRatingInt = new ArrayList<Integer>();
		for(int i=0;i<rsRatingList.size();i++) {
		 String listText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",rsRatingList.get(i));	
		 rsRatingInt.add(Integer.parseInt(listText)) ;
	   }    
		List<Integer> listInteger=new ArrayList<Integer>();
		listInteger.addAll(rsRatingInt);
		Comparator<Integer> cmp=Collections.reverseOrder();
		Collections.sort(rsRatingInt,cmp);
		System.out.println("Actual:"+listInteger);
		System.out.println("Expected:"+rsRatingInt);
		waitUntilVisibilityOfElement();
		Assert.assertEquals(listInteger, rsRatingInt," not matched");
	}
	
	/**
	 * Method Description (testCase:0577):Is there a "View More Details" link?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0577:
	public void tc0577_VerifyViewMoreDetailsLink(){
		Assert.assertEquals(pageLib.gettopIndustriesinSectorsTable().getText(), "Top Industries in Sector","Text not matched");
		Assert.assertEquals(pageLib.getviewMoreDetailsLink().getText().trim(), "View More Details","Link not present");
	}
	
	/**
	 * Method Description (testCase:0578):Click on the View More Details link. Does the list manager display all the industry groups contained within the sector?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0578:
	public void tc0578_ValidateViewMoreDetailsLink(){
		Assert.assertEquals(pageLib.getviewMoreDetailsLink().getText().trim(), "View More Details","Link not present");
		pageLib.getviewMoreDetailsLink().click();
		waitUntilVisibilityOfElement();
		List<WebElement> rsRatingList=pageLib.getrsRatingsOfAllIndustryGroups();
		Assert.assertTrue(pageLib.getspecialList().isDisplayed(), "Lm not displayed industryGroups in sector");
		List<WebElement> symbolList=pageLib.getsymbolList();
		Assert.assertEquals(symbolList.size(),rsRatingList.size(),"LM Lm not displayed industryGroups in sector");
	}
	
	/**
	 * Method Description (testCase:0579):Is there a button labeled "View Stocks in Sector" below the Sector table?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0579:
	public void tc0579_VerifyViewStocksInSector(){
		Assert.assertEquals(pageLib.gettopIndustriesinSectorsTable().getText(), "Top Industries in Sector","Text not matched");
		String ViewStocksinSectorText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinSector());
		Assert.assertEquals(ViewStocksinSectorText, "View Stocks in Sector","Text not displayed");
	}
	
	/**
	 * Method Description (testCase:0580):When clicked, does the button change to "Hide Stocks in Sector"? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0580:
	public void tc0580_VerifyHideStocksInsector(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		waitUntilElementIsClickable(pageLib.getviewStocksinSector());
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getviewStocksinSector());
		String hideStocksinSectorText =(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinSector());
		Assert.assertEquals(hideStocksinSectorText,"Hide Stocks in Sector","Not Matched");
	}
	
	/**
	 * Method Description (testCase:0581):Does the list manager and side bar become highlighted and display a list of stocks in the sector? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0581:
	public void tc0581_ValidateHideStockInSector(){
		String hideStocksinSectorText =(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinSector());
		Assert.assertEquals(hideStocksinSectorText,"Hide Stocks in Sector","Not Matched");
		//validate side bar high lighted
		Assert.assertTrue(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar not highlighted");
		//validate list manager highlighted
		Utility.verifyBackgroundColor(pageLib.getlistPanel(), "Soft blue");
		//Validate LM displays the funds holdings 
		waitUntilVisibilityOfElement();
		waitUntilElementisVisible(pageLib.getspecialList());
		Assert.assertTrue(pageLib.getspecialList().isDisplayed(),"It has not shown Industry groups in sector");
	}
	
	/**
	 * Method Description (testCase:0582):When entering a new stock symbol in a different sector,does the list manager display a new list showing the stocks in the sector of the new stock symbol? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0582:
	public void tc0582_EnterNewTickerWhenLMHighlighted(String symbol){
		Assert.assertTrue(pageLib.getspecialList().isDisplayed(),"It has not shown shares holdings");
		Utility.EnterStockSymbol(symbol);
		waitUntilElementisVisible(pageLib.getsymbolInformation());
		String sectorName=pageLib.getsectorName().getText();
		waitUntilVisibilityOfElement();
		Assert.assertTrue(pageLib.getspecialList().getText().contains(sectorName), "It is not display the stocks in sector list for new ticker");
	}
	
	/**
	 * Method Description (testCase:0583):When clicking "Hide Stocks in Sector", does the button change back to "Show Stocks in Sector"? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0583:
	public void tc0583_VerfiyViewStocksinSector(){
		String hideStocksinSectorText =(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinSector());
		Assert.assertEquals(hideStocksinSectorText,"Hide Stocks in Sector","Not Matched");
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getviewStocksinSector());
		String vieStocksinSectorText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinSector());
		Assert.assertEquals(vieStocksinSectorText,"View Stocks in Sector","Not Matched");
	}
	
	/**
	 * Method Description (testCase:0584):Is the list manager and side bar no longer highlighted? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0584:
	public void tc0584_ValidateViewStocksinSector(){
		String vieStocksinSectorText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getviewStocksinSector());
		Assert.assertEquals(vieStocksinSectorText,"View Stocks in Sector","Not Matched");
		//Validate LM is not highlighted
		Assert.assertTrue(pageLib.getlistPanel().getAttribute("style").contains("display: none;"),"LM still in highlighted state");
		//validate side bar is not high lighted
		Assert.assertFalse(pageLib.getsideBarRI().getAttribute("class").contains("infoPanelActive"),"Side bar highlighted");
	}
	
	/**
	 * Method Description (testCase:0585):Enter a new stock symbol in a different sector. Verify the list manager contains the same items in the list should not change. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0585:
	public void tc0585_EnterNewTickerWhenLMnotHighLighted(String symbol){
		Assert.assertTrue(pageLib.getlistPanel().getAttribute("style").contains("display: none;"),"LM still in highlighted state");
		Utility.EnterStockSymbol(symbol);
		waitUntilElementisVisible(pageLib.getsymbolInformation());
		String sectorName=pageLib.getsectorName().getText();
		Assert.assertFalse(pageLib.getspecialList().getText().contains(sectorName), "It is not display the stocks in sector list for new ticker");
	}
	
	/**
	 * Method Description (testCase:0593):Open the "News" tab. Does a list of news appear? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0593:
	public void tc0593_VerifyNewsTab(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(2));
		riOptions.get(2).click();
		waitUntilPresenceOfAllElements(".title");
		waitUntilVisibilityOfElement();
		List<WebElement> newList=pageLib.getnewsList();
		Assert.assertTrue(newList.get(0).isDisplayed(), "not showing any News list");
	}
	
	/**
	 * Method Description (testCase:0595):Is there a drop down menu called "Edit News"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0594:
	public void tc0594_VerifyNewsDropdown(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilPresenceOfAllElements(".title");
		Assert.assertEquals(pageLib.geteditNewsDropDown().getText().trim(),"Edit News","Text not matched");
	}
	
	/**
	 * Method Description (testCase:0595):When hovering over the drop down menu, do the options "StockTwits", "Yahoo! Finance", and "Google Finance" appear?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0595:
	public void tc0595_VerifyNewsDropdownOptions(){
		Assert.assertEquals(pageLib.geteditNewsDropDown().getText().trim(),"Edit News","Text not matched");
		Actions action=new Actions(driver);
		action.moveToElement(pageLib.geteditNewsDropDown()).build().perform();
		waitUntilElementisVisible(pageLib.getnewsOptionWindow());
		List<WebElement> allNewsOptionsList=pageLib.getallNewsOptions();
		//String newsoptions[]={"Investor's Business Daily","Yahoo! Finance","Google Finance"};
		String newsoptions[]={"Yahoo! Finance","Google Finance"};
		for(int i=0;i<allNewsOptionsList.size();i++){
			Assert.assertEquals(allNewsOptionsList.get(i).getText().trim(), newsoptions[i],"Text not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0599):Click the refresh button. Does the news list refresh?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0599:
	public void tc0599_VerifyNewsList(){
		Assert.assertEquals(pageLib.geteditNewsDropDown().getText().trim(),"Edit News","Text not matched");
		List<WebElement> allNewsDates=pageLib.getallNewsDates();
		List<String> actualDates=new ArrayList<String>();
		for(int i=0;i<allNewsDates.size();i++) {
		    	String dateText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",allNewsDates.get(i));
				actualDates.add(dateText);
		    }
		Date[] dates1=new Date[actualDates.size()];
	    DateFormat dateFormatter=new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
	    for(int i=0;i<actualDates.size();i++){
				try {
					dates1[i]=dateFormatter.parse(actualDates.get(i).toString());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    }
	    List<String> dateText=new ArrayList<String>();
	    for(int i=0;i<dates1.length;i++){
	    	dateText.add((String)new SimpleDateFormat("yyyy/MM/dd HH:mm:ss",Locale.ENGLISH).format(dates1[i]));
	    }
		
		List<String> ExpDateText=new ArrayList<String>();
		ExpDateText.addAll(dateText);
		Comparator<String> cmp=Collections.reverseOrder();
		Collections.sort(ExpDateText, cmp);
		System.out.println("actual array "+dateText);
		System.out.println("Expected array "+ExpDateText);
		Assert.assertEquals(dateText, ExpDateText," not matched");
	}
	
	//testCase:0600:Click on the close button (x). Does the sidebar close?
	
	/**
	 * Method Description (testCase:0601):Open the "Options" tab. Does the information load?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0601:
	public void tc0601_VerifyOptionsTab(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(3));
		riOptions.get(3).click();
		waitUntilPresenceOfAllElements(".OptionsPanel.subPanel.subPanelShow>div>div:nth-of-type(2)>div");
		List<WebElement> optionsTables=pageLib.getoptionsTables();
		for(int i=0;i<optionsTables.size();i++){
			Assert.assertTrue(optionsTables.get(i).isDisplayed(), "option tab not loaded");
		}
	}
	
	/**
	 * Method Description (testCase:0602):Is there data for "Calls" and "Puts" as well as "Stock Data"? (Only stocks with available options will have Call or Put data)
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0602:
	public void tc0602_VerifyCallsAndPutsAndStockData(){
		List<WebElement> optionsTables=pageLib.getoptionsTables();
		Assert.assertTrue(optionsTables.get(0).isDisplayed(), "option tab not loaded");
		List<WebElement> callsData=pageLib.getcallsData();
		for(int i=0;i<callsData.size();i++){
		Assert.assertTrue(pageLib.getcallsData().get(i).isDisplayed(), "Calls data not displayed");
		}
		List<WebElement> putsData=pageLib.getputsData();
		for(int i=0;i<putsData.size();i++)
		{
			Assert.assertTrue(pageLib.getputsData().get(i).isDisplayed(), "Putsdata not displayed");
		}
		Assert.assertTrue(pageLib.getstockTableData().isDisplayed(), "StockData table not having any data");
	}
	
	/**
	 * Method Description (testCase:0603):Do the Calls and Puts tables have "Exp.", "Strike", "Last", "Vol", and "Open Int" columns? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0603:
	public void tc0603_VerifyCallssAndPutsTableColumns(){
		List<WebElement> optionsTables=pageLib.getoptionsTables();
		Assert.assertTrue(optionsTables.get(0).isDisplayed(), "option tab not loaded");
		List<WebElement> callsTableHeader=pageLib.getcallsTableHeader();
		List<WebElement> putsTableHeader=pageLib.getputsTableHeader();
		String callsAndputsHeader[]={"Exp.","Strike","Last","Vol","Open Int"};
		for(int i=0;i<callsAndputsHeader.length;i++){
			Assert.assertEquals(callsTableHeader.get(i).getText().trim(), callsAndputsHeader[i],"Text not matched");
			Assert.assertEquals(putsTableHeader.get(i).getText().trim(), callsAndputsHeader[i],"text not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0604):verify stock data table have data for labels
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0604:
	public void tc0604_VerifyStockDataForLabels(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		List<WebElement> stockDataLabels=pageLib.getstockDataLabels();
		List<WebElement> stockData=pageLib.getstockDataTableData();
		String stockDataLabel[]={"Earnings Due (est.)","Next Ex-Div Date","Next Dividend Amount","Avg True Range (last 30 Days)","Current Div Yield","% Off High","52 Week High","52 Week Low","Beta","Alpha"};
		for(int i=0;i<stockDataLabels.size();i++){
			Assert.assertEquals(stockDataLabels.get(i).getText().trim(), stockDataLabel[i],"Text not matched");
		}
		Assert.assertEquals(stockDataLabels.size(), stockData.size());
	}
	
	/**
	 * Method Description (testCase:0605):Is there a disclaimer message at the bottom? . 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0605:
	public void tc0605_VerifyDisclaimerMessage(){
		List<WebElement> optionsTables=pageLib.getoptionsTables();
		Assert.assertTrue(optionsTables.get(1).isDisplayed(), "option tab not loaded");
		String disclaimerText="Options data are provided by Interactive Data Services and are reported as of end of day for prior trading day";
		Assert.assertEquals(pageLib.getdisclaimerMessage().getText().trim(), disclaimerText,"Text not matched");
	}
	
	/**
	 * Method Description (testCase:0606):Is there a button labeled "Show More Information"?. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0606:
	public void tc0606_VerifyShowMoreInformation(){
		List<WebElement> optionsTables=pageLib.getoptionsTables();
		Assert.assertTrue(optionsTables.get(1).isDisplayed(), "option tab not loaded");
		Assert.assertEquals(pageLib.getshowMoreInfo().getText().trim(),"Show More Information","Text not matched");
	}
	
	/**
	 * Method Description (testCase:0607):When you click on the Show More Information button, does the side bar open up with more information? 
	   The Company Name, Stock Symbol, Stock Exchange, Current Price, Price % Change and Volume should be visible at the top.. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0607:
	public void tc0607_ValidateShowMoreInformation(){
		Assert.assertEquals(pageLib.getshowMoreInfo().getText().trim(),"Show More Information","Text not matched");
		waitUntilElementIsClickable(pageLib.getshowMoreInfo());
		pageLib.getshowMoreInfo().click();
		Assert.assertTrue(pageLib.getoptionsMoreInfoPanel().getAttribute("style").contains("display: block;"), "info panel not displayed");
		List<WebElement> optionsInformations=pageLib.getoptionsInformation();
		Assert.assertTrue(optionsInformations.get(0).isDisplayed(), "Company Name not displayed");
		Assert.assertTrue(optionsInformations.get(1).isDisplayed(), "stock symbol not displayed");
		Assert.assertTrue(optionsInformations.get(2).isDisplayed(), "stock exchange not displayed");
		Assert.assertTrue(optionsInformations.get(3).isDisplayed(), "current price not displayed");
		Assert.assertTrue(optionsInformations.get(4).isDisplayed(), "price%change not displayed");
		Assert.assertTrue(optionsInformations.get(6).isDisplayed(), "volume not displayed");
	}
	
	/**
	 * Method Description (testCase:0608):there should be a "View by_" that changes according to which radio button you have selected on the right ("Expiration Date" or "Strike Price") 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0608:
	public void tc0608_VerifyViewByOptions(){
		Assert.assertTrue(pageLib.getoptionsMoreInfoPanel().getAttribute("style").contains("display: block;"), "info panel not displayed");
		List<WebElement> viewByRadioButtons=pageLib.getviewByRadioButtons();
		waitUntilElementIsClickable(viewByRadioButtons.get(0));
		viewByRadioButtons.get(0).click();
		waitUntilElementisVisible(pageLib.getviewByInfo());
		Assert.assertEquals(pageLib.getviewByInfo().getText().trim(),"View by Expiration Date","View by Not changed");
		waitUntilElementIsClickable(viewByRadioButtons.get(0));
		viewByRadioButtons.get(1).click();
		waitUntilElementisVisible(pageLib.getviewByInfo());
		Assert.assertEquals(pageLib.getviewByInfo().getText().trim(),"View by Strike Price","View by Not changed");
	}
	
	/**
	 * Method Description (testCase:0463):testCase:0609:Select the "Preferences" option. Are you able to change your preferences to show expirations for the next 3, 6, 12 or 24 months 
	   and show 3, 5 or 7 options with strikes above and below the current price? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//
	public void tc0609_VerifyPreferenceOption(){
		Assert.assertTrue(pageLib.getoptionsMoreInfoPanel().getAttribute("style").contains("display: block;"), "info panel not displayed");
		waitUntilElementIsClickable(pageLib.getpreferenceLink());
		pageLib.getpreferenceLink().click();
		waitUntilElementisVisible(pageLib.getchangePreferencewindow());
		waitUntilElementIsClickable(pageLib.getexpirationMonthDropDown());
		pageLib.getexpirationMonthDropDown().click();
		List<String> allMonthOptions=getAllSelectedOptionFromDropDown(pageLib.getexpirationMonthDropDown());
		String monthsOptions[]={"3","6","12","24"};
		for(int i=0;i<allMonthOptions.size();i++){
		Assert.assertEquals(allMonthOptions.get(i).trim(), monthsOptions[i],"Not matched");
		}
		waitUntilElementisVisible(pageLib.getchangePreferencewindow());
		waitUntilElementIsClickable(pageLib.getstrikeOptionDropdown());
		pageLib.getstrikeOptionDropdown().click();
		List<String> allstrikeOptions=getAllSelectedOptionFromDropDown(pageLib.getstrikeOptionDropdown());
		String strikeOptions[]={"3","5","7"};
		for(int j=0;j<allMonthOptions.size();j++){
		Assert.assertEquals(allstrikeOptions.get(j).trim(), strikeOptions[j],"Not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0610):Select the Expiration Date radio button. A list of expiration dates should be visible with the most recent expiration date on top. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0610:
	public void tc0610_ValidateExpirationDates(){
		List<WebElement> viewByRadioButtons=pageLib.getviewByRadioButtons();
		waitUntilElementIsClickable(viewByRadioButtons.get(0));
		viewByRadioButtons.get(0).click();
		List<WebElement> allExpirationdates=pageLib.getexpirationDates();
		List<Integer> expirationDateInt=new ArrayList<Integer>();
		for(int i=0;i<allExpirationdates.size();i++){
			String expirationDate=allExpirationdates.get(i).getText().substring(10, 12);
			System.out.println(expirationDate);
			expirationDateInt.add(Integer.parseInt(expirationDate));
		}
		List<Integer> expirationDates=new ArrayList<Integer>();
		expirationDates.addAll(expirationDateInt);
		Collections.sort(expirationDateInt);
		System.out.println("Actual:"+expirationDates);
		System.out.println("Expected:"+expirationDateInt);
		waitUntilVisibilityOfElement();
		Assert.assertEquals(expirationDates, expirationDateInt," not matched");
	}
	
	/**
	 * Method Description (testCase:0611):Clicking on a row will result in information being displayed for that particular expiration date. Is there Call and Put information for the strike price? (Last, Bid, Ask, Open Int, Call Vol)
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0611:
	public void tc0611_ValdateRowResultInformation(){
		List<WebElement> viewByRadioButtons=pageLib.getviewByRadioButtons();
		waitUntilElementIsClickable(viewByRadioButtons.get(0));
		viewByRadioButtons.get(0).click();
		waitUntilElementisVisible(pageLib.getexpirationDateDetails());
		pageLib.getexpirationDateDetails().click();
		Assert.assertTrue(pageLib.getexpirationDateDetails().isDisplayed(), "expiration details not displayed");
		List<WebElement> callsPutsheader=pageLib.getcallsPutsStrikeHeader();
		String callsPuts[]={"Calls","Strike","Puts"};
		for(int i=0;i<callsPutsheader.size();i++){
			Assert.assertEquals(callsPutsheader.get(i).getText().trim(), callsPuts[i],"text Not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0612):Click the Strike Price radio button. A list should be displayed with options available in order by strike price, low to high. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0612:
	public void tc0612_ValidateStrikePriceRadioButton(){
		List<WebElement> viewByRadioButtons=pageLib.getviewByRadioButtons();
		waitUntilElementIsClickable(viewByRadioButtons.get(1));
		viewByRadioButtons.get(1).click();
		List<WebElement> strikeprice=pageLib.getstrikePricesList();
		List<Double> strikepriceInt = new ArrayList<Double>();
		for(int i=0;i<strikeprice.size();i++) {
		 String listText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",strikeprice.get(i));	
		 strikepriceInt.add(Double.parseDouble(listText)); 
	    }    
		List<Double> listInteger=new ArrayList<Double>();
		listInteger.addAll(strikepriceInt);
		Collections.sort(strikepriceInt);
		waitUntilVisibilityOfElement();
		Assert.assertEquals(listInteger, strikepriceInt," not matched");
	}
	
	/**
	 * Method Description (testCase:0613):Expand a strike price row to display more information. Is there Call and Put information? (Price, Volume, Open Int, Bid, Ask). 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0613:
	public void tc0613_VerifyStrikePriceInfo(){
		List<WebElement> strikeprice=pageLib.getstrikePricesList();
		strikeprice.get(0).click();
		List<WebElement> strikePriceLabels=pageLib.getstrikePriceLabels();
		String strikePriceAllLabels[]={"Price","Volume","Open Int","Bid","Ask"};
		for(int i=0;i<strikePriceLabels.size();i++){
			Assert.assertEquals(strikePriceLabels.get(i).getText().trim(), strikePriceAllLabels[i],"Text not matched");
		}
	}
	
	/**
	 * Method Description (testCase:0620):Click on the close button (x). Does the sidebar close? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:620:
	public void tc0620_ValidateCloseButton(){
		waitUntilElementIsClickable(pageLib.getshowMoreInfo());
		pageLib.getshowMoreInfo().click();
		Assert.assertTrue(pageLib.getinformationPanel().getAttribute("style").contains("display: block;"), "Info Panel not displayed");
		waitUntilElementIsClickable(pageLib.getriCloseButton());
		pageLib.getriCloseButton().click();
		Assert.assertTrue(pageLib.getinformationPanel().getAttribute("style").contains("display: none;"), "Info Panel not closed");
	}
	
	/**
	 * Method Description (testCase:0621):Open the "Checklist" tab. Does the information load? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:621:
	public void tc0621_VerifyCheckListOption(){
		if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			 pageLib.getRelatedInfoTab().click();  
		}
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(4));
		riOptions.get(4).click();
		waitUntilElementisVisible(pageLib.getcheckListContent());
		Assert.assertTrue(pageLib.getcheckListContent().isDisplayed(),"checklist not loaded");
	}
	
	/**
	 * Method Description (testCase:0622):Is there a drop down menu?. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0622:
	public void tc0622_VerifyDropDown(){
		Assert.assertTrue(pageLib.getcheckListContent().isDisplayed(),"checklist not loaded");
		waitUntilVisibilityOfElement();
		Assert.assertTrue(pageLib.getcheckListDropdown().isDisplayed(),"Checklist dropdown not present");
	}
	
	/**
	 * Method Description (testCase:0623):Above the dropdown menu, are the words "Base your Checklist on this screen" visible?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0623:
	public void tc0623_VerifyTextAboveTheDropdown(){
		Assert.assertTrue(pageLib.getcheckListContent().isDisplayed(),"checklist not loaded");
		Assert.assertEquals(pageLib.gettextAboveDropdown().getText().trim(), "Base your Checklist on this screen","text not matched");
	}
	
	/**
	 * Method Description (testCase:0624):Does the dropdown menu contain the name of the screen last chosen?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0624:
	public void tc0624_ValidateDropdownSelection(){
		Assert.assertTrue(pageLib.getcheckListDropdown().isDisplayed(),"Checklist dropdown not present");
		pageLib.getcheckListDropdown().click();
		waitUntilElementisVisible(pageLib.getwaitForChecklistDoptions());
		List<WebElement> checklistScreens=pageLib.getallCheckListScreens();
		String thirdScreenName=checklistScreens.get(2).getText();
		checklistScreens.get(2).click();
		Assert.assertTrue(pageLib.getinformationPanel().getAttribute("style").contains("display: block;"), "Info Panel not displayed");
		waitUntilElementIsClickable(pageLib.getriCloseButton());
		pageLib.getriCloseButton().click();
		Assert.assertTrue(pageLib.getinformationPanel().getAttribute("style").contains("display: none;"), "Info Panel not closed");
		waitUntilVisibilityOfElement();
		List<WebElement> riOptions=pageLib.getriOptions();
		waitUntilElementIsClickable(riOptions.get(4));
		riOptions.get(4).click();
		waitUntilElementisVisible(pageLib.getcheckListContent());
		Assert.assertEquals(pageLib.getselectedScreenList().getText(),thirdScreenName,"Text not matched");
	}
	
	/**
	 * Method Description (testCase:0625):Click on the dropdown menu. Does a list appear with the MarketSmith Stock Screens (William J. Oneil, Warren Buffett, Benjamin Graham, Peter Lynch, Martin Zweig, James P. O'Shaughnessy, Up on Volume, Down on Volume)? Any custom made screens should also appear. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0625:
	public void tc0625_VerifyCheckListDropdownOptions(){
		Assert.assertTrue(pageLib.getcheckListDropdown().isDisplayed(),"Checklist dropdown not present");
		if(!(pageLib.getLeftPanelScreenerButton().getAttribute("class").contains("toLeftArrow"))){
			pageLib.getLeftPanelScreenerButton().click();
		  }
		 if(pageLib.getmyScreensFolder().getAttribute("class").contains("isFileOpen")){
			 pageLib.getmyScreensFolder().click(); 
		 }
		 if(pageLib.getmsScreensFolder().getAttribute("class").contains("isFileOpen")){
			 pageLib.getmsScreensFolder().click(); 
		 }
         //to get all stock screens
		 List<WebElement> MyScreensSpan=pageLib.getmyScreensSpan();
		 List<WebElement> msStock=pageLib.getmsStockScreens();
		 msStock.addAll(MyScreensSpan);
		 pageLib.getcheckListDropdown().click();
		 waitUntilElementisVisible(pageLib.getwaitForChecklistDoptions());
		 List<WebElement> checklistScreens=pageLib.getallCheckListScreens();
		 
		 for(int j=0;j<msStock.size();j++){
			 Assert.assertEquals(checklistScreens.get(j).getText().trim(),msStock.get(j).getText().trim(),"Text not matched");	 
		 }
		 pageLib.getcheckListDropdown().click(); 
	}
	
	/**
	 * Method Description (testCase:0626):percentage reflecting how many items the stock satisfies for the criteria of the chosen screen?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//tesyCase:0626:
	public void tc0626_ValidatePercentageReflecting(){
		Assert.assertTrue(pageLib.getcheckListContent().isDisplayed(),"checklist not loaded");
		List<WebElement> passFailCriteria=pageLib.getpassFailCriteria();
		List<String> passCriteria=new ArrayList<String>();
		for(int i=0;i<passFailCriteria.size();i++){
			if(passFailCriteria.get(i).getText().contains("Pass")){
				String onlyPass=passFailCriteria.get(i).getText();
				passCriteria.add(onlyPass);
			}
		}
		List<String> allPassCriteria=new ArrayList<String>();
		allPassCriteria.addAll(passCriteria);
		int totalCriteriaSize=passFailCriteria.size();
		int allPassCriteriasize=allPassCriteria.size();
		double result=(double)allPassCriteriasize/totalCriteriaSize;
		int totalpercentage=(int) (result*100);
		String strPercentage=String.valueOf(totalpercentage);
		Assert.assertTrue(pageLib.getchecListPercentage().getText().contains(strPercentage), "% mismatched");
	}
	
	/**
	 * Method Description (testCase:0628):Are the items rated as Fail highlighted red? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0628:
	public void tc0628_VerifyFailiedTextColor(){
		Assert.assertTrue(pageLib.getcheckListContent().isDisplayed(),"checklist not loaded");
		List<WebElement> redTextedcriteria=pageLib.getredCriteria();
		for(int i=0;i<redTextedcriteria.size();i++){
			Assert.assertTrue(redTextedcriteria.get(i).getText().contains("Fail"), "Failed criteria not in red color");
			Utility.verifyTextColor(redTextedcriteria.get(i), "DarkRed");
		}
	}
	
	/**
	 * Method Description (testCase:0629):Click on the close button (x). Does the sidebar close? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	//testCase:0629:
	public void tc0635_ValidateCloseButton(){
		Assert.assertTrue(pageLib.getinformationPanel().getAttribute("style").contains("display: block;"), "Info Panel not displayed");
		waitUntilElementIsClickable(pageLib.getriCloseButton());
		pageLib.getriCloseButton().click();
		Assert.assertTrue(pageLib.getinformationPanel().getAttribute("style").contains("display: none;"), "Info Panel not closed");
	}
	
}		
	
