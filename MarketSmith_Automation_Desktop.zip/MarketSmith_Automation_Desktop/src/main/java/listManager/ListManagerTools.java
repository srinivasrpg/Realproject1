package listManager;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.google.common.base.Stopwatch;

import static genericLib.Utility.*;

import java.util.List;
import java.util.concurrent.TimeUnit;


public class ListManagerTools {
	ListManagerToolsLib pageLib=PageFactory.initElements(driver, ListManagerToolsLib.class);
	
	/**
	 * Method Description (testCase:0297):Verify that a List is present in the LIST MANAGER by default when you open up the MS Tool.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	 * @throws InterruptedException 
	**/
	public void tc0297_VerifyListManagerVisibility() throws InterruptedException{
		closeWindow();
		launchMSTool();
		verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementisVisible(pageLib.getDefaultViewButton());
		Assert.assertTrue(pageLib.getDefaultViewButton().getAttribute("class").contains("Clicked"), "It is not in default view");
		logger.info(pageLib.getDefaultViewButton().getAttribute("titletooltip")+" is clicked by default");
	}
	
	/**
	 * Method Description (testCase:0298):In the upper-right-hand corner of the List Manager window, there are three View icons (Mini, Default, and Max). Validate that the List Manager defaults to the middle icon (Default View). 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0298_VerifyViewIcons(){
		verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		Assert.assertTrue(pageLib.getlistViewButton().isDisplayed(), "list view icon not dispalyed");
		Assert.assertTrue(pageLib.getChartViewButton().isDisplayed(), "list view icon not dispalyed");
		Assert.assertTrue(pageLib.getDefaultViewButton().isDisplayed(), "list view icon not dispalyed");
	}
	
	/**
	 * Method Description (testCase:0299):Is there a PLAY button to the left of the view icons, as well as a dropdown button?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0299_VerifyPlayButtonAndDropdown(){
		verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementisVisible(pageLib.getPlayButton());
		Assert.assertTrue(pageLib.getPlayButton().isDisplayed(), "Play Button is not displayed");
		logger.info(pageLib.getPlayButton().getText()+" Is present");
		Assert.assertTrue(pageLib.getPlayDropDown().isDisplayed(), "Play dropdown is not displayed");
		logger.info(pageLib.getPlayDropDown().getAttribute("titletooltip")+" Is present");
	}
	
	/**
	 * Method Description (testCase:0300):To the right of the VIEW buttons, verify there is a Tool button (wrench) and a Help button (question mark).
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0300_VerifyToolAndHelpButtons(){
		verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementisVisible(pageLib.getListManagerTool());
		Assert.assertTrue(pageLib.getListManagerTool().isDisplayed(), "List Manager Tool option is missing");
		Assert.assertTrue(pageLib.getListManagerHelpOption().isDisplayed(), "List Manager help option is missing");
	}
	
	/**
	 * Method Description (testCase:0301):Validate that you are able to change the list manager view with the MINI view icon, the DEFAULT view icon, and the MAX view icon buttons.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0301_ValidateDifferentViewButtons(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	//for chart view
        waitUntilElementIsClickable(pageLib.getChartViewButton());
    	pageLib.getChartViewButton().click();
    	waitUntilVisibilityOfElement();
    	Assert.assertTrue(pageLib.getChartViewButton().isEnabled(), "List Manager is not changed to chart view");
    	logger.info(pageLib.getChartViewButton().getAttribute("titletooltip"));
    	//for List manager view
    	waitUntilElementIsClickable(pageLib.getlistViewButton());
    	pageLib.getlistViewButton().click();
    	waitUntilVisibilityOfElement();
    	Assert.assertTrue(pageLib.getlistViewButton().isEnabled(), "ListManager is not changed to List view");
    	logger.info(pageLib.getlistViewButton().getAttribute("titletooltip"));
    	//for default view
    	waitUntilElementIsClickable(pageLib.getDefaultViewButton());
    	pageLib.getDefaultViewButton().click();
    	waitUntilVisibilityOfElement();
    	Assert.assertTrue(pageLib.getDefaultViewButton().isEnabled(), "ListManager is not changed to default view");
    	logger.info(pageLib.getDefaultViewButton().getAttribute("titletooltip"));
    }
    
    /**
	 * Method Description (testCase:0302):When the panel is in one of those arbitrary positions, verify you can click DEFAULT, MIN, and MAX and get back to those default settings.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0302_ValidateListManagerDrag(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.getdragLM());
    	Actions action=new Actions(driver);
    	action.dragAndDropBy(pageLib.getdragLM(), 0, -200).perform();
    	Point currentLoc=pageLib.getdragLM().getLocation();
    	waitUntilElementisVisible(pageLib.getdragLM());
    	System.out.println("current loc:"+currentLoc.getY());
    	Assert.assertEquals(currentLoc.getY(), currentLoc.getY());
    }
    
    /**
	 * Method Description (testCase:0304):Click on the dropdown next to the PLAY button, and verify that the 1, 3, 5, 10, 15, 30, 45, and 60 seconds appear. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0304_ValidatePlayDropdownOptions(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	waitUntilElementIsClickable(pageLib.getPlayDropDown());
    	pageLib.getPlayDropDown().click();
    	logger.info(pageLib.getPlayDropDown().getAttribute("titletooltip")+" selected");
    	List<WebElement> intervalsList=pageLib.getplayIntervals();
    	String allIntervals[]={"1 Second","3 Seconds","5 Seconds","10 Seconds","15 Seconds","20 Seconds","30 Seconds","45 Seconds","60 Seconds"};
    	for(int i=0;i<intervalsList.size();i++){
    		Assert.assertEquals(intervalsList.get(i).getText().trim(), allIntervals[i],"Not present");
    		logger.info(intervalsList.get(i).getText()+" present");
    	}
    	pageLib.getPlayDropDown().click();
    }
    
    /**
	 * Method Description (testCase:0305):Click on the PLAY button and verify that it works correctly with the time of seconds you have selected.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0305_ValidatePlayButton(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	ValidateItemsOfList();
    	List<WebElement> symbolList=pageLib.getsymbolList();
    	waitUntilElementIsClickable(pageLib.getselectedStock());
    	pageLib.getselectedStock().click();
    	Actions action=new Actions(driver);
    	action.doubleClick(pageLib.getselectedStock()).build().perform();
    	waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), symbolList.get(0).getText());
    	waitUntilElementisVisible(pageLib.getlistViewButton());
    	pageLib.getlistViewButton().click();
    	int seconds=10;
    	Stopwatch timer=Stopwatch.createUnstarted();
    	waitUntilElementIsClickable(pageLib.getPlayDropDown());
    	pageLib.getPlayDropDown().click();
    	logger.info(pageLib.getPlayDropDown().getAttribute("titletooltip")+" selected");
    	waitUntilElementIsClickable(pageLib.getsingleInterval());
    	pageLib.getsingleInterval().click();
    	waitUntilElementIsClickable(pageLib.getPlayButton());
    	pageLib.getPlayButton().click();
    	timer.start();
       	for(int i=1;i<symbolList.size()-1;i++){
    		//waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), symbolList.get(i).getText());
    		while(timer.elapsed(TimeUnit.SECONDS)!=seconds) {
    			continue;
    		}
    		timer.stop();
    		timer.reset();
    		timer.start();
    		Assert.assertEquals(pageLib.getChartSymbol().getText(), symbolList.get(i).getText(),"Symbol not dispalyed");
    		logger.info("displayed for given seconds"+pageLib.getChartSymbol().getText());
        }
    }
    
    /**
	 * Method Description (testCase:0310):Verify that if you start to type or click on the chart, the playlist pauses and a window appears. The window should correctly state the amount of items remaining as well as contain a RESUME PLAYING button.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0310_VerifyResumePlayWindow(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	ValidateItemsOfList();
    	waitUntilVisibilityOfElement();
    	waitUntilElementIsClickable(pageLib.getselectedStock());
    	pageLib.getselectedStock().click();
    	Actions action=new Actions(driver);
    	action.doubleClick(pageLib.getselectedStock()).build().perform();
    	waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), pageLib.getselectedStock().getText());
    	pageLib.getPlayButton().click();
    	pageLib.getSymbolEntryField().click();
    	pageLib.getSymbolEntryField().clear();
    	pageLib.getSymbolEntryField().sendKeys("A");
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.getresumePlayWindow());
    	//Validate pause window appears
    	Assert.assertTrue(pageLib.getresumePlayWindow().isDisplayed(), "Resume play window not displayed");
    	String resumePlaycontent=pageLib.getresumePlayContent().getText();
    	int actualResult=Integer.parseInt(resumePlaycontent);
    	int activerownum=0;
    	List<WebElement> entireRow=pageLib.getEntireRow();
    	for(int i=0;i<entireRow.size()-1;i++){
    		if(entireRow.get(i).getAttribute("class").contains("cellActive ")){
    			 activerownum=i+1;
    	 int expectedResult=entireRow.size()-1-activerownum;
    	 //validate amount of items remaining
    	 Assert.assertEquals(actualResult, expectedResult,"Not matched");
    	}
     }
    	//Verify  contain a RESUME PLAYING button
    	Assert.assertTrue(pageLib.getResumePlayButton().isDisplayed(), "Resume paly button not displayed");
    	logger.info(pageLib.getResumePlayButton()+" Displayed");
    }
    
    /**
	 * Method Description (testCase:0313):Start the list playing again, then click on the pause button. Does the playlist stop?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0313_ValidatePlayFunctionality(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	ValidateItemsOfList();
    	waitUntilVisibilityOfElement();
    	waitUntilElementIsClickable(pageLib.getselectedStock());
    	pageLib.getselectedStock().click();
    	Actions action=new Actions(driver);
    	action.doubleClick(pageLib.getselectedStock()).build().perform();
    	waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), pageLib.getselectedStock().getText());
    	pageLib.getPlayButton().click();
    	waitUntilElementisVisible(pageLib.getPlayButton());
    	pageLib.getPlayButton().click();
    	Assert.assertEquals(pageLib.getPlayButton().getText().trim(), "Play","Text is not matched");
    }
    
    /**
	 * Method Description (testCase:0314):Verify that you can change the list panel size, open the Related Information Sidebar, change the chart periodicity, and change the time interval, all without the playlist stopping. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0314_ValidatePlayFunctionality(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	ValidateItemsOfList();
    	waitUntilVisibilityOfElement();
    	waitUntilElementIsClickable(pageLib.getselectedStock());
    	pageLib.getselectedStock().click();
    	Actions action=new Actions(driver);
    	action.doubleClick(pageLib.getselectedStock()).build().perform();
    	waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), pageLib.getselectedStock().getText());
    	pageLib.getPlayButton().click();
    	if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			waitUntilElementIsClickable(pageLib.getRelatedInfoTab());
			pageLib.getRelatedInfoTab().click();
			logger.info("clicked on tab "+pageLib.getRelatedInfoTab().getText());
			Assert.assertTrue(pageLib.getRiArrow().getAttribute("class").contains("labelAfterSmall"), "RI panel Not opened");
		}
		else{
			logger.info("RI is in open status");
		}
    	pageLib.getDailyButton().click();
    	Assert.assertTrue(pageLib.getDailyButton().isEnabled(),"Not enabled");
    	pageLib.getPlayDropDown().click();
    	logger.info(pageLib.getPlayDropDown().getAttribute("titletooltip")+" selected");
    	waitUntilElementIsClickable(pageLib.getFifthInterval());
    	pageLib.getFifthInterval().click();
    	Assert.assertFalse(pageLib.getresumePlayWindow().isDisplayed(), "Resume play window displayed");
    }
    
    /**
	 * Method Description (testCase:0315):While opening the Related Information sidebar should not stop playback, selecting one of the RI tabs should. So while the list is playing, open the RI sidebar panel, then click on "Owners & Funds" or one of the other tabs. Verify the list is paused and a window comes up telling you how many items is remaining.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0315_ValidatePlayWithRItab(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	ValidateItemsOfList();
    	waitUntilVisibilityOfElement();
    	waitUntilElementIsClickable(pageLib.getselectedStock());
    	pageLib.getselectedStock().click();
    	Actions action=new Actions(driver);
    	action.doubleClick(pageLib.getselectedStock()).build().perform();
    	waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), pageLib.getselectedStock().getText());
    	pageLib.getPlayButton().click();
    	if(pageLib.getRiArrow().getAttribute("class").contains("toLeftArrow")){
			waitUntilElementIsClickable(pageLib.getRelatedInfoTab());
			pageLib.getRelatedInfoTab().click();
			logger.info("clicked on tab "+pageLib.getRelatedInfoTab().getText());
			Assert.assertFalse(pageLib.getresumePlayWindow().isDisplayed(), "Resume play window displayed");
    	  }
    	  pageLib.getnewsTab().click();
		  logger.info("clicked on tab:"+pageLib.getnewsTab().getText());
		  Assert.assertTrue(pageLib.getresumePlayWindow().isDisplayed(), "Resume play window not displayed");
		  Assert.assertTrue(pageLib.getresumePlayContent().isDisplayed(), "Not showing how many items is remaining.");
		  pageLib.getRiArrow().click();
	}
    
    /**
	 * Method Description (testCase:0316):Verify the playlist stops once the last item is selected.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0316_VerifyPlayListStopsAtLastItem(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	List<WebElement> symbolList=pageLib.getsymbolList();
    	int listSize=symbolList.size()-1;
    	waitUntilElementIsClickable(pageLib.getselectedStock());
    	pageLib.getselectedStock().click();
    	Actions action=new Actions(driver);
    	action.doubleClick(pageLib.getselectedStock()).build().perform();
    	waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), pageLib.getselectedStock().getText());
    	pageLib.getPlayButton().click();
    	waitUntilVisibilityOfElement();
    	waitUntilVisibilityOfElement();
    	String chartedSymbol=pageLib.getChartSymbol().getText();
    	if(chartedSymbol.equals(symbolList.get(listSize-1).getText())){
    		Assert.assertTrue(pageLib.getendOfListMsg().isDisplayed(), "Play has not stopped");
    	}
    }
    
    
    /**
	 * Method Description (testCase:0318):Click on the Tool button (wrench icon) for the List Manager options. Does the dropdown menu appear?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0318_VerifyListMangerTool(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementIsClickable(pageLib.getlmTriangle());
    	pageLib.getlmTriangle().click();
    	logger.info("clicked on "+pageLib.getListManagerTool().getAttribute("class"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.gettoolsWindow());
    	Assert.assertTrue(pageLib.gettoolsWindow().isDisplayed(), "Tools options not displayed");
    }
    
    /**
	 * Method Description (testCase:0319):Verify the following options are present on the menu: "View Details," "Print List," "Export In," "Importing Lists," "Customize Column Layout," "Select Column Layout," "Append Screen Parameters," "Column Width Preference."
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0319_VerifyListManagerDropdown(){
    	Assert.assertTrue(pageLib.gettoolsWindow().isDisplayed(), "Tools options not displayed");
    	List<WebElement> listToolOptions=pageLib.gettoolsOptions();
    	String lmtoolOptions[]={"View Details","Print List","Export In","Importing Lists","Customize Column Layout","Select Column Layout","Append Screen Parameters","Column Width Preference"};
    	for(int i=0;i<listToolOptions.size();i++){
    	  logger.info(listToolOptions.get(i).getText()+" present");	
    	  Assert.assertEquals(listToolOptions.get(i).getText().trim(), lmtoolOptions[i],"Not matched");
        }
    }
    
    /**
	 * Method Description (testCase:0320):Click on View Details. Verify a window appears with information about the current list. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0320_ValidateViewDetailsOption(){
    	Assert.assertTrue(pageLib.gettoolsWindow().isDisplayed(), "Tools options not displayed");
    	String listTitleText=pageLib.getlistTitle().getText();
    	pageLib.getviewDetailsOption().click();
    	windowHandles();
    	waitUntilElementisVisible(pageLib.getcommunityWindow());
    	waitUntilVisibilityOfElement();
    	logger.info("switch to:"+pageLib.getcommunityWindow().getText().trim());
    	waitUntilVisibilityOfElement();
    	Assert.assertEquals(pageLib.getcommunityWindow().getText().trim() ,listTitleText,"Not opened window for current list");
    }
    
    /**
	 * Method Description (testCase:0321):Verify the information window contains a "Rating", "Tracked by", "Author", "Last Updated", "Number of Results", "Description", "Tags", any comments made by other members, and an "Add a comment" section to make comments about the list.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0321_VerifyContentsOfViewDetails(){
    	Assert.assertTrue(pageLib.getcommunityWindow().isDisplayed(),"Not opened community window for current list" );
    	Assert.assertTrue(pageLib.getRatingName().isDisplayed(), "Rating name not displayed");
 	    Assert.assertTrue(pageLib.getTrackedByLabel().isDisplayed(), "tracked by label not present");
 	    Assert.assertTrue(pageLib.getAuthorLabel().isDisplayed(), "Author is not displayed");
 	    Assert.assertTrue(pageLib.getLastUpdatedField().isDisplayed(), "Last updated is not displayed");
 	    Assert.assertTrue(pageLib.getnoOfResults().isDisplayed(), "No of Items not dispalyed");
 	    Assert.assertTrue(pageLib.getDescriptionLAbel().isDisplayed(), "Description is not present");
 	    Assert.assertTrue(pageLib.getTagsSection().isDisplayed(), "tags section is not present");
 	    Assert.assertTrue(pageLib.getShowComments().isDisplayed(), "Show comment section is not present");
 	    Assert.assertTrue(pageLib.getAddCommentSection().isDisplayed(), "Add comments section is not displayed");
 	    logger.info("All contents displayed");
 	 }
    
    /**
	 * Method Description (testCase:0324):Above the rating, is there a "Sharing status"? The default should be set to "Private" with a "change" link next to it.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0324_VerifySharingStatus(){
    	Assert.assertTrue(pageLib.getcommunityWindow().isDisplayed(),"Not opened community window for current list" );
    	WebElement sharingStatus=pageLib.getsharingstatus();
    	Assert.assertTrue(sharingStatus.isDisplayed(), "Sharing status not displayed");
    	Assert.assertEquals(sharingStatus.getText(), "Private","It is not private");
    	logger.info(sharingStatus.getText()+" is sharing status");
    	Assert.assertTrue(pageLib.getstatusChangeLink().isDisplayed(), "Change link not present");
    	logger.info(pageLib.getstatusChangeLink().getText()+" link is present");
    }
    
    /**
	 * Method Description (testCase:0325):Click on change. Verify a new "Share a List" window appears.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0325_ValidateChangeLink(){
    	Assert.assertTrue(pageLib.getstatusChangeLink().isDisplayed(), "Change link not present");
    	pageLib.getstatusChangeLink().click();
    	logger.info("clicked on "+pageLib.getstatusChangeLink().getText());
    	windowHandles();
    	waitUntilElementisVisible(pageLib.getShareListWindow());
    	logger.info("switch to window "+pageLib.getShareListWindow().getText());
    	Assert.assertEquals(pageLib.getShareListWindow().getText().trim(), "Share a List","share a list window not appeared");
    }
    
    /**
	 * Method Description (testCase:0326):Verify the window contains three selectable sharing options with radio buttons on the left, a description box with a 500 character limit, available tags to assign as well as a description on the bottom about shared lists.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0326_VerifyContentsOfShareList(){
    	Assert.assertEquals(pageLib.getShareListWindow().getText().trim(), "Share a List","share a list window not appeared");
    	List<WebElement> sharedOptions=pageLib.getSharingOptions();
    	for(int i=0;i<sharedOptions.size();i++){
    		sharedOptions.get(i).click();
    		logger.info(sharedOptions.get(i).getText()+" is clicked");
    		waitUntilVisibilityOfElement();
    		Assert.assertTrue(sharedOptions.get(i).isSelected(), "is not clickable");
    	}
    	Assert.assertEquals(sharedOptions.size(), 3,"It does not contain 3 options");
    	Assert.assertTrue(pageLib.getdescriptionArea().isDisplayed(), "Description area is missing");
    	Assert.assertTrue(pageLib.getcharLeftNum().isDisplayed(), "Character Left number is missing");
    	Assert.assertTrue(pageLib.getalltagsSection().isDisplayed(), "Tags not available");
    	Assert.assertTrue(pageLib.getaboutSharingScreen().isDisplayed(), "about sharing screens is not present");
    }
    
    /**
	 * Method Description (testCase:0327):Edit the list settings by changing the sharing status, editing the description, and adding or removing tags. Click Cancel.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0327_ValidateEditContentsOfsharedList(){
    	try{Assert.assertEquals(pageLib.getShareListWindow().getText().trim(), "Share a List","share a list window not appeared");
    	List<WebElement> sharedOptions=pageLib.getSharingOptions();
    	sharedOptions.get(1).click();
    	logger.info("selected:"+sharedOptions.get(1).getAttribute("name"));
    	waitUntilElementIsClickable(pageLib.getdescriptionArea());
    	pageLib.getdescriptionArea().sendKeys("List description by jimjohn");
    	logger.info("added description: "+pageLib.getdescriptionArea().getAttribute("value"));
    	List<WebElement> tagsList=pageLib.getAllTags();
    	tagsList.get(0).click();
    	tagsList.get(1).click();
    	waitUntilElementisVisible(pageLib.gettagsApplied());
    	waitUntilElementIsClickable(pageLib.getshareCancelButton());
    	pageLib.getshareCancelButton().click();
    	}catch(Exception e){
    		Assert.fail("Cancel button is not clickable");
    	}
    } 
    
    /**
	 * Method Description (testCase:0328):Verify the list settings have not been changed.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0328_VerifyListSettingsChanged(){
    	Assert.assertTrue(pageLib.getcommunityWindow().isDisplayed(),"Not opened community window for current list" );
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.getsharingstatus());
    	WebElement sharingStatus=pageLib.getsharingstatus();
    	logger.info("Sharing status:"+sharingStatus.getText());
    	Assert.assertEquals(sharingStatus.getText().trim(), "Private","List setting has changed");
    }
    
    /**
	 * Method Description (testCase:0329):Edit the list settings by changing the sharing status, editing the description, and adding or removing tags. Click Apply.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0329_ValidateContentsOfShareList(){
    	Assert.assertTrue(pageLib.getcommunityWindow().isDisplayed(),"Not opened community window for current list" );
    	pageLib.getstatusChangeLink().click();
    	windowHandles();
    	waitUntilElementisVisible(pageLib.getShareListWindow());
    	List<WebElement> sharedOptions=pageLib.getSharingOptions();
    	waitUntilElementIsClickable(sharedOptions.get(1));
    	sharedOptions.get(1).click();
    	logger.info("selected:"+sharedOptions.get(1).getAttribute("name"));
    	waitUntilElementIsClickable(pageLib.getdescriptionArea());
    	pageLib.getdescriptionArea().sendKeys("List description by jimjohn");
    	logger.info("added description: "+pageLib.getdescriptionArea().getAttribute("value"));
    	waitUntilVisibilityOfElement();
    	List<WebElement> tagsList=pageLib.getAllTags();
    	tagsList.get(0).click();
    	tagsList.get(1).click();
    	waitUntilElementisVisible(pageLib.gettagsApplied());
    	
    	//Validate Tags applied or not
    	Assert.assertTrue(pageLib.gettagsApplied().isDisplayed(), "Tags not applied");
    	sharedOptions.get(1).click();
    	waitUntilElementIsClickable(pageLib.getApplyButton());
    	pageLib.getApplyButton().click();
    	logger.info("clicked on button: "+pageLib.getApplyButton().getText());
    	waitUntilVisibilityOfElement();
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.getcommunityWindow());
    	Assert.assertTrue(pageLib.getcommunityWindow().isDisplayed(),"Not opened community window for current list" );
    }
    
    /**
	 * Method Description (testCase:0330):Verify the list settings have been changed. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0330_VerifyListSettings(){
    	Assert.assertTrue(pageLib.getcommunityWindow().isDisplayed(),"Not opened community window for current list" );
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.getsharingstatus());
    	WebElement sharingStatus=pageLib.getsharingstatus();
    	logger.info("Sharing status:"+sharingStatus.getText());
    	waitUntilVisibilityOfElement();
    	Assert.assertEquals(sharingStatus.getText().trim(), "Public","It is not public");
    }
    
    /**
	 * Method Description (testCase:0331):Verify that a shared list shows a "shared" icon next to the list name on the list manager.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0331_VerifySharedIconForSharedList(){
    	Assert.assertEquals(pageLib.getsharingstatus().getText().trim(), "Public","It is not public");
    	pageLib.getcloseButton().click();
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.getSecondList());
    	Assert.assertTrue(pageLib.getsecSharedIcon().isDisplayed(), "shared icon is not present");
    	logger.info("Shared icon is present");
    }
    
    /**
	 * Method Description (testCase:0339):Click on Export. Verify the current export options appear: "Comma Delimited (.csv)", "Excel 97-2003 (.xls)", "Excel (.xlsx)", and "Text (.txt)".
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0339_VerifyExportOptions(){
    	waitUntilElementIsClickable(pageLib.getlmTriangle());
    	pageLib.getlmTriangle().click();
    	logger.info("clicked on "+pageLib.getListManagerTool().getAttribute("class"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.gettoolsWindow());
    	Actions action=new Actions(driver);
    	action.moveToElement(pageLib.getexportButton()).build().perform();
    	waitUntilElementisVisible(pageLib.getwaitForExportOptions());
    	String exportOptions[]={"Comma Delimited (.csv)","Excel 97-2003 (.xls)","Excel (.xlsx)","Text (.txt)"};
    	List<WebElement> exportOptionList=pageLib.getallExportOptions();
    	for(int i=0;i<exportOptionList.size();i++){
    		logger.info(exportOptionList.get(i).getText()+" present");
    		Assert.assertEquals(exportOptionList.get(i).getText(), exportOptions[i], "option not present");
    	}
    } 
    
    /**
	 * Method Description (testCase:0340):Select "Comma Delimited (.csv)" in the Export menu. The file download process starts
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0340_ValidateCommaDelimitedOption(){
    	waitUntilElementisVisible(pageLib.gettoolsWindow());
    	Actions action=new Actions(driver);
    	action.moveToElement(pageLib.getexportButton()).build().perform();
    	waitUntilElementisVisible(pageLib.getwaitForExportOptions());
    	List<WebElement> exportOptionList=pageLib.getallExportOptions();
    	exportOptionList.get(0).click();
    	logger.info("selected option:"+exportOptionList.get(0).getText());
    	Assert.fail("not yet done");
    }
    
    /**
	 * Method Description (testCase:0350):Click on Customize Column Layout. Does a window appear?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0350_VerifyCustomizeColumnLayoutOption(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementIsClickable(pageLib.getlmTriangle());
    	pageLib.getlmTriangle().click();
    	logger.info("clicked on "+pageLib.getListManagerTool().getAttribute("class"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.gettoolsWindow());
    	pageLib.getcustomizeColumnOption().click();
    	waitUntilElementisVisible(pageLib.getcustomizeColumnLayout());
    	Assert.assertEquals(pageLib.getcustomizeColumnLayout().getText().trim(), "Customize Column Layout", "Customize window not appeared");
    }
    
    /**
	 * Method Description (testCase:0351):The top should contain dropdown menus similar to that of the screener. Each dropdown menu will contain selectable criteria in the form of boxes that are draggable to the bottom layout preview. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0351_VerifySelectableCriteria(){
    	Assert.assertEquals(pageLib.getcustomizeColumnLayout().getText().trim(), "Customize Column Layout", "Customize window not appeared");
    	waitUntilElementIsClickable(pageLib.getcellExtendDropdown());
    	pageLib.getcellExtendDropdown().click();
    	List<WebElement> allRatingColumnList=pageLib.getallRatingColumns();
    	for(int i=0;i<allRatingColumnList.size();i++){
    		Assert.assertTrue(allRatingColumnList.get(i).isDisplayed(), "selectable criteria not present");
    	}
    	((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getcustomizeColumnCancelButton());
    	waitUntilVisibilityOfElement();
    }
    
    /**
	 * Method Description (testCase:0353):Hover over Select Column Layout. The default layouts should appear ("197 Industry Groups", "Stock List", "Fund List", and "Market/Indices") as well as any custom layouts you created in the Customize Column Layout option.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0353_VerifyColumnLayoutOption(){
    	waitUntilVisibilityOfElement();
    	waitUntilElementIsClickable(pageLib.getlmTriangle());
    	pageLib.getlmTriangle().click();
    	logger.info("clicked on "+pageLib.getListManagerTool().getAttribute("class"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.gettoolsWindow());
    	waitUntilElementIsClickable(pageLib.getcolumnLayoutOption());
    	Actions action=new Actions(driver);
    	action.moveToElement(pageLib.getcolumnLayoutOption()).build().perform();
    	waitUntilElementisVisible(pageLib.getwaitForColumnLayoutOptions());
    	String columnLayoutoption[]={"Saved","marketsCap","Defaults","197 Industry Groups","Stock List","Fund List","Market/Indices"};
    	List<WebElement> columnLayoutOptions=pageLib.getcolumnLayoutOptions();
    	for(int i=0;i<columnLayoutOptions.size();i++){
    		logger.info(columnLayoutOptions.get(i).getText()+" present");
    		Assert.assertEquals(columnLayoutOptions.get(i).getText().trim(), columnLayoutoption[i],"Option not present");
    	}
    }
    
    /**
	 * Method Description (testCase:0354):Click on any column layout. Verify the list panel column titles change to reflect your selection.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0354_ValidateColumnLayoutOptions(){
    	waitUntilElementisVisible(pageLib.gettoolsWindow());
    	Actions action=new Actions(driver);
    	action.moveToElement(pageLib.getcolumnLayoutOption()).build().perform();
    	waitUntilElementisVisible(pageLib.getwaitForColumnLayoutOptions());
    	List<WebElement> columnLayoutOptions=pageLib.getcolumnLayoutOptions();
    	columnLayoutOptions.get(3).click();
    	waitUntilVisibilityOfElement();
    	List<WebElement> columnNamelist=pageLib.getColumnNames();
    	String flagImg="url(\"http://marketsmith.stage-ibd.com/mstool/Images/ListManager/LMImgsCnt.png\")"; 
 	    String columnHeader[]={"",flagImg,"#","Symbol","Name","Type","Number of Stocks","Ind Group Rank","Ind Grp Rnk Last Week","Ind Grp Rnk 3 Mo Ago","Ind Grp Rnk 6 Mo Ago","% Chg YTD","Ind Mkt Val (bil)"};
 	    for(int i=1;i<columnNamelist.size();i++){
 	    	switch(i) {
 	    	case 1:
 	    		Assert.assertEquals(columnNamelist.get(i).findElement(By.className("LMImgs")).getCssValue("background-image"), columnHeader[i]," not matched");
 		    	logger.info("column name is"+columnNamelist.get(i).getText());
 	    		break;
 	    	default:
 	    		Assert.assertEquals(((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML;", columnNamelist.get(i)), columnHeader[i]," not matched");
 	    		logger.info("column name is"+columnNamelist.get(i).getText());
 	    	}
 	    }
 	   waitUntilElementIsClickable(pageLib.getlmTriangle());
   	   pageLib.getlmTriangle().click();
   	   waitUntilElementisVisible(pageLib.gettoolsWindow());
	   action.moveToElement(pageLib.getcolumnLayoutOption()).build().perform();
	   waitUntilElementisVisible(pageLib.getwaitForColumnLayoutOptions());
	   columnLayoutOptions.get(4).click(); 
	   waitUntilVisibilityOfElement();
    }
    
    /**
	 * Method Description (testCase:0356):Click on Column Width Preference. Verify the "Column Width Preference" window appears and contains two radio buttons.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0356_VerifyColumnWidthPrefButtons(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementIsClickable(pageLib.getlmTriangle());
    	pageLib.getlmTriangle().click();
    	logger.info("clicked on "+pageLib.getListManagerTool().getAttribute("class"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.gettoolsWindow());
    	waitUntilElementIsClickable(pageLib.getcolumnWidthPreference());
    	pageLib.getcolumnWidthPreference().click();
    	windowHandles();
    	waitUntilElementisVisible(pageLib.getcolumnWidthPrefWindow());
    	Assert.assertTrue(pageLib.getcolumnWidthPrefWindow().isDisplayed(),"Column width preferences not appeared");
    	List<WebElement> liRadioButtons=pageLib.getcolumnWidthButtons();
    	for(int i=0;i<liRadioButtons.size();i++){
    		Assert.assertTrue(liRadioButtons.get(i).isDisplayed(),"this radio button is missing");
    	}
    }
       
    /**
	 * Method Description (testCase:0357):Select the first radio button and hit Accept. Verify adjusting a column does not affect the same column on another list. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0357_ValidateAdjustColumnWidthforCurrentList(){
    	Assert.assertTrue(pageLib.getcolumnWidthPrefWindow().isDisplayed(),"Column width preferences not appeared");
    	List<WebElement> liRadioButtons=pageLib.getcolumnWidthButtons();
    	waitUntilElementIsClickable(liRadioButtons.get(0));
    	liRadioButtons.get(0).click();
    	waitUntilElementIsClickable(pageLib.getcolumnPrefAccept());
    	pageLib.getcolumnPrefAccept().click();
    	waitUntilElementisVisible(pageLib.getsymbolColumn());
    	((JavascriptExecutor) driver).executeScript("arguments[0].style.width='50px'",pageLib.getsymbolColumn());
    	waitUntilElementIsClickable(pageLib.getUserCreatedList());
    	pageLib.getUserCreatedList().click();
    	waitUntilTextTobePresentInElement(pageLib.getlistTitle(),pageLib.getUserCreatedList().getText());
    	waitUntilElementisVisible(pageLib.getsymbolColumn());
    	Assert.assertNotEquals(pageLib.getsymbolColumn().getAttribute("style"), "width: 50px"," width are matching");
    }
    
    /**
	 * Method Description (testCase:0358):Select the second option and hit Accept. Verify adjusting a column will affect it on all lists.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0358_ValidateColumnWidthForAllLists(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementIsClickable(pageLib.getlmTriangle());
    	pageLib.getlmTriangle().click();
    	logger.info("clicked on "+pageLib.getListManagerTool().getAttribute("class"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.gettoolsWindow());
    	waitUntilElementIsClickable(pageLib.getcolumnWidthPreference());
    	pageLib.getcolumnWidthPreference().click();
    	windowHandles();
    	waitUntilElementisVisible(pageLib.getcolumnWidthPrefWindow());
    	List<WebElement> liRadioButtons=pageLib.getcolumnWidthButtons();
    	waitUntilElementIsClickable(liRadioButtons.get(1));
    	liRadioButtons.get(1).click();
    	waitUntilElementIsClickable(pageLib.getcolumnPrefAccept());
    	pageLib.getcolumnPrefAccept().click();
    	waitUntilElementisVisible(pageLib.getsymbolColumn());
    	((JavascriptExecutor) driver).executeScript("arguments[0].style.width='40px'",pageLib.getsymbolColumn());
    	waitUntilVisibilityOfElement();
    	waitUntilElementIsClickable(pageLib.getSecondList());
    	pageLib.getSecondList().click();
    	waitUntilTextTobePresentInElement(pageLib.getlistTitle(),pageLib.getSecondList().getText());
    	waitUntilVisibilityOfElement();
    	String width=pageLib.getsymbolColumn().getAttribute("style");
    	waitUntilElementisVisible(pageLib.getsymbolColumn());
    	Assert.assertEquals(pageLib.getsymbolColumn().getAttribute("style"), width," width are not matching");
    }
    
    /**
	 * Method Description (testCase:0359):Click on the first radio button again, except hit Cancel. When changing the width of a column, are the selected preferences still in affect? 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0359_ValidateColumnWidthPrefCancelButton(){
    	verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementIsClickable(pageLib.getlmTriangle());
    	pageLib.getlmTriangle().click();
    	logger.info("clicked on "+pageLib.getListManagerTool().getAttribute("class"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.gettoolsWindow());
    	waitUntilElementIsClickable(pageLib.getcolumnWidthPreference());
    	pageLib.getcolumnWidthPreference().click();
    	windowHandles();
    	waitUntilElementisVisible(pageLib.getcolumnWidthPrefWindow());
    	List<WebElement> liRadioButtons=pageLib.getcolumnWidthButtons();
    	waitUntilElementIsClickable(liRadioButtons.get(1));
    	liRadioButtons.get(0).click();
    	waitUntilElementIsClickable(pageLib.getcolumPrefCancel());
    	pageLib.getcolumPrefCancel().click();
    	waitUntilVisibilityOfElement();
    	waitUntilElementIsClickable(pageLib.getlmTriangle());
    	pageLib.getlmTriangle().click();
    	logger.info("clicked on "+pageLib.getListManagerTool().getAttribute("class"));
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.gettoolsWindow());
    	waitUntilElementIsClickable(pageLib.getcolumnWidthPreference());
    	pageLib.getcolumnWidthPreference().click();
    	windowHandles();
    	waitUntilElementisVisible(pageLib.getcolumnWidthPrefWindow());
    	Assert.assertFalse(liRadioButtons.get(0).isSelected(), "Cancel is not working");
    	pageLib.getcolumPrefCancel().click();
    	waitUntilVisibilityOfElement();
    }
    
    /**
	 * Method Description (testCase:0322):Change the Sharing Status of the list from PRIVATE to SHARE WITH EVERYONE. Then verify that you are able to comment on the list. Does the comment appear in the Comments section?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0322_VerifyCommentSectionOfSharedList(){
    	Assert.assertEquals(pageLib.getsharingstatus().getText().trim(), "Public","It is not public");
    	waitUntilElementIsClickable(pageLib.getTextArea());
    	pageLib.getTextArea().sendKeys("commentbyJimJhon");
   	    waitUntilElementIsClickable(pageLib.getcommentSubmit());
   	    pageLib.getcommentSubmit().click();
   	    logger.info("clicked on  "+pageLib.getcommentSubmit().getText()+" button");
        logger.info("comments added");
   	    waitUntilVisibilityOfElement();
   	    waitUntilVisibilityOfElement();
   	    waitUntilElementisVisible(pageLib.getShowComments());
   	    waitUntilVisibilityOfElement();
   	    //validating comments added or not
   	    Assert.assertTrue(pageLib.getShowComments().isDisplayed(),"Comments not added");
   	 }
    
    /**
	 * Method Description (testCase:0323):Rate the list by hovering over the Stars next to the Rating section and clicking on a star. The stars should be highlighted Grey. When you exit the window, the average star rating will update and will highlight the stars Red (Note: The average rating (Red) may differ from your (Grey) rating).
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0323_VerifyRatingSectionOfSharedList(){
     Assert.assertEquals(pageLib.getsharingstatus().getText().trim(), "Public","It is not public");
     waitUntilElementIsClickable(pageLib.getRatingSection());
   	 pageLib.getRatingSection().click();
   	 logger.info("rating section selected");
   	 waitUntilVisibilityOfElement(); 
   	 pageLib.getcloseButton().click();
   	 waitUntilVisibilityOfElement();
	 waitUntilElementIsClickable(pageLib.getlmTriangle());
	 pageLib.getlmTriangle().click();
	 logger.info("clicked on "+pageLib.getListManagerTool().getAttribute("class"));
	 waitUntilVisibilityOfElement();
	 waitUntilElementisVisible(pageLib.gettoolsWindow());
	 pageLib.getviewDetailsOption().click();
 	 windowHandles();
 	 waitUntilElementisVisible(pageLib.getcommunityWindow());
 	 waitUntilVisibilityOfElement();
 	 logger.info("switch to:"+pageLib.getcommunityWindow().getText().trim());
 	 Assert.assertTrue(pageLib.getRatingSection().getAttribute("class").contains("screen_darkbigRedStar"), "Rating not changed to red");
 	 }
    
    /**
	 * Method Description (testCase:0332):Click View Details. Verify the information window appears and that the information is correct/related to the screen.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0332_ValidateViewDetailsOfListSharedwithUs(){
       verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
 	   pageLib.getBrowseButton().click();
 	   logger.info("selected button "+pageLib.getBrowseButton().getText());
 	   windowHandles();
 	   waitUntilElementisVisible(pageLib.getBrowseListWindow());
 	   logger.info("switched to "+pageLib.getBrowseListWindow().getText());
 	   waitUntilVisibilityOfElement();
 	   waitUntilElementIsClickable( pageLib.getSharedList());
 	   pageLib.getSharedList().click();
 	   logger.info("clicked on "+pageLib.getSharedList().getText());
 	   waitUntilElementisVisible(pageLib.getcommunityWindow());
  	   waitUntilVisibilityOfElement();
  	   logger.info("switch to:"+pageLib.getcommunityWindow().getText().trim());
  	   Assert.assertTrue(pageLib.getcommunityWindow().isDisplayed(),"Not opened community window for current list" );
    }
    
    /**
	 * Method Description (testCase:0333):click VIEW LIST button in list details window
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0333_ValidateViewListButton(){
       Assert.assertTrue(pageLib.getcommunityWindow().isDisplayed(),"Not opened community window for current list" );
       String sharedListName=pageLib.getcommunityWindow().getText();
 	   pageLib.getViewListButton().click();
 	   waitUntilVisibilityOfElement();
 	   waitUntilTextTobePresentInElement(pageLib.getCurrentListName(), sharedListName);
 	   logger.info("opened list manager for "+sharedListName);
    }
    
    /**
	 * Method Description (testCase:0334):view profile of author who shares list, via browse name link and other way
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0334_ViewProfileOfAuthorWhoSharedList(){
    	
       try{Assert.assertTrue(pageLib.getcommunityWindow().isDisplayed(),"Not opened community window for current list" );
       waitUntilElementIsClickable(pageLib.getAuthorLink());
 	   pageLib.getAuthorLink().click();
 	   windowHandles();
 	   
 	   //Verifying authors c profile
 	   verifyPageTitle(CONSTANTS.getProperty("COMMUNITY_PAGE_TITLE"));
 	   logger.info("Navigated to URL: "+driver.getCurrentUrl());
       }finally{
    	   closeWindow();
       }
 	 }
    
    /**
	 * Method Description (testCase:0335):validate (T) if you are tracking list
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0335_ValidateTsymbolForTrackedList(){
       Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
       String sharedList=pageLib.getsecondSharedList().getText();
 	   pageLib.getsecondSharedList().click();
 	   logger.info("clicked on "+sharedList);
 	   waitUntilElementisVisible(pageLib.getcommunityWindow());
 	   if(!(pageLib.getTrackButton().getAttribute("style").contains("display: none"))){
 		 pageLib.getTrackButton().click();
 		 waitUntilElementisVisible(pageLib.getUnTrackButton());
 		 logger.info("list is tracked");
 	   }else{
 		  logger.info("It is already tracked");
 	   }
 	   pageLib.getcloseButton().click();
 	   waitUntilVisibilityOfElement();
 	   waitUntilElementisVisible(pageLib.getsecondSharedList());
 	   Assert.assertTrue(pageLib.getsecondSharedList().getAttribute("class").contains("ListSpanWithTSymbol"), "It does not contain T symbol");
 	   pageLib.getbrowseListWindowClose().click();
 	   waitUntilVisibilityOfElement();
    	
    }
}
