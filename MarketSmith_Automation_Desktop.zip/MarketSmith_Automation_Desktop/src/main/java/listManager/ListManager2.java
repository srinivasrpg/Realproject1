package listManager;

import static genericLib.Utility.*;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;


import genericLib.Utility;

public class ListManager2 {
	
	ListManager2Lib pageLib=PageFactory.initElements(driver, ListManager2Lib.class);
	
	/**
	 * Method Description (testCase:0413 and 414):Verify that on the top tool bar the far left side displays the total number of items in the list. Also, the name of the list (or screen) should be displayed to the left of that, above the List Manager panel.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	
	public void tc0414_ValidateItemsDisplay(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		if(!(myListLink.getAttribute("class").contains("down"))){
		 myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		 }
		  WebElement myListElements=pageLib.getMyListElements();
			if(myListElements.getAttribute("class").contains("listExplorerItem ")){
			WebElement createdListLink=pageLib.getUserCreatedList();
			String createdListText=createdListLink.getText();
			createdListLink.click();
			logger.info("clicked on "+createdListText+" list");
			waitUntilElementisVisible(pageLib.getitemNum());
			Assert.assertTrue(pageLib.getitemNum().isDisplayed(), "not dispalyed");
			Assert.assertEquals(pageLib.getCurrentListName().getText().trim(), createdListText);
			logger.info("the no of items present "+pageLib.getitemNum().getText());
			}else{
					logger.info("it is a folder ");
				   }
	}
	
	/**
	 * Method Description (testCase:0416):Choose another list from the List Manager. Ensure that this list appears. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0416_ValidateItemsOfList(){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		if(!(myListLink.getAttribute("class").contains("down"))){
		  	myListLink.click();
			logger.info("clicked on "+MyListText+" folder");
		  } 
		   WebElement myListElements=pageLib.getmyListElements();
		   if(myListElements.getAttribute("class").contains("listExplorerItem ")){
		   WebElement createdListLink=pageLib.getSecondList();
			  String createdListText=createdListLink.getText();
			  createdListLink.click();
			  logger.info("clicked on "+createdListText+" list");
			  Assert.assertEquals(pageLib.getCurrentListName().getText().trim(), createdListText);
		}else{
			  logger.info("it is a folder ");
			}
   }
	
	/**
	 * Method Description (testCase:0418):Enter a stock symbol into the Symbol Field. Verify the new symbol is charted correctly. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/ 
	public void tc0418_ValidateEnterNewSymbol(String symbol){
		waitUntilElementIsClickable(pageLib.getSymbolEntryField());
		pageLib.getSymbolEntryField().clear();
		pageLib.getSymbolEntryField().sendKeys(symbol);
		Actions actions =new Actions(driver);
		actions.sendKeys(Keys.ENTER).build().perform();
		waitUntilVisibilityOfElement();
		waitUntilElementisVisible(pageLib.getChartSymbol());
		Assert.assertTrue(pageLib.getsymbolInformation().isDisplayed(), "Not charted for entered symbol");
	}
	
	/**
	 * Method Description (testCase:0419):Select a third list from the List Manager. Verify that the list you selected appears. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0419_ValidateThirdListDisplay(){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		if(!(myListLink.getAttribute("class").contains("down"))){
		 myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		 }
		  WebElement myListElements=pageLib.getmyListThirdListLoc();
			if(myListElements.getAttribute("class").contains("listExplorerItem ")){
			WebElement createdListLink=pageLib.getthirdList();
			String createdListText=createdListLink.getText();
			createdListLink.click();
			logger.info("clicked on "+createdListText+" list");
			waitUntilElementisVisible(pageLib.getitemNum());
			Assert.assertTrue(pageLib.getitemNum().isDisplayed(), "not dispalyed");
			Assert.assertEquals(pageLib.getCurrentListName().getText().trim(), createdListText);
		 }else{
					logger.info("it is a folder ");
				   }
	}
	
	/**
	 * Method Description (testCase:0420):Are you able to click on all the row items in the List Panel? When clicked, is there a "Trash Can" as well as a "Global Flag" Icon to the left of the item that you can click on? (hardcoded MarketSmith lists won't have the trashcan).
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0420_ValidateFlagnThrashForEachItem(){
		Assert.assertTrue(pageLib.getitemNum().isDisplayed(), "not dispalyed");
		pageLib.getlistViewButton().click();
		List<WebElement> symbolList=pageLib.getsymbolList();
		if(symbolList.size()!=0){
		for(int i=0;i<symbolList.size()-1;i++){
		waitUntilElementIsClickable(symbolList.get(i));	
		((JavascriptExecutor) driver).executeScript("arguments[0].click();",symbolList.get(i));
		logger.info("clicking on tickers ");
		waitUntilElementisVisible(pageLib.getFlagElement());
		Assert.assertTrue(pageLib.getFlagElement().isDisplayed(), "flag icon not displayed");
		Assert.assertTrue(pageLib.getThrashCan().isDisplayed(), "thrash can is not displayed");
		}
	 }else{
			Assert.fail("no symbols present");
		}
	}
	
	/**
	 * Method Description (testCase:0421):Verify you can scroll the list panel. The list panel should be scrollable up and down for a list larger than the current panel size. The list panel should also be scrollable left and right to view additional columns you have set.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0421_VerifyListPanelScroll(){
		pageLib.getDefaultViewButton().click();
		waitUntilVisibilityOfAllElements(pageLib.getsymbolList());
		List<WebElement> symbolList=pageLib.getsymbolList();
		int listSize=symbolList.size()-1;
		if(listSize>=5){
			((JavascriptExecutor) driver).executeScript("scroll(0,150);");
		}
	}
	
	/**
	 * Method Description (testCase:0423):Double-click the NAME column. Verify the column auto-expands to the width of the longest line of data, and that the ellipses are now gone.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0423_VerifyNameColumnAutoExpansion(){
		waitUntilElementisVisible(pageLib.getnameLoc());
		Actions action=new Actions(driver);
		action.doubleClick(pageLib.getnameLoc()).build().perform();
		waitUntilVisibilityOfElement();
		Assert.assertEquals(pageLib.getnameLoc().getAttribute("style"),"width: 170px;", "Name column not auto expanded");
	}
	
	/**
	 * Method Description (testCase:0424):Close the MS TOOL, open it again, and go back to the list. Verify the new widths you created in the last step are still active.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	 * @throws InterruptedException 
	**/
	public void tc0424_VerifyNewWidthCreatedInLastSession() throws InterruptedException{
		verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		closeWindow();
		launchMSTool();
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementisVisible(pageLib.getnameLoc());
		Assert.assertEquals(pageLib.getnameLoc().getAttribute("style"),"width: 170px;", "Name column width has  changed");
	}

	/**
	 * Method Description (testCase:0425):Validate that a new list has the following default columns: "[flag icon]," "#," "Symbol," "Name," "Type," "Current Price," "Price % Chg," "Volume 1000s," "Vol % Chg vs 50-day," "EPS Rating," "RS rating," Ind Group RS," "SMR Rating," A/D Rating," and "Comp Rating."
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0425_ValidateDefaultColumns(){
		waitUntilElementisVisible(pageLib.getitemNum());
		List<WebElement> columnNamelist=pageLib.getColumnNames();
	    String flagImg="url(\"http://marketsmith.stage-ibd.com/mstool/Images/ListManager/LMImgsCnt.png\")"; 
	    String columnHeader[]={"",flagImg,"#","Symbol","Name","Type","Current Price","Price % Chg","Price $ Chg","Volume (1000s)","Vol % Chg vs 50-Day","EPS Rating","RS Rating","Ind Group RS","SMR Rating","A/D Rating","Comp Rating"};
	    for(int i=0;i<columnNamelist.size()-1;i++){
	    	switch(i) {
	    	case 1:
	    		Assert.assertEquals(columnNamelist.get(i).findElement(By.className("LMImgs")).getCssValue("background-image"), columnHeader[i]," not matched");
		    	logger.info("column name is"+columnNamelist.get(i).getText());
	    		break;
	    	default:
	    		Assert.assertEquals(((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML;", columnNamelist.get(i)), columnHeader[i]," not matched");
	    		logger.info("column name is"+columnNamelist.get(i).getText());
	    	}
	    }
	}
	
	/**
	 * Method Description (testCase:0426):Verify that you can't drag the following hardcoded headers into a new order/location: "[flag symbol]," "#" symbol, "Symbol," "Name," and "Type." 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/ 
	public void tc0426_VerifyNondragableColumns(){
		waitUntilElementisVisible(pageLib.getsymbolLoc());
		Actions action=new Actions(driver);
		action.dragAndDrop(pageLib.getsymbolLoc(), pageLib.getnameLoc());
		Assert.assertNotEquals(pageLib.getsymbolColumn().getText(), "Name", "Freezed columns are dragable");
	}
	
	/**
	 * Method Description (testCase:0427):Click any of the headers to the right of these, and you should be able to drag them around into different orders, provided you don't go left past the "Type" field.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0427_VerifyDragableColumns(){
		waitUntilElementisVisible(pageLib.getsecondFlexibleColumnLoc());
		String secondFlexibleCol=pageLib.getsecondFlexibleColName().getText();
		System.out.println(secondFlexibleCol);
		Actions action=new Actions(driver);
		action.dragAndDrop(pageLib.getsecondFlexibleColumnLoc(), pageLib.getthirdFlexibleColumnLoc()).build().perform();
		waitUntilElementisVisible(pageLib.getthirdFlexibleColName());
		Assert.assertEquals(pageLib.getthirdFlexibleColName().getText(), secondFlexibleCol,"Column is not dragable");
	}
	
	/**
	 * Method Description (testCase:0428):Verify that you are able to click on any column title. The list panel should sort in order by the column.  
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
		public void tc0428_SortByColumn(){
		    waitUntilElementIsClickable(pageLib.getnameLoc());
		    pageLib.getnameLoc().click();
		    waitUntilElementIsClickable(pageLib.getsymbolLoc());
			pageLib.getsymbolLoc().click();
			waitUntilVisibilityOfElement();
			waitUntilVisibilityOfAllElements(pageLib.getsymbolList());
			List<WebElement> li=pageLib.getsymbolList();
			List<String> sortedListText=new ArrayList<String>();
			for(int i=0;i<li.size()-1;i++) {
				String listText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",li.get(i));
			     sortedListText.add(listText);
			 }
			List<String> listText=new ArrayList<String>();
			listText.addAll(sortedListText);
			Collections.sort(sortedListText);
			System.out.println("actual array "+listText);
			System.out.println("Expected array "+sortedListText);
			Assert.assertEquals(listText, sortedListText," not matched");
		}
		
		/**
		 * Method Description (testCase:0429):Click on the same column title again. Is the sort order reversed?
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
		public void tc0429_SortInDesc(){
			waitUntilElementIsClickable(pageLib.getsymbolColumn());
			pageLib.getsymbolColumn().click();
			logger.info(pageLib.getsymbolColumn().getText()+" clicked");
			waitUntilVisibilityOfElement();
			Utility.waitUntilVisibilityOfAllElements(pageLib.getsymbolList());
		    List<WebElement> li=pageLib.getsymbolList();
			List<String> sortedListText=new ArrayList<String>();
			for(int i=0;i<li.size()-1;i++) {
			 String listText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",li.get(i));	
			 sortedListText.add(listText);
			}
			List<String> listText=new ArrayList<String>();
			listText.addAll(sortedListText);
			Comparator<String> cmp=Collections.reverseOrder();
			Collections.sort(sortedListText,cmp);
			System.out.println("Actual:"+listText);
			System.out.println("Expected:"+sortedListText);
			Assert.assertEquals(listText, sortedListText," not matched");
			pageLib.getsymbolLoc().click();
		}
	
		/**
		 * Method Description (testCase:0430):In the header of the TYPE column, there is a little black arrow button. Press that button, and verify that the NAME and TYPE columns are hidden.
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	  public void tc0430_ValidateBlackArrow(){
	  waitUntilElementIsClickable(pageLib.getBlackArrow());
	  pageLib.getBlackArrow().click();
	  logger.info("clicked on "+pageLib.getBlackArrow().getAttribute("titletooltip"));
	  List<WebElement> columnHeaders=pageLib.getColumnNamesAfter();
	  for(int i=0;i<columnHeaders.size();i++){
		  if(columnHeaders.get(i).getAttribute("style").contains("display: none")){
			  Assert.assertFalse(columnHeaders.get(i).isDisplayed(), "Are not hidden");
			  logger.info(pageLib.getColumnNames().get(i).getText()+"  is present");
			  }
		 }
	}
	
	/**
	 * Method Description (testCase:0431):The black arrow button should now be on the "Symbol" column. Click it again, and see the NAME and TYPE fields both re-expand.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0431_ReexpandNameAndTypeColumn(){
		waitUntilElementIsClickable(pageLib.getSymbolBlackArrow());
		pageLib.getSymbolBlackArrow().click();
		logger.info("clicked on "+pageLib.getSymbolBlackArrow().getAttribute("titletooltip"));
		List<WebElement> columnHeaders=pageLib.getColumnNamesAfter();
		for(int i=0;i<columnHeaders.size();i++){
			 if(columnHeaders.get(i).getAttribute("style").contains("display: block")){
				  Assert.assertTrue(columnHeaders.get(i).isDisplayed(), "Are not displayed");
				  logger.info(pageLib.getColumnNames().get(i).getText()+"  is present");
			  }	 
		}
	}
	
	/**
	 * Method Description (testCase:432):Verify a lock appears when clicking on a column title. Is the number within the lock "1"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0432_VerifyLockWhenColumnSelected(){
	   waitUntilElementIsClickable(pageLib.getnameLoc());
	   pageLib.getnameLoc().click(); 
	   waitUntilElementIsClickable(pageLib.getsymbolLoc());
	   pageLib.getsymbolLoc().click();
	   waitUntilElementisVisible(pageLib.getunLockSymbol());
	   Assert.assertTrue(pageLib.getunLockSymbol().isDisplayed(),"lock not appeared");
	   Assert.assertEquals(pageLib.getunLockSymbol().getText(), "1","No not appeared");
	}
	
	/**
	 * Method Description (testCase:0433):Click on the lock. Does the lock symbol change from being unlocked to locked?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0433_ChangeToLockedAndUnlockedState(){
	  Assert.assertTrue(pageLib.getunLockSymbol().isDisplayed());
	  pageLib.getunLockSymbol().click();
	  waitUntilVisibilityOfElement();
	  waitUntilElementisVisible(pageLib.getunLockSymbol());
	  Assert.assertTrue(pageLib.getunLockSymbol().getAttribute("class").contains("headerLocked"), "Changed to locked status");
	}
	
	/**
	 * Method Description (testCase:0434):Now click on another column title. A second lock should appear with the number 2 within it. Is the list panel sorted correctly according to your sort order? You can lock up to as many columns as are available. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0434_VerifySecondColumnLock(){
	  Assert.assertTrue(pageLib.getunLockSymbol().getAttribute("class").contains("headerLocked"), "Changed to locked status");	
	  pageLib.getnameLoc().click();
	  waitUntilVisibilityOfElement();
	  waitUntilElementisVisible(pageLib.getnameLockSymbol());
	  Assert.assertTrue(pageLib.getnameLockSymbol().isDisplayed(),"lock not appeared");
	  Assert.assertEquals(pageLib.getnameLockSymbol().getText(), "2","No not appeared");
	  logger.info(pageLib.getnameLoc().getText()+" clicked"); 
	  
	  //verify sorted list
	  List<WebElement> li=pageLib.getTickerNameList();
	  List<String> sortedListText=new ArrayList<String>();
		for(int i=0;i<li.size()-1;i++) {
			String listText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",li.get(i));
		     sortedListText.add(listText);
		 }
		List<String> listText=new ArrayList<String>();
		listText.addAll(sortedListText);
		Collections.sort(sortedListText);
		System.out.println("actual array "+listText);
		System.out.println("Expected array "+sortedListText);
		Assert.assertEquals(listText, sortedListText," not matched");
	}
	
	/**
	 * Method Description (testCase:0435):Unlock the original locked column title and click on another column title. The original column should no longer have a lock. Any locked columns should move up in order of sort (3 will become 2, etc.) with the newest column sorted last. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0435_VerifyThirdColumnLock(){
		Assert.assertTrue(pageLib.getunLockSymbol().getAttribute("class").contains("headerLocked"), "Changed to locked status");
		pageLib.getunLockSymbol().click();
		Assert.assertTrue(pageLib.getunLockSymbol().getAttribute("class").contains("headerUnlocked"), "Changed to unlocked status");
		waitUntilElementIsClickable(pageLib.getseventhcolumn());
		pageLib.getseventhcolumn().click();
		waitUntilVisibilityOfElement();
		Assert.assertFalse(pageLib.getunLockSymbol().getAttribute("class").contains("headerLocked"),"lock appeared");
	}
	
	/**
	 * Method Description (testCase:0441):Click on any row with your mouse. Do this several times on different rows, each time on a different place on the row. Verify the orange highlight follows your choices. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public  void tc0441_ValidateHighlightedRows(){
    	waitUntilElementisVisible(pageLib.getitemNum());
    	pageLib.getlistViewButton().click();
    	List<WebElement> symbolList=pageLib.getTickerNameList();
		for(int i=0;i<symbolList.size()-1;i++){
			symbolList.get(i).click();
			logger.info("clicked on "+symbolList.get(i).getText());
			if(symbolList.get(i).getText().equals(pageLib.getChartSymbol().getText())){
				Utility.verifyBackgroundColor(pageLib.getSelectedRow(), "Yellow");
			}else{
		   	Utility.verifyBackgroundColor(pageLib.getSelectedRow(), "Orange");
		  }
		}
    }
    
    /**
	 * Method Description (testCase:0442):Type in a symbol from your list into the SEARCH field at the top-left of the TOOL screen. Verify the highlight once again follows the searched-for item.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
   public void tc0442_VerifyChartedTickerHighlighted(){
	   String symbol=pageLib.getselectedStock().getText();
	   waitUntilElementIsClickable(pageLib.getSymbolEntryField());
	   pageLib.getSymbolEntryField().clear();
	   pageLib.getSymbolEntryField().sendKeys(symbol);
	   Actions actions =new Actions(driver);
	   actions.sendKeys(Keys.ENTER).build().perform();
	   waitUntilVisibilityOfElement();
	   waitUntilElementisVisible(pageLib.getChartSymbol());
	   waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), symbol);
	   Utility.verifyBackgroundColor(pageLib.getlistPanelFirstRow(), "Yellow");
   }
    
   /**
	 * Method Description (testCase:0443):Click on the trash can. Is the item deleted from the list?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0443_ValidateTrashIcon(){
    	waitUntilElementisVisible(pageLib.getitemNum());
    	String selectedStock=pageLib.getselectedStock().getText();
    	pageLib.getselectedStock().click();
    	waitUntilElementisVisible(pageLib.getThrashCan());
    	pageLib.getThrashCan().click();
    	logger.info("symbol got deleted");
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.getselectedStock());
    	Assert.assertNotEquals(pageLib.getselectedStock().getText(), selectedStock, "not deleted");
    }
    
    /**
	 * Method Description (testCase:0444):Right click on a list item. Verify the options appear: "Delete", "Flag", "View Comparison Chart", and "Set Alert".
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0444_ValidateSymbolOptions(){
    	waitUntilVisibilityOfElement();
    	waitUntilElementisVisible(pageLib.getitemNum());
    	waitUntilElementIsClickable(pageLib.getSecondStock());
    	pageLib.getSecondStock().click();
    	String optionsList[]={"Delete","Flag","View Comparison Chart","Set Alert"};
    	Actions action=new Actions(driver);
    	action.contextClick(pageLib.getSecondStock()).build().perform();
    	waitUntilElementisVisible(pageLib.getRowRightClickWindow());
    	action.moveToElement(pageLib.getRowRightClickWindow()).build().perform();
    	List<WebElement> rightClickOptions=pageLib.getRightClickOptions();
    	for(int i=0;i<optionsList.length;i++){
    		Assert.assertEquals(rightClickOptions.get(i).getText().trim(), optionsList[i]," not matched");
    		logger.info(rightClickOptions.get(i).getText()+" is present");
    	}
    }
    
    /**
	 * Method Description (testCase:0445):Click on DELETE from the drop-down menu. Verify the item is no longer within the list. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0445_ValidateDeleteOption(){
    	waitUntilElementisVisible(pageLib.getitemNum());
    	pageLib.getSecondStock().click();
    	Actions action=new Actions(driver);
    	action.contextClick(pageLib.getSecondStock()).build().perform();
    	waitUntilElementisVisible(pageLib.getRowRightClickWindow());
    	action.moveToElement(pageLib.getRowRightClickWindow()).build().perform();
    	pageLib.getdeleteOption().click();
    	logger.info("symbol got deleted");
    	waitUntilElementisVisible(pageLib.getDeleteMsg()); 
    	Assert.assertTrue(pageLib.getDeleteMsg().getText().contains("removed"), "Symbol not deleted");
    }
    
    /**
	 * Method Description (testCase:0446):Click on another row, and hit the DELETE key on the keyboard. Verify the stock is deleted.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0446_ValidateDeleteRowByDeleteKey(){
    	waitUntilElementisVisible(pageLib.getitemNum());
    	waitUntilVisibilityOfElement();
    	waitUntilVisibilityOfElement(); 
    	pageLib.getselectedStock().click();
    	Actions action=new Actions(driver);
 	    action.sendKeys(Keys.DELETE).build().perform();
 	    logger.info("symbol got deleted");
   	    waitUntilElementisVisible(pageLib.getDeleteMsg()); 
   	    Assert.assertTrue(pageLib.getDeleteMsg().getText().contains("removed"), "Symbol not deleted");
    }
    
    /**
	 * Method Description (testCase:0447):Click on the Global Flag icon at the far left of the row. Verify the stock is flagged in List Manager, and appears in the Flagged Symbols' list. Also verify that it is flagged at the top-left of the Tool screen, right next to the Company Name.  
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0447_ValidateFlagSymbol(){
    	Utility.ValidateItemsOfList();
    	waitUntilVisibilityOfElement();
    	Utility.waitUntilElementisVisible(pageLib.getselectedStock());
    	String selectedStock=pageLib.getselectedStock().getText();
    	((JavascriptExecutor) driver).executeScript("arguments[0].click();",pageLib.getselectedStock());
    	WebElement flagElement=pageLib.getFirstFlagELement();
    	if(!(flagElement.getAttribute("class").contains("FlagOrangeCell"))){
    		flagElement.click();
    		logger.info("flagged a symbol");
    		waitUntilVisibilityOfElement();
    		Assert.assertTrue(flagElement.getAttribute("class").contains("FlagOrangeCell"), "symbol not flagged");
    		if(!(pageLib.getSmartList().getAttribute("class").contains("down"))){
  			  pageLib.getSmartList().click();
  		     logger.info("selected "+pageLib.getSmartList().getText());
             } 
    		pageLib.getFlaggedSymbolsList().click();
    		logger.info("selected "+pageLib.getFlaggedSymbolsList().getText());
    		Assert.assertEquals(pageLib.getselectedStock().getText(),selectedStock, "ticker not prsent in flagged symbols  list");
    		pageLib.getSmartList().click();
    	}else{
    		logger.info("It is already flagged");
    	}
    }
    
    /**
	 * Method Description (testCase:0447_1):Also verify that it is flagged at the top-left of the Tool screen, right next to the Company Name.   
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0447_1ValidateFlaggedSymbols(){
    	Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
        if(!(pageLib.getSmartList().getAttribute("class").contains("down"))){
			  pageLib.getSmartList().click();
		   logger.info("selected "+pageLib.getSmartList().getText());
        } 
		pageLib.getFlaggedSymbolsList().click();
		logger.info("selected "+pageLib.getFlaggedSymbolsList().getText());
		waitUntilElementisVisible(pageLib.getWaitFlaggedList());
		pageLib.getselectedStock().click();
		Actions action=new Actions(driver);
		action.doubleClick(pageLib.getselectedStock()).build().perform();
		waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), pageLib.getselectedStock().getText());
		Assert.assertTrue(pageLib.getFlagSymbol().getAttribute("class").contains("flagActive"), "It is not  flagged");
	 }
    
    /**
	 * Method Description (testCase:0448):Click View Comparison Chart. The Comparison Chart window should appear with the selected item displayed.  
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0448_ValidateViewComparisonChart(){
    	waitUntilElementisVisible(pageLib.getitemNum());
    	Utility.ValidateItemsOfList();
    	String selectedStock=pageLib.getselectedStock().getText();
    	pageLib.getselectedStock().click();
    	Actions action=new Actions(driver);
    	action.contextClick(pageLib.getselectedStock()).build().perform();
    	waitUntilElementisVisible(pageLib.getRowRightClickWindow());
    	action.moveToElement(pageLib.getRowRightClickWindow()).build().perform();
    	pageLib.getViewComparisonChart().click();
    	Utility.windowHandles();
    	waitUntilVisibilityOfElement();
    	waitUntilVisibilityOfElement();
    	logger.info(driver.getCurrentUrl());
    	waitUntilElementisVisible(pageLib.getcomparisonChartSymbol());
    	Assert.assertEquals(pageLib.getcomparisonChartSymbol().getText(), selectedStock, "comparison chart is not opened for selected symbol");
    	driver.close();
    	Utility.windowHandles();
    }
    
    /**
	 * Method Description (testCase:0449):Click Set Alert. Verify the Set Price Alert window appears. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0449_ValidateSetAlert(){
      waitUntilElementisVisible(pageLib.getitemNum());
      pageLib.getselectedStock().click();
      Actions action=new Actions(driver);
  	  action.contextClick(pageLib.getselectedStock()).build().perform();
  	  waitUntilElementisVisible(pageLib.getRowRightClickWindow());
  	  action.moveToElement(pageLib.getRowRightClickWindow()).build().perform();
  	  pageLib.getsetAlertOption().click();
  	  Utility.windowHandles();
  	  waitUntilElementisVisible(pageLib.getsetAlertWindow());
  	  Assert.assertEquals(pageLib.getsetAlertWindow().getText(), "Set Price Alert"," price alert window not appear ");
  	  pageLib.getCloseAlert().click();
    }
    
    /**
	 * Method Description (testCase:0450):Note the periodicity of whichever chart is currently above the List Manager. Now go to the List Panel and double-click on an item within the list. Verify the chart appears for the selected item. Also verify that it is using the Periodicity (DAILY | WEEKLY | MONTHLY) that was already selected on the toolbar at the top of the screen.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0450_VerifyChartAppearsForSelectedTicker(){
      waitUntilElementIsClickable(pageLib.getdailyButton());
      pageLib.getdailyButton().click();
      waitUntilVisibilityOfElement();
      waitUntilElementisVisible(pageLib.getitemNum());
      waitUntilElementIsClickable(pageLib.getselectedStock());
      pageLib.getselectedStock().click();
      Actions action=new Actions(driver);
      action.doubleClick(pageLib.getselectedStock()).build().perform();
      waitUntilVisibilityOfElement();
      waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), pageLib.getselectedStock().getText());
      Assert.assertEquals(pageLib.getChartSymbol().getText(),pageLib.getselectedStock().getText(),"Not charted for selected symbol");
      Assert.assertTrue(pageLib.getdailyButton().getAttribute("class").contains("chartButtonActive"), "It is not using the periodicity");
    }
    
    /**
	 * Method Description (testCase:0451):Navigate the list panel using the up and down arrow keys. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0451_ListPanelNavigation(){
      waitUntilElementisVisible(pageLib.getitemNum());
      pageLib.getSecondStock().click();
      Actions action=new Actions(driver);
      logger.info("Arrow Up");
      action.sendKeys(Keys.ARROW_UP).build().perform();
      waitUntilElementIsClickable(pageLib.getselectedStock());
        if(pageLib.getselectedStock().getText().equals(pageLib.getChartSymbol().getText())){
			Utility.verifyBackgroundColor(pageLib.getSelectedRow(), "Yellow");
		 }else{
	    	Utility.verifyBackgroundColor(pageLib.getSelectedRow(), "Orange");
		   }
       logger.info("Arrow Down"); 
      action.sendKeys(Keys.ARROW_DOWN).build().perform();
      if(pageLib.getSecondStock().getText().equals(pageLib.getChartSymbol().getText())){
			Utility.verifyBackgroundColor(pageLib.getSelectedRow(), "Yellow");
		 }else{
	   	    Utility.verifyBackgroundColor(pageLib.getSelectedRow(), "Orange");
         }
      }
    
    /**
	 * Method Description (testCase:0452):Press enter on any item. Is the item displayed on the chart?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0452_LoadChartByEnter(){
	   waitUntilElementisVisible(pageLib.getitemNum());
	   pageLib.getselectedStock().click();
	   Actions action=new Actions(driver);
	   action.sendKeys(Keys.ENTER).build().perform();
	   waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), pageLib.getselectedStock().getText());
	   Assert.assertEquals(pageLib.getChartSymbol().getText(), pageLib.getselectedStock().getText());
	   logger.info("opened chart for "+pageLib.getselectedStock().getText());
    }
    
    /**
	 * Method Description (testCase:0453):Press space bar. The next item on the list should be selected from the currently selected item. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0453_LoadChartBySpaceBar(){
	   waitUntilElementisVisible(pageLib.getitemNum());
	   waitUntilVisibilityOfElement();
	   pageLib.getselectedStock().click();
	   Actions action=new Actions(driver);
	   action.doubleClick(pageLib.getselectedStock()).build().perform();
	   waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), pageLib.getselectedStock().getText());
	   logger.info("opened chart for "+pageLib.getselectedStock().getText());
	   action.sendKeys(Keys.SPACE).build().perform();
	   waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), pageLib.getSecondStock().getText());
	   Assert.assertEquals(pageLib.getChartSymbol().getText(),  pageLib.getSecondStock().getText(), "chart is not opened" );
    }
    
    /**
	 * Method Description (testCase:0454):ListPanelOption > Column Width Preference > adjust all columns width within user lists
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0454_ValidateAdjustColumnWidth(){
   	   waitUntilVisibilityOfElement();
   	   waitUntilElementIsClickable(pageLib.getlmTriangle());
   	   pageLib.getlmTriangle().click();
   	   waitUntilVisibilityOfElement();
   	   waitUntilElementisVisible(pageLib.gettoolsWindow());
   	   waitUntilElementIsClickable(pageLib.getcolumnWidthPreference());
       pageLib.getcolumnWidthPreference().click();
   	   Utility.windowHandles();
   	   waitUntilElementisVisible(pageLib.getcolumnWidthPrefWindow());
   	   List<WebElement> liRadioButtons=pageLib.getcolumnWidthButtons();
	   waitUntilElementIsClickable(liRadioButtons.get(0));
	   liRadioButtons.get(0).click();
	   waitUntilElementIsClickable(pageLib.getcolumnPrefAccept());
	   pageLib.getcolumnPrefAccept().click();
	   waitUntilVisibilityOfElement();
	   waitUntilElementisVisible(pageLib.getsymbolLoc());
	   ((JavascriptExecutor) driver).executeScript("arguments[0].style.width='50px'",pageLib.getsymbolLoc());
	   Assert.assertEquals(pageLib.getsymbolLoc().getAttribute("style"), "width: 50px;","can not change the width");
    }
    
    /**
	 * Method Description (testCase:0455):Click on an item in the list and move it up or down. Verify the item moves to the new location, but the Item Number hasn't changed yet.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0455_VerifyMovingItemUporDown() {
       List<WebElement> symbolList=pageLib.getTickerNameList();
       String tickerName=symbolList.get(1).getText();
       Actions action=new Actions(driver);
       WebElement src=pageLib.getlistPanelFirstRow();
       src.click();
       action.dragAndDropBy(src, 0, src.getLocation().getY()+300).perform();
       /*WebElement dest=pageLib.getnameLoc();
       src.click();
       action.dragAndDrop(src, dest).build().perform();
       // action.dragAndDrop(pageLib.getlistPanelFirstRow(), pageLib.getallRowsOfList().get(1)).build().perform();*/
       Assert.assertEquals(pageLib.getselectedStock().getText(), tickerName,"ticker not moved");
    }
    
    /**
	 * Method Description (testCase:0456):Right click on the "#" column header, then click "Set # Order." Verify the items below are renumbered according to their current position (so the one you moved will change). 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0456_VerifyHashOrders(){
    	pageLib.getnameLoc().click();
    	waitUntilElementIsClickable(pageLib.gethashLoc());
    	Actions action=new Actions(driver);
    	action.contextClick(pageLib.gethashLoc()).build().perform();
    	waitUntilElementisVisible(pageLib.getwaitSetOrder());
    	pageLib.getwaitSetOrder().click();
    	waitUntilVisibilityOfElement();
    	waitUntilPresenceOfAllElements("div.freezeVirtualizedPanel > div > div:nth-of-type(3)>div>span");
    	List< WebElement> hashOrder=pageLib.gethashNumberList();
    	for(int i=0;i<hashOrder.size()-1;i++){
    		int k=Integer.parseInt(hashOrder.get(i).getText());
    		Assert.assertEquals(k, i+1,"not ordered");
    	}
    }
    
    /**
	 * Method Description (testCase:0458):Go to a system (hardcoded default) list, and validate that you cannot perform the following actions on any items in the list, or on the list itself: RENAME, DELETE,  
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0458_ValidateOptionsForSystemLlist(){
    	WebElement market197IndustryLink=pageLib.getmarket197IndustryGroup();
     	String market197IndustryLinkText=market197IndustryLink.getText();
     	if(!(pageLib.getMarket197DownLink().getAttribute("class").contains("down"))){
     		market197IndustryLink.click();
	     	 logger.info("clicked on  "+market197IndustryLinkText+" link");
	     	}
     	waitUntilElementIsClickable(pageLib.get197IndustryGroups());
     	WebElement m197IndustryLink=pageLib.get197IndustryGroups();
     	String m197IndustryLinkText=m197IndustryLink.getText();
     	m197IndustryLink.click();
     	logger.info("clicked on  "+m197IndustryLinkText+" list link");
     	Actions action=new Actions(driver);
		action.moveToElement(m197IndustryLink).build().perform();
		pageLib.getMsDropdown().click();
		logger.info("clicked on dropdown "+pageLib.getMsDropdown().getAttribute("class"));
		waitUntilElementisVisible(pageLib.getWaitDropdownOptions());
		action.moveToElement(pageLib.getWaitDropdownOptions()).build().perform();
		List<WebElement> msListDropDown=pageLib.getMsDropDownElements();
		for(int i=0;i<msListDropDown.size();i++){
			  Assert.assertNotEquals(msListDropDown.get(i).getText().trim(),"RENAME","WE can rename a list");
			  Assert.assertNotEquals(msListDropDown.get(i).getText().trim(),"DELETE","We can delete a list");
			 }
		m197IndustryLink.click();
    }
    
    /**
	 * Method Description (testCase:0458_1):validate that you cannot perform the following actions change SORT # ORDER. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0458_ValidateSetOrderForSystemList(){
    	waitUntilTextTobePresentInElement(pageLib.getCurrentListName(), pageLib.get197IndustryGroups().getText());
    	waitUntilElementisVisible(pageLib.gethashLoc());
    	Actions action=new Actions(driver);
    	action.contextClick(pageLib.gethashLoc()).build().perform();
    	waitUntilElementisVisible(pageLib.getwaitSetOrder());
    	Assert.assertFalse(pageLib.getwaitSetOrder().isEnabled(),"Set order is enabled");
    }
    
    /**
	 * Method Description (testCase:0463):Highlight a ticker in the List, then try to drag it to parts of the screen that cannot accept it. Verify the cursor turns into a circle-and-slash "Do Not Enter" symbol. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0463_VerifyDragTickerToUnAllowedPlace(){
    	 Utility.ValidateItemsOfList();
    	 WebElement firstRow=pageLib.getlistPanelFirstRow();
    	 waitUntilElementIsClickable(firstRow);
    	 pageLib.getselectedStock().click();
    	 Actions action=new Actions(driver);
    	 action.dragAndDropBy(firstRow, 0, -200).build().perform();
    }
    
    /**
	 * Method Description (testCase:0360):if some tickers are invalid, they generate NOT FOUND message in their rows. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
    public void tc0468_ValidateForInValidTickers(){
    	 pageLib.getlistViewButton().click();
    	 waitUntilVisibilityOfElement();
    	 waitUntilVisibilityOfElement();
    	// waitUntilElementIsClickable(pageLib.getlpInputSymbolBox());
    	 ((JavascriptExecutor) driver).executeScript("arguments[0].type ='text';",pageLib.getlpInputSymbolBox(),"john");
    	// pageLib.getlpInputSymbolBox().sendKeys("john");
    	 Actions action=new Actions(driver);
    	 action.sendKeys(Keys.ENTER).build().perform();
    	 waitUntilVisibilityOfElement();
    	 Assert.assertFalse(pageLib.getinvalidSymbolError().isDisplayed(), "Error not dislplayed");
    }
   
   
   
}
   
