package listManager;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import static genericLib.Utility.*;

public class BrowseAndTrackLists {
	
	ListManager2Lib pageLib=PageFactory.initElements(driver, ListManager2Lib.class);
	   
	   /**
		 * Method Description (testCase:0469):Click on the "Browse Lists" button. Verify the Browse Lists window appears. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0469_ValidateBrowseListButton(){
		   pageLib.getBrowseButton().click();
		   logger.info("selected button "+pageLib.getBrowseButton().getText());
		   windowHandles();
		   waitUntilElementisVisible(pageLib.getBrowseListWindow());
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   logger.info("navaigated to "+pageLib.getBrowseListWindow().getText()+"window");
	   }
	   
	   /**
		 * Method Description (testCase:0470):SHARING: Make sure the three Sharing radio buttons work ("All," "Public," "Private"). When you click on each they should properly filter the list results to the right. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0470_ValidateRadioButtons(){
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   pageLib.getSharedWithAllButton().click();
		   logger.info("selected All radio button"+pageLib.getSharedWithAllButton().getAttribute("name"));
		   waitUntilVisibilityOfElement();
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   waitUntilVisibilityOfElement();
		   String totalList=pageLib.getNoOfLists().getText();
		   Assert.assertEquals(pageLib.getNoOfLists().getText().trim(),totalList,"not filtrerd for ALL radio button");
		}
	   
	   /**
		 * Method Description (testCase:0470_1):SHARING: Make sure the three Sharing radio buttons work ("All," "Public," "Private"). When you click on each they should properly filter the list results to the right. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0470_ValidatePublicShareRadioButton(){
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   pageLib.getSharedWithPublic().click();
		   logger.info("selected public radio button"+pageLib.getSharedWithPublic().getAttribute("name"));
		   waitUntilVisibilityOfElement();
		   waitUntilVisibilityOfElement();
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   String totalList=pageLib.getNoOfLists().getText();
		   //waitUntilPresenceOfAllElements("div#ModalPanel > div:nth-of-type(3) > div:nth-of-type(3) > table > tbody > tr > td:nth-of-type(2)");
		   Assert.assertEquals(pageLib.getNoOfLists().getText().trim(), totalList,"not filtrerd for public radio button"); 
	   }
	   
	   /**
		 * Method Description (testCase:0470_2):SHARING: Make sure the three Sharing radio buttons work ("All," "Public," "Private"). When you click on each they should properly filter the list results to the right. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0470_ValidatePrivateShareRadioButton(){
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   pageLib.getsharedWithPrivate().click();
		   logger.info("selected public radio button"+pageLib.getsharedWithPrivate().getAttribute("name"));
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   waitUntilVisibilityOfElement();
		   waitUntilVisibilityOfElement();
		   String totalList=pageLib.getNoOfLists().getText();
		   Assert.assertEquals(pageLib.getNoOfLists().getText().trim(), totalList,"not filtrerd for private radio button");   
	   }
	   
	   /**
		 * Method Description (testCase:0471):TAGS: click on several different tags, and ensure the list results window displays only those lists associated with those tags. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0471_ValidateTagCheckbox(){
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   waitUntilPresenceOfAllElements(".listManagerBrowseTags");
		   List<WebElement> tagsList=pageLib.getAllTags();
		   String tagName= tagsList.get(0).getText();
		   tagsList.get(0).click();
		   logger.info("checkbox selected "+tagsList.get(0).getText());
		   waitUntilVisibilityOfElement();
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   //waitUntilPresenceOfAllElements("div#ModalPanel > div:nth-of-type(3) > div:nth-of-type(3) > table > tbody > tr > td:nth-of-type(2)");
		   String sharedList=pageLib.getSharedList().getText();
		   pageLib.getSharedList().click();
		   logger.info("clicked on "+sharedList);
		   windowHandles();
		   waitUntilElementisVisible(pageLib.getCommunityActivity());
		   List<WebElement> appliedTagsList=pageLib.getAppliedTags();
		   int listSize=appliedTagsList.size();
		   int index=0;
		   for(index=0;index<listSize;index++) {
			   if(appliedTagsList.get(index).getText().equals(tagName)) {
				   logger.info("Filtered for applied tags");
				   break;
			   }
		      if(index==listSize) {
			   Assert.fail("Not filtered for applied tags");
		      }
		   }
		   pageLib.getCloseButton().click();
	   }
	   
	   /**
		 * Method Description (testCase:0471):TAGS: click on several different tags, and ensure the list results window displays only those lists associated with those tags. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0471_ValidateTagsCheckbox(){
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   waitUntilPresenceOfAllElements(".listManagerBrowseTags");
		   List<WebElement> tagsList=pageLib.getAllTags();
		   String tagName1= tagsList.get(0).getText();
		   String tagName2=tagsList.get(1).getText();
		   tagsList.get(1).click();
		   logger.info("checkbox selected "+tagsList.get(1).getText());
		   waitUntilVisibilityOfElement();
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   //waitUntilPresenceOfAllElements("div#ModalPanel > div:nth-of-type(3) > div:nth-of-type(3) > table > tbody > tr > td:nth-of-type(2)");
		   String sharedList=pageLib.getsecondSharedList().getText();
		   pageLib.getsecondSharedList().click();
		   logger.info("clicked on "+sharedList);
		   windowHandles();
		   waitUntilElementisVisible(pageLib.getCommunityActivity());
		   List<WebElement> appliedTagsList=pageLib.getAppliedTags();
		   int listSize=appliedTagsList.size();
		   int index=0;
		   for(index=0;index<listSize;index++) {
			   if((appliedTagsList.get(index).getText().equals(tagName1))||(appliedTagsList.get(index).getText().equals(tagName2))) {
				   logger.info("Filtered for applied tags");
				   break;
			   }
		      if(index==listSize) {
			   Assert.fail("Not filtered for applied tags");
		      }
		   }
			   pageLib.getCloseButton().click();  
		}
	   
	   /**
		 * Method Description (testCase:0472):Click CLEAR, and ensure that all the tags you previously selected are now unselected, and that you once again see the whole list. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0472_ValidateClear(){
		  Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared"); 
		  List<WebElement> tagsList=pageLib.getAllTags();
		  String clearButton=pageLib.getclearButton().getText();
		  pageLib.getclearButton().click();
		  logger.info("clicked on "+clearButton);
		  waitUntilVisibilityOfElement();
		  Assert.assertFalse(tagsList.get(0).isSelected(), "Tags not cleared");
		  Assert.assertFalse(tagsList.get(1).isSelected(), "Tags not cleared");
		  waitUntilVisibilityOfElement();
		  waitUntilVisibilityOfElement();
		  waitUntilElementisVisible(pageLib.getNoOfLists());
		  String totalList=pageLib.getNoOfLists().getText();
		  //waitUntilPresenceOfAllElements("div#ModalPanel > div:nth-of-type(3) > div:nth-of-type(3) > table > tbody > tr > td:nth-of-type(2)");
		  Assert.assertEquals(pageLib.getNoOfLists().getText().trim(), totalList," not matched");
	    }
	     
	   /**
		 * Method Description (testCase:0474):UPDATED WITHIN LAST: Select the radio buttons for "All," "Day," "Week," "Month," and "Year," and ensure the list results to the right are filtered properly by each of them. When done, click back to "All." 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0474_ValidateUpdatedWithinLastDay(){
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   List<WebElement> updatedWithinRadio=pageLib.getupdatedWithInRadio();
		   updatedWithinRadio.get(0).click();
		   waitUntilVisibilityOfElement();
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   String totalList=pageLib.getNoOfLists().getText();
		   Assert.assertEquals(pageLib.getNoOfLists().getText().trim(), totalList," not matched");
		   updatedWithinRadio.get(1).click();
		   waitUntilVisibilityOfElement();
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   String totalList1=pageLib.getNoOfLists().getText();
		   Assert.assertEquals(pageLib.getNoOfLists().getText().trim(), totalList1," not matched");
		   updatedWithinRadio.get(2).click();
		   waitUntilVisibilityOfElement();
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   String totalList2=pageLib.getNoOfLists().getText();
		   Assert.assertEquals(pageLib.getNoOfLists().getText().trim(), totalList2," not matched");
		   updatedWithinRadio.get(3).click();
		   waitUntilVisibilityOfElement();
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   String totalList3=pageLib.getNoOfLists().getText();
		   Assert.assertEquals(pageLib.getNoOfLists().getText().trim(),totalList3," not matched");
		   waitUntilElementIsClickable(pageLib.getupdatedWithinAll());
		   pageLib.getupdatedWithinAll().click();
		   waitUntilVisibilityOfElement();
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   String totalList4=pageLib.getNoOfLists().getText();
		   Assert.assertEquals(pageLib.getNoOfLists().getText().trim(),totalList4," not matched");
	   }
	   
	   /**
		 * Method Description (testCase:0475):KEYWORD, TAG, OR AUTHOR: Using the list to the right as a guide, try typing in different Keywords, Tags, and Authors, making sure that the list gets filtered correctly each time. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0475_ValidateKeywordTagAuthorFilter(){
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   waitUntilElementIsClickable(pageLib.getauthorEntryField());
		   pageLib.getauthorEntryField().sendKeys("john");
		   waitUntilVisibilityOfElement();
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   //waitUntilPresenceOfAllElements("div#ModalPanel > div:nth-of-type(3) > div:nth-of-type(3) > table > tbody > tr > td:nth-of-type(2)");
		   List<WebElement> authorList=pageLib.getAuthorRow();
		   for(int i=0;i<authorList.size();i++){
			   Assert.assertEquals(authorList.get(i).getText().trim(), "john", "Not filtered");
		   }
	   }
	   
	   /**
		 * Method Description (testCase:0476):Try typing in the same text with a mix of upper and lowercase, and verify that the case doesn't matter at all to the results.  
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0476_ValidateKeywordTagAuthorFilter(){
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   waitUntilElementIsClickable(pageLib.getauthorEntryField());
		   pageLib.getauthorEntryField().sendKeys("JoHn");
		   waitUntilVisibilityOfElement();
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   //waitUntilPresenceOfAllElements("div#ModalPanel > div:nth-of-type(3) > div:nth-of-type(3) > table > tbody > tr > td:nth-of-type(2)");
		   List<WebElement> authorList=pageLib.getAuthorRow();
		   for(int i=0;i<authorList.size();i++){
			   Assert.assertEquals(authorList.get(i).getText().trim(), "john", "Not filtered");
		   }
	   }
	   
	   /**
		 * Method Description (testCase:0477):Delete the text from the KEYWORD, TAG, OR AUTHOR field, and ensure the list results once again displays all of the lists.  
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0477_ValidateKeywordTagAuthorFilter(){
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   waitUntilElementIsClickable(pageLib.getauthorEntryField());
		   pageLib.getauthorEntryField().clear();
		   Actions action=new Actions(driver);
		   action.sendKeys(Keys.ENTER).build().perform();
		   waitUntilVisibilityOfElement();
		   waitUntilElementisVisible(pageLib.getNoOfLists());
		   waitUntilVisibilityOfElement();
		   String totalList=pageLib.getNoOfLists().getText();
		   //waitUntilPresenceOfAllElements("div#ModalPanel > div> div:nth-of-type(3) > table > tbody > tr > td:nth-of-type(2)");
		   Assert.assertEquals(pageLib.getNoOfLists().getText().trim(), totalList, "filter not removed");
	   }
	   
	   /**
		 * Method Description (testCase:0478):After you select a bunch of filter options, close the BROWSE LISTS window. Then click the BROWSE LISTS button to open the window again. Your previously selected filter settings should be saved. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0478_ValidatePreviouslySelectedFilters(){
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   List<WebElement> tagsList=pageLib.getAllTags();
		   tagsList.get(0).click();
		   tagsList.get(1).click();
		   List<WebElement> updatedWithinLast=pageLib.getupdatedWithInRadio();
		   updatedWithinLast.get(3).click();
		   waitUntilVisibilityOfElement();
		   pageLib.getbrowseListWindowClose().click();
		   waitUntilElementIsClickable(pageLib.getBrowseButton());
		   pageLib.getBrowseButton().click();
		   Assert.assertTrue(tagsList.get(0).isSelected(), "Filter removed");
		   Assert.assertTrue(tagsList.get(1).isSelected(), "Filter removed");
		   Assert.assertTrue(updatedWithinLast.get(3).isSelected(), "Filter removed");
		   pageLib.getclearButton().click();
		   pageLib.getupdatedWithinAll().click();
		   pageLib.getbrowseListWindowClose().click();
	   }
	   
	   /**
		 * Method Description (testCase:0479):Click on BROWSE LISTS, then select a shared list created by you or someone else in QA at WON. Verify that the COMMUNITY ACTIVITY window for that list appears. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0479_ValidatetheListSharedWithUs(){
		   pageLib.getBrowseButton().click();
		   logger.info("selected button "+pageLib.getBrowseButton().getText());
		   windowHandles();
		   waitUntilElementisVisible(pageLib.getBrowseListWindow());
		   logger.info("switched to "+pageLib.getBrowseListWindow().getText());
		   waitUntilVisibilityOfElement();
		   waitUntilElementIsClickable( pageLib.getSharedList());
		   pageLib.getSharedList().click();
		   logger.info("clicked on "+pageLib.getSharedList().getText());
		   waitUntilElementisVisible(pageLib.getCommunityActivity());
		   Assert.assertEquals(pageLib.getCommunityActivity().getText().trim(), "Community Activity", "Window not opened");
	   }
	   
	   /**
		 * Method Description (testCase:480):Verify that the contents of this window match prod, and that the following features are present: list name in title bar of window, VIEW LIST and TRACK/UNTRACK LIST buttons, star RATINGS (along with the number of ratings printed next to them), TRACKED BY ** MEMBERS field, AUTHOR field, LAST UPDATED field with date and time, NUMBER OF ITEMS field, DESCRIPTION field, TAGS section, COMMENT window, and ADD A COMMENT window, and a greyed out SUBMIT button. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0480_VerifyAllContentsOfCommunity(){
		   Assert.assertEquals(pageLib.getCommunityActivity().getText().trim(), "Community Activity", "Window not opened");
		   Assert.assertTrue(pageLib.getcommunitWindowTop().isDisplayed(), "list Name not present");
		   Assert.assertTrue(pageLib.getViewListButton().isDisplayed(),"View List Button not dispalyed");
		   if(pageLib.getTrackButton().getAttribute("style").contains("display: none")){
			   Assert.assertTrue(pageLib.getUnTrackButton().isDisplayed(), "untrack button is not displayed");
		   }
		   else{
			   Assert.assertTrue(pageLib.getTrackButton().isDisplayed(), "track button is not present");
		   }
		   Assert.assertTrue(pageLib.getRatingName().isDisplayed(), "Rating name not displayed");
		   Assert.assertTrue(pageLib.getTrackedByLabel().isDisplayed(), "tracked by label not present");
		   Assert.assertTrue(pageLib.getAuthorLabel().isDisplayed(), "Author is not displayed");
		   Assert.assertTrue(pageLib.getLastUpdatedField().isDisplayed(), "Last updated is not displayed");
		   Assert.assertTrue(pageLib.getnoOfResults().isDisplayed(), "No of Items not dispalyed");
		   Assert.assertTrue(pageLib.getDescriptionLAbel().isDisplayed(), "Description is not present");
		   Assert.assertTrue(pageLib.getTagsSection().isDisplayed(), "tags section is not present");
		   Assert.assertTrue(pageLib.getShowComments().isDisplayed(), "Show comment section is not present");
		   Assert.assertTrue(pageLib.getAddCommentSection().isDisplayed(), "Add comments section is not displayed");
		   Assert.assertFalse(pageLib.getsubmitButton().isEnabled(), "submit button is enabled");
	   }
	   
	   /**
		 * Method Description (testCase:0481):Click the VIEW LIST button, verify the COMMUNITY ACTIVITY window closes, and you are taken to that list in List Manager. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0481_ValidateViewListButton(){
		   Assert.assertEquals(pageLib.getCommunityActivity().getText().trim(), "Community Activity", "Window not opened");
		   String sharedListName=pageLib.getcommunitWindowTop().getText();
		   pageLib.getViewListButton().click();
		   waitUntilVisibilityOfElement();
		   waitUntilTextTobePresentInElement(pageLib.getCurrentListName(), sharedListName);
		   logger.info("olpened list manager for "+sharedListName);
		}
	   
	   /**
		 * Method Description (testCase:0482):Click the TRACK and UNTRACK lists buttons and verify you can toggle between those two states. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0482_ValidateTrackUntrackButton(){
		   pageLib.getBrowseButton().click();
		   logger.info("selected button "+pageLib.getBrowseButton().getText());
		   windowHandles();
		   waitUntilElementisVisible(pageLib.getBrowseListWindow());
		   logger.info("switched to "+pageLib.getBrowseListWindow().getText());
		   String sharedList=pageLib.getSharedList().getText();
		   pageLib.getSharedList().click();
		   logger.info("clicked on "+sharedList);
		   waitUntilElementisVisible(pageLib.getCommunityActivity());
		   if(!(pageLib.getTrackButton().getAttribute("style").contains("display: none"))){
			 pageLib.getTrackButton().click();
			 waitUntilElementisVisible(pageLib.getUnTrackButton());
			 Assert.assertTrue(pageLib.getUnTrackButton().isDisplayed(), "untrack button is not displayed");
			 logger.info("Toggle to"+pageLib.getUnTrackButton().getText()+" button");
		   }
		   else{
			   pageLib.getUnTrackButton().click();
			   waitUntilElementisVisible(pageLib.getTrackButton());
			   Assert.assertTrue(pageLib.getTrackButton().isDisplayed(), "track button is not present");
			   logger.info("Toggle to"+pageLib.getUnTrackButton().getText()+" button");
		   }
	    }
	   
	   /**
		 * Method Description (testCase:0483):Select a RATING by clicking on one of the stars. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0483_ValidateRatings(){
		   Assert.assertEquals(pageLib.getCommunityActivity().getText().trim(), "Community Activity", "Window not opened");
		   waitUntilElementIsClickable(pageLib.getRatingStars());
		   pageLib.getRatingStars().click();
		   Assert.assertTrue(pageLib.getRatingStars().getAttribute("class").contains("screen_darkbigRedStar"), "rating not selected");
		   logger.info("Ratings selected");
	   }
	   
	   /**
		 * Method Description (testCase:0484):Click on the AUTHOR's name (which should be hyperlinked), and verify you are taken to a MarketSmith community web page for that author. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0484_ValidateAuthorNameLink(){
		   Assert.assertEquals(pageLib.getCommunityActivity().getText().trim(), "Community Activity", "Window not opened");
		   waitUntilElementIsClickable(pageLib.getAuthorLink());
		   try{
		   pageLib.getAuthorLink().click();
		   windowHandles();
		   verifyPageTitle(CONSTANTS.getProperty("COMMUNITY_PAGE_TITLE"));
		   logger.info("Navigated to URL: "+driver.getCurrentUrl());
		   }finally{
		   driver.close();
		   windowHandles();
		   }
	  }
	   
	   /**
		 * Method Description (testCase:0485):Click on one of the TAGS in the TAGS section of the Community Activity window, and verify you are taken back to the BROWSE LISTS window, and that the results on the right are being filtered by that tag. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0485_ValidateTagsPresentInCommunityWindow(){
		   Assert.assertEquals(pageLib.getCommunityActivity().getText().trim(), "Community Activity", "Window not opened");
		   if(pageLib.getAppliedTags().size()!=0){
			   String tag=pageLib.getAppliedTags().get(0).getText();
			   pageLib.getAppliedTags().get(0).click();
			   waitUntilElementisVisible(pageLib.getBrowseListWindow());
			   List<WebElement> allTags=pageLib.getAllTags();
			   List<WebElement> allTagsNames=pageLib.getallTagsNames();
			   for(int i=0;i<allTagsNames.size();i++){
				   if(allTagsNames.get(i).getText().contains(tag)){
					   Assert.assertTrue(allTags.get(i).isSelected(), "Not filtered for selected tag");
					   break;
				   }
			   }
			 }else{
			   logger.info("No tags assigned");
			   pageLib.getCloseButton().click();
		   }
	   }
	   
	   /**
		 * Method Description (testCase:0486):If there are multiple comments in the COMMENTS window, make sure they are being ordered with the oldest comment on top. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0486_ValidateAddedCommentsSection(){
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   String sharedList=pageLib.getSharedList().getText();
		   pageLib.getSharedList().click();
		   logger.info("clicked on "+sharedList);
		   waitUntilElementisVisible(pageLib.getCommunityActivity()); 
		   List<WebElement> allCommentsdate=pageLib.getallCommentsDate();
		   if(allCommentsdate.size()!=0){
		   List<String> actualDates=new ArrayList<String>();
			for(int i=0;i<allCommentsdate.size();i++) {
			    	String dateText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",allCommentsdate.get(i));
					actualDates.add(dateText);
			    }
			Date[] dates1=new Date[actualDates.size()];
		    DateFormat dateFormatter=new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
		    for(int i=0;i<actualDates.size();i++){
					try {
						dates1[i]=dateFormatter.parse(actualDates.get(i).toString());
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		    }
		    List<String> dateText=new ArrayList<String>();
		    for(int i=0;i<dates1.length;i++){
		    	dateText.add((String)new SimpleDateFormat("yyyy/MM/dd HH:mm:ss",Locale.ENGLISH).format(dates1[i]));
		    }
			
			List<String> ExpDateText=new ArrayList<String>();
			ExpDateText.addAll(dateText);
			Collections.sort(ExpDateText);
			System.out.println("actual array "+dateText);
			System.out.println("Expected array "+ExpDateText);
			Assert.assertEquals(dateText, ExpDateText," not matched");
		   }else{
			   logger.info("there is no comments");
		   }
		   pageLib.getCloseButton().click();
	   }
	   
	   /**
		 * Method Description (testCase:0487):In the ADD A COMMENT window, type a single character. Verify the SUBMIT button is still greyed out, and you cannot add a comment yet. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0487_ValidateAddCommentSection(){
		   Assert.assertEquals(pageLib.getBrowseListWindow().getText(), "Browse Lists"," browse List window not appeared");
		   String sharedList=pageLib.getSharedList().getText();
		   pageLib.getSharedList().click();
		   logger.info("clicked on "+sharedList);
		   waitUntilElementisVisible(pageLib.getCommunityActivity());
		   waitUntilElementIsClickable(pageLib.getAddCommentSection());
		   pageLib.getAddCommentSection().sendKeys("a");
		   waitUntilElementisVisible(pageLib.getsubmitButton());
		   Assert.assertFalse(pageLib.getsubmitButton().isEnabled(), "Submit button is enabled");
	   }
	   
	   /**
		 * Method Description (testCase:0488):Now click a second character. With two characters, the SUBMIT button should become active.
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0488_ValidateSubmitButton(){
		   Assert.assertEquals(pageLib.getCommunityActivity().getText().trim(), "Community Activity", "Window not opened");
		   waitUntilElementIsClickable(pageLib.getAddCommentSection());
		   pageLib.getAddCommentSection().sendKeys("commentsByJimJohn");
		   waitUntilElementisVisible(pageLib.getenabledSubmit());
		   Assert.assertTrue(pageLib.getenabledSubmit().isDisplayed(), "Submit button is not enabled");
		   pageLib.getCloseButton().click();
		   pageLib.getbrowseListWindowClose();
	   }
	   
	   /**
		 * Method Description (testCase:0490):Click the BROWSE LISTS button in List Manager, then select one of the lists from the master list in order to bring up that list's "Community Activity" details page. Then click the TRACK LIST button. Verify the TRACK LIST button changes to UNTRACK LIST. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0489_TrackAList(){
		   pageLib.getBrowseButton().click();
		   logger.info("selected button "+pageLib.getBrowseButton().getText());
		   windowHandles();
		   waitUntilElementisVisible(pageLib.getBrowseListWindow());
		   logger.info("switched to "+pageLib.getBrowseListWindow().getText());
		   waitUntilVisibilityOfElement();
		   String sharedList=pageLib.getSharedList().getText();
		   pageLib.getSharedList().click();
		   logger.info("clicked on "+sharedList);
		   waitUntilElementisVisible(pageLib.getCommunityActivity());
		   if(!(pageLib.getTrackButton().getAttribute("style").contains("display: none"))){
			 pageLib.getTrackButton().click();
			 waitUntilElementisVisible(pageLib.getUnTrackButton());
			 Assert.assertTrue(pageLib.getUnTrackButton().isDisplayed(), "List is not tracked");
			 logger.info("list is tracked");
			}else{
				logger.info("list is already tracked");
			}
	   }
	   
	   /**
		 * Method Description (testCase:0490):Close the windows, and make sure the list appears under TRACKED in List Manager. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0490_ValidateTrackedList(){
		   Assert.assertTrue(pageLib.getUnTrackButton().isDisplayed(), "List is not tracked");
		   String sharedList=pageLib.getSharedList().getText();
		   pageLib.getCloseButton().click();
		   pageLib.getbrowseListWindowClose().click();
		   waitUntilElementIsClickable(pageLib.getTrackedFolder());
		   if(!(pageLib.getTrackedDownLink().getAttribute("class").contains("down"))){
			   pageLib.getTrackedFolder().click();
			   logger.info("clicked on "+pageLib.getTrackedFolder().getText());
		   }
		   waitUntilVisibilityOfElement();
		   List<WebElement> trackedLists=pageLib.getTrackedList();
		   for(int i=0;i<trackedLists.size();i++){
			   if(trackedLists.get(i).getText().equals(sharedList)){
		   Assert.assertEquals(trackedLists.get(i).getText(),sharedList,"Not present");
		    }
		  }
	   }
	   
	   /**
		 * Method Description (testCase:0491):Also make sure it has a "(T)" symbol after the name in the BROWSE LISTS window.
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0491_ValidateTSymbol(){
		  try{ 
		   pageLib.getBrowseButton().click();
		   logger.info("selected button "+pageLib.getBrowseButton().getText());
		   windowHandles();
		   waitUntilElementisVisible(pageLib.getBrowseListWindow());
		   logger.info("switched to "+pageLib.getBrowseListWindow().getText());
		   waitUntilVisibilityOfElement();
		   String sharedList=pageLib.getsecondSharedList().getText();
		   pageLib.getsecondSharedList().click();
		   logger.info("clicked on "+sharedList);
		   waitUntilElementisVisible(pageLib.getCommunityActivity());
		   if(!(pageLib.getTrackButton().getAttribute("style").contains("display: none"))){
			 pageLib.getTrackButton().click();
			 waitUntilElementisVisible(pageLib.getUnTrackButton());
			 logger.info("list is tracked");
		  }else{
			  logger.info("It is already tracked");
		  }
		   pageLib.getCloseButton().click();;
		   waitUntilVisibilityOfElement();
		   Assert.assertTrue(pageLib.getsecondSharedList().getAttribute("class").contains("ListSpanWithTSymbol"), "It does not contain T symbol");
		  }finally{  pageLib.getbrowseListWindowClose().click();
		   waitUntilVisibilityOfElement();
		  }
	   }
	   
	   /**
		 * Method Description (testCase:0492):Select one of the lists you currently have under MY LISTS. Click on the down-arrow dropdown menu and select VIEW DETAILS. On this details screen, make sure there is no TRACK LIST button. (it should not be available for personal, unshared lists). 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0492_ValidateViewDetailsOfcreatedList(){
		   waitUntilElementIsClickable(pageLib.getMyListsLink());
		   WebElement myListLink=pageLib.getMyListsLink();
		   String MyListText=pageLib.getMyListName().getText();
		   WebElement myListElements=pageLib.getMyListElements();
		   WebElement createdListLink=pageLib.getUserCreatedList();
		   if(!(myListLink.getAttribute("class").contains("down"))){
			myListLink.click();
			logger.info("clicked on "+MyListText+" folder");
		    }
			if(myListElements.getAttribute("class").contains("listExplorerItem ")){
				 createdListLink.click();
				 Actions action=new Actions(driver);
				 action.moveToElement(createdListLink).build().perform();
			     pageLib.getFirstDropdown().click();
			     waitUntilElementisVisible(pageLib.getWaitOptions());
			   //locate all options
				List<WebElement> myListDropdown=pageLib.getDropdownElements();
						 
				//clicking on view/Edit details option
				 logger.info("Clicking on option: "+myListDropdown.get(10).getText());
				 myListDropdown.get(10).click();
			     windowHandles();
			     waitUntilElementisVisible(pageLib.getViewDetailsWindow());
			     logger.info("switch to "+pageLib.getViewDetailsWindow().getText()+"  window");
			     Assert.assertFalse(pageLib.getTrackButton().isDisplayed(), "It contains Track List button");
			     pageLib.getCloseButton().click();
			}else{
				logger.info("It is folder");
			}
		}
	   
	   /**
		 * Method Description (testCase:0493):Under SMART LISTS, select the down-arrow dropdown menu. Verify the VIEW DETAILS button is greyed out, preventing you from tracking these lists. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0493_ValidateViewDetailOfSmartList(){
		   verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		   waitUntilElementIsClickable(pageLib.getSmartList());
		   if(!(pageLib.getSmartList().getAttribute("class").contains("down"))){
					pageLib.getSmartList().click();
					logger.info("selected folder "+pageLib.getSmartListLabel().getText());
			} 
		    pageLib.getRecentSymbols().click();
		    Actions action=new Actions(driver);
			action.moveToElement(pageLib.getRecentSymbols()).build().perform();
			pageLib.getDropdownRecent().click();
			waitUntilElementisVisible(pageLib.getWaitRecentOptions());
			
			//locate view details
			WebElement flaggedListViewDetail=pageLib.getflaggedSymbolsDropDownOptions().get(6);
			 
		   
			Assert.assertTrue(flaggedListViewDetail.getAttribute("class").contains("disabled"), "View Details is not disabeld");
			logger.info("View Details option is disabeld");
	   }
	    
	   /**
		 * Method Description (testCase:0495):Exit out of all windows and go back to the List Manager. Find the TRACKED folder that holds your Tracked Lists. Try moving one of the tracked lists to a different position in the folder, and verify that the list successfully moves to the new position. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public  void tc0495_ValidateDragAndDropInsideTrackedFolder(){
		   waitUntilElementIsClickable(pageLib.getTrackedFolder());
		   if(!(pageLib.getTrackedDownLink().getAttribute("class").contains("down"))){
			   pageLib.getTrackedFolder().click();
			   logger.info("clicked on "+pageLib.getTrackedFolder().getText()+" folder");
		   }
		   List<WebElement> trackedLists=pageLib.getTrackedList();
		   List<WebElement> trackedListsLoc=pageLib.gettrackedListsLoc();
		   if(trackedLists.size()>1){
			  String firstTrackedList= trackedLists.get(0).getText();
			  Actions action=new Actions(driver);
			  action.dragAndDrop(trackedListsLoc.get(0),trackedListsLoc.get(1)).build().perform();
			  waitUntilVisibilityOfElement();
			  Assert.assertEquals(trackedLists.get(1).getText(), firstTrackedList,"tracked lists are not movable");
		   }
		   else{
			   logger.info("Tracked folder is empty");
		   }
		   
	   }
	   
	   /**
		 * Method Description (testCase:0496):Select a list from the TRACKED folder, click the down-arrow dropdown menu, and select Un-Track. Verify that the list is removed from this folder.  
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0496_ValidateUntrack(){
		   waitUntilElementIsClickable(pageLib.getTrackedFolder());
		   if(!(pageLib.getTrackedDownLink().getAttribute("class").contains("down"))){
			   pageLib.getTrackedFolder().click();
			   logger.info("clicked on "+pageLib.getTrackedFolder().getText()+" folder");
		   }
		   List<WebElement> trackedLists=pageLib.getTrackedList();
		   int noOfTrackedList=trackedLists.size();
		   waitUntilElementIsClickable(pageLib.getTrackedList().get(0));
		   pageLib.getTrackedList().get(0).click();
		   Actions action=new Actions(driver);
		   action.moveToElement(pageLib.getTrackedList().get(0)).build().perform();
		   pageLib.getTrackedListDropdown().click();
		   waitUntilElementisVisible(pageLib.getTrackedListDropdownOptions());
		   pageLib.getUnTrackOption().click();
		   waitUntilVisibilityOfElement();
		   Assert.assertNotEquals(pageLib.getTrackedList().size(), noOfTrackedList,"List not deleted from the tracked folder");
	  }
	   
	   
	   /**
		 * Method Description (testCase:0497):Click on any list in List Manager. Click on the drop-down, select View Details. Click on a tag, and make sure that the Browse Lists window appears, and that only lists that share that tag show up in the results. 
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	   public void tc0497_ValidateAppliedTagsSection(){
		   waitUntilElementIsClickable(pageLib.getMyListsLink());
		   WebElement myListLink=pageLib.getMyListsLink();
		   String MyListText=pageLib.getMyListName().getText();
		   WebElement myListElements=pageLib.getMyListElements();
		   WebElement createdListLink=pageLib.getLastCreatedList();
		   if(!(myListLink.getAttribute("class").contains("down"))){
			myListLink.click();
			logger.info("clicked on "+MyListText+" folder");
		    }
			if(myListElements.getAttribute("class").contains("listExplorerItem ")){
				 createdListLink.click();
				 Actions action=new Actions(driver);
				 action.moveToElement(createdListLink).build().perform();
			     pageLib.getDropdown().click();
			     waitUntilElementisVisible(pageLib.getWaitOptions());
			     pageLib.getViewDetailsOption().click();
			     windowHandles();
			     logger.info("switch to "+pageLib.getViewDetailsWindow().getText()+"  window");
			     List<WebElement> tagList=pageLib.getAppliedTags();
			     if(tagList.size()!=0){
			    	 tagList.get(0).click();
			    	 waitUntilElementisVisible(pageLib.getBrowseListWindow());
			    	 Assert.assertTrue(pageLib.getBrowseListWindow().isDisplayed(), "Not switched to browse list window");
			    	 waitUntilVisibilityOfElement();
			    	 List<WebElement> allTags=pageLib.getAllTags();
			    	 Assert.assertTrue(allTags.get(0).isSelected(),"Is not displayed tag results");
			    	 pageLib.getclearButton().click();
			    	 pageLib.getbrowseListWindowClose().click();  
			     }
			     else{
			    	 logger.info("No tags assigned");
			         }
			   }
		   else{
				logger.info("it is folder");
			  }
		}
}
