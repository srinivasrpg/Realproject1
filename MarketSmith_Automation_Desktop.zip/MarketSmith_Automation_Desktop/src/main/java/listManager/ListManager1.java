package listManager;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import genericLib.Utility;

import static genericLib.Utility.*;
import java.util.List;


public class ListManager1 {
	ListManager1Lib pageLib=PageFactory.initElements(driver, ListManager1Lib.class);
	
	/**
	 * Method Description (testCase:0360):Verify the left panel of the list manager contains links for "My Lists", "Favorites", "Smart Lists", "Tracked", "Reports", "Markets/197 Industry Groups", and the current list you are viewing. (Favorites and Tracked appear only if a list is marked as a favorite or is being tracked) 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0360_VerifyLeftPanel(){
	    Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		WebDriverWait wait=new WebDriverWait(driver, 70);
		List<WebElement> folderList=wait.until(ExpectedConditions.visibilityOfAllElements(pageLib.getFolderlist()));
	    String listNames[]={"My Lists","Favorites","Activity Lists","Tracked","Reports","Markets/197 Industry Groups"};
	    for(int i=0;i<listNames.length;i++){
	        Assert.assertEquals(folderList.get(i).getText().trim(),listNames[i],"it is not matched");
	        logger.info(folderList.get(i).getText().trim()+" present");
	    }
  }
	
	/**
	 * Method Description (testCase:0362):Verify that above the lists are two buttons: NEW and BROWSE LISTS.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0362_Verify2ButtonsAboveList(){
		 List<WebElement> topButtons=pageLib.getNewAndBrowseButtons();
		 String topButtonsArray[]={"New","Browse Lists"};
		 for(int i=0;i<topButtonsArray.length;i++){
		 Assert.assertEquals(topButtons.get(i).getText(), topButtonsArray[i], "it is not matched");
		 logger.info(topButtons.get(i).getText()+"  present");
		}
	}
	
	/**
	 * Method Description (testCase:0363):Verify that when you click on a list, the title of the list appears at the top of this panel, above the two buttons.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0363_verifyListtitle(){
		//verify screen Results
		waitUntilElementIsClickable(pageLib.getScreenResultList());
		WebElement screenResults=pageLib.getScreenResultList();
		String screenResultstext=screenResults.getText();
		screenResults.click();
		logger.info("clicked on "+screenResultstext+" list");
		waitUntilTextTobePresentInElement(pageLib.getCurrentListName(), screenResultstext);
		Assert.assertEquals(pageLib.getCurrentListName().getText(), screenResultstext,"list name not appeared for screen results");
		logger.info("******************");
		
		//Verify the lists of My list folder
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		if(!(myListLink.getAttribute("class").contains("down"))){
		 myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		 }
		 if(myListElements.getAttribute("class").contains("listExplorerItem ")){		
		 WebElement createdListLink=pageLib.getUserCreatedList();
		 String createdListText=createdListLink.getText();
		 createdListLink.click();
		 logger.info("clicked on "+createdListText+" list");
		 Assert.assertEquals(pageLib.getCurrentListName().getText(), createdListText,"list name not appeared");
		 } else{
		   	 logger.info("it is folder");
		       }
	  }
	
	/**
	 * Method Description (testCase:0364):Click on various lists. Make sure the highlight follows the lists you are clicking on, and that no other list is also highlighted. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
     public void tc0364_VerifyHighLightedList(){
    	waitUntilElementIsClickable(pageLib.getMyListsLink());
 		WebElement myListLink=pageLib.getMyListsLink();
 		String MyListText=pageLib.getMyListName().getText();
 		if(!(myListLink.getAttribute("class").contains("down"))){
 		 myListLink.click();
 		 logger.info("clicked on "+MyListText+" folder");
 		 }
 		List<WebElement> allCreatedLists=pageLib.getallCreatedLists();
 		for(int i=0;i<allCreatedLists.size();i++){
 			if(allCreatedLists.get(i).getAttribute("class").contains("listExplorerItem")){
 				allCreatedLists.get(i).click();
 				Utility.verifyBackgroundColor(pageLib.gethighlightedList(), "Bright orange");
 			}
 			else{
 				logger.info("It is folder");
 			}
 		}
     }
     
     /**
 	 * Method Description (testCase:0365):Does a "down arrow" dropdown button appear to the right of the list name when hovering over any list?
 	   (testCase:0366):On a list that you created (as opposed to one that comes with MarketSmith) click on the dropdown, and verify the dropdown contains "Copy", "Rename", "Add to Favorites", "Sharing", "Delete", "Print List', "View Comparison Charts", and "View Details". 
 	 * Created By:- Mamata, Created Date:- 06/03/2016
 	 * Changes made#1:
 	**/
	public void tc0366_VerifyDropDownOfCreatedList(){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		if(!(myListLink.getAttribute("class").contains("down"))){
	     myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		 }
		 WebElement myListElements=pageLib.getMyListElements();
		 //Verify file or folder
		 if(myListElements.getAttribute("class").contains("listExplorerItem ")){
		   Actions action = new Actions(driver);
		   action.moveToElement(myListElements).build().perform();
		   //drop down is present or not
		   Assert.assertTrue(pageLib.getDropdown().isDisplayed(), "drop down button not present");
		   
		   pageLib.getDropdown().click();
		   logger.info("clicked on dropdown"+pageLib.getDropdown().getAttribute("class"));
		   waitUntilElementisVisible(pageLib.getWaitOptions());
		   action.moveToElement(pageLib.getWaitOptions()).build().perform();
		   String listNames[]={CONSTANTS.getProperty("LIST_ANALYSIS"),CONSTANTS.getProperty("PRINT_LIST"),CONSTANTS.getProperty("VIEW_COMPARISON_CHART"),CONSTANTS.getProperty("LIST_ACTIONS"),CONSTANTS.getProperty("COPY"),CONSTANTS.getProperty("ADD_TO_FAVORITES"),CONSTANTS.getProperty("SHARING"),CONSTANTS.getProperty("RENAME"),CONSTANTS.getProperty("DELETE"),CONSTANTS.getProperty("LIST_DISPLAY"),CONSTANTS.getProperty("VIEW_DETAILS")};
		   List<WebElement> myListDropdown=pageLib.getDropdownElements();
		   for(int i=0;i<listNames.length;i++){
		    Assert.assertEquals(myListDropdown.get(i).getText().trim(), listNames[i]," is not present");
		    logger.info(myListDropdown.get(i).getText()+" is present");
		   }
		 }else{
			  logger.info("it is a folder ");
			}
		}
	
	/**
	 * Method Description (testCase:0367):Then click the dropdown button on a list that comes with MarketSmith. Verify the options Rename, Sharing, and Delete do not appear for these lists, leaving "Copy", "Add to Favorites", "Print List', "View Comparison Charts", and "View Details". 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0367_verifyDropdownOfMsList(){
		WebElement m197IndustryGroup= pageLib.getMarket197IndustryGroup();
		String m197IGText=pageLib.getMarket197IGname().getText();
		if(!(m197IndustryGroup.getAttribute("class").contains("down"))){
		  m197IndustryGroup.click();
		  logger.info("clicked on "+m197IGText+"  folder");
		 }
		  WebElement m197IGlist=pageLib.getM197IndustrygroupList();
		  m197IGlist.click();
		  Actions action=new Actions(driver);
		  action.moveToElement(m197IGlist).build().perform();
		  pageLib.getMsDropdown().click();
		  logger.info("clicked on dropdown "+pageLib.getMsDropdown().getAttribute("class"));
		  waitUntilElementisVisible(pageLib.getWaitDropdownOptions());
		  action.moveToElement(pageLib.getWaitDropdownOptions()).build().perform();
		  List<WebElement> msListDropDown=pageLib.getMsDropDownElements();
		  String listElemnts[]={CONSTANTS.getProperty("LIST_ANALYSIS"),CONSTANTS.getProperty("PRINT_LIST"),CONSTANTS.getProperty("VIEW_COMPARISON_CHART"),CONSTANTS.getProperty("LIST_ACTIONS"),CONSTANTS.getProperty("COPY"),CONSTANTS.getProperty("ADD_TO_FAVORITES"),CONSTANTS.getProperty("LIST_DISPLAY"),CONSTANTS.getProperty("MS_LIST_DETAILS")};
		  for(int i=0;i<listElemnts.length;i++){
			  Assert.assertEquals(msListDropDown.get(i).getText().trim(),listElemnts[i],"text is not matched");
			  logger.info(msListDropDown.get(i).getText().trim()+" is present ");
			 }
	   }
	
	/**
	 * Method Description (testCase:0368 And 369):Click on the "New" button. Does a dropdown appear to create a new "List" or a new "Folder"?
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	 public void tc0369_CreateNewList(String listName){
		waitUntilElementIsClickable(pageLib.getNewButton());
		WebElement newButton=pageLib.getNewButton(); 
		newButton.click();
		logger.info("clicked on "+newButton.getText()+" button");
		Actions action=new Actions(driver);
		action.moveToElement(pageLib.getNewWindow()).build().perform();
		String newOptions[]={"List","Folder"};
		List<WebElement> newOptions1=pageLib.getNewOptions();
		for(int i=0;i<newOptions.length;i++){
		 //drop down contains List and folder	
		 Assert.assertEquals(newOptions1.get(i).getText(), newOptions[i]," option not present");
		 logger.info(newOptions1.get(i).getText()+" option present");
		 }
		WebElement listMenu=pageLib.getListMenu();
		logger.info("selected a menu "+listMenu.getText());
		listMenu.click();
		Utility.windowHandles();
		logger.info("switch to "+pageLib.getNewListWindow().getText()+"  window");
		waitUntilElementIsClickable(pageLib.getListNameField());
		pageLib.getListNameField().sendKeys(listName);
		logger.info(listName+" Entered");
		WebElement savebutton=pageLib.getListNamesave();
		savebutton.click();
		logger.info(listName+" list created successfully");
		waitUntilVisibilityOfElement();
		Assert.assertEquals(pageLib.getUserCreatedList().getText(), listName,"is not created");
		
		//verify list is empty
		pageLib.getUserCreatedList().click();
		Assert.assertEquals(pageLib.getListSymbols().size(),1,"symbols present");
	}
	
	 /**
	   * Method Description (testCase:0370):Click on Folder. Verify that you are able to create a new folder.
	   * Created By:- Mamata, Created Date:- 06/03/2016
	   * Changes made#1:
	   **/
	public void tc0370_CreateNewFolder(String folderName){
		waitUntilElementIsClickable(pageLib.getNewButton());
		WebElement newButton=pageLib.getNewButton(); 
		newButton.click();
		logger.info("clicked on "+newButton.getText()+" button");
		Actions action=new Actions(driver);
		action.moveToElement(pageLib.getNewWindow()).build().perform();
		WebElement folderMenu=pageLib.getFolderMenu();
		logger.info("selected "+folderMenu.getText());
		folderMenu.click();
		Utility.windowHandles();
		logger.info("switch to "+pageLib.getNewListWindow().getText()+"  window");
		waitUntilElementIsClickable(pageLib.getListNameField());
		pageLib.getListNameField().sendKeys(folderName);
		logger.info(folderName+" Entered");
		WebElement savebutton=pageLib.getListNamesave();
		savebutton.click();
		logger.info(folderName+" folder created successfully");
		if(!(pageLib.getMyListsLink().getAttribute("class").contains("down"))){
		  pageLib.getMyListsLink().click();
		 }
		  //folder is created or not
		  waitUntilElementisVisible(pageLib.getCreatedFolder());
		  Assert.assertTrue(pageLib.getCreatedFolder().isDisplayed()," is not present");
		  pageLib.getCreatedFolder().click();
		  WebElement folderstatus=pageLib.getFolderstatus();
		  //verify folder is empty
		  Assert.assertTrue(folderstatus.getCssValue("display").contains("block"),"it is not empty");
	}
	
	/**
	 * Method Description (testCase:0374):COPY any list. Verify that a new window appears to enter a name for the new list. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0374_CreateCopyOfList(){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
			myListLink.click();
			logger.info("clicked on "+MyListText+" folder");
		}
		if(myListElements.getAttribute("class").contains("listExplorerItem ")){		
		 createdListLink.click();
		 Actions action=new Actions(driver);
		 action.moveToElement(createdListLink).build().perform();
		 pageLib.getDropdown().click();
		 waitUntilElementisVisible(pageLib.getWaitOptions()); //locate all options
		 List<WebElement> myListDropdown=pageLib.getDropdownElements();
		 
		 //clicking on Copy option
		 logger.info(myListDropdown.get(4).getText()+" selecting");
		 myListDropdown.get(4).click();
		 Utility.windowHandles();
		 logger.info("switch to "+pageLib.getNewListWindow().getText()+"  window");
		 //Checks window present or not
		 Assert.assertTrue(pageLib.getNewListWindow().isDisplayed(), "window not appeared");
		 WebElement savebutton=pageLib.getListNamesave();
		 savebutton.click();
		 logger.info(pageLib.getUserCreatedList().getText()+" list copied successfully");
		 waitUntilVisibilityOfElement();
		 Assert.assertEquals(pageLib.getUserCreatedList().getText(),createdListLink.getText(),"it is not matched");
		} else{
	    	 logger.info("it is folder");
		  }
	 }
	
	/**
	 * Method Description (testCase:0373):Click CANCEL. Verify that a new list is not created.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0373_ValidateCopyOption(String listName){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
			myListLink.click();
			logger.info("clicked on "+MyListText+" folder");
		}
		if(myListElements.getAttribute("class").contains("listExplorerItem ")){		
		 createdListLink.click();
		 Actions action=new Actions(driver);
		 action.moveToElement(createdListLink).build().perform();
		 pageLib.getDropdown().click();
		 waitUntilElementisVisible(pageLib.getWaitOptions());
		 
		 //locate all options
		 List<WebElement> myListDropdown=pageLib.getDropdownElements();
		 
		 //clicking on copy option
		 logger.info("Clicking on option :"+myListDropdown.get(4).getText());
		 myListDropdown.get(4).click();
		 Utility.windowHandles();
		 logger.info("switch to "+pageLib.getNewListWindow().getText()+"  window");
		 waitUntilElementIsClickable(pageLib.getListNameField());
		 pageLib.getListNameField().clear();
		 pageLib.getListNameField().sendKeys(listName);
		 WebElement cancelButton=pageLib.getcopyCancel();
		 cancelButton.click();
		 logger.info("Clicked on button"+cancelButton.getText());
		 Assert.assertNotEquals(pageLib.getUserCreatedList().getText(), listName,"list names are equal");
		}else{
	    	 logger.info("it is folder");
		  }
	}
	
	/**
	 * Method Description (testCase:0375):MOVE any list by dragging and dropping it. Verify the list successfully moves to the new location. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/ 
	public void tc0375_VerifyMoveListByDragAndDrop(){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		WebElement myListElements=pageLib.getMyListElements();
		String createdListLink=pageLib.getUserCreatedList().getText();
		if(!(myListLink.getAttribute("class").contains("down"))){
			myListLink.click();
		}
		//check file or Folder
		if(myListElements.getAttribute("class").contains("listExplorerItem ")){	
			Actions action=new Actions(driver);
			action.dragAndDrop(myListElements, pageLib.getdestLocToListDrop()).build().perform();
			waitUntilVisibilityOfElement();
			Assert.assertEquals(pageLib.getfourthUserList().getText(), createdListLink,"LIst not moved");
		}else{
	    	 logger.info("it is folder");
		  }
	}
	
	/**
	 * Method Description (testCase:0376):Try to MOVE a list to a disallowed or locked location, and make sure the list does not move.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0376_VerifyListMoveToUnAllowedLoc(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		String createdListLink=pageLib.getUserCreatedList().getText();
		if(!(myListLink.getAttribute("class").contains("down"))){
			myListLink.click();
			logger.info("clicked on "+MyListText+" folder");
		}
		if(myListElements.getAttribute("class").contains("listExplorerItem ")){	
			Actions action=new Actions(driver);
			action.dragAndDropBy(myListElements, 50, -100).build().perform();
			action.dragAndDrop(myListElements, pageLib.getdestLocToListDrop()).build().perform();
			waitUntilVisibilityOfElement();
			Assert.assertEquals(pageLib.getUserCreatedList().getText(), createdListLink,"List moved to unallowed location");
		}else{
	    	 logger.info("it is folder");
		  }
	}

 
	/**
	 * Method Description (testCase:0377 and 379):RENAME a created list. Verify that a new window appears to enter a name for the list with the text box filled in with the current name of the list. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0377_RenameCreateList(String listName){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
		  myListLink.click();
	      logger.info("clicked on "+MyListText+" folder");
		 }
		
	    if(myListElements.getAttribute("class").contains("listExplorerItem ")){
         createdListLink.click();
         waitUntilElementisVisible(pageLib.getUserCreatedList());
	     Actions action=new Actions(driver);
	     action.moveToElement(createdListLink).perform();
	     pageLib.getDropdown().click();
	     waitUntilElementisVisible(pageLib.getWaitOptions());
	     action.moveToElement(pageLib.getWaitOptions());
	     //locate all options
		 List<WebElement> myListDropdown=pageLib.getDropdownElements();
		 
		 //clicking on Rename option
		 logger.info(myListDropdown.get(7).getText()+" selecting");
		 myListDropdown.get(7).click();
	     Utility.windowHandles();
	     logger.info("switch to "+pageLib.getNewListWindow().getText()+"  window");
	    //Checks window present or not
	     Assert.assertTrue(pageLib.getNewListWindow().isDisplayed(), "Window not opened");
	     waitUntilElementIsClickable(pageLib.getListNameField());
	     pageLib.getListNameField().clear();
	     pageLib.getListNameField().sendKeys(listName);
	     logger.info(listName+" Entered");
	     WebElement savebutton=pageLib.getListNamesave();
	     savebutton.click();
	     logger.info(listName+" list renamed successfully");
	     waitUntilVisibilityOfElement();
	     waitUntilElementisVisible(pageLib.getUserCreatedList());
	     Assert.assertEquals(pageLib.getUserCreatedList().getText(), listName,"is not renamed");
	   }else{
	    	 logger.info("it is folder");
         }
	} 
	
	/**
	 * Method Description (testCase:0378):Enter a new name and click CANCEL. Verify that the list name has not been changed. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0378_ValidateRenameOption(String listName){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
		 myListLink.click();
	    logger.info("clicked on "+MyListText+" folder");
		}
	    if(myListElements.getAttribute("class").contains("listExplorerItem ")){
        createdListLink.click();
	    Actions action=new Actions(driver);
	    try{
	    	action.moveToElement(createdListLink).build().perform();
	    	pageLib.getDropdown().click();
	    }catch(Exception e){
	    	e.printStackTrace();
	    }
	    waitUntilElementisVisible(pageLib.getWaitOptions());
	    action.moveToElement(pageLib.getWaitOptions());
	    //locate all options
		List<WebElement> myListDropdown=pageLib.getDropdownElements();
		 
		//clicking on Rename option
		logger.info(myListDropdown.get(7).getText()+" selecting");
		myListDropdown.get(7).click();
	    Utility.windowHandles();
	    logger.info("switch to "+pageLib.getNewListWindow().getText()+"  window");
	    waitUntilElementIsClickable(pageLib.getListNameField());
	    pageLib.getListNameField().clear();
	    pageLib.getListNameField().sendKeys(listName);
	    WebElement cancelButton=pageLib.getcopyCancel();
		cancelButton.click();
		logger.info("Clicked on button"+cancelButton.getText());
		Assert.assertNotEquals(pageLib.getUserCreatedList().getText(), listName,"list names are equal");
	    }else{
	    	 logger.info("it is folder");
        }
	}
	
	/**
	 * Method Description (testCase:0380):Add any list to FAVORITES. Confirm that the list now appears under the FAVORITES dropdown on the list manager.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0380_AddToFavourites(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getSmartList());
		if(!(pageLib.getSmartList().getAttribute("class").contains("down"))){
				pageLib.getSmartList().click();
		  }
		  Actions action=new Actions(driver);
		  action.moveToElement(pageLib.getRecentSymbols()).build().perform();
		  pageLib.getDropdownRecent().click();
		  waitUntilElementisVisible(pageLib.getWaitRecentOptions());
		  //locate all options
			List<WebElement> flaggedListDropdown=pageLib.getflaggedSymbolsDropDownOptions();
			 
		  //clicking on add to favorites option
		  logger.info("Clicking on option: "+flaggedListDropdown.get(5).getText());
		  flaggedListDropdown.get(5).click();
		 
		  //validate in favorites folder
		  waitUntilElementisVisible(pageLib.getFavouriteFolder());
		  if(!(pageLib.getFavouriteFolder().getAttribute("class").contains("down"))){
			  pageLib.getFavouriteFolder().click();
		    }
		  waitUntilVisibilityOfElement();
		  Utility.waitUntilElementisVisible(pageLib.getFavouriteList().get(0));
		  Assert.assertTrue(pageLib.getFavouriteList().get(0).isDisplayed(), "not added");
	  }
	
	/**
	 * Method Description (testCase:0381):Make sure the columns for the list in Favorites match the column for the list in its original location.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0381_ValidateFavouriteListColumns(){
		waitUntilElementisVisible(pageLib.getFavouriteFolder());
		String flagImg="url(\"http://marketsmith.stage-ibd.com/mstool/Images/ListManager/LMImgsCnt.png\")"; 
	    String RecentSymbolHeader[]={"",flagImg,"#","Symbol","Name","Type","Current Price","Price % Chg","Price $ Chg","Volume (1000s)","Vol % Chg vs 50-Day","EPS Rating","RS Rating","Ind Group RS","SMR Rating","A/D Rating","Comp Rating"};
	    if(!(pageLib.getFavouriteFolder().getAttribute("class").contains("down"))){
			  pageLib.getFavouriteFolder().click();
		    }
	    int favoriteListsCount=pageLib.getFavouriteList().size();
	    pageLib.getFavouriteList().get(favoriteListsCount-1).click();
	    waitUntilVisibilityOfElement();
	    List<WebElement> columnNamelist=pageLib.getColumnNames();
	    for(int i=0;i<columnNamelist.size()-1;i++){
	    	switch(i) {
	    	case 1:
	    		Assert.assertEquals(columnNamelist.get(i).findElement(By.className("LMImgs")).getCssValue("background-image"), RecentSymbolHeader[i]," not matched");
		    	logger.info("column name is"+columnNamelist.get(i).getText());
	    		break;
	    	default:
	    		Assert.assertEquals(((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML;", columnNamelist.get(i)), RecentSymbolHeader[i]," not matched");
	    		logger.info("column name is"+columnNamelist.get(i).getText());
	    	}
	    }
	}
	
	/**
	 * Method Description (testCase:0382):Make sure the columns for the list in Favorites match the column for the list in its original location.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0382_VerifyDropDownOfFavourite(){
		if(!(pageLib.getFavouriteFolder().getAttribute("class").contains("down"))){
			 pageLib.getFavouriteFolder().click();
		 }
		    Actions action=new Actions(driver);
		    pageLib.getFavouriteList().get(0).click();
			action.moveToElement(pageLib.getFavouriteList().get(0)).build().perform();
			pageLib.getDropdownFavourite().get(0).click();
			waitUntilElementisVisible(pageLib.getWaitFavouriteOptions());
			action.moveToElement(pageLib.getWaitFavouriteOptions()).build().perform();
			List<WebElement> favDropdownElements=pageLib.getFavoriteDropdownElements();
			String listElemnts[]={CONSTANTS.getProperty("LIST_ANALYSIS"),CONSTANTS.getProperty("PRINT_LIST"),CONSTANTS.getProperty("VIEW_COMPARISON_CHART"),CONSTANTS.getProperty("LIST_ACTIONS"),CONSTANTS.getProperty("COPY"),CONSTANTS.getProperty("REMOVE_FAVORITES"),CONSTANTS.getProperty("GOTO_ORIGINAL_LIST"),CONSTANTS.getProperty("LIST_DISPLAY"),CONSTANTS.getProperty("MS_LIST_DETAILS")};
			for(int i=0;i<listElemnts.length;i++){
			 Assert.assertEquals(favDropdownElements.get(i).getText().trim(),listElemnts[i],"text is not matched");
			 logger.info(favDropdownElements.get(i).getText().trim()+" is present ");
			}
	 }
	
	/**
	 * Method Description (testCase:0383):Make sure you can change the order of items in the FAVORITES list group.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0383_VerifyDragListInsideFavorite(){
		if(!(pageLib.getFavouriteFolder().getAttribute("class").contains("down"))){
			 pageLib.getFavouriteFolder().click();
		 }
		String firstFavList=pageLib.getfavoriteFirstList().getText();
		Actions action=new Actions(driver);
		pageLib.getfavoriteFirstLoc().click();
		action.dragAndDrop(pageLib.getfavoriteFirstLoc(), pageLib.getfavoriteSecLoc()).build().perform();
		waitUntilElementisVisible(pageLib.getfavoriteSecList());
		Assert.assertEquals(pageLib.getfavoriteSecList().getText(), firstFavList,"order not changed");
	}
	
	/**
	 * Method Description (testCase:0384):Pick a list from each section of the LISTS panel, and drag them to the FAVORITES folder. Make sure each list is successfully added to FAVORITES. The only folders that can't be copied to FAVORITES are SCREEN RESULTS and TEMPORARY.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0384_ValidateAddToFavoriteForScreenResults(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		pageLib.getscreenResults().click();
		List<WebElement> allListsUnderFavorite=pageLib.getallFavoriteFolderLists();
		int totalNoofListInfavorite=allListsUnderFavorite.size();
		Actions action=new Actions(driver);
		action.dragAndDrop(pageLib.getscreenResults(), pageLib.getFavouriteFolder());
		waitUntilVisibilityOfElement();
		Assert.assertEquals(allListsUnderFavorite.size(), totalNoofListInfavorite,"Not equal");
	}
	
	/**
	 * Method Description (testCase:0385):After you drag one of your custom lists to FAVORITES, try dragging the same list there again. Make sure that no duplicate list gets copied.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0385_ValidateDuplicacyInFavorite(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getdestLocToListDrop();
		if(!(myListLink.getAttribute("class").contains("down"))){
		 myListLink.click();
	    logger.info("clicked on "+MyListText+" folder");
		}
		 if(myListElements.getAttribute("class").contains("listExplorerItem ")){
			Actions action=new Actions(driver);
			action.dragAndDrop(myListElements, pageLib.getFavouriteFolder()).build().perform();
			waitUntilVisibilityOfElement();
			List<WebElement> allListsUnderFavorite=pageLib.getallFavoriteFolderLists();
			int totalNoofListInfavorite=allListsUnderFavorite.size();
			action.dragAndDrop(myListElements, pageLib.getFavouriteFolder()).build().perform();
			Assert.assertEquals(allListsUnderFavorite.size(), totalNoofListInfavorite,"Not equal");
		 }else{
	    	 logger.info("it is folder");
	        }
	}
	
	/**
	 * Method Description (testCase:0386):On any list, click the dropdown menu button on the right, and then click ADD TO FAVORITES. Make sure the list is successfully added to the FAVORITES folder. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	 public void tc0386_RemoveFromFavourites(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getSmartList());
		if(!(pageLib.getSmartList().getAttribute("class").contains("down"))){
		   	pageLib.getSmartList().click();
		   	logger.info("clicked on "+pageLib.getSmartList().getText());
		  }	
		    pageLib.getRecentSymbols().click();
		    Actions action=new Actions(driver);
		    action.moveToElement(pageLib.getRecentSymbols()).build().perform();
			pageLib.getDropdownRecent().click();
			waitUntilElementisVisible(pageLib.getWaitRecentOptions());
			//locate all options
			List<WebElement> flaggedListDropdown=pageLib.getflaggedSymbolsDropDownOptions();
			 
		    //clicking on add to favorites option
		    logger.info("Clicking on option: "+flaggedListDropdown.get(5).getText());
		    flaggedListDropdown.get(5).click();
			logger.info(pageLib.getRecentSymbols().getText()+"  removed from favourites");
			//validate in favorites folder
			 waitUntilElementisVisible(pageLib.getFavouriteFolder());
			 if(!(pageLib.getFavouriteFolder().getAttribute("class").contains("down"))){
				  pageLib.getFavouriteFolder().click();
			    }
			 waitUntilVisibilityOfElement();
			 Assert.assertNotEquals(pageLib.getFavouriteList().get(0).getText(), pageLib.getRecentSymbols().getText(),"is present");
	}
	 
	 /**
		 * Method Description (testCase:0387):Click on any original list currently in the FAVORITES section, and select REMOVE FROM FAVORITES. Make sure the list disappears from the FAVORITES folder (This option only appears in the dropdown of the original. The list under the Favorites folder does not have this option).
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	public void tc0387_SharingList(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
		  myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		}
		 if(myListElements.getAttribute("class").contains("listExplorerItem ")){
			 createdListLink.click();
			 Actions action=new Actions(driver);
			 action.moveToElement(createdListLink).build().perform();
		     pageLib.getDropdown().click();
		     waitUntilElementisVisible(pageLib.getWaitOptions());
		     
		     //locate all options
			 List<WebElement> myListDropdown=pageLib.getDropdownElements();
				 
			 //clicking on sharing option
			 logger.info(myListDropdown.get(6).getText()+" selecting");
			 myListDropdown.get(6).click();
		     Utility.windowHandles();
		     waitUntilVisibilityOfElement();
		     waitUntilElementisVisible(pageLib.getShareListWindow());
			 logger.info("switch to "+pageLib.getShareListWindow().getText()+"  window");
		     Assert.assertEquals(pageLib.getShareListWindow().getText().trim(), "Share a List","window is not present"); 
		    }  else{
	    	    logger.info("it is folder");
	            }
	}
	
	/**
	 * Method Description (testCase:0388 and 389):Go back to a created list. Click on Sharing and verify that the Share a List window appears. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0388_ShareWithSpecificMember(){
		Assert.assertEquals(pageLib.getShareListWindow().getText().trim(), "Share a List","window is not present");
		waitUntilElementIsClickable(pageLib.getShareWithSpecificRadio());
		pageLib.getShareWithSpecificRadio().click();
		logger.info("selected "+pageLib.getShareWithSpecificRadio().getAttribute("name"));
		waitUntilElementIsClickable(pageLib.getselectContact());
		pageLib.getselectContact().click();
		waitUntilElementIsClickable(pageLib.getSharebutton());
		pageLib.getSharebutton().click();
		logger.info("shared with this member  "+pageLib.getSharedMember().getText());
		waitUntilElementIsClickable(pageLib.getApplyButton());
		pageLib.getApplyButton().click();
		logger.info("clicked on "+pageLib.getApplyButton().getText()+" button");
		waitUntilVisibilityOfElement();
		waitUntilVisibilityOfElement();
		waitUntilElementisVisible(pageLib.getUserCreatedList());
		waitUntilVisibilityOfElement();
		Assert.assertTrue(pageLib.getSharedIcon().isDisplayed(), "shared icon is not present");
	}
	
	/**
	 * Method Description (testCase:0390):Under the SHARING section,  Select SHARE WITH EVERYONE for now.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0389_shareWithEveryone(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getSecondList();
		if(!(myListLink.getAttribute("class").contains("down"))){
		 myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		}
		if(myListElements.getAttribute("class").contains("listExplorerItem ")){
			 createdListLink.click();
			 Actions action=new Actions(driver);
			 action.moveToElement(createdListLink).build().perform();
		     pageLib.getsecondDropdown().click();
		     waitUntilElementisVisible(pageLib.getWaitOptions());
		     //locate all options
			 List<WebElement> myListDropdown=pageLib.getDropdownElements();
				 
			 //clicking on sharing option
			 logger.info(myListDropdown.get(6).getText()+" selecting");
			 myListDropdown.get(6).click();
		     Utility.windowHandles();
		     waitUntilVisibilityOfElement();
		     logger.info("switch to "+pageLib.getShareListWindow().getText()+"  window");
		     pageLib.getShareWithEveryone().click();
			 logger.info("selected "+pageLib.getShareWithEveryone().getAttribute("name"));
			 pageLib.getShareWithEveryone().click();
			 waitUntilElementIsClickable(pageLib.getApplyButton());
			 pageLib.getApplyButton().click();
			 logger.info("clicked on "+pageLib.getApplyButton().getText()+" button");
			 waitUntilVisibilityOfElement();
			 waitUntilVisibilityOfElement();
			 waitUntilElementisVisible(pageLib.getSecondList());
			 Assert.assertTrue(pageLib.getthirdSharedIcon().isDisplayed(), "shared icon is not present");
		    }else{
	    	    logger.info("it is folder");
	            }
	}
		
	/**
	 * Method Description (testCase:0392):Under ASSIGN TAGS TO YOUR LIST, choose a few default tags. As you click each button, verify the tag in question populates the TAGS APPLIED section towards the bottom of the window.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0391_VerifyTheTagsApplied(){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
		 myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		}
		if(myListElements.getAttribute("class").contains("listExplorerItem ")){
			 createdListLink.click();
			 Actions action=new Actions(driver);
			 action.moveToElement(createdListLink).build().perform();
		     pageLib.getDropdown().click();
		     waitUntilElementisVisible(pageLib.getWaitOptions());
		     //locate all options
			 List<WebElement> myListDropdown=pageLib.getDropdownElements();
				 
			 //clicking on sharing option
			 logger.info(myListDropdown.get(6).getText()+" selecting");
			 myListDropdown.get(6).click();
		     Utility.windowHandles();
		     waitUntilVisibilityOfElement();
		     logger.info("switch to "+pageLib.getShareListWindow().getText()+"  window");
		     List<WebElement> allTagsList=pageLib.getallTagsList();
		     allTagsList.get(0).click();
		     allTagsList.get(1).click();
		     waitUntilElementisVisible(pageLib.gettagsApplied());
		     Assert.assertTrue(pageLib.gettagsApplied().isDisplayed(), "Tags not applied");
		}else{
		    	    logger.info("it is folder");
		            }
	}
	
	/**
	 * Method Description (testCase:0393):To the right of the VIEW buttons, verify there is a Tool button (wrench) and a Help button (question mark).
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0392_VerifyAdditionalTags(){
		Assert.assertEquals(pageLib.getShareListWindow().getText().trim(), "Share a List","window is not present");
		waitUntilElementIsClickable(pageLib.gettagTextArea());
		pageLib.gettagTextArea().clear();
		pageLib.gettagTextArea().sendKeys("\"My Own Tag\"");
		waitUntilElementisVisible(pageLib.gettagsApplied());
		Assert.assertTrue(pageLib.gettagsApplied().isDisplayed(), "Tags not applied");
		pageLib.getApplyButton().click();
		waitUntilVisibilityOfElement();
		waitUntilVisibilityOfElement();
	}
	
	/**
	 * Method Description (testCase:0394):Under ADDITIONAL TAGS, make up a few new custom tags. For multi-word tags, use quotation marks around the words so that they are added as a single logical tag.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0393_VerifyAdditionalTags(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
		 myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		 }
		if(myListElements.getAttribute("class").contains("listExplorerItem ")){
			 createdListLink.click();
			 Actions action=new Actions(driver);
			 action.moveToElement(createdListLink).build().perform();
		     pageLib.getDropdown().click();
		     waitUntilElementisVisible(pageLib.getWaitOptions());
		     //locate all options
			 List<WebElement> myListDropdown=pageLib.getDropdownElements();
				 
			 //clicking on sharing option
			 logger.info(myListDropdown.get(6).getText()+" selecting");
			 myListDropdown.get(6).click();
		     Utility.windowHandles();
		     waitUntilVisibilityOfElement();
		     logger.info("switch to "+pageLib.getShareListWindow().getText()+"  window");
		     String tagsApplied=pageLib.gettagsApplied().getText();
		     String tagsArray[]=tagsApplied.split(",");
		     int totalNoOfTags=tagsArray.length;
		     pageLib.gettagTextArea().clear();
			 pageLib.gettagTextArea().sendKeys("!@#$%^&");
			 waitUntilElementisVisible(pageLib.gettagsApplied());
			 Assert.assertEquals(tagsApplied.split(",").length, totalNoOfTags,"Added new tag");
		}else{
    	    logger.info("it is folder");
            } 
		pageLib.getApplyButton().click();
		waitUntilVisibilityOfElement();
		waitUntilVisibilityOfElement();
	}
	
	/**
	 * Method Description (testCase:0395):After you click APPLY to save your changes, confirm that after sharing a list, the "Shared" symbol (a light blue person icon) appears to the right of the list name.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0395_VerifySharedIconInsideFavourite(){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		waitUntilVisibilityOfElement();
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
		 myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		}
		waitUntilVisibilityOfElement();
		if(myListElements.getAttribute("class").contains("listExplorerItem ")){
			createdListLink.click();
			Actions action=new Actions(driver);
			action.moveToElement(createdListLink).build().perform();
		    pageLib.getDropdown().click();
		    waitUntilElementisVisible(pageLib.getWaitOptions());
		    //locate all options
			List<WebElement> myListDropdown=pageLib.getDropdownElements();
			 
		    //clicking on add to favorites option
		    logger.info("Clicking on option: "+myListDropdown.get(5).getText());
		    myListDropdown.get(5).click();
			  waitUntilElementisVisible(pageLib.getFavouriteFolder());
			  if(!(pageLib.getFavouriteFolder().getAttribute("class").contains("down"))){
				  pageLib.getFavouriteFolder().click();
			    }
			  int favoriteListsCount=pageLib.getFavouriteList().size();
			  Assert.assertTrue(pageLib.getFavouriteList().get(favoriteListsCount-1).isDisplayed(),"List is not added to favourite");
			  waitUntilVisibilityOfElement();
			  Assert.assertTrue(pageLib.getfavSharedIcon().isDisplayed(), "Shared icon not displayed inside favorite");
		}else{
    	    logger.info("it is folder");
            } 
	}
	
	/**
	 * Method Description (testCase:0396):Click the drop-down menu for the list, and select ADD TO FAVORITES. Verify that the List appears in the FAVORITES section of List Manager. For that list in the FAVORITES section, verify that the Shared icon appears next to the list name, just as it did in its previous location.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0396_VerifyViewDetailsOfFavoriteList(){
		waitUntilElementisVisible(pageLib.getFavouriteFolder());
		  if(!(pageLib.getFavouriteFolder().getAttribute("class").contains("down"))){
			  pageLib.getFavouriteFolder().click();
		    }
		int favoriteListsCount=pageLib.getFavouriteList().size(); 
		pageLib.getFavouriteList().get(favoriteListsCount-1).click();
		Actions action=new Actions(driver);
		action.moveToElement(pageLib.getFavouriteList().get(favoriteListsCount-1)).build().perform();
		pageLib.getDropdownFavourite().get(favoriteListsCount-1).click();
		waitUntilElementisVisible(pageLib.getWaitFavouriteOptions());
		
		//locate all the favorite options
		List<WebElement> favDropdownElements=pageLib.getFavoriteDropdownElements();
		
		logger.info("clicking on option: "+favDropdownElements.get(8));
		favDropdownElements.get(8).click();
		waitUntilElementisVisible(pageLib.getViewDetailsWindow());
		waitUntilElementisVisible(pageLib.getsharingstatus());
		Assert.assertEquals(pageLib.getsharingstatus().getText(), "Public","Not matched");
	}
	
	/**
	 * Method Description (testCase:0400):Also verify you can select a star rating for the list. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0400_ChangeSharingStatus(){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
		 myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		 }
		 if(myListElements.getAttribute("class").contains("listExplorerItem ")){
		 createdListLink.click();
		 Actions action=new Actions(driver);
		 action.moveToElement(createdListLink).build().perform();
		 pageLib.getDropdown().click();
		 waitUntilElementisVisible(pageLib.getWaitOptions());
		//locate all options
		List<WebElement> myListDropdown=pageLib.getDropdownElements();
			 
		 //clicking on view/Edit details option
		 logger.info("Clicking on option: "+myListDropdown.get(9).getText());
		 myListDropdown.get(9).click();
		 Utility.windowHandles();
		 waitUntilVisibilityOfElement();
		 logger.info("switch to "+pageLib.getViewDetailsWindow().getText()+"  window");
		 waitUntilElementIsClickable( pageLib.getstatusChangeLink());
		 pageLib.getstatusChangeLink().click();
		 Utility.windowHandles();
		 waitUntilVisibilityOfElement();
		 waitUntilElementisVisible(pageLib.getShareListWindow());
		 logger.info("switch to "+pageLib.getShareListWindow().getText()+"  window");
		 waitUntilElementIsClickable(pageLib.getDoNotShareButton());
		 pageLib.getDoNotShareButton().click();
		 logger.info("selected "+pageLib.getDoNotShareButton().getAttribute("name"));
		 waitUntilElementIsClickable(pageLib.getApplyButton());
		 pageLib.getApplyButton().click();
		 logger.info("clicked on "+pageLib.getApplyButton().getText()+" button");
		 waitUntilVisibilityOfElement();
		 waitUntilVisibilityOfElement();
		 waitUntilElementisVisible(pageLib.getViewDetailsWindow());
		 Assert.assertEquals(pageLib.getsharingstatus().getText(),"Private","Sharing status not changed");
		 pageLib.getCloseBtn().click();
		 } else{
	    	    logger.info("it is folder");
	            }
	}
	
	/**
	 * Method Description (testCase:0403):Go to any list that is not currently shared (i.e., does not have the small light blue person icon next to the name). Click on VIEW DETAILS for that list, and verify that you aren't allowed to add comments (the ADD COMMENT window should be greyed out).
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0402_deleteCreatedList(){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
		  myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		}
		  
		 if(myListElements.getAttribute("class").contains("listExplorerItem ")){
		 String createdList=createdListLink.getText();
		 createdListLink.click();
		 Actions action=new Actions(driver);
		 action.moveToElement(createdListLink).build().perform();
		 pageLib.getDropdown().click();
		 waitUntilElementisVisible(pageLib.getWaitOptions());
		 //locate all options
		 List<WebElement> myListDropdown=pageLib.getDropdownElements();
			 
		  //clicking on delete option
		  logger.info("Clicking on option: "+myListDropdown.get(8).getText());
		  myListDropdown.get(8).click();
		 Utility.windowHandles();
	     logger.info("switch to "+pageLib.getdeleteWindow().getText()+"  window");
	     waitUntilElementIsClickable(pageLib.getdoNotShowCheckbox());
	     pageLib.getdoNotShowCheckbox().click();
	     pageLib.getConfirmationDelete().click();
	     logger.info("list got deleted");
	     waitUntilVisibilityOfElement();
	     Assert.assertNotEquals(pageLib.getUserCreatedList().getText(), createdList,"List not deleted");
		 } else{
		     Actions action=new Actions(driver);
			 action.moveToElement(pageLib.getCreatedFolder()).build().perform();
		     pageLib.getDropdownCreatedFolder().click();
		     waitUntilElementisVisible(pageLib.getWaitFolderDeleteWindow());
		     pageLib.getFolderDeleteOption().click();
		     Utility.windowHandles();
		     logger.info("switch to "+pageLib.getdeleteWindow().getText()+"  window");
		     pageLib.getConfirmationDelete().click(); 
		     logger.info("folder got deleted");
		     
		     //verify folder deleted or not
		     Assert.assertFalse(pageLib.getDropdownCreatedFolder().isDisplayed(),"folder not  deleted");
	   }
	}
	
	/**
	 * Method Description (testCase:0403):Click on Cancel. Verify the list was not deleted and is still in the list manager.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	 public void tc0403_VerifyCancelDeleteList(){
			waitUntilElementIsClickable(pageLib.getMyListsLink());
			WebElement myListLink=pageLib.getMyListsLink();
			String MyListText=pageLib.getMyListName().getText();
			WebElement myListElements=pageLib.getMyListElements();
			waitUntilVisibilityOfElement();
			WebElement createdListLink=pageLib.getUserCreatedList();
			String createdList=createdListLink.getText();
			if(!(myListLink.getAttribute("class").contains("down"))){
			  myListLink.click();
			 logger.info("clicked on "+MyListText+" folder");
			}
			 if(myListElements.getAttribute("class").contains("listExplorerItem ")){
			 createdListLink.click();
			 Actions action=new Actions(driver);
			 action.moveToElement(createdListLink).build().perform();
			 pageLib.getDropdown().click();
			 waitUntilElementisVisible(pageLib.getWaitOptions());
			 //locate all options
			 List<WebElement> myListDropdown=pageLib.getDropdownElements();
				 
			  //clicking on Delete option
			  logger.info("Clicking on option: "+myListDropdown.get(8).getText());
			  myListDropdown.get(8).click();
			 Utility.windowHandles();
		     logger.info("switch to "+pageLib.getdeleteWindow().getText()+"  window");
		      waitUntilElementIsClickable(pageLib.getcancelDeleteList());
		      pageLib.getcancelDeleteList().click();
		      Assert.assertEquals(pageLib.getUserCreatedList().getText(), createdList,"List got deleted");
		     } else{
		    	    logger.info("it is folder");
		            }
	 }
	
	 /**
		 * Method Description (testCase:0405):Click on Delete and check the "Do not show" confirmation button. Verify the list was deleted and is no longer in the list manager.
		 * Created By:- Mamata, Created Date:- 06/03/2016
		 * Changes made#1:
		**/
	public void tc0405_deleteCreatedListWithoutConfirmation(){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
		  myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		}
		String createdList=createdListLink.getText();
		 if(myListElements.getAttribute("class").contains("listExplorerItem ")){
		 createdListLink.click();
		 Actions action=new Actions(driver);
		 action.moveToElement(createdListLink).build().perform();
		 pageLib.getDropdown().click();
		 waitUntilElementisVisible(pageLib.getWaitOptions());
		 //locate all options
			List<WebElement> myListDropdown=pageLib.getDropdownElements();
			 
		  //clicking on delete option
		  logger.info("Clicking on option: "+myListDropdown.get(8).getText());
		  myListDropdown.get(8).click();
		 Assert.assertFalse(pageLib.getdeleteWindow().isDisplayed(), "Confirmation window displayed");
		 logger.info("list got deleted");
		 waitUntilVisibilityOfElement();
		 Assert.assertNotEquals(pageLib.getUserCreatedList().getText(), createdList,"List got deleted");
		 }else{
	    	    logger.info("it is folder");
         }
	}
	
	/**
	 * Method Description (testCase:0401 and 402):Under SHARING STATUS, verify you can click CHANGE and change the sharing status from public to private and back again, as well as to sharing it with only selected contacts. 
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0401_verifyCommentSectionOfViewDetails(){
		waitUntilElementIsClickable(pageLib.getMyListsLink());
		WebElement myListLink=pageLib.getMyListsLink();
		String MyListText=pageLib.getMyListName().getText();
		WebElement myListElements=pageLib.getMyListElements();
		WebElement createdListLink=pageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
		 myListLink.click();
		 logger.info("clicked on "+MyListText+" folder");
		}
		if(myListElements.getAttribute("class").contains("listExplorerItem ")){
			 createdListLink.click();
			 Actions action=new Actions(driver);
			 action.moveToElement(createdListLink).build().perform();
		     pageLib.getDropdown().click();
		     waitUntilElementisVisible(pageLib.getWaitOptions());
		   //locate all options
			List<WebElement> myListDropdown=pageLib.getDropdownElements();
					 
			//clicking on view/Edit details option
			logger.info("Clicking on option: "+myListDropdown.get(9).getText());
			myListDropdown.get(9).click();
		     Utility.windowHandles();
		     waitUntilElementisVisible(pageLib.getViewDetailsWindow());
		     logger.info("switch to "+pageLib.getViewDetailsWindow().getText()+"  window");
		     waitUntilElementisVisible(pageLib.getsharingstatus());
		     WebElement  sharingStatus=pageLib.getsharingstatus();
		     if(sharingStatus.getText().contains("Public")){
		    	 waitUntilElementIsClickable(pageLib.getRatingSection());
		    	 pageLib.getRatingSection().click();
		    	 logger.info("rating section selected");
		    	 waitUntilElementIsClickable(pageLib.getTextArea());
		    	 pageLib.getTextArea().sendKeys("commentbyJimJhon");
		    	 waitUntilElementIsClickable(pageLib.getcommentSubmit());
		    	 pageLib.getcommentSubmit().click();
		    	 logger.info("clicked on  "+pageLib.getcommentSubmit().getText()+" button");
		      	 logger.info("comments added");
		    	 waitUntilVisibilityOfElement();
		    	 waitUntilVisibilityOfElement();
		    	 waitUntilElementisVisible(pageLib.getShowComments());
		    	 //validating comments added or not
		    	 Assert.assertTrue(pageLib.getShowComments().isDisplayed(), "Comments not added");
		    }else{
		    	 logger.info("comment section is disabled");
		    	 //Validating comments section disabled for private list
		    	 Assert.assertFalse(pageLib.getTextArea().isEnabled(),"is enabled");   
		        }
		       	 pageLib.getCloseBtn().click();
	      }else{
	    	    logger.info("it is folder");
	            }
	}
	
	/**
	 * Method Description (testCase:0412):Click View Comparison Charts. Verify a Comparison Chart window appears with the contents of the list displayed. Try this on lists in each category to verify they all work.
	 * Created By:- Mamata, Created Date:- 06/03/2016
	 * Changes made#1:
	**/
	public void tc0412_VerifyComparisonChart(){
		Utility.deleteCreatedList();
		waitUntilVisibilityOfElement();
		ValidateItemsOfList();
		WebElement createdListLink=pageLib.getSecondList();
		Actions action=new Actions(driver);
		action.moveToElement(createdListLink).build().perform();
		pageLib.getsecondDropdown().click();
		waitUntilElementisVisible(pageLib.getWaitOptions());
		//locate all options
		List<WebElement> myListDropdown=pageLib.getDropdownElements();
			 
		//clicking on comparison chart option
		logger.info(myListDropdown.get(2).getText()+" selecting");
		myListDropdown.get(2).click();
		
	    windowHandles();
	    
		System.out.println(driver.getCurrentUrl());
		waitUntilElementisVisible(pageLib.getcomparisonChartWindow());
		logger.info("switch to "+pageLib.getcomparisonChartWindow().getText()+"  window");
		Assert.assertEquals(pageLib.getcomparisonChartWindow().getText().trim(), "Comparison Chart","not matched");
		Utility.closeWindow();
	}
}

