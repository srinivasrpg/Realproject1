package charts;

import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.JavascriptExecutor;

import genericLib.Utility;

import static genericLib.Utility.*;
import java.util.*;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class ChartPage {
	ChartPageLib pageLib = PageFactory.initElements(driver, ChartPageLib.class);
	
	//Test Case : 1009 : Click on Open Charts to launch MSTool
	public void tc003_launchMSTool() {
	   try {
			WebElement settingIcon = pageLib.getLoginButton();
			if (settingIcon.isDisplayed()) {
				logger.info("Not Logged In");
			} else {
				throw new Exception();
			}
		} catch (Exception e) {

			waitUntilElementIsClickable(pageLib.getOpenChartButton());
			WebElement openChartBtn = pageLib.getOpenChartButton();
			String openChartBtnText = openChartBtn.getText();
			openChartBtn.click();
			logger.info("Clicked on " + openChartBtnText + " button");
			WebDriverWait wait=new WebDriverWait(driver, 5);
			//System.out.println("LAUNCHING TOOL___>>" + driver.getCurrentUrl());
			try {
				Thread.sleep(10000);
				Utility.windowHandles();
				wait.until(ExpectedConditions.urlToBe(CONSTANTS.getProperty("MSTOOL_URL")));
				logger.info("User launched MSTOOL successfully");
				driver.manage().window().maximize();
			}
			catch(/*TimeoutException*/InterruptedException te) {
				try {
					Utility.windowHandles();
					wait.until(ExpectedConditions.urlToBe(CONSTANTS.getProperty("MSTOOL_URL")));
					logger.info("User launched MSTOOL successfully");
				}
				catch(TimeoutException toe) {
					Assert.assertEquals(driver.getCurrentUrl(), CONSTANTS.getProperty("MSTOOL_URL"), "MSTOOL URL is not matched");
				}
			}
			finally{
				if(!(pageLib.getSymbolEntryField().getAttribute("value").equals("AAPL"))){
					waitUntilElementIsClickable(pageLib.getSymbolEntryField());
					System.out.println("Symbol input ready to be clicked");
					pageLib.getChartCnt().click();
					pageLib.getSymbolEntryField().sendKeys(Keys.DELETE);
					Actions action1 = new Actions(driver);
					action1.sendKeys(pageLib.getSymbolEntryField(),"AAPL").sendKeys(Keys.ENTER).build().perform();
					waitUntilElementIsClickable(pageLib.getCompanyInfo_symbol());
				}
			}
        }
	}
	/**********************************************************************************************************************************
	 **********************************************************************************************************************************/
	//tc1010_VerifyFlag: Verify that flag icon exists
	public void tc1010_VerifyFlag()
	{
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		if(pageLib.getFlagIcon().isDisplayed()){
			Assert.assertTrue(pageLib.getFlagIcon().isDisplayed()," is not present");
			logger.info("Flag icon is displayed");
		}
		else{
			Assert.fail("Flag icon is not present");
			logger.info("Flag icon is NOT Displayed");
		}
	}
	
	
	//tc1010_VerifyFlag_toggle: Verify that flag icon TOGGLE
	public void tc1010_VerifyFlag_toggle(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementisVisible(pageLib.getFlagIcon());
		//flag INITIALLY is checked
		if(pageLib.getFlagIcon().getAttribute("class").contains("flagActive")){
			pageLib.getFlagIcon().click();
			logger.info("click on flag to deselect/uncheck = NO COLOR");
			waitUntilVisibilityOfElement();
			//if element still contains flagActive->NOT toggled correctly, ELSE toggled correctly
			if(pageLib.getFlagIcon().getAttribute("class").contains("flagActive")){
				Assert.fail("Flag was not unchecked correctly");
			}
			else{
				Assert.assertTrue(true,"Flag toggled correctly");
			}
		}
		//flag NOT INITIALLY checked and perform this logic instead (inverse of above conditional)
		else{
			pageLib.getFlagIcon().click();
			logger.info("click on flag to select/check = COLOR");
			waitUntilVisibilityOfElement();
			//if element contains flagActive->toggled CORRECTLY, ELSE not toggled correctly
			if(pageLib.getFlagIcon().getAttribute("class").contains("flagActive")){
				Assert.assertTrue(true,"Flag toggled correctly");
			}
			else{
				Assert.fail("Flag was not unchecked correctly");
			}
		}
	}
	
	
	//tc1011_VerifyAddToList_Content: Verify Add to List content matches content under My List folder
	public void tc1011_VerifyAddToList_Content()
	{
		boolean passed = true;
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		//clicking on LM default button
		waitUntilElementIsClickable(pageLib.getDefaultLM_button());
		//System.out.println(pageLib.getDefaultLM_button().getAttribute("class"));
		pageLib.getDefaultLM_button().click();
		//clicking on My List root folder
		waitUntilElementIsClickable(pageLib.getMyListRoot_button());
		//If MyList folder content are already showing, DONT click MyList bc it will collapse content
		if(pageLib.getMyListRoot_button().getAttribute("class").contains("isFileOpen")) pageLib.getMyListRoot_button().click();
		//getting elements under My List (ie NOT nested folder content)
		List<WebElement> MyListContent = pageLib.getMyLists();
		//clicking on Add To List button drop down if NOT already expanded, followed by storing content in a List
		if(!(pageLib.getAddToListDDbutton().getAttribute("class").contains("expandBackground"))) pageLib.getAddToListDDbutton().click();
		waitUntilElementIsClickable(pageLib.getAddToNewList_option());
		List<WebElement> addToMyListContent = pageLib.getAddToListContent();
		//if the Add to New List options is NOT present, FAIL the TC, else Cont.
		if(pageLib.getAddToNewList_option().getText().contains("Add to New List"))
			logger.info("Add to List New List button displayed");
		else{
			logger.info("Add to New List button not displayed");
			passed = false;
		}
		
		for(int i=0; i<MyListContent.size();i++)
		{
			String str1 = (MyListContent.get(i)).getAttribute("name");
			String str2 = (addToMyListContent.get(i)).getAttribute("listname");
			if(str1.equals(str2)){
				logger.info(str1+ " = " + str2);
			}
			else{
				passed = false;
				logger.info(str1+ " NOT EQUAL " + str2);
			}
		}
		Assert.assertTrue(passed, "All lists do NOT match. Check Logger.");
	}
		
	
	//tc1012_VerifyAddToList_NewList: Verify Add to NEW list
	public void tc1012_VerifyAddToList_NewList()
	{
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));				
		//Click on button to add to list if NOT expanded
		//System.out.println("BEGIN TC, " + pageLib.getAddToListDDbutton().getAttribute("class"));
		String curr_symbol = pageLib.getSymbolEntryField().getText();
		if(!(pageLib.getAddToListDDbutton().getAttribute("class").contains("expandBackground"))){
			waitUntilElementIsClickable(pageLib.getAddToListDDbutton());
			pageLib.getAddToListDDbutton().click();
		}
		
		//Storing Add to List content
		List<WebElement> addToListItems = pageLib.getAddToListContent();
		int addToListCount_old = addToListItems.size();
		//Storing My List content
		List<WebElement> myListItems = pageLib.getMyLists();
		int myListItemsCount_old = myListItems.size();
		//click on Add to New List option and wait for Pop to appear
		waitUntilElementIsClickable(pageLib.getAddToNewList_option());
		pageLib.getAddToNewList_option().click();
		waitUntilElementisVisible(pageLib.getNewListPopUp());
		if(pageLib.getNewListPopUp().isDisplayed()){
			System.out.println("IN HERE ----->>>>>");
			//Click on input box and enter text using sendKeys(text)
			pageLib.getNewListPopUp_Input().click();
			pageLib.getNewListPopUp_Input().sendKeys("automation add to new list test");
			pageLib.getClickSaveForNewList().click();
			//TODO: check symbol has been added to list and click UNDO after
			//waitUntilElementisVisible(pageLib.getLMToolTip());
			//System.out.println("CHECK ADDED TO NEW LIST AND PERFORM UNDO ACTION");
			//System.out.println(pageLib.getLMToolTip().getCssValue("display"));
			//System.out.println(pageLib.getLMToolTip().getText());
			waitUntilVisibilityOfElement();
			
			//check message after adding stock to list and click UNDO
			if(pageLib.getLMToolTip().getCssValue("display").equals("block"))
			{
				//get current selected list, which would be the NEW created list
				String LM_curr_list = "";
				for(WebElement e:pageLib.getMyLists())
				{
					if(e.getAttribute("class").contains("itemActive") && pageLib.getLMToolTip().getText().contains(e.getText()) && 
							pageLib.getLMToolTip().getText().contains(curr_symbol))
					{
						//System.out.println(e.getText());
						logger.info("Correct message: "+pageLib.getLMToolTip().getText());
						LM_curr_list = e.getText();
						//System.out.println("List match: "+pageLib.getLMToolTip().getText().contains(e.getText()));
					}
				}
			}
			else{
				Assert.fail("Undo button is not show after adding symbol to list");
			}
			/*
				//click on Undo button in LM tool tip message
				pageLib.getLMToolTip_Undo().click();
				waitUntilVisibilityOfElement();
				List<WebElement> symbolsInCurrList = pageLib.getCurr_LMList_symbols();
				for(int i=0;i<symbolsInCurrList.size()-1;i++) {
					 String listText=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",symbolsInCurrList.get(i));	
					 logger.info("Currently selected list has symbol: "+listText);
					 //if the symbol added to the NEW list is still present, then FAIL TC
					 System.out.println("Curr symbol: "+curr_symbol);
					 System.out.println(listText.contains(curr_symbol));
					 if(listText.contains(curr_symbol))
						 Assert.fail(listText+" was NOT removed from "+LM_curr_list);
					 else{
						logger.info(curr_symbol+" removed from "+LM_curr_list+" by UNDO button");
					 	System.out.println(curr_symbol+" removed from "+LM_curr_list);}
				}
				*/
				
				/*
				String LM_curr_list = "";
				for(WebElement e:pageLib.getMyLists())
				{
					if(e.getAttribute("class").contains("itemActive") && pageLib.getLMToolTip().getText().contains(e.getText())){
						System.out.println(e.getText());
						LM_curr_list = e.getText();
						//System.out.println("List match: "+pageLib.getLMToolTip().getText().contains(e.getText()));
					}
				}
				*/
			//}
			
			//waitUntilElementIsClickable(pageLib.getAddToListDDbutton());
			pageLib.getAddToListDDbutton().click();
			//wait 1.5 seconds in order for NEW list to be added to My Lists
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			//System.out.println(addToListCount_old < (pageLib.getAddToListContent()).size() && myListItemsCount_old < (pageLib.getMyLists()).size());
			if(addToListCount_old < (pageLib.getAddToListContent()).size() && myListItemsCount_old < (pageLib.getMyLists()).size()){
				System.out.println("NEW LIST ADDED");
				Assert.assertTrue(true);
			}
			else{
				Assert.fail("New list was not added to user created lists");
				logger.info("New list was not added to user created lists");
			}
		}
		else{
			Assert.fail("Add To List button is not displayed");
			logger.info("Add To List button NOT clickable");
		}
	}
	
	//tc1013_VerifyNewChart: Verify new chart is opened with same symbol and periodicity selected in Main chart
	public void tc1013_VerifyNewChart(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		//declaring a list to store the Window handles
		boolean passed = false;
		//get charted symbol ticker
		waitUntilElementisVisible(pageLib.getCompanyInfo_symbol());
		String symbol = pageLib.getSymbolEntryField().getAttribute("value");
		//System.out.println(symbol);
		logger.info("Main window charted symbol is: " + symbol);
		//get selected periodicity
		String sel_periodicity = "";
		List<WebElement> temp = pageLib.getPeriodicitySelected();
		for(WebElement e:temp){
			if(e.getAttribute("class").contains("chartButtonActive"))
				sel_periodicity = e.getText();
		}
		logger.info("Main window selected periodicity is: " + sel_periodicity);
		//wait for New Chart button to click and wait 5 seconds
		waitUntilElementIsClickable(pageLib.getNewChartButton());
		pageLib.getNewChartButton().click();
		Utility.windowHandles();
		logger.info("Window handle switched to: " + driver.getCurrentUrl());
		
		//ASSERT LOGIC************
		//Iterate through NEW Window periodicities and check whether symbol and selected periodicity match MAIN window
		for(WebElement e2: pageLib.getPeriodicitySelected()){
			if((e2.getAttribute("class")).contains("chartButtonActive")){
				if((e2.getText()).equals(sel_periodicity) && symbol.equals(pageLib.getSymbolEntryField().getAttribute("value"))){
					logger.info("New window charted symbol is: " + (pageLib.getSymbolEntryField()).getAttribute("value") + " and selected periodicity is: "+ e2.getText());
					passed = true;
				}
			}	
		}
		//RESULT
		Assert.assertTrue(passed,"Main periodicity or Symbol do NOT match NEW window periodicty or Symbol");
		//closing NEW window and switching driver handles back to Main tool window. Wait 1 second.
		Utility.closeWindow();
	}
	
	//tc1014_VerifyNewChart_headerButtons: Make sure all header buttons are present in New Chart
	public void tc1014_VerifyNewChart_headerButtons(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		//Get list of chart buttons on main window and store class names in list
		boolean passed = true;
		waitUntilElementIsClickable(pageLib.getNewChartButton());
		List<WebElement> origWindowButtons = pageLib.getHeaderChartButtons();
		List<String> origWindowButtonClasses = new ArrayList<String>();
		for(WebElement e:origWindowButtons){
			origWindowButtonClasses.add(e.getAttribute("class"));	
		}
		//open new chart window and wait for it to finish loading
		pageLib.getNewChartButton().click();
		Utility.windowHandles();

		logger.info("Window handle switch to: " + driver.getCurrentUrl());
		//Get list of element buttons in new window -> ASSERT logic****************
		List<WebElement> newWindowButtons = pageLib.getHeaderChartButtons();
		for(WebElement e:newWindowButtons){
			if(origWindowButtonClasses.contains(e.getAttribute("class"))){
				logger.info(e.getAttribute("class") + " button exists in Main tool window");
			}
			else{
				passed = false;
				logger.info(e.getAttribute("class") + " button does NOT exist in Main tool window");
				Assert.fail(e.getAttribute("class") + " respective button is NOT present");
			}
		}
		//RESULT
		Assert.assertTrue(passed,"NOT all window header buttons appear in main tool window");
		//close NEW chart window. Switch window handle. Wait 1 seconds.
		logger.info("closing New window");
		Utility.closeWindow();
	}
	
	//tc1015_VerifyNewChart_rightClick: Verify right click Menu
	public void tc1015_VerifyNewChart_rightClick(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		//local vars in TC
		List<String> winHandles = new ArrayList<String>();
		boolean passed = true;
		List<String> rightClickItems = new ArrayList<String> (Arrays.asList("Temporary Line Pen (CTRL+Click)","Track Price (CTRL+SHIFT+Click)","Select (SHIFT+Click)","Delete All Annotations","Delete Annotation","Set Alert"));
		//Entering a symbol that will NOT have a base pattern
		waitUntilElementIsClickable(pageLib.getSymbolEntryField());
		Utility.EnterStockSymbol("0NDQ");
		
		//click on NEW chart window and wait 5 seconds for it to load. Switch window handles to NEW chart window
		pageLib.getNewChartButton().click();
		Utility.windowHandles();
		logger.info("Window handle switch to: " + driver.getCurrentUrl());
		
		//right clicking on New Chart Window->ASSERT LOGIC***************************
		Actions action = new Actions(driver);
		action.contextClick(pageLib.getChartCnt()).build().perform();
		//iterating through the Right click menu and comparing against List declared at the beginning of TC
		for(WebElement e:pageLib.getRightClickOptions()){
			if(rightClickItems.contains(e.getText()))
				logger.info(e.getText() + " is available as an option when Right clicking in New Chart Window");
			else
				passed = false;
		}
		//RESULT
		Assert.assertTrue(passed,"All options are not present when Right clicking on New Chart Window");
		//close NEW chart window. Switch window handle. Wait 1 seconds.
		Utility.closeWindow();
	}

	//tc1016_VerifyNewChart_DontReceiveFromMain: Verify new chart does NOT receive symbols from MAIN
	public void tc1016_VerifyNewChart_DontReceiveFromMain(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		String newChartSymbol = "";
		String mainChartSymbol = "";
		String checked = "";
		List<String> winHandles = new ArrayList<String>();

		waitUntilElementIsClickable(pageLib.getNewChartButton());
		//open new chart window. Wait 5 seconds. Store handles in List. Switch handles.
		pageLib.getNewChartButton().click();
		Utility.windowHandles();
		
		for (String win:driver.getWindowHandles()){
			winHandles.add(win);
		}
		logger.info("Window handle switch to: " + driver.getCurrentUrl());
		checked = pageLib.getReceiveSymbolsFromMain().getAttribute("checked");
		System.out.println(checked);
		System.out.println(pageLib.getReceiveSymbolsFromMain().getCssValue("display"));
		//WORKS -> TRUE
		//if(checked == null) System.out.println("HERE <-------------");
		//NOTHING OUTPUTS

		//check IF receive from main is displayed and is un-checked.
		//Else, FAIL. Chart BAC in NEW chart window and wait 1 second. Switch window handles and wait another 1 second.
		if(((pageLib.getReceiveSymbolsFromMain()).getCssValue("display")).equals("block") && checked == null){
			logger.info("Receive from main window option is displayed");
			waitUntilElementIsClickable(pageLib.getSymbolEntryField());
			//SOLUTION
			pageLib.getChartCnt().click();
			pageLib.getSymbolEntryField().sendKeys(Keys.DELETE);
			Actions action = new Actions(driver);
			action.sendKeys(pageLib.getSymbolEntryField(),"BAC").sendKeys(Keys.ENTER).build().perform();
		} else{
			logger.info("Receive from main window option is NOT displayed");
			Assert.fail("Receive from main window option is NOT displayed");
		}
		try { 
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//0: main site. 1: Main tool window. 2: New chart window . 
		driver.switchTo().window(winHandles.get(1));
		try { 
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//Charting symbol in MAIN chart window and store value
		pageLib.getChartCnt().click();
		pageLib.getSymbolEntryField().sendKeys(Keys.DELETE);
		Actions action = new Actions(driver);
		action.sendKeys(pageLib.getSymbolEntryField(),"TSLA").sendKeys(Keys.ENTER).build().perform();
		try { 
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		mainChartSymbol = pageLib.getSymbolEntryField().getAttribute("value");
		//switch to NEW chart window handle and store charted symbol
		driver.switchTo().window(winHandles.get(2));
		newChartSymbol = pageLib.getSymbolEntryField().getAttribute("value");
		//If symbols are equal, FAIL. Else, PASS.
		if(mainChartSymbol.equals(newChartSymbol)){
			logger.info("New Chart window INCORRECTLY receives stock symbol from Main window");
			Assert.fail("New Chart window INCORRECTLY receives stock symbol from Main window");
		} else{
			logger.info("New Chart window keeps current symbols when new symbol is charted in Main window");
			Assert.assertTrue(true);
		}
		//close NEW chart window. Switch window handle. Wait 1 seconds.
		Utility.closeWindow();	
	}
	
	
	//tc1017_VerifyNewChart_ReceiveFromMain: Verify NEW chart receives from MAIN AND PERIODICITY NOT MATCH
	public void tc1017_VerifyNewChart_ReceiveFromMain(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		String newChartSymbol = "";
		String mainChartSymbol = "";
		List<String> winHandles = new ArrayList<String>();
		
		waitUntilElementIsClickable(pageLib.getNewChartButton());
		//open new chart window. Wait 5 seconds. Store handles in List. Switch handles to NEW window.
		pageLib.getNewChartButton().click();
		Utility.windowHandles();
		//waitUntilVisibilityOfElement();
		for (String win:driver.getWindowHandles()){
			winHandles.add(win);
		}
		//driver.switchTo().window(winHandles.get(2));
		logger.info("Window handle switch to: " + driver.getCurrentUrl());
		//STORE selected PERIODICITY from NEW chart
		String new_sel_periodicity = "";
		for(WebElement e:pageLib.getPeriodicitySelected()){
			if(e.getAttribute("class").contains("chartButtonActive"))
				new_sel_periodicity = e.getText();
		}
		//click on Web Element to receive symbols from MAIN chart. Switch back to MAIN window
		pageLib.getReceiveSymbolsFromMain().click();
		driver.switchTo().window(winHandles.get(1));
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		//Click on MAIN chart to focus on symbol entry field and enter a new symbol.
		pageLib.getChartCnt().click();
		pageLib.getSymbolEntryField().sendKeys(Keys.DELETE);
		Actions action = new Actions(driver);
		action.sendKeys(pageLib.getSymbolEntryField(),"0NDQ").sendKeys(Keys.ENTER).build().perform();
		//CHANGE MAIN periodicity
		String main_sel_periodicity = "";
		for(WebElement e:pageLib.getPeriodicitySelected()){
			if(e.getText().contains("Weekly")){
				e.click();
				main_sel_periodicity = e.getText();
			}
		}
		waitUntilVisibilityOfElement();
		//Storing charted symbol
		waitUntilElementisVisible(pageLib.getCompanyInfo_symbol());
		mainChartSymbol = pageLib.getSymbolEntryField().getAttribute("value");

		//switch to NEW chart window handle. Wait 1 second. Store charted symbol in NEW window
		Utility.windowHandles();

		logger.info("PERIODICITY matching: "+new_sel_periodicity.equals(main_sel_periodicity));
		newChartSymbol = pageLib.getSymbolEntryField().getAttribute("value");
		//RESULT->Assert LOGIC***************** CHECK to see if periodicities match. If yes, FAIL, otherwise Check SYMBOLS NOT match
		if(new_sel_periodicity != main_sel_periodicity)
			Assert.assertTrue(mainChartSymbol.equals(newChartSymbol), "NEW chart window does NOT receive symbols from MAIN window");
		else
			Assert.fail("Periodicities are INCORRECTLY matching");
		//close NEW chart window. Switch window handle. Wait 1 seconds.
		Utility.closeWindow();
	}

	/*
	* Method Description (TC1018): VerifyComparisonChart(): Verify Comparison chart correctly opens AND main chart SYMBOL charted
	* Created By:- Michael D,
	* Changes made#1: 3/12/17
	*/
	public void tc1018_VerifyComparisonChart(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		String sCompChartsURL="ChartComparisonPopout";
		//STORE charted Symbol in String. GET window size.
		boolean passed = false;
		String mainChartSymbol = pageLib.getSymbolEntryField().getAttribute("value");

		//open COMPARISON chart window. Wait 5 seconds. Store handles in List. Switch handles to COMPARISON CHART window.
		waitUntilElementIsClickable(pageLib.getComparisonChart());
		pageLib.getComparisonChart().click();
		Utility.windowHandles();
		//System.out.println(mainChartSymbol);
		logger.info("Window handle switch to: " + driver.getCurrentUrl());
		Utility.waitUntilVisibilityOfElement();
		//Mazimize Comparison chart window size
		//Declare a list of WebElements in Comparison Charts and iterate through result
		List<WebElement> compChartSymbols = pageLib.getComparisonChart_dataBlockSymbols();
		System.out.println(compChartSymbols.size());
		for(WebElement e:compChartSymbols)
		{
			System.out.println(e.getText()+" IN COMP CHART.."+e.getText().contains(mainChartSymbol));
			if((e.getText()).contains(mainChartSymbol)){
				passed = true;
				logger.info(mainChartSymbol + " found in, " + e.getText());
			}
			else {
				passed = false;
			}
		}
		System.out.println(passed);
		//RESULT->ASSERT LOGIC*****CHECK WINDOW SIZE AND main SYMBOL charted in COMP chart
		if(driver.getCurrentUrl().contains(sCompChartsURL))
			Assert.assertTrue(passed,"Symbol in Main tool window is not charted in Comparison Window");
		else
			Assert.fail("Comparison chart window was NOT maximized");
		//close COMPARISON chart window. Switch window handle. Wait 1 seconds.
		Utility.closeWindow();
	}
	
	/*
	* Method Description (TC1019): VerifyComparisonChart_buttons(): Verify Comp chart buttons
	* Created By:- Michael D,
	* Changes made#1: 3/12/17
	*/
	public void tc1019_VerifyComparisonChart_buttons(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		//Local vars.
		boolean passed = false;
		//List of buttons that should be present in Comparison Chart window
		List<String> comparisonChart_buttonsList = new ArrayList<String> (Arrays.asList("comparisonLabel","symbolsInput","expendRecentSymbol toolTip-help","comparisonListCnt","timeRangeCon","printCharts","msLogo"));
		
		//open COMPARISON chart window. Wait 5 seconds. Store handles in List. Switch handles to COMPARISON CHART window.
		waitUntilElementIsClickable(pageLib.getComparisonChart());
		pageLib.getComparisonChart().click();
		Utility.windowHandles();
		logger.info("Window handle switch to: " + driver.getCurrentUrl());
		
		//count to keep track of index/position
		int count = 0;
		for(WebElement e:pageLib.getComparisonChart_buttons()){
			if(comparisonChart_buttonsList.contains(e.getAttribute("class"))){
				count++;
				logger.info(e.getAttribute("class") + " is found in Comparison Chart buttons");
			}			
			if(count >= comparisonChart_buttonsList.size()) {
				passed = true;
				break;
			}
		}
		//RESULT
		Assert.assertTrue(passed,"Not all chart buttons present in Comparison Chart window");
		//close COMPARISON chart window. Switch window handle. Wait 1 seconds.
		Utility.closeWindow();
	}
	
	/*
	* Method Description (TC1020): VerifyComparisonChart_initSymbolColor and Scale
	* Created By:- Michael D,
	* Changes made#1: 3/12/17
	*/
	public void tc1020_ComparisonChart_initSymbolColor_Scale(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		//open COMPARISON chart window. Wait 5 seconds. Store handles in List. Switch handles to COMPARISON CHART window.
		waitUntilElementIsClickable(pageLib.getComparisonChart());
		pageLib.getComparisonChart().click();
		Utility.windowHandles();
		logger.info("Window handle switch to: " + driver.getCurrentUrl());
		
		//Check comparison chart colors
		String initColor = "";
		for(String color:comparisonChartStockColors(pageLib.getComparisonChart_chartedSymbols())){
			initColor = color;
			logger.info("cur color: "+color);
		}
		if(initColor.contains("rgb(0,0,0)") && pageLib.getComparisonChart_keyScale().getText().contains("100"))
			Assert.assertTrue(true,"Initial symbol charted is black and 100 is present in scale");
		else
			Assert.fail("Initial color is not BLACK or 100 NOT displayed in scale");
		
		Utility.closeWindow();
	}
	
	
	/*
	* Method Description (TC1020): Verify Comparison Chart addSymbol
	* Created By:- Michael D,
	* Changes made#1: 3/12/17
	*/
	public void tc1020_VerifyComparisonChart_addSymbol(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getCompanyInfo_symbol());
		//local vars
		boolean passed = false;
		List<String> compCharts_stockColors_before = new ArrayList<String>();
		List<String> compCharts_stockColors_after = new ArrayList<String>();
		String stock = "TSLA";
		//opening comparison charts. wait 5 sec. switch window handles
		waitUntilElementIsClickable(pageLib.getComparisonChart());
		pageLib.getComparisonChart().click();
		Utility.windowHandles();
		logger.info("Window handle switch to: " + driver.getCurrentUrl());
		//Return a list of colors charted on comparison chart screen
		compCharts_stockColors_before = comparisonChartStockColors(pageLib.getComparisonChart_chartedSymbols());
		//add new symbol, TSLA, to the chart. Wait 2 seconds to appear.
		waitUntilElementIsClickable(pageLib.getSymbolEntryField());
		Actions action = new Actions(driver);
		action.sendKeys(pageLib.getSymbolEntryField(),stock).sendKeys(Keys.ENTER).build().perform();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//FIRST check to see if stock was added to chart
		//Declare a list of WebElements in Comparison Charts and iterate through result
		List<WebElement> compChartSymbols = pageLib.getComparisonChart_dataBlockSymbols();
		for(WebElement e:compChartSymbols){
			if((e.getText()).contains(stock)){
				passed = true;
				logger.info(stock + " was added to chart");
				break;
			}
			else {
				passed = false;
			}
		}
		//SECOND check to make sure that line is another color
		compCharts_stockColors_after = comparisonChartStockColors(pageLib.getComparisonChart_chartedSymbols());
		String lastColor = compCharts_stockColors_after.get(compCharts_stockColors_after.size()-1);
		if(!compCharts_stockColors_before.contains(lastColor))
			logger.info(lastColor + " was charted with " + stock);
		//RESULT
		Assert.assertEquals(passed,!compCharts_stockColors_before.contains(lastColor), stock + " was not charted with new color: " + lastColor);
		//close COMPARISON chart window. Switch window handle. Wait 1 seconds.
		Utility.closeWindow();
	}

	/*
	* Method Description (TC1021): Verify Comparison Chart addSymbol drop down
	* Created By:- Michael D,
	* Changes made#1: 3/12/17
	*/
	public void tc1021_VerifyComparisonChart_addSymbol_dropDown(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		//local vars
		boolean empty = false;
		List<String> addedSymbols = new ArrayList<String>();
		
		//opening comparison charts. wait 5 sec. switch window handles
		//waitUntilElementIsClickable(pageLib.getCompanyInfo_symbol());
		waitUntilElementIsClickable(pageLib.getComparisonChart());
		pageLib.getComparisonChart().click();
		Utility.windowHandles();
		logger.info("Window handle switch to: " + driver.getCurrentUrl());
		waitUntilElementIsClickable(pageLib.getComparisonChart_symbolDropDown());
		
		//switch cases for 3 sections in drop down
		for(int i=0;i<=2;i++)
		{
			int click_elem = 0;
			pageLib.getComparisonChart_symbolDropDown().click();
			List<WebElement> temp_list = null;
			switch(i) {
			//RECENT symbols case
			case 0:
				temp_list = pageLib.getComparisonChart_recentSymbols();
				click_elem = 3;
				break;
			//POPULAR indices case
			case 1:
				temp_list = pageLib.getComparisonChart_popularIndices();
				click_elem = 4;
				break;
			//ALL indices case
			case 2:
				temp_list = pageLib.getComparisonChart_allIndices();
				click_elem = 10;
				break;
			default:
				break;
			}
			
			//if the size of the list is 0, fail the TC, close the window, and BREAK
			//System.out.println(temp_list.size()); -> has +2 due to section title and section bottom divider
			if(temp_list.size() < 2){
				empty = false;
				break;
			}
			
			//iterate through the selected list from the case statements
			for(WebElement e:temp_list){
				if(temp_list.indexOf(e) == click_elem){
					logger.info("From Drop down, adding " + e.getText() + " to Comparison Chart");
					addedSymbols.add(e.getText().substring(0, e.getText().indexOf(" ")));
					e.click();
				}
			}
			//after selecting what list elem to select, wait for 1.5 sec for elem to be charted
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		if(empty){
			Assert.fail("Section in drop down has returned an empty list");
			Utility.closeWindow();
		}
		
		//Increment count for stocks recently added
		int count_found = 0;
		for(int i=0;i<addedSymbols.size();i++)
		{
			for(WebElement e:pageLib.getComparisonChart_dataBlockSymbols())
			{
				if(e.getText().contains(addedSymbols.get(i)))
				{
					logger.info(e.getText() + " CONTAINS --> " + addedSymbols.get(i));
					count_found++;
					break;
				}
			}
		}
		//RESULT
		Assert.assertEquals(count_found, addedSymbols.size(),"One of the symbols in " + addedSymbols + " was NOT charted");
		//close COMPARISON chart window. Switch window handle. Wait 1 seconds.
		Utility.closeWindow();
	}
	
	/*
	* Method Description (TC1022): Verifying Comparison Chart remove symbol content and confirming removal
	* Created By:- Michael D,
	* Changes made#1: 3/12/17
	*/
	public void tc1022_VerifyComparisonChart_removeSymbolContent(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		//local vars
		boolean passed = true;
		//opening comparison charts. wait 5 sec. switch window handles
		//waitUntilElementIsClickable(pageLib.getCompanyInfo_symbol());
		waitUntilElementIsClickable(pageLib.getComparisonChart());
		pageLib.getComparisonChart().click();
		Utility.windowHandles();
		logger.info("Window handle switch to: " + driver.getCurrentUrl());
		waitUntilElementIsClickable(pageLib.getComparisonChart_trashButton());
		pageLib.getComparisonChart_trashButton().click();
		logger.info("Initial # of Charted Symbols: "+pageLib.getComparisonChart_chartedSymbols().size());
		int initCount=pageLib.getComparisonChart_chartedSymbols().size();
		
		
		for(WebElement e:pageLib.getComparisonChart_deleteSymbolsContent()){
			//get elem on data block corresponding to elem on trash icon drop down list
			WebElement current_elem = pageLib.getComparisonChart_dataBlockSymbols().get(pageLib.getComparisonChart_deleteSymbolsContent().indexOf(e));
			//iterating through list of trash icon dd, get text up to new line
			String del_temp_symbol = e.getText().substring(0,e.getText().indexOf("\n"));
			
			//check if trash icon drop down list matches with comparison chart data block
			//check to see if elem text on data block matches with trash icon dd elem text
			if(current_elem.getText().contains(del_temp_symbol)){
				logger.info(del_temp_symbol+" found in comparison chart data block and trash icon drop down");
				e.click();
				logger.info(del_temp_symbol+" has been DELETED from COMPARISON chart");
				try{
					Thread.sleep(2500);
				}catch(Exception ex){
					logger.info(ex);				
				}
			}
			else{
				logger.info("Inconsistency found with symbol -> "+del_temp_symbol);
				passed = false;
			}
		}
		Assert.assertTrue(pageLib.getComparisonChart_chartedSymbols().size()<initCount,"Symbol NOT deleted correctly");
		Utility.closeWindow();
	}
	
	/*
	* Method Description (TC1023): Verifying Comparison Chart remove ALL symbols links
	* Created By:- Michael D,
	* Changes made#1: 3/13/17
	*/
	public void tc1023_VerifyComparisonChart_removeAllSymbols()
	{
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		//Click on COMPARISON CHART icon. switch window handles
		waitUntilElementIsClickable(pageLib.getComparisonChart());
		pageLib.getComparisonChart().click();
		Utility.windowHandles();
		
		//Click on Trash icon followed by Remove ALL symbols link
		waitUntilElementIsClickable(pageLib.getComparisonChart_trashButton());
		pageLib.getComparisonChart_trashButton().click();
		waitUntilElementIsClickable(pageLib.getdeleteAllSymbolsCompChartsLINK());
		pageLib.getdeleteAllSymbolsCompChartsLINK().click();
		waitUntilElementisVisible(pageLib.getModalBoxConfirm_compChart());
		
		//Assert confirmation modal box has correct TEXT
		boolean isText=pageLib.getModalBoxConfirm_compChart().getText().contains("Remove All Symbols?");
		isText = isText && pageLib.getModalBoxConfirm_compChart().getText().contains("Cancel Remove");
		Assert.assertTrue(isText,"modal box does NOT contain correct text");
		logger.info("The following TEXT is PRESENT"+pageLib.getModalBoxConfirm_compChart().getText());
		
		//Click on 'Cancel' button, Remove ALL symbols link start process again
		pageLib.getCancelButtonModalBox().click();
		waitUntilVisibilityOfElement();
		//COMPARISON charts should go back to modal-FREE view.
		//Click on trash icon followed by Remove ALL symbols link
		if(pageLib.getModalPanel().getCssValue("display").contains("none"))
		{
			//Again click on trash icon, remove all symbols link, and Remove all this time
			waitUntilElementIsClickable(pageLib.getComparisonChart_trashButton());
			pageLib.getComparisonChart_trashButton().click();
			waitUntilElementIsClickable(pageLib.getdeleteAllSymbolsCompChartsLINK());
			pageLib.getdeleteAllSymbolsCompChartsLINK().click();
			waitUntilElementisVisible(pageLib.getModalBoxConfirm_compChart());
			//click REMOVE all symbols links
			pageLib.getRemoveButtonModalBox().click();
			waitUntilVisibilityOfElement();
			Assert.assertTrue(pageLib.getComparisonChart_chartedSymbols().size()==1,"COMPARISON CHART is NOT empty");
		}
		else{
			Assert.fail("Cancel button in COMPARISON CHARTS, remove all link, did NOT work correctly");
		}
		Utility.closeWindow();
	}

	/*
	* Method Description (TC1024): Verifying Comparison Chart Add a List Modal Box is displayed with correct content
	* Created By:- Michael D,
	* Changes made#1: 3/13/17
	*/
	public void tc1024_VerifyComparisonChart_addAListModalBox(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		//local vars
		int LM_MyList_size=pageLib.getMyLists().size();
		String FooterNoteCompCharts="A maximum of 50 symbols can be added to a Comparison Chart at one time";
		
		//opening comparison charts. switch window handles
		waitUntilElementIsClickable(pageLib.getComparisonChart());
		pageLib.getComparisonChart().click();
		Utility.windowHandles();
		logger.info("Window handle switch to: " + driver.getCurrentUrl());
		
		//Clcking on Add a List button
		waitUntilElementIsClickable(pageLib.getAddListButton_CompCharts());
		pageLib.getAddListButton_CompCharts().click();
		waitUntilElementisVisible(pageLib.getAddList_comparisonFooterNote());
		Assert.assertTrue(pageLib.getAddList_modalBox().getCssValue("display").contains("block"),"Add to List dialog box NOT opened");
		logger.info("Add to List modal dialog box, COMP CHART, displayed correctly: "+pageLib.getAddList_modalBox().getCssValue("display"));
		
		//Click to expand My List section
		waitUntilElementIsClickable(pageLib.getMyListSection_CompCharts());
		if(pageLib.getMyListSection_CompCharts().getAttribute("class").contains("isFileOpen"))
			pageLib.getMyListSection_CompCharts().click();
		//while My List tree NOT displayed, LOOP
		while(pageLib.getMyListSectionTree_CompCharts().getCssValue("display").contains("none"));
		//My List Tree content is NOW displayed, VERIFY user created list size
		Assert.assertTrue(pageLib.getMyListSectionTreeCONTENT_CompCharts().size()==LM_MyList_size,"LM My Lists do NOT equal COMPARISON CHARTS My Lists");
		logger.info("My Lists and Comparison Chart users lists content are equal");
		
		//If footer note is displayed, VERIFY correct TEXT
		if(pageLib.getAddList_comparisonFooterNote().isDisplayed())
		{
			Assert.assertTrue(pageLib.getAddList_comparisonFooterNote().getText().contains(FooterNoteCompCharts),"Footer Note for COMPARISON CHARTS is NOT correct");
			logger.info("Footer Note for COMPARISON CHARTS is has correct TEXT");
		}
		else
		{
			Assert.fail("Footer Note for COMPARISON CHARTS is NOT displayed");
		}
		Utility.closeWindow();
	}
	
	
	public void tc1000_VerifyChartedSymbol_priceData(){
		//STAGING PRICE DATA PULLED FROM DB62MASTER, wondb
		//TODO: get data from excel sheet (valid, unvalid tickers)
		
		waitUntilElementisVisible(pageLib.getCompanyInfo_symbol());
		//Dev purposes -> COMMENT AFTERWARDS
		pageLib.getSymbolEntryField().sendKeys("AAPL");
		waitUntilElementIsClickable(pageLib.getDailyButton());
		pageLib.getDailyButton().click();
		
		
		//GET Symbol and periodicity selected
		//need to add '' around ticker symbol in order to be able to use in WHERE clause
		String symbol = "'"+pageLib.getSymbolEntryField().getAttribute("value")+"'";
		String sel_periodicity = "";
		for(WebElement e:pageLib.getPeriodicitySelected()){
			if(e.getAttribute("class").contains("chartButtonActive"))
				sel_periodicity = e.getText();
		}
		System.out.println(symbol + " -- " + sel_periodicity);
		waitUntilVisibilityOfElement();
		
		
		//****************** HERE*********//
		//WHSF = weekly (WAHSF = archived) -> not split adjusted
		//MHSF = weekly (MAHSF = archived) -> not split adjusted
		//prod latest node [695]
		//stage [695] latest node -> cont. changing due to data being updated!!!
		//System.out.println("string2 "+ (String) ((JavascriptExecutor)driver).executeScript("return document.title"));
		
		//TreeMap preserves order, a HashMap does not (for lookup optimization->hashes things)
		TreeMap<String,List<String>> FrontEnd_dict = new TreeMap<String,List<String>>();
		
		//NEEDS TO RUN AFTER MARKET CLOSE TO GET LATEST NODE
		//0-851(latest node) -> 852 current day
		//Price
		//System.out.println(((JavascriptExecutor)driver).executeScript("return chart.datasource.priceChartDatasource.priceSeries.length.toString()"));
		String numPriceNodes = (String)((JavascriptExecutor)driver).executeScript("return chart.datasource.priceChartDatasource.priceSeries.length.toString()");
		int priceNodesCount = Integer.parseInt(numPriceNodes);
		//TODO conditional to tell what time of day it is
		//System.out.println(numPriceNodes);
		
		
		//(-2) for NOW to get YESTERDAY as the MOST CURRENT NODE
		for(int i=priceNodesCount-2;i>=0;i--){
			List<String> temp_values = new ArrayList<String>();
			String temp_date = (String)((JavascriptExecutor)driver).executeScript("return chart.datasource.priceChartDatasource.priceSeries["+i+"].argument.toISOString().split('T')[0]");
			String temp_close = (String)((JavascriptExecutor)driver).executeScript("return chart.datasource.priceChartDatasource.priceSeries["+i+"].value.toString()");
			String temp_low = (String)((JavascriptExecutor)driver).executeScript("return chart.datasource.priceChartDatasource.priceSeries["+i+"].lowValue.toString()");
			String temp_high = (String)((JavascriptExecutor)driver).executeScript("return chart.datasource.priceChartDatasource.priceSeries["+i+"].highValue.toString()");
			String temp_vol = (String)((JavascriptExecutor)driver).executeScript("return chart.datasource.priceChartDatasource.volumeSeries["+i+"].value.toString()");
			//arList.addAll(Arrays.asList(1, 2, 3, 4, 5));
			temp_values.addAll(Arrays.asList(temp_close,temp_low,temp_high,temp_vol));
			FrontEnd_dict.put(temp_date,temp_values);
		}
		
		String oldest_date = "'"+FrontEnd_dict.firstKey()+"'";
		System.out.println("oldest date "+oldest_date);
		System.out.println(FrontEnd_dict.size());
		for (String key: FrontEnd_dict.keySet()){ 
            System.out.println(key+" "+FrontEnd_dict.get(key));  
		}
		
		
		//chart.datasource.priceChartDatasource.priceSeries 
		//window.chart.datasource.priceChartDatasource.priceSeries
		//Array[229]
		
		//DEBUGGING PURPOSES
		//date
		//System.out.println(((JavascriptExecutor)driver).executeScript("return chart.datasource.priceChartDatasource.priceSeries[694].argument.toISOString().split('T')[0]"));
		//high value
		//System.out.println(((JavascriptExecutor)driver).executeScript("return chart.datasource.priceChartDatasource.priceSeries[694].highValue.toString()"));
		//low value
		//System.out.println(((JavascriptExecutor)driver).executeScript("return chart.datasource.priceChartDatasource.priceSeries[694].lowValue"));
		//close value
		//System.out.println(((JavascriptExecutor)driver).executeScript("return chart.datasource.priceChartDatasource.priceSeries[694].value"));
		//Volume
		//System.out.println(((JavascriptExecutor)driver).executeScript("return chart.datasource.priceChartDatasource.volumeSeries[694].value"));
		//DEBUGGING
		TreeMap<String,List<String>> BackEnd_dict = new TreeMap<String,List<String>>();
		Connection con;
		try{
			System.out.println("Inside TRY/CATCH 1");
			//con = DriverManager.getConnection("jdbc:sqlserver://db62master;databaseName=wondb;integratedSecurity=true;packetSize=4096;applicationName=ms-services;sendStringParametersAsUnicode=false;responseBuffering=full");
			con = DriverManager.getConnection("jdbc:sqlserver://db62master;databaseName=wondb;integratedSecurity=true");
			System.out.println(con);
			Statement st = con.createStatement();
			
			//GET OSID: String sql_getOSID = String.format("select top 1 OSID from SECMaster where Symbol = %s", symbol);
			String sql_getOSID = "select top 1 OSID from SECMaster where Symbol = " + symbol;
			ResultSet rs = st.executeQuery(sql_getOSID);
			String curr_OSID = "";
			while (rs.next()) {
				System.out.println(rs.getString("OSID"));
				curr_OSID = rs.getString("OSID");
			}
			
			//USE CURRENT SYMBOL OSID TO GET DATA FROM DB BY ASC ORDER BC OF TREEMAP
			//h.Date > DATEADD(YYYY,-2,getdate())
			String sql_getPrices = "select h.Date, h.Price, h.Low, h.High, (h.Volume*100) as Vol from secMaster sM inner join HSF h on (sM.OSID = h.OSID) inner join hhsfInt hI on (hI.CountryCode = 1 and hI.Holiday = 1 and hI.HDate = h.Date) where sM.OSID = "+curr_OSID+" and h.Date > "+oldest_date+" order by h.Date asc";
			rs = st.executeQuery(sql_getPrices);
			while (rs.next()) {
				List<String> DB_temp_values = new ArrayList<String>();
				String DB_date = rs.getString("Date").substring(0,rs.getString("Date").indexOf(" "));
				//String date_only = date_time.substring(0,date_time.indexOf(" "));
				String DB_close = rs.getString("Price");
				String DB_low = rs.getString("Low");
				String DB_high = rs.getString("High");
				String DB_vol = rs.getString("Vol");
				//price = String
				System.out.println(DB_date + " - " + DB_close);
				DB_temp_values.addAll(Arrays.asList(DB_close,DB_low,DB_high,DB_vol));
				BackEnd_dict.put(DB_date,DB_temp_values);
			}
			System.out.println("FINISHED QUERYING DB...");
		}catch (Exception e){
			System.out.println("QUERYING DB FAIL *****");
			System.out.println(e);
			e.getStackTrace();
		}
		
		for (String key: BackEnd_dict.keySet()){ 
            System.out.println(key+" "+BackEnd_dict.get(key));  
		}
		
		Assert.fail("not done yet..");
	}
	
	//testCase:0158:In the List Manager, navigate to REPORTS>MARKETSMITH GROWTH250>G250 - PATTERN RECOGNITION> RECENT BREAKOUTS. All of these charts should have patterns. Bring up one of the charts.
	public void tc0158_VerifyRecentBreakOutsCharts(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getReportsLink());
     	WebElement reportsLink=pageLib.getReportsLink();
     	if(!(pageLib.getReportClass().getAttribute("class").contains("down"))){
     	 reportsLink.click();
     	}
     	waitUntilElementIsClickable(pageLib.getMSGrowthFoderLink());
     	WebElement msgrowthFolderLink=pageLib.getMSGrowthFoderLink();
     	if(!(pageLib.getMsGrowthDownLink().getAttribute("class").contains("down"))){
     	 msgrowthFolderLink.click();
	    }
     	waitUntilElementIsClickable(pageLib.getg250PatternRecFolder());
     	if(!(pageLib.getg250PatternRecDownLink().getAttribute("class").contains("down"))){
     	  pageLib.getMSGrowthFoderLink().click();
     	}
     	((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageLib.getrecentBreakOutsList());
     	//pageLib.getrecentBreakOutsList().click();
     	String recentBreakoutListText= pageLib.getrecentBreakOutsList().getText();
     	waitUntilTextTobePresentInElement(pageLib.getCurrentListName(),recentBreakoutListText);
     	waitUntilVisibilityOfElement();
     	pageLib.getDailyButton().click();
     	waitUntilElementisVisible(pageLib.getCompanyInfo_symbol());
     	Actions action=new Actions(driver);
     	String selectedTickerText=pageLib.getselectFirstTickerFromLM().getText();
     	action.doubleClick(pageLib.getselectFirstTickerFromLM()).build().perform();
     	waitUntilTextTobePresentInElement(pageLib.getChartSymbol(), selectedTickerText);
     	waitUntilElementisVisible(pageLib.getpivotText());
     	Assert.assertTrue(pageLib.getpivotText().isDisplayed(), "Ticker does not have pattern");
	}
	
	//testCase:0176:Go to a chart that has an ALERT configured for it. Click the CHART TOOLS button. Toggle the ALERTS checkbox. You should see a small black triangular arrow icon appear and disappear on the right side of the chart, 
	//pointing to the exact point where the alert is set to trigger.
	public void tc0176_VerifyBlackTriangularArrow(String symbol){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		Utility.EnterStockSymbol(symbol);
		waitUntilVisibilityOfElement();
		waitUntilElementIsClickable(pageLib.getchartToolButton());
		pageLib.getchartToolButton().click();
		waitUntilElementisVisible(pageLib.getwaitForChartToolOptions());
		List<WebElement> allToolOptions=pageLib.getallToolOptions();
		if(!(allToolOptions.get(0).getAttribute("class").contains("imgchecked"))){
			allToolOptions.get(0).click();
		}
		List<WebElement> alertImgOnChart=pageLib.getallAlertImgonChart();
		if(alertImgOnChart.size()!=0){
			for(int i=0;i<alertImgOnChart.size();i++){
				Assert.assertTrue(alertImgOnChart.get(i).isDisplayed(), "Black triangular arrow not displayed");
			}
		}
		else{
			logger.info("No alerts for this symbol");
		}
	}
	
	//testCase:0177:MARKUP TOOL: Click CHART TOOLS > MARKUP TOOL. Verify that the markup toolbar appears on the chart.
	public void tc0177_VerifyMarkupToolOption(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilVisibilityOfElement();
		waitUntilElementIsClickable(pageLib.getchartToolButton());
		if(pageLib.getchartToolButton().getAttribute("class").contains("toolsClicked")){
			pageLib.getchartToolButton().click();
		}
		waitUntilElementisVisible(pageLib.getwaitForChartToolOptions());
		List<WebElement> allToolOptions=pageLib.getallToolOptions();
		if(!(allToolOptions.get(2).getAttribute("class").contains("imgchecked"))){
			allToolOptions.get(2).click();
		}
		waitUntilElementisVisible(pageLib.getmarkUpToolBar());
		Assert.assertTrue(pageLib.getmarkUpToolBar().isDisplayed(),"Mark up tool bar not appeared");
		waitUntilVisibilityOfElement();
		waitUntilElementIsClickable(pageLib.getchartToolButton());
		pageLib.getchartToolButton().click();
		waitUntilElementisVisible(pageLib.getwaitForChartToolOptions());
		allToolOptions.get(2).click();
	}
	
	//testCase:0211:Type in ticker AAPL to bring up Apple Inc. Does the chart appear quickly? (within 1-2 seconds?)
	public void tc0211_VerifyChartAppearingTime(String symbol){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getSymbolEntryField());
		pageLib.getSymbolEntryField().clear();
		pageLib.getSymbolEntryField().sendKeys(symbol);
		Actions actions =new Actions(driver);
		actions.sendKeys(Keys.ENTER).build().perform();
		long seconds=2000;//give 2 seconds
		try {
			Thread.sleep(seconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertEquals(pageLib.getChartSymbol().getText().trim(), "Intl Business Machines","Exceeded 2 seconds");
	}
	
	//testCase:0214:Verify that databox displayed when user select option in setting
	public void tc0214_VerifyDataBoxesFOrEnteredTicker(){
	   Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
	   pageLib.getDailyButton().click();
	   waitUntilElementIsClickable(pageLib.getchartToolButton());
	   pageLib.getchartToolButton().click();
	   waitUntilElementisVisible(pageLib.getwaitForChartToolOptions());
	   List<WebElement> allToolOptions=pageLib.getallToolOptions();
	   if(!(allToolOptions.get(4).getAttribute("class").contains("imgchecked"))){
			allToolOptions.get(4).click();
		}
		waitUntilElementisVisible(pageLib.getcompanyInformation());
		Assert.assertTrue(pageLib.getcompanyInformation().isDisplayed(),"CompnayInfoNot displyed");
		Assert.assertTrue(pageLib.getdailyBoxInfo().isDisplayed(), "Daily box not displayed");
	}
	
	//testCase:0235:Click on the WEEKLY button to bring up a weekly chart. Does the chart appear?
	public void tc0235_VerifyWeeklyButton(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getweeklyButton());
		pageLib.getweeklyButton().click();
		waitUntilElementisVisible(pageLib.getCompanyInfo_symbol());
		Assert.assertTrue(pageLib.getweeklyButton().getAttribute("class").contains("chartButtonActive"), "WEEKLY chart not opened");
	}
	
	//testCase:0240:Is the last tick for the last valid trading date?
	public void tc0240_VerifyLastTradingDate(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getopenCalendar());
		if(!(pageLib.getcalendarStatus().getAttribute("class").contains("imgRotate"))){
			pageLib.getopenCalendar().click();
		}
		waitUntilElementisVisible(pageLib.getresetToToday());
		pageLib.getresetToToday().click();
		String actualDate=pageLib.getcurrentDate().getText();
		String lastTradingDate=(String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML",pageLib.getlastTradingDate());
		System.out.println("Last trading date:"+lastTradingDate);
		String[] lastTradingDate1=lastTradingDate.split("\\.");
		for(int i=0;i<lastTradingDate1.length;i++){
			System.out.println(lastTradingDate1[i]);
		}

		String LastTradingDay= lastTradingDate1[1];
		Assert.assertEquals(actualDate, LastTradingDay,"Date not matched");
		pageLib.getopenCalendar().click();
	}
	
	//testCase:0259:Click on the MONTHLY button to bring up a monthly chart. Does the chart appear?
	public void tc0259_VerifyMonthlyButton(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getmonthlyButton());
		pageLib.getmonthlyButton().click();
		waitUntilElementisVisible(pageLib.getCompanyInfo_symbol());
		Assert.assertTrue(pageLib.getmonthlyButton().getAttribute("class").contains("chartButtonActive"), "Monthly chart not opened");
		pageLib.getDailyButton().click();
		waitUntilElementisVisible(pageLib.getCompanyInfo_symbol());
	}
	
	//testCase:0270:Does the top Data Box contain information for the current Stock? (Company Name, Stock Symbol, Stock Exchange, Industry Group, Market Capitalization, URL Address, Volume, Price, Price Change, 50-Day Avg Volume, IPO Date)
	public void tc0270_VerifyTopDataBoxInfo(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilVisibilityOfElement();
		waitUntilElementIsClickable(pageLib.getchartToolButton());
		pageLib.getchartToolButton().click();
		waitUntilElementisVisible(pageLib.getwaitForChartToolOptions());
		List<WebElement> allToolOptions=pageLib.getallToolOptions();
		if(!(allToolOptions.get(6).getAttribute("class").contains("imgchecked"))){
			allToolOptions.get(6).click();
		}
		pageLib.getmonthlyButton().click();
		waitUntilVisibilityOfElement();
		waitUntilElementisVisible(pageLib.getCompanyInfo_symbol());
		//String companySymbolGroupInfo[]=pageLib.getsymbolExchangeGroupInfo().getText().split(" ",5);
		/*Assert.assertTrue(pageLib.getsymbolExchangeGroupInfo().isDisplayed(), "Symbol,exchange,group and volume info not displayed");
		Assert.assertTrue(pageLib.geturlLink().isDisplayed(),"URL link is missing");
		Assert.assertTrue(pageLib.getmarketCap().isDisplayed(), "MarketCap has not shown");*/
		 List<WebElement> companyLeftInfo=pageLib.getcompanyLeftInfo();
		 for(int i=0;i<companyLeftInfo.size();i++){
			 Assert.assertTrue(companyLeftInfo.get(i).isDisplayed(), "Symbol,exchange,group and volume info not displayed");
		 }
		List<WebElement> companyCenterInfo=pageLib.getcompanyCenterInfo();
		Assert.assertTrue(companyCenterInfo.get(0).getText().contains("50-Day"), "50-Day Avg Volume info missing");
		Assert.assertTrue(companyCenterInfo.get(1).getText().contains("IPO"), "IPO date missing");
		
		List<WebElement> companyRightInfo=pageLib.getcompanyRightInfo();
		for(int i=0;i<companyRightInfo.size();i++){
			Assert.assertTrue(companyRightInfo.get(i).isDisplayed(),"Price and price change info missing");
		}
	}
	
	//testCase:277:Click on the INTRADAY button to bring up an intraday chart. Does the chart appear for 1, 5, 10, 15, 30 and 60 Min?
	public void tc0277_VerifyIntraDayOptions(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("MSTOOL_TITLE"));
		waitUntilElementIsClickable(pageLib.getintraDayButton());
		pageLib.getintraDayButton().click();
		waitUntilElementisVisible(pageLib.getCompanyInfo_symbol());
		Assert.assertTrue(pageLib.getintraDayButton().getAttribute("class").contains("chartButtonActive"), "IntraDAy chart not opened");
		waitUntilElementIsClickable(pageLib.getintraDayDropdown());
		pageLib.getintraDayDropdown().click();
		List<WebElement> intraDayMinoptions=pageLib.getintradayMinOptions();
		String intraDayOption =intraDayMinoptions.get(1).getText().trim();
		intraDayMinoptions.get(1).click();
		waitUntilElementisVisible(pageLib.getintraDayButton());
		Assert.assertEquals(pageLib.getintraDayButton().getText().trim(),intraDayOption ,"It is not opened for selcted minute ");
		
	}
}
