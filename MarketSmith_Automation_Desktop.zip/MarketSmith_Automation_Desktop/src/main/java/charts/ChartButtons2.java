package charts;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import static genericLib.Utility.*;


import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class ChartButtons2 {
	ChartPageLib pageLib = PageFactory.initElements(driver, ChartPageLib.class);
	
	public void analyzeLogs(){
		//LogEntries logs = driver.manage().logs().g
		LogEntries logs = driver.manage().logs().get("browser");
		//LogEntries logEntries = driver.manage().logs().get(LogType.BROWSER);
        for (LogEntry entry : logs) {
            System.out.println(new Date(entry.getTimestamp()) + " " + entry.getLevel() + " " + entry.getMessage());
            //do something useful with the data
        }
	}
	
	/*
	* Method Description (TC0193): MARKUP TOOL: Click CHART TOOLS > Stochastics. Verify that the stochastics section toggle on the chart.
	* Created By:- Michael D, Created Date:1/27/16 
	* Changes made#1:
	*/
	public void tc0193_verifyToggleOfStochastics()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		//height: 0px = NOT displayed
		//height: 20% = is displayed
		boolean isStochasticsDisplayed = pageLib.getStochasticDataBox().getAttribute("style").contains("20%");
		boolean isToggled = false;

		//click on Chart tool button (ie wrench icon)
		pageLib.getchartToolButton().click();
		
		//Might need to add this if Code Execution gets stuck when clicking the chart tool option button
		//TEMP solution for chart tool menu not displaying on click
		while(!pageLib.getwaitForChartToolOptions().getCssValue("display").contains("block"))
		{
			pageLib.getchartToolButton().click();
		}
		
		//clicking on STOCHASTICS chart option
		waitUntilElementisVisible(pageLib.getStochastics_chartToolOptions());
		pageLib.getStochastics_chartToolOptions().click();
		//DEPENDING on whether stochastics are displayed initially or not, execute logic accordingly
		if(isStochasticsDisplayed)
		{
			logger.info("DISABLE - STOCHASTICS");
			//set boolean to TRUE if toggled correctly, check via Assert
			isToggled = !(pageLib.getStochasticDataBox().getAttribute("style").contains("20%"));
			Assert.assertTrue(isToggled,"Stochastics section NOT hidden when feature toggled DISABLED");
			logger.info("Stochastics setion hidden correctly after toggling DISABLED");
		}
		else
		{
			logger.info("ENABLE - STOCHASTICS");
			//set boolean to TRUE if toggled correctly, check via Assert
			isToggled = pageLib.getStochasticDataBox().getAttribute("style").contains("20%");
			Assert.assertTrue(isToggled,"Stochastics section is NOT displayed when feature toggled ENABLED");
			logger.info("Stochastics displayed correctly after toggling ENABLED");
		}
	}
	
	/*
	* Method Description (TC0194): MARKUP TOOL: Click CHART TOOLS > Data Boxes. Verify the data boxes section toggle on the chart.
	* Created By:- Michael D, Created Date:1/27/16 
	* Changes made#1:
	*/
	public void tc0194_verifyToggleOfDataBoxes()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		boolean isToggled = false;
		boolean areDataBoxesDisplayed = false;
		String sPeriodicity = "";
		
		//Determine periodicity currently selected, SET var
		for(WebElement el:pageLib.getPeriodicitySelected())
		{
			if(el.getAttribute("class").contains("chartButtonActive"))
				sPeriodicity = el.getText();
		}
		
		//click on Chart tool button (ie wrench icon)
		pageLib.getchartToolButton().click();
		//Might need to add this if Code Execution gets stuck when clicking the chart tool option button
		//TEMP solution for chart tool menu not displaying on click
		while(!pageLib.getwaitForChartToolOptions().getCssValue("display").contains("block"))
		{
			pageLib.getchartToolButton().click();
		}
		
		//DEPENDING on periodicity, execute logic accordingly
		if(sPeriodicity.contains("Daily"))
		{
			areDataBoxesDisplayed = pageLib.getDailyDataBoxes().getCssValue("display").contains("block");
			//clicking on DATA BOXES chart option
			waitUntilElementisVisible(pageLib.getDataBoxes_chartToolOptions());
			pageLib.getDataBoxes_chartToolOptions().click();
			//DEPENDING if DATA BOXES are displayed or NOT, execute logic accordingly 
			if(areDataBoxesDisplayed)//pageLib.getDailyDataBoxes().getCssValue("display").contains("block"))
			{
				logger.info("DISABLE - DATA BOXES");
				//set boolean to TRUE if toggled correctly, check via Assert				
				isToggled = pageLib.getDailyDataBoxes().getCssValue("display").contains("none");
				Assert.assertTrue(isToggled,"DAILY- Data Boxes are NOT HIDDEN when feature toggled DISABLED");
				logger.info("Data Boxes are HIDDEN CORRECTLY after toggling DISABLED");
			}
			else{
				logger.info("ENABLE - DATA BOXES");
				//set boolean to TRUE if toggled correctly, check via Assert
				isToggled = pageLib.getDailyDataBoxes().getCssValue("display").contains("block");
				Assert.assertTrue(isToggled,"DAILY- Data Boxes are NOT DISPLAYED when feature toggled ENABLED");
				logger.info("Data Boxes are DISPLAYED CORRECTLY after toggling ENABLED");
			}
		}
		else
		{
			areDataBoxesDisplayed = pageLib.getWeeklyDataBoxes().getCssValue("display").contains("block");
			//clicking on DATA BOXES chart option
			waitUntilElementisVisible(pageLib.getDataBoxes_chartToolOptions());
			pageLib.getDataBoxes_chartToolOptions().click();
			//DEPENDING if DATA BOXES are displayed or NOT, execute logic accordingly 
			if(areDataBoxesDisplayed)//pageLib.getWeeklyDataBoxes().getCssValue("display").contains("block"))
			{
				logger.info("DISABLE - DATA BOXES");
				//set boolean to TRUE if toggled correctly, check via Assert
				isToggled = !(pageLib.getWeeklyDataBoxes().getCssValue("display").contains("block"));
				Assert.assertTrue(isToggled,"WEEKLY- Data Boxes are NOT HIDDEN when feature toggled DISABLED");
				logger.info("WEEKLY- Data Boxes are HIDDEN CORRECTLY after toggling DISABLED");
			}
			else{
				logger.info("ENABLE - DATA BOXES");
				//set boolean to TRUE if toggled correctly, check via Assert
				isToggled = pageLib.getWeeklyDataBoxes().getCssValue("display").contains("block");
				Assert.assertTrue(isToggled,"WEEKLY- Data Boxes are NOT DISPLAYED when feature toggled ENABLED");
				logger.info("WEEKLY- Data Boxes are DISPLAYED CORRECTLY after toggling ENABLED");
			}	
		}
	}
	
	
	/*
	* Method Description (TC0195): MARKUP TOOL: Click CHART TOOLS > Corporate Events. Verify that the Corporate Events indicators toggle on the chart.
	* Created By:- Michael D, Created Date:1/27/16 
	* Changes made#1:
	*/
	public void tc0195_verifyToggleOfCorporateEvents()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		boolean isCorpEventsDisplayed = pageLib.getCorporateEvents().getCssValue("display").contains("block");
		boolean isToggled = false;
		//System.out.println(pageLib.getCorporateEvents().getCssValue("display"));
		pageLib.getchartToolButton().click();
		//Might need to add this if Code Execution gets stuck when clicking the chart tool option button
		//TEMP solution for chart tool menu not displaying on click
		while(!pageLib.getwaitForChartToolOptions().getCssValue("display").contains("block"))
		{
			pageLib.getchartToolButton().click();
		}
		//clicking on CORPORATE EVENTS chart option
		waitUntilElementisVisible(pageLib.getCorporateEvents_chartToolOptions());
		pageLib.getCorporateEvents_chartToolOptions().click();
		if(isCorpEventsDisplayed)
		{
			logger.info("DISABLE - CORPORATE EVENTS");
			//set boolean to TRUE if toggled correctly, check via Assert
			isToggled = pageLib.getCorporateEvents().getCssValue("display").contains("none");
			Assert.assertTrue(isToggled,"Corporate Events NOT hidden when feature toggled DISABLED");
			logger.info("Corporate Events hidden correctly after toggling DISABLED");
		}
		else{
			logger.info("ENABLE - CORPORATE EVENTS");
			//set boolean to TRUE if toggled correctly, check via Assert
			isToggled = pageLib.getCorporateEvents().getCssValue("display").contains("block");
			Assert.assertTrue(isToggled,"Corporate Events is NOT DISPLAYED when feature toggled ENABLED");
			logger.info("Corporate Events DISPLAYED CORRECTLY after toggling ENABLED");
		}
	}

	
	/*
	* Method Description (TC0196): MARKUP TOOL: Click CHART TOOLS > Stochastics. Verify that the stochastics section toggles on the chart.
	* Created By:- Michael D, Created Date:1/27/16 
	* Changes made#1:
	*/
	
	
	
	/*
	* Method Description (TC0197): MARKUP TOOL: Click CHART TOOLS > Stochastics. Verify that the stochastics section toggles on the chart.
	* Created By:- Michael D, Created Date:1/27/16 
	* Changes made#1:
	*/
	public void tc0197_verifyToggleOfIndexLine()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		boolean isIndexLineDisplayed = pageLib.getIndexLine().getCssValue("display").contains("block");
		boolean isToggled = false;
		//System.out.println(pageLib.getCorporateEvents().getCssValue("display"));
		pageLib.getchartToolButton().click();
		//Might need to add this if Code Execution gets stuck when clicking the chart tool option button
		//TEMP solution for chart tool menu not displaying on click
		while(!pageLib.getwaitForChartToolOptions().getCssValue("display").contains("block"))
		{
			pageLib.getchartToolButton().click();
		}
		//clicking on INDEX LINE chart option
		waitUntilElementisVisible(pageLib.getIndexLine_chartToolOptions());
		pageLib.getIndexLine_chartToolOptions().click();
		if(isIndexLineDisplayed)
		{
			logger.info("DISABLE - INDEX LINE");
			//set boolean to TRUE if toggled correctly, check via Assert
			isToggled = pageLib.getIndexLine().getCssValue("display").contains("none");
			Assert.assertTrue(isToggled,"Index Line NOT HIDDEN when feature toggled DISABLED");
			logger.info("Index Line HIDDEN CORRECTLY after toggling DISABLED");
		}
		else{
			logger.info("ENABLE - INDEX LINE");
			//set boolean to TRUE if toggled correctly, check via Assert
			isToggled = pageLib.getIndexLine().getCssValue("display").contains("block");
			Assert.assertTrue(isToggled,"Index Line is NOT DISPLAYED when feature toggled ENABLED");
			logger.info("Index Line DISPLAYED CORRECTLY after toggling ENABLED");
		}

	}

	/*
	* Method Description (TC0197): MARKUP TOOL: Click CHART TOOLS > Stochastics. Verify that the stochastics section toggles on the chart.
	* Created By:- Michael D, Created Date:1/27/16 
	* Changes made#1:
	*/
	public void tc0198_verifyChartLegend()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		boolean isOpen= false;
		//Get handle count before clicking on Chart Legend option
		int handleCount = driver.getWindowHandles().size();
		
		//Click on Chart Tool option (ie wrench icon)
		pageLib.getchartToolButton().click();
		//Might need to add this if Code Execution gets stuck when clicking the chart tool option button
		//TEMP solution for chart tool menu not displaying on click
		while(!pageLib.getwaitForChartToolOptions().getCssValue("display").contains("block"))
		{
			pageLib.getchartToolButton().click();
		}
		//clicking on CHART LEGEND chart option
		waitUntilElementisVisible(pageLib.getChartLegend_chartToolOptions());
		pageLib.getChartLegend_chartToolOptions().click();
		
		//While handle count less than 3 (ie NEW WINDOW HAS NOT OPENED) 
		while(handleCount < 3)
		{
			handleCount = driver.getWindowHandles().size();
		}
		//once SELENIUM picks up the new window, switch to NEW window
		windowHandles();
		logger.info("Changing window handle to URL, "+driver.getCurrentUrl());
		//SET boolean to true, and check via Assert
		isOpen = driver.getCurrentUrl().contains("ChartLegends");
		Assert.assertTrue(isOpen,"New window Chart Legend did NOT open");
		logger.info("Chart Legend window opened correctly");
		//Close Chart Legend window and return to parent window
		driver.close();
		windowHandles();
	}
	
	/*
	* Method Description (TC0197): MARKUP TOOL: Click CHART TOOLS > Stochastics. Verify that the stochastics section toggles on the chart.
	* Created By:- Michael D, Created Date:1/27/16 
	* Changes made#1:
	*/
	public void tc0199_verifyMovingAvgsWindow()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		boolean isModalDisplayed = false;

		//Click on Chart Tool option (ie wrench icon)
		pageLib.getchartToolButton().click();
		//Might need to add this if Code Execution gets stuck when clicking the chart tool option button
		//TEMP solution for chart tool menu not displaying on click
		while(!pageLib.getwaitForChartToolOptions().getCssValue("display").contains("block"))
		{
			pageLib.getchartToolButton().click();
		}
		
		//clicking on MOVING AVGS chart option
		waitUntilElementisVisible(pageLib.getMvgAvgs_chartToolOptions());
		pageLib.getMvgAvgs_chartToolOptions().click();
		//SET boolean to true, and check via Assert
		isModalDisplayed = pageLib.getMovingAvgsModalWindow().getCssValue("display").contains("block");
		Assert.assertTrue(isModalDisplayed,"Moving Averages modal window is NOT displayed");
		logger.info("Moving Averages modal window is NOT displayed");
		//Close Modal window
		pageLib.getCloseButton_MovingAvgsWindow().click();
	}
	
	/*
	* Method Description (TC0197): MARKUP TOOL: Click CHART TOOLS > Stochastics. Verify that the stochastics section toggles on the chart.
	* Created By:- Michael D, Created Date:1/27/16 
	* Changes made#1:
	*/
	public void tc0205_verifyLinePenWindow()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		boolean isModalDisplayed = false;

		//Click on Chart Tool option (ie wrench icon)
		pageLib.getchartToolButton().click();
		//Might need to add this if Code Execution gets stuck when clicking the chart tool option button
		//TEMP solution for chart tool menu not displaying on click
		while(!pageLib.getwaitForChartToolOptions().getCssValue("display").contains("block"))
		{
			pageLib.getchartToolButton().click();
		}
		//clicking on LINE PEN chart option
		waitUntilElementisVisible(pageLib.getLinePen_chartToolOptions());
		pageLib.getLinePen_chartToolOptions().click();
		//SET boolean to true, and check via Assert
		//System.out.println(pageLib.getLinePenWindow().getCssValue("style"));
		isModalDisplayed = pageLib.getLinePenWindow().getCssValue("display").contains("block");
		Assert.assertTrue(isModalDisplayed,"Line Pen modal window is NOT displayed");
		logger.info("Line Pen modal window is NOT displayed");
		//Close Modal window
		pageLib.getCloseButton_LinePenWindow().click();
	}
	
	/*
	* Method Description (TC0197): MARKUP TOOL: Click CHART TOOLS > Stochastics. Verify that the stochastics section toggles on the chart.
	* Created By:- Michael D, Created Date:2/8/17 
	* Changes made#1:
	*/
	public void tc0206_verifyTightAreas()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		boolean isTightAreasDisplayed = false;
		boolean isToggled = false;
		boolean isTightAreaFound = false;
		
		//Click on Weekly periodicity Button in the case that it is NOT yet charted
		if(!pageLib.getweeklyButton().getAttribute("class").contains("chartButtonActive"))
		{
			pageLib.getweeklyButton().click();
			waitUntilElementisVisible(pageLib.getMainPriceChart());
		}
		
		//Adding this for loop to RANDOMIZE the RECENT BREAKOUT stock 
		//in the case that it does NOT have 3  wks tight trading
		while(!isTightAreaFound)
		{
			try{
				Thread.sleep(5000);
				logger.info("Stock currently charted is, "+pageLib.getSymbolEntryField().getAttribute("value"));
				if((pageLib.getPriceTightAreas().size()-1) < 0)
				{
					logger.info("Chart a NEW symbol to check for Tight Areas");
					EnterStockSymbol(DB_getRecentBreakOutSymbol());
					waitUntilElementisVisible(pageLib.getMainPriceChart());
				}
				else{
					isTightAreaFound = true;
				}
			}catch(Exception e){
				logger.info(e);
			}
		}
		logger.info("EXIT loop checking tight areas");
		//Get the last weekly tight price area WebElement from List<WebElement>
		WebElement lastTightArea = pageLib.getPriceTightAreas().get(pageLib.getPriceTightAreas().size()-1);
		isTightAreasDisplayed = lastTightArea.getCssValue("display").contains("inline");
		
		//Click on chart tool button
		pageLib.getchartToolButton().click();
		//Might need to add this if Code Execution gets stuck when clicking the chart tool option button
		//TEMP solution for chart tool menu not displaying on click
		while(!pageLib.getwaitForChartToolOptions().getCssValue("display").contains("block"))
		{
			pageLib.getchartToolButton().click();
		}

		//clicking on INDEX LINE chart option
		waitUntilElementisVisible(pageLib.getTightAreas_chartToolOptions());
		pageLib.getTightAreas_chartToolOptions().click();
		if(isTightAreasDisplayed)
		{
			logger.info("DISABLE - TIGHT AREAS");
			//set boolean to TRUE if toggled correctly, check via Assert
			isToggled = lastTightArea.getCssValue("display").contains("none");
			Assert.assertTrue(isToggled,"Tight Areas NOT HIDDEN when feature toggled DISABLED");
			logger.info("Tight Areas HIDDEN CORRECTLY after toggling DISABLED");
		}
		else{
			logger.info("ENABLE - TIGHT AREAS");
			//set boolean to TRUE if toggled correctly, check via Assert
			isToggled = lastTightArea.getCssValue("display").contains("inline");
			Assert.assertTrue(isToggled,"Tight Areas is NOT DISPLAYED when feature toggled ENABLED");
			logger.info("Tight Areas DISPLAYED CORRECTLY after toggling ENABLED");
		}
	}
	
	/*
	* Method Description (TC0207): MARKUP TOOL: Click CHART TOOLS > Key Price Ranges. Verify the 3 Key Price Ranges section toggles on the chart.
	* Created By:- Michael D, Created Date:2/9/17
	* Changes made#1:
	*/
	public void tc0207_verifyKeyPriceRanges()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		//Declare local vars
		boolean isKeyPriceAreasDisplayed = false;
		boolean isToggled = false;
		//Get a symbol who recently broke out of a Base
		String retQuerySymbol = DB_getRecentBreakOutSymbol();

		//if the current symbol charted is NOT the stock returned by the DB query above
		if(!pageLib.getSymbolEntryField().getAttribute("value").contains(retQuerySymbol))
			EnterStockSymbol(retQuerySymbol);
		
		logger.info("Current stock charted is, "+pageLib.getSymbolEntryField().getAttribute("value"));
		//Get the last key price area WebElement from List<WebElement>
		WebElement kpa = pageLib.getKeyPriceAreas().get(pageLib.getKeyPriceAreas().size()-1);
		
		//displays block, NOT inline 
		//System.out.println(kpa.getCssValue("display")); // -> block
		pageLib.getchartToolButton().click();
		//Might need t no add this if Code Execution gets stuck when clicking the chart tool option button
		//TEMP solution for chart tool menu not displaying on click
		while(!pageLib.getwaitForChartToolOptions().getCssValue("display").contains("block"))
		{
			pageLib.getchartToolButton().click();
		}
		//check if WebElement stored above, kpa, is Displayed
		isKeyPriceAreasDisplayed = kpa.getCssValue("display").contains("block");
		//clicking on KEY PRICE RANGES chart option
		waitUntilElementisVisible(pageLib.getKeyPriceRanges_chartToolOptions());
		pageLib.getKeyPriceRanges_chartToolOptions().click();
		//Depending on initial state of MS tool, enable or disble Key Price Ranges
		if(isKeyPriceAreasDisplayed)
		{
			logger.info("DISABLE - KEY PRICE RANGES");
			//set boolean to TRUE if toggled correctly, check via Assert
			for(WebElement e:pageLib.getKeyPriceAreas())
			{
				isToggled = e.getCssValue("display").contains("none");
				Assert.assertTrue(isToggled,"Key Price Ranges NOT HIDDEN when feature toggled DISABLED");
			}
			logger.info("Key Price Ranges HIDDEN CORRECTLY after toggling DISABLED");
		}
		else{
			logger.info("ENABLE - KEY PRICE RANGES");
			//set boolean to TRUE if toggled correctly, check via Assert
			for(WebElement e:pageLib.getKeyPriceAreas())
			{
				isToggled = e.getCssValue("display").contains("block");
				Assert.assertTrue(isToggled,"Key Price Ranges is NOT DISPLAYED when feature toggled ENABLED");
			}
			logger.info("Key Price Ranges DISPLAYED CORRECTLY after toggling ENABLED");
		}
	}
	
	
	/*
	* Method Description (TC0160): Pattern Recognition: Verify % from Pivot box in the upper right hand corner of the Chart
	* Created By:- Michael D, Created Date:2/9/17 
	* Changes made#1:
	*/
	public void tc0160_verifyPercentFromPivot()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		//Declare local vars and get symbol with Recent Break Out
		String retQuerySymbol = DB_getRecentBreakOutSymbol();
		boolean isPivotPercentDisplayed = false;
		
		if(!pageLib.getDailyButton().getAttribute("class").contains("chartButtonActive"))
		{
			pageLib.getDailyButton().click();
			waitUntilElementisVisible(pageLib.getMainPriceChart());
		}

		//if the current symbol charted is NOT the stock returned by the DB query above
		if(!pageLib.getSymbolEntryField().getAttribute("value").contains(retQuerySymbol))
			EnterStockSymbol(retQuerySymbol);
		
		logger.info("Current stock charted is, "+pageLib.getSymbolEntryField().getAttribute("value"));
		//Search Chart button headers for PR button, if found and NOT enabled, then turn ON PR
		for(WebElement e:pageLib.getHeaderChartButtons())
		{
			if(e.getAttribute("class").contains("patternRecognition") && !e.getAttribute("class").contains("patternRecognitionOn"))
				e.click();
		}
		//Check if pivot % text box is displayed
		waitUntilElementisVisible(pageLib.getPercentFromPivotText());
		isPivotPercentDisplayed = pageLib.getPercentFromPivotText().getCssValue("display").contains("block") & pageLib.getPercentFromPivotText().getText().contains("%");
		Assert.assertTrue(isPivotPercentDisplayed,"% from Pivot text box NOT displayed");
		logger.info("% from Pivot text box is displayed correctly");
	}
	
	//private function to return visible/clickable bases list
	//parameters: none
	//return: List<WebElement>
	private List<WebElement> VisibleRecentBases()
	{
		List<WebElement> PRBasesVisible =new ArrayList<WebElement>();
		int currPR = 0;
		for(WebElement p:pageLib.getAllBasePatternsOnChart())
		{
			//Only check most recent patterns with following condition
			//if the current PR is displayed on the Chart, Bases outside of Chart will have a NEGATIVE(-) 'x' coordinate
			if(!p.getAttribute("x").contains("-"))
			{
				try{
					p.click();
					PRBasesVisible.add(p);
					currPR = Integer.parseInt(p.getAttribute("together"));
					logger.info("Currently HOVERING over PR base with class of, "+p.getAttribute("class")+" & ID, "+currPR);
				}catch(Exception e){
					logger.info("PR not clickable due to Data boxes or Expanded Screener. SKIP."+e);
				}
				//currPR = Integer.parseInt(p.getAttribute("together"));
				//logger.info("Currently HOVERING over PR base with class of, "+p.getAttribute("class")+" & ID, "+currPR);
			}
		}
		return PRBasesVisible;
	}
	
	/*
	* Method Description (TC0162): Pattern Recognition: Verify PR tool tip for pattern itself and BreakOut
	* Created By:- Michael D, Created Date:2/20/17 
	* Changes made#1:
	*/ 
	public void tc0162_verifyPRToolTips(){
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		//Decalring local vars
		String retQuerySymbol = DB_getRecentBreakOutSymbol();
		int currPR;
		List<String> greenText = new ArrayList<String> (Arrays.asList("Stage","Pivot","Length","Depth","Handle"));
		List<String> blueText = new ArrayList<String> (Arrays.asList("Price %","Vol %"));
		List<String> checkedTextBoxes =new ArrayList<String>();
		List<WebElement> PRBasesVisible =new ArrayList<WebElement>(); 
		String tempText = "";
		int count = 0;
		
		//Search Chart button headers for PR button, if found and NOT enabled, then turn ON PR
		for(WebElement e:pageLib.getHeaderChartButtons())
		{
			if(e.getAttribute("class").contains("patternRecognition") && !e.getAttribute("class").contains("patternRecognitionOn"))
				e.click();
		}
		
		//If Daily periodicity NOT selected, click on button
		if(!pageLib.getDailyButton().getAttribute("class").contains("chartButtonActive"))
			pageLib.getDailyButton().click();
		
		//if the current symbol charted is NOT the stock returned by the DB query above
		//System.out.println(retQuerySymbol);
		//change back to retQuerySymbol/IRWD/QGTA/  ingn/cbsh
		if(!pageLib.getSymbolEntryField().getAttribute("value").contains(retQuerySymbol))
			EnterStockSymbol(retQuerySymbol);

		PRBasesVisible=VisibleRecentBases();
		
		//FOR ALL the bases visible/clickable on the MS chart, NOT all in DOM
		for(WebElement vPattern:PRBasesVisible)
		{
			//Set current PR ID based on Front end and count (ie hoverboxes checked per pattern) to 0
			currPR=Integer.parseInt(vPattern.getAttribute("together"));
			count = 0;
			//perform HOVER over, FOR ALL patterns visible/clickable
			performMouseHover(vPattern);
			
			//Validate BLUE LINE is displayed for current PR BASE being hovered over
			for(WebElement line:pageLib.getRecent_PR_HoverBoxes_line())
			{
				if(currPR==Integer.parseInt(line.getAttribute("together")))
				{
					Assert.assertTrue(line.getCssValue("display").contains("inline"),"BlUE line is NOT being DISPLAYED when hovering over PR base pattern");
					logger.info("BlUE line correctly DISPLAYED for PR base pattern ID, "+currPR);
				}
			}
			
			//FOR ALL hoverboxes that are available on the DOM
			for(WebElement h:pageLib.getRecent_PR_HoverBoxes())
			{
				try{
					//if(PRBasesVisible_ID.contains(Integer.parseInt(h.getAttribute("together"))) & h.getCssValue("display").contains("inline"))
					//if current HOVERBOX has same ID as currPR base AND the HOVERBOX is displayed (ie hovered over)
					if(currPR==Integer.parseInt(h.getAttribute("together")) && h.getCssValue("display").contains("inline"))
					{
						//FOR ALL the text boxes available on the DOM
						for(WebElement textBox:pageLib.getRecent_PR_HoverBoxes_text())
						{
							//if(PRBasesVisible_ID.contains(Integer.parseInt(textBox.getAttribute("together"))) && !checkedTextBoxes.contains(textBox.getAttribute("x")))
							//System.out.println(currPR+"=="+Integer.parseInt(textBox.getAttribute("together"))+": "+(currPR==Integer.parseInt(textBox.getAttribute("together"))));
							//if the current TEXTBOX (different from hoverbox) has SAME ID as currPR base AND the TEXTBOX has NOT been checked
							if(currPR==Integer.parseInt(textBox.getAttribute("together")) && !checkedTextBoxes.contains(textBox.getAttribute("x")))
							{
								//Declare local list of elements by finding all TEXTBOX CORRESPONDING inner tspan elements
								List<WebElement> temp = textBox.findElements(By.cssSelector("tspan"));
								//if HOVERBOX is GREEN, execute following logic *** (VALIDATION for COLOR & CONTENT done in CONDITIONAL logic -> TC0162 & TC0163) ***
								if(h.getAttribute("stroke").contains("green"))
								{
									//System.out.println("GREEN");
									//FOR ALL tspan elements from current TEXTBOX
									for(WebElement t2:temp)
									{
										//System.out.println(temp.indexOf(t2)+".. "+(temp.indexOf(t2)>0)+"ID NUM"+t2.getAttribute("dy")+" -bool: "+t2.getAttribute("dy").contains("13")); 
										//if elem contains dy attribute of 13 (ie text) and is NOT header text
										if(t2.getAttribute("dy").contains("13") && temp.indexOf(t2)>0)
										{
											//Set text to comparable format and validate via Assert
											tempText = t2.getText().trim();
											//System.out.println(tempText);
											Assert.assertTrue(greenText.contains(tempText),"Green hover box text is NOT correct, "+t2.getText().trim());
											logger.info("hoverox contains text, "+tempText);
										}
									}
								}
								//if HOVERBOX is BLUE, execute following logic *** (VALIDATION for COLOR & CONTENT done in CONDITIONAL logic -> TC0162 & TC0164) ***
								else if(h.getAttribute("stroke").contains("#66ffff") || h.getAttribute("stroke").contains("#047ca4"))
								{
									//System.out.println("BLUE");
									//FOR ALL tspan elements from current TEXTBOX
									for(WebElement t2:temp)
									{
										//if elem contains dy attribute of 13 (ie text) and is NOT header text
										if(t2.getAttribute("dy").contains("13") && temp.indexOf(t2)>0)
										{
											//System.out.println(t2.getText().substring(0,t2.getText().indexOf("%")+1));
											//set text to comparable format and validate via assert
											tempText = t2.getText().substring(0,t2.getText().indexOf("%")+1);
											Assert.assertTrue(blueText.contains(tempText),"Blue hover box text is NOT correct, "+tempText);
											logger.info("hoverox contains text, "+tempText);
										}
									}
								}
								//ELSE hovebox is of an INCORRECT color, FAIL TC
								else
								{
									logger.info("Incorrect color detected for, "+pageLib.getSymbolEntryField().getAttribute("value")+"->stroke: "+h.getAttribute("stroke"));
									Assert.fail("Incorrect color detected for, "+pageLib.getSymbolEntryField().getAttribute("value")+"->stroke: "+h.getAttribute("stroke"));
								}
								//System.out.println(textBox.getAttribute("x"));
								checkedTextBoxes.add(textBox.getAttribute("x"));
								count++;
								break;
							}
						}
						//System.out.println(checkedTextBoxes);
					}
				}catch(Exception e){
					logger.info(e);
				}
				//If the two HOVERBOXES have been checked for the current PR base, break, and hover over next PR base
				if(count==2) break;
			}
		}
	}
	
	/*
	* Method Description (TC0166): Verify Large Vol icon in Volume area with correct Text
	* Created By:- Michael D, Created Date:2/21/17 
	* Changes made#1:
	*/ 
	public void tc0166_verifyLargeVolume()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		//Declaring local vars
		String retQuerySymbol = DB_getRecentBreakOutSymbol();
		boolean isLargeVolPresent = false;
		boolean isLargeVol_hoverOver = false;
		boolean isCorrectText = false;
		String tempText = "";
		String currChartedSymbol = "";
		
		//Chart Daily periodicity if NOT selected already
		if(!pageLib.getDailyButton().getAttribute("class").contains("chartButtonActive"))
			pageLib.getDailyButton().click();
		
		//while Large vol is NOT present, loop until Large Vol is displayed on chart
		while(!isLargeVolPresent)
		{
			//LEAVING COMMENTS INSIDE WHILE IN CASE THIS IMPLEMENTATION FAILS
			try{
				//If Large vol icon is Displayed on chart, hover over icon, and break out of loop
				if(pageLib.getlargestVolumeIcon().isDisplayed())
				{
					performMouseHover(pageLib.getlargestVolumeIcon());
					isLargeVolPresent = true;
				}
				//Else throw exception and get another symbol to chart
				else
				{
					//logger.info("No LARGE vol icon for, "+pageLib.getSymbolEntryField().getAttribute("value"));
					//retQuerySymbol = DB_getRecentBreakOutSymbol();
					//EnterStockSymbol(retQuerySymbol);
					throw new Exception("Current stock, "+pageLib.getSymbolEntryField().getAttribute("value")+" has NO large volume ICON visibly displayed");
				}
				
					//throw new Exception("Current stock has NO large volume ICON visibly displayed");
			}catch(Exception e){
				logger.info(e);
				retQuerySymbol = DB_getRecentBreakOutSymbol();
			}
			//If Large Vol still not present, chart the new symbol
			if(!isLargeVolPresent)
				EnterStockSymbol(retQuerySymbol);
		}
		
		currChartedSymbol = pageLib.getSymbolEntryField().getAttribute("value");
		//hlcp
		//Traverse elements and look for largest vol icon, set boolean depending if BOX is displayed
		for(WebElement e:pageLib.getRecent_PR_HoverBoxes())
		{
			if(e.getAttribute("together").contains("largestvol"))
				isLargeVol_hoverOver = e.getCssValue("display").contains("inline");
		}
		
		//Traverse elements and look for largest vol icon, set boolean depending if BOX is displayed and TEXT is displayed
		for(WebElement e:pageLib.getRecent_PR_HoverBoxes_text())
		{
			if(e.getAttribute("together").contains("largestvol"))
			{
				isLargeVol_hoverOver = isLargeVol_hoverOver && e.getCssValue("display").contains("block");
				tempText = e.getText();
				isCorrectText = tempText.contains("Largest Vol");
			}
		}
		
		//Validate correct hoverover behavior by checking that BOX and TEXT are displayed, as well as text CONTENT is correct
		Assert.assertTrue(isCorrectText&&isLargeVol_hoverOver,"Largest vol icon NOT displayed correctly for, "+currChartedSymbol);
		logger.info("Largest Vol icon is displayed correctly for, "+currChartedSymbol);
	}
	
	/*
	* Method Description (TC0167): Verify Key Price ranges text when hovering over
	* Created By:- Michael D, Created Date:2/22/17 
	* Changes made#1:
	*/ 
	public void tc0167_verifyPostBreakOut_KeyPriceRanges()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		//Declaring local vars
		String retQuerySymbol = DB_getRecentBreakOutSymbol();
		int currKeyPrice = 0;
		String tempText = "";
		List<String> keyPriceText = new ArrayList<String> (Arrays.asList("Loss","Pivot","Profit"));
		
		//Chart Daily periodicity if NOT selected already
		if(!pageLib.getDailyButton().getAttribute("class").contains("chartButtonActive"))
			pageLib.getDailyButton().click();
		
		
		//System.out.println(pageLib.getKeyPriceAreas().size());
		//While there are NO key prices displayed, CHART a new symbol
		while(pageLib.getKeyPriceAreas().size()==0)
		{
			EnterStockSymbol(DB_getRecentBreakOutSymbol());
		}
		tempText = pageLib.getSymbolEntryField().getAttribute("value");
		logger.info("Currently charted symbol is, "+tempText);
		
		//Traverse key price area BOX and try to hover over if elem is found
		for(WebElement e:pageLib.getKeyPriceAreas())
		{
			try{
				performMouseHover(e);
				currKeyPrice = Integer.parseInt(e.getAttribute("together"));
				//Traverse key price area TEXT, if together matches and display=BLOCK, validate correct TEXT
				for(WebElement e2:pageLib.getKeyPriceAreasText())
				{
					if(currKeyPrice==Integer.parseInt(e2.getAttribute("together")) && e2.getCssValue("display").contains("block"))
					{
						tempText = e2.getText().trim();
						Assert.assertTrue(keyPriceText.contains(tempText),"Key price NOT displayed correctly, "+tempText);
						logger.info("Key price, "+tempText.toUpperCase()+" is Displayed correctly");
					}
				}
			}catch(Exception ex){
				logger.info(ex);
			}
		}
	}
	
	
	/*
	* Method Description (TC0300): Testing for blank FUND chart
	* Created By:- Michael D, Created Date:2/10/17 
	* Changes made#1:
	*/
	public void tc0300_blankChartTest()
	{
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		System.out.println("BLANK CHART TEST");
		waitUntilElementIsClickable(pageLib.getChangeDateInput());
		if(!pageLib.getweeklyButton().getAttribute("class").contains("chartButtonActive"))
			pageLib.getweeklyButton().click();
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		System.out.println(pageLib.getBlankChart().size());
		
		
		
		System.out.println(pageLib.getChangeDateInput().getAttribute("value"));
		while(pageLib.getChangeDateInput().getAttribute("value").length()>0)
		{
			pageLib.getChangeDateInput().sendKeys(Keys.BACK_SPACE);
			System.out.println("BSpace");
		}
		//System.out.println(pageLib.getChangeDateInput().getAttribute("value").length());
		//pageLib.getChangeDateInput().sendKeys(Keys.BACK_SPACE);
		//System.out.println("CLEARED");
		Actions action1 = new Actions(driver);
		action1.sendKeys(pageLib.getChangeDateInput(),"2/10/2010").sendKeys(Keys.ENTER).build().perform();
		System.out.println("Changed DATE!!!!");
		//If Daily periodicity NOT selected, click on button
		//if(!pageLib.getweeklyButton().getAttribute("class").contains("chartButtonActive"))
			//pageLib.getweeklyButton().click();
		
		//if(pageLib.getweeklyButton().getAttribute("class").contains(""))
		//pageLib.getweeklyButton().click();
		waitUntilElementisVisible(pageLib.getMainPriceChart());
		if(!pageLib.getSymbolEntryField().getAttribute("value").contains("FCNTX"))
		{
			EnterStockSymbol("FCNTX");
			waitUntilElementisVisible(pageLib.getMainPriceChart());
		}
		
		//TODO: CHECK CHART nodes present
		System.out.println(pageLib.getBlankChart().size());
		
		//waitUntilElementIsClickable(pageLib.getChangeDateInput());
		//pageLib.getChangeDateInput().sendKeys(Keys.DELETE);
		//Actions action1 = new Actions(driver);
		//action1.sendKeys(pageLib.getChangeDateInput(),"2/10/2010").sendKeys(Keys.ENTER).build().perform();
		
		//waitUntilElementisVisible(pageLib.getMainPriceChart());
		Assert.fail("not done yet");
		
		
	}
	
}