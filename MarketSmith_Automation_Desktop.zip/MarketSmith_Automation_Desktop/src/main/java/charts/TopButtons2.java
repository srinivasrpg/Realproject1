package charts;

import static genericLib.Utility.*;
import java.util.Hashtable;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import excelReader.TestUtil;

public class TopButtons2 {
	TopButtons2PageLib oPageLib=PageFactory.initElements(driver, TopButtons2PageLib.class);
	WebDriverWait smallWait=new WebDriverWait(driver, 10);

	/************************************************************************************************	
	  Method Description(TC-0002) : Make sure the following options are listed: "Show Hover Help," "Show Tutorials," "Show Shared Content Alerts," "Reset Disable Notifications," "My Account," "My Community Profile," "My Contacts," "Delayed Data," "BATS (Real-Time reference data)," "eSignal Real-Time Setup," "Generate Log File." (NOTE: "My Account" will be greyed out for WON's in-house entitled accounts).
	  @Author:Mukund               					@Date:20-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC002_TopButtons2() {
		String expectedLinks[] = { CONSTANTS.getProperty("SETTING_LINK_1"), CONSTANTS.getProperty("SETTING_LINK_2"),
				CONSTANTS.getProperty("SETTING_LINK_3"), CONSTANTS.getProperty("SETTING_LINK_4"),
				CONSTANTS.getProperty("SETTING_LINK_5"), CONSTANTS.getProperty("SETTING_LINK_6"),
				CONSTANTS.getProperty("SETTING_LINK_7"), CONSTANTS.getProperty("SETTING_LINK_8"),
				CONSTANTS.getProperty("SETTING_LINK_9"), CONSTANTS.getProperty("SETTING_LINK_10"),
				CONSTANTS.getProperty("SETTING_LINK_11"), CONSTANTS.getProperty("SETTING_LINK_12") };
		oPageLib.getSettingIcon().click();
		logger.info("Clicked on Tool Options icon");
		try{
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getToolOptionPopup()));
			logger.info("Tool Options popup is displayed");
		}
		catch(Exception e) {
			Assert.fail("Tool Options popup is not displayed");
		}
		List<WebElement> links=oPageLib.getSettingLinks();
		for(int index=0;index<links.size();index++) {
			WebElement link =links.get(index);
			String actualLink=link.getText().trim();
			Assert.assertEquals(actualLink, expectedLinks[index], "Link text is not matched under Tool Options popup");
			logger.info("Link text is matched under Tool Options popup. Text : " + actualLink);
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0004) : Make sure you are at a Daily Chart. Then click SHOW TUTORIALS, Does the MARKETSMITH TUTORIAL window pop up? Does the menu option change to read HIDE TUTORIALS?
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC004_TopButtons2() {
		if(!oPageLib.getToolOptionPopup().isDisplayed()) {
			oPageLib.getSettingIcon().click();
			logger.info("Clicked on Tool Options icon");
		}
		//Clicking on Show Tutorial link & verifying MS tutorial pop up is opened
		WebElement link=oPageLib.getSettingLinks().get(2);
		String linkText=link.getText();
		link.click();
		logger.info("Clicked on " + linkText + " link");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getMsTutorialPopup()));
			logger.info("MarketSmith Tutorial popup is displayed");
		}
		catch(Exception e) {
			Assert.fail("MarketSmith Tutorial popup is not displayed");
		}
		//Verifying Show Tutorial link text is changed
		String expectedLinkText=CONSTANTS.getProperty("SETTING_LINK_TOOGLE_3");
		String actualLinkText=oPageLib.getSettingLinks().get(2).getText();
		Assert.assertEquals(actualLinkText, expectedLinkText, "Link text is not changed after clicking on it");
		logger.info("Link text is changed after clicking on it. Link Text : " + actualLinkText);
	}

	/************************************************************************************************	
	  Method Description(TC-0007) : Click on the CONTACT MY COACH button. Verify that the CONTACT MARKETSMITH window appears, and that your email address is defaulted into the EMAIL field.
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC007_TopButtons2() {
		//Clicking on Contact My Coach button and verifying Contact MS window appears
		WebElement button=oPageLib.getContactCoachBtn();
		String buttonText=button.getText();
		button.click();
		logger.info("Clicked on " + buttonText + " button");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getContactMSPopup()));
			logger.info("Contact MarketSmith popup is opened");
		}
		catch(Exception e) {
			Assert.fail("Contact MarketSmith popup is not opened");
		}
		//Verifying email address
		Hashtable<String, String> data=TestUtil.getData("loginToMarketSmith", "Global", dataXl);
		String expectedEmail=data.get("UserName");
		String actualEmail=oPageLib.getEmailMSPopup().getAttribute("value");
		Assert.assertEquals(actualEmail, expectedEmail, "Email address is not matched on Conatact MarketSmith window");
		logger.info("Email address is matched on Conatact MarketSmith window. Email : " + actualEmail);
	}

	/************************************************************************************************	
	  Method Description(TC-0008) : Verify that if you click the SUBMIT SUPPORT REQUEST without entering anything into the two required fields (SUBJECT and MESSAGE), the window gives you an error rather than closing and sending the message.
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC008_TopButtons2() {
		WebElement button=oPageLib.getSubmitRequestBtn();
		String buttonText=button.getText();
		button.click();
		logger.info("Clicked on " + buttonText + " button");
		//Verifying error
		String expectedClass=CONSTANTS.getProperty("REQUIRED_FIELD_ERROR_CLASS");
		String actualClass=oPageLib.getSubjectMSPopup().getAttribute("class");
		Assert.assertTrue(actualClass.contains(expectedClass), "Subject field is not giving error when clicked on " + buttonText + " button");
		logger.info("Subject field is giving error when clicked on " + buttonText + " button");
		actualClass=oPageLib.getMessageMSPopup().getAttribute("class");
		Assert.assertTrue(actualClass.contains(expectedClass), "Messgae field is not giving error when clicked on " + buttonText + " button");
		logger.info("Messgae field is giving error when clicked on " + buttonText + " button");
		//Verifying Contact MarketSmith window is not closed
		Assert.assertTrue(oPageLib.getContactMSPopup().isDisplayed(), "Contact MarketSmith window is closed");
		logger.info("Contact MarketSmith window is not closed");
	}

	/************************************************************************************************	
	  Method Description(TC-0013) : Back at the MARKETSMITH TUTORIAL window, click on the SELF-GUIDED TOUR tab. Verify that a series of four text bubbles appear across your screen: 1) Chart, 2) Screener, 3) List Panel, and 4) Related Information.
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC013_TopButtons2() {
		if(oPageLib.getContactMSPopup().isDisplayed()) {
			oPageLib.getContactMSPopupClose().click();
			logger.info("Clicked on Close button of Contact MarketSmith window");
		}
		WebElement tab=oPageLib.getSelfGuidedTab();
		String tabText=tab.getText();
		tab.click();
		logger.info("Clicked on " + tabText + tab);
		String[] expectedBubbles = { CONSTANTS.getProperty("SELF_GUIDED_TEXT_1"),
				CONSTANTS.getProperty("SELF_GUIDED_TEXT_2"), CONSTANTS.getProperty("SELF_GUIDED_TEXT_3"),
				CONSTANTS.getProperty("SELF_GUIDED_TEXT_4") };
		List<WebElement> bubbles=oPageLib.getSelfGuidedBubbles();
		for(int index=0;index<bubbles.size();index++) {
			String actualBubble=bubbles.get(index).getText().trim();
			Assert.assertEquals(actualBubble, expectedBubbles[index] , "Bubble text is not matched on MarketSmith Tutorial window");
			logger.info("Bubble text is matched on MarketSmith Tutorial window");
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0014) : In  the SELF-GUIDED TOUR tab, click on the three hyperlinks: CHARTS, SCREENER, and LIST PANEL. Make sure that for each, the relevant window opens up
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC014_TopButtons2() {
		//Clicking on Charts link & verifying window
		WebElement link=oPageLib.getSelfGuidedLinks().get(0);
		String linkText=link.getText();
		link.click();
		logger.info("Clicked on " + linkText + " link");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getChartHelpWindow()));
			logger.info("Chart help window is displayed");
		}
		catch(Exception e) {
			Assert.fail("Chart help window is displayed");
		}
		oPageLib.getChartHelpWindowClose().click();
		logger.info("Clicked on close button of Chart help window");

		//Clicking on Screener link & verifying window
		link=oPageLib.getSelfGuidedLinks().get(1);
		linkText=link.getText();
		link.click();
		logger.info("Clicked on " + linkText + " link");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getScreenerHelpWindow()));
			logger.info("Screener help window is displayed");
		}
		catch(Exception e) {
			Assert.fail("Screener help window is displayed");
		}
		oPageLib.getScreenerHelpWindowClose().click();
		logger.info("Clicked on close button of Screener help window");

		//Clicking on List Panel link & verifying window
		link=oPageLib.getSelfGuidedLinks().get(2);
		linkText=link.getText();
		link.click();
		logger.info("Clicked on " + linkText + " link");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getListPanelHelpWindow()));
			logger.info("List Panel help window is displayed");
		}
		catch(Exception e) {
			Assert.fail("List Panel help window is displayed");
		}
		oPageLib.getListPanelHelpWindowClose().click();
		logger.info("Clicked on close button of List Panel help window");
	}

	/************************************************************************************************	
	  Method Description(TC-0019) : Click the OFF button. Ensure that the MARKETSMITH TUTORIAL window disappears. Also verify that a text bubble appears next to the TOOL OPTIONS button that says: "You can turn help on again by selecting "Show Tutorials" under this menu.
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC019_TopButtons2() {
		//Clicking on Off button & Verifying MarketSmith Tutorial window is closed
		oPageLib.getMsTutorialOff().click();
		logger.info("Clicked on MarketSmith Tutorial Off button");
		Assert.assertFalse(oPageLib.getMsTutorialPopup().isDisplayed(), "MarketSmith Tutorial window is not closed");
		logger.info("MarketSmith Tutorial window is closed");
		//Verifying text bubble is displayed
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getMsTutorialOffPopup()));
			logger.info("Text bubble is displayed after closing MarketSmith Tutorial window");
		}
		catch(Exception e) {
			Assert.fail("Text bubble is not displayed after closing MarketSmith Tutorial window");
		}
		//Verifying bubble text
		String expectedText=CONSTANTS.getProperty("MS_TUTORIAL_OFF_BUBBLE");
		String actualText=oPageLib.getMsTutorialOffPopupText().getText().trim();
		Assert.assertEquals(actualText, expectedText, "Bubble text is not matched");
		logger.info("Bubble text is matched. Text : " + actualText);
	}

	/************************************************************************************************	
	  Method Description(TC-0020) : Back on the TOOL OPTIONS button drop-down menu, select SHOW SHARED CONTENT ALERTS. Ensure that the NOTIFICATION MANAGEMENT window appears. 
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC020_TopButtons2() {
		if(!oPageLib.getToolOptionPopup().isDisplayed()) {
			oPageLib.getSettingIcon().click();
			logger.info("Clicked on Tool Options icon");
		}
		WebElement link=oPageLib.getSettingLinks().get(3);
		String linkText=link.getText();
		link.click();
		logger.info("Clicked on " + linkText + " link");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getNotfMgmtWindow()));
			logger.info("Notification Management window is displayed");
		}
		catch(Exception e) {
			Assert.fail("Notification Management window is not displayed");
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0021) : Click the NOTIFY ME and DO NOT NOTIFY ME radio buttons. Verify that when one is clicked, the other section is greyed out.
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC021_TopButtons2() {
		//Clicking on Notify Me radio button & verifying that other section is disabled
		oPageLib.getNotifyRadioBtn().click();
		logger.info("Clicked on Notify Me radio button");
		Assert.assertFalse(oPageLib.getNoNotifyCheckbox().isEnabled(), "Do Not Notify checkbox is enabled");
		logger.info("Do Not Notify checkbox is disabled");
		//Clicking on Do Not Notify Me radio button & verifying that other section is disabled
		oPageLib.getNoNotifyRadioBtn().click();
		logger.info("Clicked on Do Not Notify Me radio button");
		Assert.assertFalse(oPageLib.getNotifyCheckbox().isEnabled(), "Notify checkbox is enabled");
		logger.info("Notify checkbox is disabled");
	}

	/************************************************************************************************	
	  Method Description(TC-0026) : Under DISPLAY NOTIFICATIONS, verify the various radio buttons work.
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC026_TopButtons2() {
		//Verifying As They occur radio button
		oPageLib.getAsTheyOccurRB().click();
		Assert.assertTrue(oPageLib.getAsTheyOccurRB().isSelected(), "As They occur radio button is not selected");
		logger.info("As They occur radio button is selected");

		//Verifying Only Once Per Day radio button
		oPageLib.getOnceADayRB().click();
		Assert.assertTrue(oPageLib.getOnceADayRB().isSelected(), "Only Once Per Day radio button is not selected");
		logger.info("Only Once Per Day radio button is selected");

		//Verifying AM radio button
		oPageLib.getAmRadioBtn().click();
		Assert.assertTrue(oPageLib.getAmRadioBtn().isSelected(), "AM radio button is not selected");
		logger.info("AM radio button is selected");

		//Verifying PM radio button
		oPageLib.getPmRadioBtn().click();
		Assert.assertTrue(oPageLib.getPmRadioBtn().isSelected(), "PM radio button is not selected");
		logger.info("PM radio button is selected");
	}

	/************************************************************************************************	
	  Method Description(TC-0027) : Click on "Only once per day," select a time and AM or PM, and click APPLY. The NOTIFICATION MANAGEMENT window should disappear.
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC027_TopButtons2(String time) {
		oPageLib.getOnceADayRB().click();
		logger.info("Clicked on Only Once Per Day radio button");
		selectOptionInDropDownByVisibleText(oPageLib.getOnceADaySelect(), time);
		logger.info(getSelectedOptionFromDropDown(oPageLib.getOnceADaySelect()) + " is selected in time dropdown");
		oPageLib.getApplyButton().click();
		logger.info("Clicked on Apply button");
		//Verifying Notification Management window is disappeared
		Assert.assertFalse(oPageLib.getNotfMgmtWindow().isDisplayed(), "Notification Management window is not disappeared");
		logger.info("Notification Management window is disappeared");
	}

	/************************************************************************************************	
	  Method Description(TC-0028) : Go back to TOOL OPTIONS > SHOW SHARED CONTENT ALERTS, and make sure that the options you selected are now updated.
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC028_TopButtons2(String expectedTime) {
		if(!oPageLib.getToolOptionPopup().isDisplayed()) {
			oPageLib.getSettingIcon().click();
			logger.info("Clicked on Tool Options icon");
		}
		WebElement link=oPageLib.getSettingLinks().get(3);
		String linkText=link.getText();
		link.click();
		logger.info("Clicked on " + linkText + " link");
		String actualTime=getSelectedOptionFromDropDown(oPageLib.getOnceADaySelect());
		Assert.assertEquals(actualTime, expectedTime, "Time is not matched in Only Once Per Day dropdown");
		logger.info("Time is matched in Only Once Per Day dropdown. Time : " + actualTime);
	}

	/************************************************************************************************	
	  Method Description(TC-0032) : Click on the VIEW ALL SCREENS SHARED WITH ME hyperlink at the bottom of the window. Verify the BROWSE SCREENS window opens.
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC032_TopButtons2() {
		WebElement link=oPageLib.getAllSharedScreenLink();
		String linkText=link.getText();
		link.click();
		logger.info("Clicked on  " + linkText + " link");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getBrowseScreenWindow()));
			logger.info("Browse Screen window is displayed");
		}
		catch(Exception e) {
			Assert.fail("Browse Screen window is not displayed");
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0033) : Using the radio buttons and checkboxes, verify the buttons work as designed and the various buttons control and modify how many screens appear in the list to the right. For example, if under SHARING you select ALL, you should get the same number of total screens as is listed under TYPE > ALL. 
	  @Author:Mukund               					@Date:22-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC033_TopButtons2() {
		oPageLib.getAllTypeRadio().click();
		logger.info("Clicked on All Type radio button");
		oPageLib.getAllSharingRadio().click();
		logger.info("Clicked on All Sharing radio button");
		oPageLib.getAllUpdatedRadio().click();
		logger.info("Clicked on All Updated Within Last radio button");
		int expectedCount=Integer.parseInt(oPageLib.getSharedScreenCount().getText().trim().replace("All (", "").replace(")", ""));
		int actualCount=oPageLib.getSharedScreensList().size();
		Assert.assertEquals(actualCount, expectedCount, "Shared screen count is not matched");
		logger.info("Shared screen count is matched. Count : " + actualCount);
	}

	/************************************************************************************************	
	  Method Description(TC-0039) : Go back to TOOL OPTIONS > SHOW SHARED CONTENT ALERTS, VIEW ALL SCREENS SHARED WITH ME, MARKETSMITH SCREENS, click on a screen to bring up the COMMUNITY ACTIVITY window, and then click on TRACK SCREEN. Verify that the screen is added to the TRACKED SCREENS folder in the SCREENER window on the left side of the MS Tool screen
	  @Author:Mukund               					@Date:23-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC039_TopButtons2() {
		//Clicking on first screen
		WebElement screen=oPageLib.getSharedScreens();
		String screenName=screen.getText().trim();
		screen.click();
		logger.info("Clicked on " + screenName + " screen");
		//Verifying Community Activity screen is opened
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getCommunityActivityWindow()));
			logger.info("Community Activity window is opened");
		}
		catch(Exception e) {
			Assert.fail("Community Activity window is not opened");
		}
		//Clicking on Track Screen and closing Community Activity window & Browse Screen window
		oPageLib.getTrackScreenBtn().click();
		logger.info("Clicked on Track Screen button");
		oPageLib.getCommunityActivityClose().click();
		logger.info("CLicked on close button of Community Activity window");
		oPageLib.getBrowseScreenClose().click();
		logger.info("CLicked on close button of Browse Screen window");
		//Verifying screen name on screener
		List<WebElement> screens=oPageLib.getTrackedScreenList();
		int listSize=screens.size();
		int index=0;
		for(index=0;index<listSize;index++) {
			String screenText=screens.get(index).getText().trim();
			if(screenText.equals(screenName)) {
				logger.info(screenText + " is added to Tracked Screen folder under screener");
				break;
			}
		}
		if(index==listSize) {
			Assert.fail(screenName + " is not added to Tracked Screen folder under screener");
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0040) : Go back to TOOL OPTIONS > SHOW SHARED CONTENT ALERTS, VIEW ALL LISTS SHARED WITH ME, verify Browse List window is opened
	  @Author:Mukund               					@Date:23-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC040_TopButtons2() {
		if(!oPageLib.getToolOptionPopup().isDisplayed()) {
			oPageLib.getSettingIcon().click();
			logger.info("Clicked on Tool Options icon");
		}
		WebElement link=oPageLib.getSettingLinks().get(3);
		String linkText=link.getText();
		link.click();
		logger.info("Clicked on " + linkText + " link");
		link=oPageLib.getAllSharedListsLink();
		linkText=link.getText();
		link.click();
		logger.info("Clicked on  " + linkText + " link");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getBrowseListWindow()));
			logger.info("Browse List window is displayed");
		}
		catch(Exception e) {
			Assert.fail("Browse List window is not displayed");
		}
		oPageLib.getBrowseListClose().click();
	}
	
	/************************************************************************************************	
	  Method Description(TC-0044) : 
	  @Author:Mukund               					@Date:23-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC044_TopButtons2() {
		
	}
	
	/************************************************************************************************	
	  Method Description(TC-0045) : 
	  @Author:Mukund               					@Date:23-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC045_TopButtons2() {
		
	}
	
	/************************************************************************************************	
	  Method Description(TC-0046) : Under the TOOL OPTIONS drop-down menu, toggle the DELAYED DATA and BATS buttons. When BATS is selected, verify the BATS indicator (the square colored item next to the INTRADAY chart button) turns green. When DELAYED DATA is selected, verify this same indicator turns grey.
	  @Author:Mukund               					@Date:24-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC046_TopButtons2() {
		if(!oPageLib.getToolOptionPopup().isDisplayed()) {
			oPageLib.getSettingIcon().click();
			logger.info("Clicked on Tool Options icon");
		}
		//Clicking on BATS data & Verifying BATS indicator
		oPageLib.getBatsData().click();
		logger.info("Clicked on BATS data radio button");
		Assert.assertTrue(oPageLib.getRealTimeIndicator().getAttribute("class").contains(CONSTANTS.getProperty("BATS_INDICATOR_ACTIVE")), "BATS indicator is not green");
		logger.info("BATS indicator is green");
		//Clicking on Delayed data & Verifying BATS indicator
		oPageLib.getDelayedData().click();
		logger.info("Clicked on Delayed data radio button");
		Assert.assertFalse(oPageLib.getRealTimeIndicator().getAttribute("class").contains(CONSTANTS.getProperty("BATS_INDICATOR_ACTIVE")), "BATS indicator is not grey");
		logger.info("BATS indicator is grey");
	}
	
	/************************************************************************************************	
	  Method Description(TC-0052) : At the far right of this top button bar in the MS Tool, click on the MARKETSMITH logo. Verify that your browser opens the MarketSmith homepage.
	  @Author:Mukund               					@Date:24-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC052_TopButtons2() {
		oPageLib.getMsLogo().click();
		logger.info("Clicked on MarketSmith logo");
		verifyPageUrl(CONFIG.getProperty("testSiteURL"));
	}
}
