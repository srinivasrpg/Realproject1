package charts;

import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import static genericLib.Utility.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TopButtons1 {
	TopButtons1PageLib oPageLib=PageFactory.initElements(driver, TopButtons1PageLib.class);
	WebDriverWait smallWait=new WebDriverWait(driver, 10);

	/************************************************************************************************	
	  Method Description(TC-0003) : Input "123" into the search field and hit ENTER. Does MS return a "Symbol Not Recognized" error message?
	  @Author:Mukund               					@Date:15-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC003_TopButtons1(String symbol) {
		oPageLib.getSearchBox().clear();
		oPageLib.getSearchBox().sendKeys(symbol);
		logger.info(symbol + " is entered in Search text box");
		Actions actions=new Actions(driver);
		actions.sendKeys(Keys.ENTER).perform();
		logger.info("Pressed Enter key");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getUnavailableSymbolBox()));
			logger.info("Unavailable Symbol message box is displayed");
		}
		catch(Exception e) {
			Assert.fail("Unavailable Symbol message box is not displayed when searched for " + symbol);
		}
		try {
			String expectedMessage=CONSTANTS.getProperty("UNAVAILABLE_SYMBOL_TEXT");
			String actualMessage=oPageLib.getUnavailableSymbolBox().getText();
			Assert.assertEquals(actualMessage, expectedMessage, "Error message is not matched");
			logger.info("Error message is matched. Message : " + actualMessage);
		}
		finally {
			oPageLib.getUnavailableSymbolClose().click();
			logger.info("Clicked on Close button on Unavailable Symbol message box");
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0004) : Input "AAP" into the search field. Does a dropdown list of tickers appear, all of which start with the letters AAP?
	  @Author:Mukund               					@Date:15-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC004_TopButtons1(String symbol) {
		oPageLib.getSearchBox().clear();
		oPageLib.getSearchBox().sendKeys(symbol);
		logger.info(symbol + " is entered in Search text box");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getAutoListBox()));
			logger.info("Auto suggest list box is displayed");
		}
		catch(Exception e) {
			Assert.fail("Auto suggest list box is not displayed when searched for " + symbol);
		}
		List<WebElement> autoList=oPageLib.getAutoListOptions();
		SoftAssert softAssert=new SoftAssert();
		for(WebElement option : autoList) {
			String optionText=option.getText();
			softAssert.assertTrue(optionText.startsWith(symbol), "Auto suggest option doesn't start with " + symbol + ". Option : " + optionText);
		}
		softAssert.assertAll();
		logger.info("All auto suggest options start with " + symbol);
	}

	/************************************************************************************************	
	  Method Description(TC-0009) : Click the Symbol Dropdown button (small button to right of Search Field). Does the dropdown list appear? Are there five symbols listed under the "Recent Symbols" header? Are there seven idices listed under the "Popular Indices" header?
	  @Author:Mukund               					@Date:15-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC009_TopButtons1() {
		oPageLib.getSymbolDropdown().click();
		logger.info("Clicked on Symbol Dropdown button");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getRecentBox()));
			logger.info("Recent symbol box is displayed");
		}
		catch(Exception e) {
			Assert.fail("Recent symbol box is not displayed when clicked on Symbol Dropdown button");
		}
		int actualCount=oPageLib.getRecentSymbolRows().size();
		int expectedCount=Integer.parseInt(CONSTANTS.getProperty("RECENT_SYMBOL_COUNT"));
		Assert.assertEquals(actualCount, expectedCount, "Recent symbol count is not matched");
		logger.info("Recent symbol count is matched. Count : " + actualCount);
		actualCount=oPageLib.getPopularIndicesRows().size();
		expectedCount=Integer.parseInt(CONSTANTS.getProperty("POPULAR_INDICES_COUNT"));
		Assert.assertEquals(actualCount, expectedCount, "Popular indices count is not matched");
		logger.info("Popular indices count is matched. Count : " + actualCount);
	}

	/************************************************************************************************	
	  Method Description(TC-0010) : In the dropdown list, click on the "View Recent Symbols List" hyperlink. Up to last 50 recent symbols should be populated on the List Manager located at the bottom of the screen
	  @Author:Mukund               					@Date:15-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC010_TopButtons1() {
		WebElement link=oPageLib.getViewRecentLink();
		String linkText=link.getText();
		link.click();
		logger.info("Clicked on " + linkText + " link");
		int actualCount=Integer.parseInt(oPageLib.getSymbolCountLM().getText().trim().replace(" items", ""));
		int maxCount=Integer.parseInt(CONSTANTS.getProperty("MAX_RECENT_SYMBOL_LM"));
		Assert.assertTrue(actualCount<=maxCount, "Recent symbol count on List Manager is greater than maximum count. Count : " + actualCount + "Max : " + maxCount);
		logger.info("Recent symbol count on List Manager is lesser than maximum count. Count : " + actualCount + "Max : " + maxCount);
	}

	/************************************************************************************************	
	  Method Description(TC-0012) : To the right of the SEARCH field, click the DAILY | WEEKLY | MONTHLY buttons. Do the expected charts appear for each button?
	  @Author:Mukund               					@Date:20-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC012_TopButtons1() {
		//Verifying Weekly chart
		oPageLib.getWeeklyButton().click();
		logger.info("Clicked on Weekly button");
		try {
			Assert.assertTrue(oPageLib.getWeeklyChart().isDisplayed(), "Weekly chart is not displayed");
			logger.info("Weekly chart is displayed");
		}
		catch(NoSuchElementException e) {
			Assert.fail("Weekly chart is not displayed");
		}

		//Verifying Monthly chart
		oPageLib.getMonthlyButton().click();
		logger.info("Clicked on Monthly button");
		try {
			Assert.assertTrue(oPageLib.getMonthlyChart().isDisplayed(), "Monthly chart is not displayed");
			logger.info("Monthly chart is displayed");
		}
		catch(NoSuchElementException e) {
			Assert.fail("Monthly chart is not displayed");
		}

		//Verifying Daily chart
		oPageLib.getDailyButton().click();
		logger.info("Clicked on Daily button");
		try {
			Assert.assertTrue(oPageLib.getDailyChart().isDisplayed(), "Daily chart is not displayed");
			logger.info("Daily chart is displayed");
		}
		catch(NoSuchElementException e) {
			Assert.fail("Daily chart is not displayed");
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0014) : Is there a green BATS indicator square to the right of the INTRADAY button?
	  @Author:Mukund               					@Date:15-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC014_TopButtons1() {
		try {
			WebElement batsIndicator=oPageLib.getBatsIndicator();
			Assert.assertTrue(batsIndicator.isDisplayed(), "Bats Indicator is not displayed");
			logger.info("Bats Indicator is displayed");
		}
		catch(NoSuchElementException e) {
			Assert.fail("Bats Indicator is not present");
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0015) : Make sure you are on a DAILY chart. Is the date in the Date Field at the top defaulted to the last trading date?
	  @Author:Mukund               					@Date:15-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC015_TopButtons1() {
		String batsDate=oPageLib.getBatsDate().getText().trim().replace(".", "/");
		String topDate=oPageLib.getDateBox().getAttribute("value");
		Assert.assertEquals(topDate, batsDate, "Top date is not matched with Bats date");
		logger.info("Top date is matched with Bats date. Date : " + topDate);
	}

	/************************************************************************************************	
	  Method Description(TC-0016) : Click the small black arrows to the left and the right of the date in the DATE field. Does the date in the date field change by one day with each click? Does the Daily Chart below change to reflect the new date? (look for the date at the bottom-right-hand corner of the chart).
	  @Author:Mukund               					@Date:15-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC016_TopButtons1() {
		//Verifying left arrow
		oPageLib.getDateLeftArrow().click();
		logger.info("Clicked on Left Arrow");
		String batsDate=oPageLib.getBatsDate().getText().trim().replace(".", "/");
		String topDate=oPageLib.getDateBox().getAttribute("value");
		Assert.assertEquals(topDate, batsDate, "Top date is not matched with Bats date");
		logger.info("Top date is matched with Bats date when clicked on left arrow. Date : " + topDate);

		//Verifying right arrow
		oPageLib.getDateRightArrow().click();
		logger.info("Clicked on Right Arrow");
		batsDate=oPageLib.getBatsDate().getText().trim().replace(".", "/");
		topDate=oPageLib.getDateBox().getAttribute("value");
		Assert.assertEquals(topDate, batsDate, "Top date is not matched with Bats date");
		logger.info("Top date is matched with Bats date when clicked on right arrow. Date : " + topDate);
	}

	/************************************************************************************************	
	  Method Description(TC-0017) : Change the periodicity to WEEKLY and MONTHLY, then click these same arrows. Do the dates change in one-week and one-month intervals, respectively?
	  @Author:Mukund               					@Date:16-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC017_TopButtons1() throws ParseException {
		//Verifying Weekly button left arrow
		SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
		String date=oPageLib.getDateBox().getAttribute("value");
		Date currentDate=sdf.parse(date);
		Date expDate=new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDate());
		int dec=currentDate.getDate()-7;
		expDate.setDate(dec);
		String expectedDate=sdf.format(expDate);
		oPageLib.getWeeklyButton().click();
		logger.info("Clicked on Weekly button");
		oPageLib.getDateLeftArrow().click();
		logger.info("Clicked on Left Arrow");
		String newDate=oPageLib.getDateBox().getAttribute("value");
		Assert.assertEquals(newDate, expectedDate, "Date is not matched when clicked on left arrow");
		logger.info("Date is matched when clicked on left arrow. Date : " + newDate);

		//Verifying Weekly button right arrow
		oPageLib.getDateRightArrow().click();
		logger.info("Clicked on Right Arrow");
		newDate=oPageLib.getDateBox().getAttribute("value");
		Assert.assertEquals(newDate, currentDate, "Date is not matched when clicked on right arrow");
		logger.info("Date is matched when clicked on right arrow. Date : " + newDate);

		//Verifying Monthly button left arrow
		date=oPageLib.getDateBox().getAttribute("value");
		currentDate=sdf.parse(date);
		expDate=new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDate());
		dec=currentDate.getDate()+7;
		expDate.setDate(dec);
		expectedDate=sdf.format(expDate);
		oPageLib.getMonthlyButton().click();
		logger.info("Clicked on Monthly button");
		oPageLib.getDateLeftArrow().click();
		logger.info("Clicked on Left Arrow");
		newDate=oPageLib.getDateBox().getAttribute("value");
		Assert.assertEquals(newDate, expectedDate, "Date is not matched when clicked on left arrow");
		logger.info("Date is matched when clicked on left arrow. Date : " + newDate);

		//Verifying Monthly button right arrow
		oPageLib.getDateRightArrow().click();
		logger.info("Clicked on Right Arrow");
		newDate=oPageLib.getDateBox().getAttribute("value");
		Assert.assertEquals(newDate, currentDate, "Date is not matched when clicked on right arrow");
		logger.info("Date is matched when clicked on right arrow. Date : " + newDate);
	}

	/************************************************************************************************	
	  Method Description(TC-0018) : In the DATE field, type in a specific date. Does the chart change to that date?
	  @Author:Mukund               					@Date:16-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC018_TopButtons1(String date) {
		oPageLib.getDailyButton().click();
		logger.info("Clicked on Daily button");
		String batsDate=oPageLib.getBatsDate().getText().trim().replace(".", "/");
		oPageLib.getDateBox().sendKeys(date);
		Actions actions=new Actions(driver);
		actions.sendKeys(Keys.ENTER).perform();
		Assert.assertEquals(date, batsDate, "Top date is not matched with Bats date");
		logger.info("Top date is matched with Bats date. Date : " + date);
	}

	/************************************************************************************************	
	  Method Description(TC-0023) : To the right of the DATE field, notice the CHANGE DATE dropdown button. Click on this button. Does a Calendar dropdown appear? Are there two tabs labeled CALENDAR and TIMELINE?
	  @Author:Mukund               					@Date:16-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC023_TopButtons1() {
		oPageLib.getCalendarExpandBtn().click();
		logger.info("Clicked on Calender Expand button");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getCalendarBox()));
			logger.info("Calender box is displayed");
		}
		catch(Exception e) {
			Assert.fail("Calender box is not displayed");
		}
		//Verifying tab names
		String actualTabName=oPageLib.getCalendarBoxTabs().get(0).getText();
		Assert.assertEquals(actualTabName, CONSTANTS.getProperty("CALENDAR_BOX_TAB_1"), "Calendar tab name is not matched");
		logger.info("Calendar tab name is matched. Tab Name : " + actualTabName);
		actualTabName=oPageLib.getCalendarBoxTabs().get(1).getText();
		Assert.assertEquals(actualTabName, CONSTANTS.getProperty("CALENDAR_BOX_TAB_2"), "Calendar tab name is not matched");
		logger.info("Calendar tab name is matched. Tab Name : " + actualTabName);
	}

	/************************************************************************************************	
	  Method Description(TC-0027) : While the CHANGE DATE dropdown window is still open, click on the different periodicity buttons (DAILY | WEEKLY | MONTHLY | INTRADAY). Do the charts below change while the dropdown stays up on the screen and the chart date remains the same?
	  @Author:Mukund               					@Date:20-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC027_TopButtons1() {
		String date=oPageLib.getDateBox().getAttribute("value");
		if(!oPageLib.getCalendarBox().isDisplayed()) {
			oPageLib.getCalendarExpandBtn().click();
			logger.info("Clicked on Calender Expand button");
		}
		//Verifying Weekly chart
		oPageLib.getWeeklyButton().click();
		logger.info("Clicked on Weekly button");
		try {
			Assert.assertTrue(oPageLib.getWeeklyChart().isDisplayed(), "Weekly chart is not displayed");
			logger.info("Weekly chart is displayed");
		}
		catch(NoSuchElementException e) {
			Assert.fail("Weekly chart is not displayed");
		}
		Assert.assertTrue(oPageLib.getCalendarBox().isDisplayed(), "Calendar box is not displayed for Weekly chart");
		logger.info("Calendar box is displayed for Weekly chart");
		String currentDate=oPageLib.getDateBox().getAttribute("value");
		Assert.assertEquals(currentDate, date, "Date doesn't remain same for Weekly chart");
		logger.info("Date remains same for Weekly chart. Date : " + currentDate);

		//Verifying Monthly chart
		oPageLib.getMonthlyButton().click();
		logger.info("Clicked on Monthly button");
		try {
			Assert.assertTrue(oPageLib.getMonthlyChart().isDisplayed(), "Monthly chart is not displayed");
			logger.info("Monthly chart is displayed");
		}
		catch(NoSuchElementException e) {
			Assert.fail("Monthly chart is not displayed");
		}
		Assert.assertTrue(oPageLib.getCalendarBox().isDisplayed(), "Calendar box is not displayed for Monthly chart");
		logger.info("Calendar box is displayed for Monthly chart");
		currentDate=oPageLib.getDateBox().getAttribute("value");
		Assert.assertEquals(currentDate, date, "Date doesn't remain same for Monthly chart");
		logger.info("Date remains same for Monthly chart. Date : " + currentDate);

		//Verifying Daily chart
		oPageLib.getDailyButton().click();
		logger.info("Clicked on Daily button");
		try {
			Assert.assertTrue(oPageLib.getDailyChart().isDisplayed(), "Daily chart is not displayed");
			logger.info("Daily chart is displayed");
		}
		catch(NoSuchElementException e) {
			Assert.fail("Daily chart is not displayed");
		}
		Assert.assertTrue(oPageLib.getCalendarBox().isDisplayed(), "Calendar box is not displayed for Daily chart");
		logger.info("Calendar box is displayed for Daily chart");
		currentDate=oPageLib.getDateBox().getAttribute("value");
		Assert.assertEquals(currentDate, date, "Date doesn't remain same for Daily chart");
		logger.info("Date remains same for Daily chart. Date : " + currentDate);
	}

	/************************************************************************************************	
	  Method Description(TC-0028) : With the CHANGE DATE dropdown still up on the screen, try changing stock tickers in the SEARCH field at the upper-left of the Tool screen. Does the stock chart change below, even while the periodicity remains the same, and the CHANGE DATE dropdown remains on the screen?
	  @Author:Mukund               					@Date:20-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC028_TopButtons1(String symbol) {
		if(!oPageLib.getCalendarBox().isDisplayed()) {
			oPageLib.getCalendarExpandBtn().click();
			logger.info("Clicked on Calender Expand button");
		}
		WebElement activeButton=null;
		if(oPageLib.getDailyButton().getAttribute("class").contains("Active")) {
			activeButton=oPageLib.getDailyButton();
		}
		else if(oPageLib.getWeeklyButton().getAttribute("class").contains("Active")) {
			activeButton=oPageLib.getWeeklyButton();
		}
		else if(oPageLib.getMonthlyButton().getAttribute("class").contains("Active")) {
			activeButton=oPageLib.getMonthlyButton();
		}
		//Searching for symbol & verifying chart is opened
		oPageLib.getSearchBox().clear();
		oPageLib.getSearchBox().sendKeys(symbol);
		Actions actions=new Actions(driver);
		actions.sendKeys(Keys.ENTER).perform();
		String companyText=oPageLib.getCompanyNameOnChart().getText();
		Assert.assertTrue(companyText.contains(symbol), "Chart is not opened for " + symbol + ". Company name on chart : " + companyText);
		logger.info("Chart is opened for " + symbol + ". Company name on chart : " + companyText);

		//Verifying Periodicity
		Assert.assertTrue(activeButton.getAttribute("class").contains("Active"), "Periodicity doesn't remain same");
		logger.info("Periodicity remains same");

		//Verifying calendar box
		Assert.assertTrue(oPageLib.getCalendarBox().isDisplayed(), "Calendar box is not displayed for Daily chart");
		logger.info("Calendar box is displayed for Daily chart");
	}

	/************************************************************************************************	
	  Method Description(TC-0039) : Is there a STOCK IDEAS button present? Does it highlight orange when you hover over it?
	  @Author:Mukund               					@Date:16-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC039_TopButtons1() {
		try {
			WebElement stockIdeasBtn=oPageLib.getStockIdeas();
			Assert.assertTrue(stockIdeasBtn.isDisplayed(), "Stock Ideas button is not displayed");
			logger.info("Stock Ideas button is displayed");
			performMouseHover(stockIdeasBtn);
			String bgImg=stockIdeasBtn.getCssValue("background-image").replace("url(\"", "").replace("\")", "");
			Assert.assertEquals(bgImg, CONSTANTS.getProperty("STOCK_IDEAS_ACTIVE"), "Stock Ideas button is not highlighted orange");
			logger.info("Stock Ideas button is highlighted orange");
		}
		catch(NoSuchElementException e) {
			Assert.fail("Stock Ideas button is not present");
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0041) : Under REPORTS, verify the following are present, and that a VIEW button is to the right of each one: "MarketSmith Growth 250," "Breaking Out Today," "IBD 50 Index," "Weekly Report of Stocks Approaching or At New High," "Fastest Growing Companies - Top 150," "Top Rated IPOs,"  "Today's Industry Performance - NEW HIGHS," "Daily % Change (Industry Group)," "Daily Graphs Company Index." 
	  @Author:Mukund               					@Date:16-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC041_TopButtons1() {
		oPageLib.getStockIdeas().click();
		logger.info("Clicked on Stock Ideas button");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getStockIdeasPopup()));
			logger.info("Stock Ideas pop up is displayed");
		}
		catch(Exception e) {
			Assert.fail("Stock Ideas pop up is not displayed");
		}

		String[] expectedLinks = { CONSTANTS.getProperty("REPORTS_LINK_1"), CONSTANTS.getProperty("REPORTS_LINK_2"),
				CONSTANTS.getProperty("REPORTS_LINK_3"), CONSTANTS.getProperty("REPORTS_LINK_4"),
				CONSTANTS.getProperty("REPORTS_LINK_5"), CONSTANTS.getProperty("REPORTS_LINK_6"),
				CONSTANTS.getProperty("REPORTS_LINK_7"), CONSTANTS.getProperty("REPORTS_LINK_8"),
				CONSTANTS.getProperty("REPORTS_LINK_9"), CONSTANTS.getProperty("REPORTS_LINK_10"),
				CONSTANTS.getProperty("REPORTS_LINK_11"), CONSTANTS.getProperty("REPORTS_LINK_12"),
				CONSTANTS.getProperty("REPORTS_LINK_13") };
		List<WebElement> links=oPageLib.getReportLinks();
		List<String> actualLinks=new ArrayList<String>();
		for(WebElement link : links) {
			actualLinks.add(link.getText().trim().replace("View", ""));
		}
		SoftAssert softAssert=new SoftAssert();
		for(int index=0;index<expectedLinks.length;index++) {
			softAssert.assertEquals(actualLinks.get(index), expectedLinks[index], "Link text is not matched under Reports");
			logger.info("Link text is matched under Reports. Link Text : " + actualLinks.get(index));
		}
		softAssert.assertAll();
	}

	/************************************************************************************************	
	  Method Description(TC-0042) : For each of the REPORTS above, click the VIEW button. Each one should cause the FIND STOCK IDEAS window to disappear, and the report you clicked on should appear in the LIST MANAGER panel at the bottom of your screen.
	  @Author:Mukund               					@Date:20-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC042_TopButtons1() {
		if(!oPageLib.getStockIdeasPopup().isDisplayed()) {
			oPageLib.getStockIdeas().click();
			logger.info("Clicked on Stock Ideas button");
		}
		List<WebElement> viewButtons=oPageLib.getViewBtnReport();
		List<WebElement> links=oPageLib.getReportLinks();
		int listSize=links.size();
		for(int index=0;index<listSize;index++) {
			//Clicking on View button
			String linkText=links.get(index).getText().trim();
			viewButtons.get(index).click();
			logger.info("Clicked on View button of " + linkText);
			//Verifying Stock Idea pop up is closed
			Assert.assertFalse(oPageLib.getStockIdeasPopup().isDisplayed(), "Stock Ideas pop up is not closed");
			logger.info("Stock Ideas pop up is closed");
			//Verifying report appeared on list manager
			String reportLM=oPageLib.getListNameLM().getText().trim();
			Assert.assertEquals(reportLM, linkText, "Report name is not matched on List Manager");
			logger.info("Report name is matched on List Manager. Report name : " + reportLM);
			oPageLib.getStockIdeas().click();
			logger.info("Clicked on Stock Ideas button");
			viewButtons=oPageLib.getViewBtnReport();
			links=oPageLib.getReportLinks();
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0043) : Under SCREENS, verify the following are present: "Up on Volume," "William J. O'Neil."
	  @Author:Mukund               					@Date:16-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC043_TopButtons1() {
		String[] expectedLinks = {CONSTANTS.getProperty("SCREEN_LINK_1"), CONSTANTS.getProperty("SCREEN_LINK_2")};
		List<WebElement> links=oPageLib.getScreenLinks();
		List<String> actualLinks=new ArrayList<String>();
		for(WebElement link : links) {
			actualLinks.add(link.getText().trim().replace("View", ""));
		}
		SoftAssert softAssert=new SoftAssert();
		for(int index=0;index<expectedLinks.length;index++) {
			softAssert.assertEquals(actualLinks.get(index), expectedLinks[index], "Link text is not matched under Screens");
			logger.info("Link text is matched under Screens. Link Text : " + actualLinks.get(index));
		}
		softAssert.assertAll();
	}

	/************************************************************************************************	
	  Method Description(TC-0044) : For each SCREEN, click VIEW. The FIND STOCK IDEAS window should disappear, the SCREENER panel should maximize across your screen, and the results of the screen should appear in the LIST MANAGER at the bottom of your screen.
	  @Author:Mukund               					@Date:20-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC044_TopButtons1() {
		if(!oPageLib.getStockIdeasPopup().isDisplayed()) {
			oPageLib.getStockIdeas().click();
			logger.info("Clicked on Stock Ideas button");
		}
		List<WebElement> viewButtons=oPageLib.getViewBtnScreen();
		List<WebElement> links=oPageLib.getReportLinks();
		int listSize=links.size();
		for(int index=0;index<listSize;index++) {
			//Clicking on View button
			String linkText=links.get(index).getText().trim();
			viewButtons.get(index).click();
			logger.info("Clicked on View button of " + linkText);
			//Verifying Stock Idea pop up is closed
			Assert.assertFalse(oPageLib.getStockIdeasPopup().isDisplayed(), "Stock Ideas pop up is not closed");
			logger.info("Stock Ideas pop up is closed");
			//Verifying report appeared on list manager
			String reportLM=oPageLib.getListNameLM().getText().trim();
			Assert.assertEquals(reportLM, linkText, "Report name is not matched on List Manager");
			logger.info("Report name is matched on List Manager. Report name : " + reportLM);
			oPageLib.getStockIdeas().click();
			logger.info("Clicked on Stock Ideas button");
			viewButtons=oPageLib.getViewBtnReport();
			links=oPageLib.getReportLinks();
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0045) : Under MARKET ANALYSIS, verify the following are present: "Read MarketSmith's latest blog post," "Make the most of MarketSmith by watching our webinars."
	  @Author:Mukund               					@Date:16-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC045_TopButtons1() {
		String[] expectedLinks = {CONSTANTS.getProperty("MARKET_ANALYSIS_LINK_1"), CONSTANTS.getProperty("MARKET_ANALYSIS_LINK_2")};
		List<WebElement> links=oPageLib.getScreenLinks();
		List<String> actualLinks=new ArrayList<String>();
		for(WebElement link : links) {
			actualLinks.add(link.getText().trim());
		}
		SoftAssert softAssert=new SoftAssert();
		for(int index=0;index<expectedLinks.length;index++) {
			softAssert.assertEquals(actualLinks.get(index), expectedLinks[index], "Link text is not matched under Market Analysis");
			logger.info("Link text is matched under Market Analysis. Link Text : " + actualLinks.get(index));
		}
		softAssert.assertAll();
	}

	/************************************************************************************************	
	  Method Description(TC-0046) : Clicking on "Read MarketSmith's latest blog post" should open a browser window and take you to COMMUNITY > BLOGS > "MARKETSMITH's blogs." NOTE: the FINS STOCK IDEAS window will not close when clicking on this.
	  @Author:Mukund               					@Date:20-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC046_TopButtons1() {
		//Clicking on link & verifying navigation
		String expectedUrl=CONSTANTS.getProperty("LATEST_BLOG_URL");
		if(!oPageLib.getStockIdeasPopup().isDisplayed()) {
			oPageLib.getStockIdeas().click();
			logger.info("Clicked on Stock Ideas button");
		}
		WebElement link=oPageLib.getMarketAnalysisLinks().get(0);
		String linkText=link.getText();
		link.click();
		logger.info("Clicked on " + linkText + " link");
		try {
			windowHandles();
			String actualUrl=driver.getCurrentUrl();
			Assert.assertEquals(actualUrl, expectedUrl, "Page URL is not matched");
			logger.info("Page URL is matched. URL : " + actualUrl);
		}
		finally {
			if(driver.getWindowHandles().size()>1) {
				driver.close();
				windowHandles();
			}
		}
		//Verifying Stock ideas pop up
		Assert.assertTrue(oPageLib.getStockIdeasPopup().isDisplayed(), "Stock Ideas pop up is closed");
		logger.info("Stock Ideas pop up is not closed");
	}

	/************************************************************************************************	
	  Method Description(TC-0047) : Clicking on "Make the most of MarketSmith by watching our webinars" should open a brower window and bring you to LEARN > WEBINARS.  NOTE: the FIND STOCK IDEAS window will not close when clicking on this.
	  @Author:Mukund               					@Date:20-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC047_TopButtons1() {
		//Clicking on link & verifying navigation
		String expectedUrl=CONSTANTS.getProperty("WEBINARS_URL");
		if(!oPageLib.getStockIdeasPopup().isDisplayed()) {
			oPageLib.getStockIdeas().click();
			logger.info("Clicked on Stock Ideas button");
		}
		WebElement link=oPageLib.getMarketAnalysisLinks().get(1);
		String linkText=link.getText();
		link.click();
		logger.info("Clicked on " + linkText + " link");
		try {
			windowHandles();
			String actualUrl=driver.getCurrentUrl();
			Assert.assertEquals(actualUrl, expectedUrl, "Page URL is not matched");
			logger.info("Page URL is matched. URL : " + actualUrl);
		}
		finally {
			if(driver.getWindowHandles().size()>1) {
				driver.close();
				windowHandles();
			}
		}
		//Verifying Stock ideas pop up
		Assert.assertTrue(oPageLib.getStockIdeasPopup().isDisplayed(), "Stock Ideas pop up is closed");
		logger.info("Stock Ideas pop up is not closed");
	}

	/************************************************************************************************	
	  Method Description(TC-0049) : Click the PRICE ALERT MENU icon (the bell icon to the right of the STOCK IDEAS button). Verify the ALERTS dropdown appears, with three hyperlinks: MANAGE ALERTS, ,VIEW ALL, and SET ALERT.
	  @Author:Mukund               					@Date:20-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC049_TopButtons1() {
		//Clicking on price alert button & verifying popup
		oPageLib.getPriceAlertBtn().click();
		logger.info("Clicked on Price Alert button");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getPriceAlertPopup()));
			logger.info("Price Alert pop up is displayed");
		}
		catch(Exception e) {
			Assert.fail("Price Alert pop up is not displayed");
		}

		//Verifying hyperlinks
		String expectedLinks[] = {CONSTANTS.getProperty("PRICE_ALERT_LINK_1"), CONSTANTS.getProperty("PRICE_ALERT_LINK_2"), CONSTANTS.getProperty("PRICE_ALERT_LINK_3")};
		List<WebElement> links=oPageLib.getPriceAlertLinks();
		for(int index=0;index<links.size();index++) {
			WebElement link=links.get(index);
			String actualLink=link.getText().trim();
			Assert.assertTrue(link.isDisplayed(), actualLink + " is not displayed");
			logger.info(actualLink + " is displayed");
			Assert.assertEquals(actualLink, expectedLinks[index], "Link text is not matched");
			logger.info("Link text is matched. Link Text : " + actualLink);
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0050) : Verify that you can click and drag the grey underside of the window (where the two white horizontal lines are printed) to stretch the window downwards and make it bigger.
	  @Author:Mukund               					@Date:20-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC050_TopButtons1() {
		if(!oPageLib.getPriceAlertPopup().isDisplayed()) {
			oPageLib.getPriceAlertBtn().click();
			logger.info("Clicked on Price Alert button");
		}
		int beforeSize=oPageLib.getPriceAlertPopup().getSize().getHeight();
		int dragBy=200;
		WebElement dragger=oPageLib.getPriceAlertDragger();
		Actions actions=new Actions(driver);
		actions.clickAndHold(dragger).moveByOffset(dragBy, 0).release().perform();
		int afterSize=oPageLib.getPriceAlertPopup().getSize().getHeight();
		Assert.assertEquals(afterSize, beforeSize+dragBy, "Price alert pop up size is not matched after dragging");
		logger.info("Price alert pop up size is matched after dragging. Height : " + afterSize);
	}

	/************************************************************************************************	
	  Method Description(TC-0057) : In the main ALERTS menu, click VIEW ALL. Verify that in the LIST MANAGER at the bottom of the MS Tool window, the ALERTS - TRIGGERED folder opens up. You may or may not have any triggered alerts here.
	  @Author:Mukund               					@Date:20-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC057_TopButtons1() {
		if(!oPageLib.getPriceAlertPopup().isDisplayed()) {
			oPageLib.getPriceAlertBtn().click();
			logger.info("Clicked on Price Alert button");
		}
		WebElement link=oPageLib.getPriceAlertLinks().get(1);
		String linkText=link.getText();
		link.click();
		logger.info("Clicked on " + linkText);
		String lmText=oPageLib.getListNameLM().getText().trim();
		Assert.assertEquals(lmText, CONSTANTS.getProperty("VIEW_ALL_PRICE_ALERTS"), "Triggred Alert text is not matched on List Manager");
		logger.info("Triggred Alert text is matched on List Manager. Text : " + lmText);
	}

	/************************************************************************************************	
	  Method Description(TC-0058) : In the LIST MANAGER, click on ALERTS - ACTIVE. This list should have all of the alerts you just created.
	  @Author:Mukund               					@Date:21-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC058_TopButtons1(String symbolName, String price) {
		//Setting an alert
		if(!oPageLib.getPriceAlertPopup().isDisplayed()) {
			oPageLib.getPriceAlertBtn().click();
			logger.info("Clicked on Price Alert button");
		}
		oPageLib.getPriceAlertLinks().get(2).click();
		logger.info("Clicked on Set Alert link");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getSetAlertPopup()));
			logger.info("Set Alert pop up is opened");
		}
		catch(Exception e) {
			Assert.fail("Set Alert pop up is not opened");
		}
		oPageLib.getSetAlertSymbol().sendKeys(symbolName);
		oPageLib.getSetAlertPrice().sendKeys(price);
		oPageLib.getSetAlertDoneBtn().click();
		logger.info("Alert is set for symbol " + symbolName + " on Price " + price);

		//Verifying that created alert is displayed in Alerts - Active tab
		oPageLib.getPriceAlertBtn().click();
		oPageLib.getPriceAlertLinks().get(0).click();
		oPageLib.getAlertsActive().click();
		logger.info("Clicked on Alert- Active tab");
		List<WebElement> symbols=oPageLib.getSymbolNamesLM();
		List<WebElement> prices=oPageLib.getAlertPricesLM();
		int listSize=symbols.size();
		int index=0;
		for(index=0;index<listSize;index++) {
			if(symbols.get(index).getText().trim().equals(symbolName) && prices.get(index).getText().trim().equals("$" + price)) {
				logger.info(symbolName + " is present in Alerts - Active tab");
				break;
			}
		}
		if(index==listSize) {
			Assert.fail(symbolName + " is not present in Alerts - Active tab");
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0059) : On the main ALERTS menu, click on MANAGE ALERTS. The MANAGE ALERTS WINDOW should open.
	  @Author:Mukund               					@Date:21-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC059_TopButtons1() {
		if(!oPageLib.getPriceAlertPopup().isDisplayed()) {
			oPageLib.getPriceAlertBtn().click();
			logger.info("Clicked on Price Alert button");
		}
		oPageLib.getPriceAlertLinks().get(0).click();
		logger.info("Clicked on Manage Alerts link");
		try {
			smallWait.until(ExpectedConditions.visibilityOf(oPageLib.getSetAlertPopup()));
			logger.info("Manage Alerts pop up is opened");
		}
		catch(Exception e) {
			Assert.fail("Manage Alerts pop up is not opened");
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0061) : Can you DELETE one or more of the alerts using the DELETE button?
	  @Author:Mukund               					@Date:21-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC061_TopButtons1(String symbolName, String price) {
		//Deleting an alert
		List<WebElement> symbols=oPageLib.getSymbolNamesMA();
		List<WebElement> prices=oPageLib.getAlertPricesMA();
		int listSize=symbols.size();
		if(listSize==0) {
			Assert.fail("No symbol found on Manage Alerts window");
		}
		int index=0;
		for(index=0;index<listSize;index++) {
			if(symbols.get(index).getText().trim().equals(symbolName) && prices.get(index).getText().trim().equals("$" + price)) {
				oPageLib.getCheckBoxesMA().get(index).click();
				oPageLib.getDeleteButtonMA().click();
				logger.info("Clicked on Delete button");
				break;
			}
		}
		if(index==listSize) {
			Assert.fail(symbolName + " is not present in Manage Alerts window");
		}
		//Verifying that alert is deleted
		symbols=oPageLib.getSymbolNamesMA();
		prices=oPageLib.getAlertPricesMA();
		listSize=symbols.size();
		index=0;
		for(index=0;index<listSize;index++) {
			if(symbols.get(index).getText().trim().equals(symbolName) && prices.get(index).getText().trim().equals("$" + price)) {
				Assert.fail(symbolName + " symbol is present in Manage Alerts window after deletion");
				break;
			}
		}
		if(index==listSize) {
			Assert.fail(symbolName + " symbol is deleted from Manage Alerts window");
		}
	}

	/************************************************************************************************	
	  Method Description(TC-0063) : Do the various checkboxes function?
	  @Author:Mukund               					@Date:21-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC063_TopButtons1() {
		WebElement checkbox=oPageLib.getCheckBoxesMA().get(0);
		checkbox.click();
		logger.info("Clicked on First checkbox on Manage Alerts window");
		Assert.assertTrue(checkbox.isSelected(), "First checkbox is not selected on Manage Alerts window");
		logger.info("First checkbox is selected on Manage Alerts window");
	}

	/************************************************************************************************	
	  Method Description(TC-0064) : Do the various EMAIL buttons function?
	  @Author:Mukund               					@Date:21-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC064_TopButtons1() {
		WebElement emailButton=oPageLib.getEmailButtonsMA().get(0);
		String buttonText=emailButton.getText();
		String expectedText=null;
		if(buttonText.equals("ON")) {
			expectedText="OFF";
		}
		else if(buttonText.equals("OFF")) {
			expectedText="ON";
		}
		emailButton.click();
		logger.info("Clicked on " + buttonText + " button");
		String actualText=emailButton.getText();
		Assert.assertEquals(actualText, expectedText, "Email button text is not matched after clicking on it");
		logger.info("Email button text is matched after clicking on it. Button text : " + actualText);
	}

	/************************************************************************************************	
	  Method Description(TC-0066) : Click over to the TRIGGERED ALERTS tab. Do the various checkboxes function?
	  @Author:Mukund               					@Date:21-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC066_TopButtons1() {
		oPageLib.getTriggeredAlertsTabMA().click();
		logger.info("Clicked on Triggered alert tab on Manage Alerts window");
		WebElement checkbox=oPageLib.getCheckBoxesMA().get(0);
		checkbox.click();
		logger.info("Clicked on First checkbox on Manage Alerts window");
		Assert.assertTrue(checkbox.isSelected(), "First checkbox is not selected on Triggered alert tab of Manage Alerts window");
		logger.info("First checkbox is selected on Triggered alert tab of Manage Alerts window");
	}

	/************************************************************************************************	
	  Method Description(TC-0067) : Click over to the TRIGGERED ALERTS tab. Do the various EMAIL buttons function?
	  @Author:Mukund               					@Date:21-02-2017 
	  Changes made#1: 
	 ************************************************************************************************/
	public void TC067_TopButtons1() {
		WebElement emailButton=oPageLib.getEmailButtonsMA().get(0);
		String buttonText=emailButton.getText();
		String expectedText=null;
		if(buttonText.equals("ON")) {
			expectedText="OFF";
		}
		else if(buttonText.equals("OFF")) {
			expectedText="ON";
		}
		emailButton.click();
		logger.info("Clicked on " + buttonText + " button");
		String actualText=emailButton.getText();
		Assert.assertEquals(actualText, expectedText, "Email button text is not matched after clicking on it");
		logger.info("Email button text is matched after clicking on it. Button text : " + actualText);
	}
}
