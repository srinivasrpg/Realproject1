package site;

import static genericLib.Utility.*;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import genericLib.Utility;

public class HomePageLoggedInUser {
	HomePageLoggedInUserLib pageLib=PageFactory.initElements(driver, HomePageLoggedInUserLib.class);
	//testCase:0851:Verify you have two tabs at the top of the page: GENERAL INQUIRIES and TECHNICAL SUPPORT in contact MarketSmith page.
	public void tc0851_VerifyContactMarketsmithPageTabs(){
		waitUntilElementIsClickable(pageLib.getcontactUsLink());
		pageLib.getcontactUsLink().click();
		Utility.verifyPageTitle(CONSTANTS.getProperty("CONTACT_MARKETSMITH_PAGE").trim());
		Utility.waitUntilVisibilityOfAllElements(pageLib.getcontactPageTabs());
		List<WebElement> contactPageTabs=pageLib.getcontactPageTabs();
		String expectedTabs[]={"General Inquiries","Technical Support"};
		for(int i=0;i<contactPageTabs.size();i++){
			Assert.assertEquals(contactPageTabs.get(i).getText().trim(), expectedTabs[i],"this tab is missing");
		}
		driver.navigate().back();
	}
	
	//testCase:0857_1:The Learn More About Investing section should have the following links: MarketSmith Blog, Stock Guide, Webinars, Stocks Charts, Stock Market, and Video Tutorials
	public void tc0857_1VerifyAllLinksUnderLearnMoreSection(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
		String learnMoreAbtLinks[]={"MarketSmith Blog","Stock Guide","Webinars","Stock Charts","Stock Market","Video Tutorials"}; 
		 Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnMoreInvestingAllLinks());
		List<WebElement> learnMoreAbtAllLinks=pageLib.getlearnMoreInvestingAllLinks();
		for(int i=0;i<learnMoreAbtAllLinks.size();i++){
			Assert.assertEquals(learnMoreAbtAllLinks.get(i).getText().trim(), learnMoreAbtLinks[i]," Link not present");
		}
	}
	
	//testCase:0857_2: MarketSmith Blog, Make sure  this links work.
	public void tc0857_2ValidateMarketsmitBlogLink(){
		Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnMoreInvestingAllLinks());
		List<WebElement> learnMoreAbtAllLinks=pageLib.getlearnMoreInvestingAllLinks();
		waitUntilElementIsClickable(learnMoreAbtAllLinks.get(0));
		learnMoreAbtAllLinks.get(0).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("BLOGS_PAGE_URL"));
		driver.navigate().back();
	}
	
	//testcase:0857_3:Stock Guide Make sure all of this links work
	public void tc0857_3ValidateStockGuideLink(){
	    Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnMoreInvestingAllLinks());
		List<WebElement> learnMoreAbtAllLinks=pageLib.getlearnMoreInvestingAllLinks();
		waitUntilElementIsClickable(learnMoreAbtAllLinks.get(1));
		learnMoreAbtAllLinks.get(1).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("STOCKGUIDE_PAGE_URL"));
		driver.navigate().back();
	}
	//testCase:0857_4:Webinars,Make sure all of this links work
	public void tc0857_4ValidateWebinarsLink(){
		Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnMoreInvestingAllLinks());
		List<WebElement> learnMoreAbtAllLinks=pageLib.getlearnMoreInvestingAllLinks();
		waitUntilElementIsClickable(learnMoreAbtAllLinks.get(2));
		learnMoreAbtAllLinks.get(2).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("WEBINARS_PAGE_URL"));
		driver.navigate().back();
	}
	//testCase:0857_5:Stocks Charts,Make sure all of this links work
	public void tc0857_5ValidateStockChartsLink(){
		Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnMoreInvestingAllLinks());
		List<WebElement> learnMoreAbtAllLinks=pageLib.getlearnMoreInvestingAllLinks();
		waitUntilElementIsClickable(learnMoreAbtAllLinks.get(3));
		learnMoreAbtAllLinks.get(3).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("STOCK_CHART_PAGE_URL"));
		driver.navigate().back();
	}
	//testCase:0857_6:Stock Market,Make sure all of this links work
	public void tc0857_6ValidateStockMarketLink(){
		List<WebElement> learnMoreAbtAllLinks=pageLib.getlearnMoreInvestingAllLinks();
		waitUntilElementIsClickable(learnMoreAbtAllLinks.get(4));
		learnMoreAbtAllLinks.get(4).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("STOCK_MARKET_PAGE_URL"));
		driver.navigate().back();
	}
	//testCase:0857_7:Video Tutorials. Make sure all of the links work.
	public void tc0857_7ValidateVideoTutorialsLink(){
		Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnMoreInvestingAllLinks());
		List<WebElement> learnMoreAbtAllLinks=pageLib.getlearnMoreInvestingAllLinks();
		waitUntilElementIsClickable(learnMoreAbtAllLinks.get(5));
		learnMoreAbtAllLinks.get(5).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("VIDEO_TUTORIALS_URL"));
		driver.navigate().back();
	}
	
	//testCase:0880:Hover over the PRODUCTS menu item at the top of the MarketSmith home page. Make sure the following options are listed:MarketSmith Online,Pattern Recognition,Growth 250, and Top Stocks.
	public void tc0880_VerifyProductsOverLinks(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
		String productsHover[]={"MarketSmith","Pattern Recognition","Growth 250","Top Stocks"};
		Actions actions=new Actions(driver);
	 	actions.moveToElement(pageLib.getproductsTab()).build().perform();
	 	Utility.waitUntilVisibilityOfAllElements(pageLib.getproductElements());
		List<WebElement> productsHoverElements=pageLib.getproductElements();
		for(int i=0;i<productsHoverElements.size();i++){
			Assert.assertEquals(productsHoverElements.get(i).getText(), productsHover[i],"element Not present");
		}
	}
	
	
	//testCase:0884_1:Hover over the COMMUNITY menu item at the top of the page, and verify that you see the following links:Blogs,Forums,Shared Lists,Shared Screens
	public void tc0884_1VerifyCommunityHoverLinks(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
		Actions actions=new Actions(driver);
	 	actions.moveToElement(pageLib.getCommunityTab()).build().perform();
	 	logger.info("moved to "+pageLib.getCommunityTab().getText()+" tab");
		String communityHover[]={"Blogs","Shared Lists","Forums","Shared Screens"};
		Utility.waitUntilVisibilityOfAllElements(pageLib.getcommunityElements());
		List<WebElement> communityElements=pageLib.getcommunityElements();
		for(int i=0;i<communityElements.size();i++){
		  logger.info(communityElements.get(i).getText()+" is present");
		  Assert.assertEquals(communityElements.get(i).getText().trim(),communityHover[i], "is not displayed");
	    }
	}	
	
	//testCase:0884_2:Validate Community-Blogs
	public void tc0884_2ValidateBlogsPage(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
		Actions actions=new Actions(driver);
	 	actions.moveToElement(pageLib.getCommunityTab()).build().perform();
	 	Utility.waitUntilVisibilityOfAllElements(pageLib.getcommunityElements());
	 	List<WebElement> communityElements=pageLib.getcommunityElements();
		waitUntilElementIsClickable(communityElements.get(0)); 
		communityElements.get(0).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("COMMUNITY_BLOGS_PAGE"));
		driver.navigate().back();
	}
	
	//testCase:0884_3:Community-Shared Lists
	public void tc0884_3ValidateSharedListPage(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
		Actions actions=new Actions(driver);
		actions.moveToElement(pageLib.getCommunityTab()).build().perform();
	 	Utility.waitUntilVisibilityOfAllElements(pageLib.getcommunityElements());
	 	List<WebElement> communityElements=pageLib.getcommunityElements();
	 	waitUntilElementIsClickable(communityElements.get(1)); 
		communityElements.get(1).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("COMMUNITY_SHAREDLIST_PAGE"));
		driver.navigate().back();
	}
	
	//testCase:0884_4:Community-Forums
	public void tc0884_4ValidateForumsPage(){
		Actions actions=new Actions(driver);
	 	actions.moveToElement(pageLib.getCommunityTab()).build().perform();
	 	Utility.waitUntilVisibilityOfAllElements(pageLib.getcommunityElements());
	 	List<WebElement> communityElements=pageLib.getcommunityElements();
		waitUntilElementIsClickable(communityElements.get(2)); 
		communityElements.get(2).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("COMMUNITY_FORUMS_PAGE"));
		driver.navigate().back();
	}
	
	//testCase:0884_5:Community-Shared Screens
	public void tc0884_5ValidateSharedScreensPage(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
		Actions actions=new Actions(driver);
		actions.moveToElement(pageLib.getCommunityTab()).build().perform();
		Utility.waitUntilVisibilityOfAllElements(pageLib.getcommunityElements());
	 	List<WebElement> communityElements=pageLib.getcommunityElements();
	 	System.out.println(communityElements.size());
		waitUntilElementIsClickable(communityElements.get(3)); 
		communityElements.get(3).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("COMMUNITY_SHAREDSCREEN_PAGE"));
		driver.navigate().back();
	}
	
	//testCase:0925_1:Learn-The hover menu should appear with the following items:Glossary,Live Events,Stock Charts,Video Tutorials,Stock Guide,Stock Market, and Webinars.
	public void tc0925_1VerifyLearnOverElements(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
		Actions actions=new Actions(driver);
	    actions.moveToElement(pageLib.getLearnTab()).build().perform();
	    logger.info("moved to "+pageLib.getLearnTab().getText()+" tab");
		String learnHoverLinks[]={"Glossary","Live Events","Stock Charts","Video Tutorials","Stock Guide","Stock Market","Webinars"};
		Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnElements());
		List<WebElement> learnElements=pageLib.getlearnElements();
		for(int i=0;i<learnElements.size();i++){
		logger.info(learnElements.get(i).getText()+" is present");
		Assert.assertEquals(learnElements.get(i).getText().trim(),learnHoverLinks[i], "is not displayed");
	   }
	}
	
	//testCase:0925_2:Validate Learn-Glossary Link
	public void tc0925_2ValidateLearnGlossaryPage(){
		waitUntilElementIsClickable(pageLib.getLearnTab());
		Actions actions=new Actions(driver);
	 	actions.moveToElement(pageLib.getLearnTab()).build().perform();
	 	Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnElements());
	 	List<WebElement> learnElements=pageLib.getlearnElements();
		waitUntilElementIsClickable(learnElements.get(0)); 
		learnElements.get(0).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("LEARN_GLOSSARY_PAGE"));
		driver.navigate().back();
	}
	
	//testCase:0925_3:VAlidate Learn-Live Events Page
	public void tc0925_3ValidateLearnLiveEventsPage(){
		waitUntilElementIsClickable(pageLib.getLearnTab());
		Actions actions=new Actions(driver);
	 	actions.moveToElement(pageLib.getLearnTab()).build().perform();
	 	Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnElements());
	 	List<WebElement> learnElements=pageLib.getlearnElements();
		waitUntilElementIsClickable(learnElements.get(1)); 
		learnElements.get(1).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("LEARN_LIVE_EVENTS_PAGE_URL"));
		driver.navigate().back();
	}
	
	//testCase:0925_4:Validate Learn-StockCharts Page
	public void tc0925_4ValidateLearnStockChartPage(){
		waitUntilElementIsClickable(pageLib.getLearnTab());
		Actions actions=new Actions(driver);
	 	actions.moveToElement(pageLib.getLearnTab()).build().perform();
	 	Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnElements());
	 	List<WebElement> learnElements=pageLib.getlearnElements();
		waitUntilElementIsClickable(learnElements.get(2)); 
		learnElements.get(2).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("LEARN_STOCK_CHARTS_PAGE_URL"));
		driver.navigate().back();
	}
	
	//testCase:0925_5:Validate Learn-Video Tutorials page
	public void tc0925_5ValidateLearnVideoTutorials(){
		waitUntilElementIsClickable(pageLib.getLearnTab());
		Actions actions=new Actions(driver);
	 	actions.moveToElement(pageLib.getLearnTab()).build().perform();
	 	Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnElements());
	 	List<WebElement> learnElements=pageLib.getlearnElements();
		waitUntilElementIsClickable(learnElements.get(3)); 
		learnElements.get(3).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("LEARN_VIDEO_TUTORIALS_PAGE_URL"));
		driver.navigate().back();
	}
	
	//testCase:0925_6:Validate Learn-Stock Guide page
	public void tc0925_6ValidateLearnStockGuidePage(){
		waitUntilElementIsClickable(pageLib.getLearnTab());
		Actions actions=new Actions(driver);
	 	actions.moveToElement(pageLib.getLearnTab()).build().perform();
	 	Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnElements());
	 	List<WebElement> learnElements=pageLib.getlearnElements();
		waitUntilElementIsClickable(learnElements.get(4)); 
		learnElements.get(4).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("LEARN_STOCK_GUIDE_PAGE_URL"));
		driver.navigate().back();
	}
	
	//testCase:0925_7:VAlidate Learn-Stock Markets page
	public void tc0925_7ValidateLearnStockMarketsPage(){
		waitUntilElementIsClickable(pageLib.getLearnTab());
		Actions actions=new Actions(driver);
	 	actions.moveToElement(pageLib.getLearnTab()).build().perform();
	 	Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnElements());
	 	List<WebElement> learnElements=pageLib.getlearnElements();
		waitUntilElementIsClickable(learnElements.get(5)); 
		learnElements.get(5).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("LEARN_STOCK_MARKET_PAGE_URL"));
		driver.navigate().back();
	}
	//testCase:0925_8:Validate Learn-Webinars page
	public void tc0925_8ValidateLearnWebinarsPage(){
		waitUntilElementIsClickable(pageLib.getLearnTab());
		Actions actions=new Actions(driver);
	 	actions.moveToElement(pageLib.getLearnTab()).build().perform();
	 	Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnElements());
	 	List<WebElement> learnElements=pageLib.getlearnElements();
		waitUntilElementIsClickable(learnElements.get(6)); 
		learnElements.get(6).click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("LEARN_WEBINARS_PAGE_URL"));
		driver.navigate().back();
	}
	
	//testCase:0927:tabs are visible in Learn page:Introduction,Screening,Chart Analysis,List Management,Investing,Community.
	public void tc0927_VerifyTabsAvailableInLearnsPage(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
		waitUntilElementIsClickable(pageLib.getLearnTab());
		pageLib.getLearnTab().click();
		Utility.verifyPageUrl(CONSTANTS.getProperty("LEARN_PAGE_URL"));
		String learnPageTabs[]={"Introduction","Screening","Chart Analysis","List Management","Investing","Community"};
		Utility.waitUntilVisibilityOfAllElements(pageLib.getlearnPageTabs());
		List<WebElement> learnPageAllTabs=pageLib.getlearnPageTabs();
		for(int i=0;i<learnPageAllTabs.size();i++){
			Assert.assertEquals(learnPageAllTabs.get(i).getText().trim(), learnPageTabs[i],"Tab not present");
		}
		driver.navigate().back();
	}
	
	//testCase:0934:Click on the SUPPORT menu item at the top of the screen verify you are taken to the SUPPORT page.
	public void tc0934_VerifySupportMenu(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
		waitUntilElementIsClickable(pageLib.SupportMenu());
		WebElement SupportMenuButton1=pageLib.SupportMenu();
		SupportMenuButton1.click();
		waitUntilElementisVisible(pageLib.getgeneralSupport());
		Utility.verifyPageUrl(CONSTANTS.getProperty("MARKET_SMITH_SUPPORT_PAGE"));
		driver.navigate().back();
	}
	
	//testCase:1008:Verify that user is navigated to community page upon clicking on it.
	public void tc1008_ValidateCommunityTab(){
		Utility.verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
		WebElement communityTab=pageLib.getCommunityTab();
		String communityTabText=communityTab.getText();
		communityTab.click();
		logger.info("clicked on "+communityTabText+" tab");
		waitUntilElementisVisible(pageLib.getblogsTabInCommPage());
		Utility.verifyPageTitle(CONSTANTS.getProperty("COMMUNITY_PAGE_TITLE"));
	}
	
	
	//testCase:1009:Verify that user is navigated to MyIBD upon clicking on it
	public void tc1009_ValidateAccountTab() throws InterruptedException{
		driver.navigate().back();
		Utility.verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
		WebElement myAccountTab=pageLib.getmyAccountTab();
		String myAccountTabText=myAccountTab.getText();
		myAccountTab.click();
		logger.info("clicked on "+myAccountTabText+" tab");
		waitUntilElementisVisible(pageLib.getheaderImageInIBD());
		Utility.verifyPageTitle(CONSTANTS.getProperty("MY_IBD_PAGE_TITLE"));
		driver.navigate().back();
		Utility.launchMSTool();
	}
	
	
	
	//Test Case : 1000 : Verify Set Up an Appointment link on site
	public void tc1000_setUpAppointment(){
		 try {
				WebElement settingIcon = pageLib.getLoginButton();
				if (settingIcon.isDisplayed()) {
					logger.info("Not Logged In");
				} else {
					throw new Exception();
				}
			} catch (Exception e) {
				waitUntilElementIsClickable(pageLib.getSetUpAppointment());
				WebElement setUpAppButton=pageLib.getSetUpAppointment();
				String setUpAppButtonText=setUpAppButton.getText();
				setUpAppButton.click();
				logger.info("clicked on  "+setUpAppButtonText+"  button");
				
			}
	}
	

}
