package site;

import static genericLib.Utility.*;

import java.util.Hashtable;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import charts.ChartPageLib;
import excelReader.TestUtil;
import genericLib.Utility;
import global.MarketsmithHomePageLib;

public class LaunchChart {
	static MarketsmithHomePageLib pageLib=PageFactory.initElements(driver, MarketsmithHomePageLib.class);
	static ChartPageLib chartLib=PageFactory.initElements(driver, ChartPageLib.class);
	static WebDriverWait wait = new WebDriverWait(driver, 60);
	
	public void chart(){
		Hashtable<String, String> data=TestUtil.getData("loginToMarketSmith", "Global",Utility.dataXl);
		loginToMarketSmith(data.get("UserName"), data.get("Password"));
	    launchMSTool();
		
	}
    
    //Login to MarketSmith and Launch tool
	public static void loginToMarketSmith(String userName, String password) {
		try {
			WebElement settingIcon=pageLib.getLogoutButton();	
			if(settingIcon.isDisplayed()) {
				logger.info("Already Logged In");
			}
			else {
				throw new Exception();
			}
		}
		catch(Exception e) {
			
			//adding to click on MAIN Sign In Button to bring up pop up
			pageLib.getMainSignInButton().click();
			waitUntilElementisVisible(pageLib.getSignInModalBox());
			driver.switchTo().frame(pageLib.getLoginFrame());
			waitUntilVisibilityOfElement();
			pageLib.getUserNameTextbox().sendKeys(userName);
			logger.info(userName + " is entered as Username");
			pageLib.getPasswordTextbox().sendKeys(password);
			logger.info(password + " is entered as Password");
			WebElement loginButton=pageLib.getLoginButton();
			String loginButtonText=loginButton.getAttribute("title");
			loginButton.click();
			logger.info("Clicked on " + loginButtonText + " button");
			driver.switchTo().defaultContent();

			if(driver.getCurrentUrl().contains(CONSTANTS.getProperty("CAMPAIGN_URL")))
				driver.navigate().back();
			try {
				wait.until(ExpectedConditions.visibilityOf(pageLib.getLogoutButton()));
				logger.info("User logged in successfully");
				logger.info("------------------------------------------------------------");
			}catch(TimeoutException ex) {
				if(driver.getCurrentUrl().contains(CONSTANTS.getProperty("CAMPAIGN_URL")))
					driver.navigate().back();
			}
		}
		}
		
		public static void launchMSTool() {
			//if logged in, throw exception and execute exception code?
			if (!waitUntilElementisVisible(pageLib.getLogoutButton())) {
				logger.info("Not Logged In");
			} else {
				waitUntilElementIsClickable(chartLib.getOpenChartButton());
				WebElement openChartBtn = chartLib.getOpenChartButton();
				String openChartBtnText = openChartBtn.getText();
				openChartBtn.click();
				logger.info("Clicked on " + openChartBtnText + " button");
				try {
					Utility.windowHandles();
					wait.until(ExpectedConditions.urlToBe(CONSTANTS.getProperty("MSTOOL_URL")));
					Utility.waitUntilElementisVisible(chartLib.getMainPriceChart());
					logger.info("User launched MSTOOL successfully");
					Thread.sleep(5000);
				}
				catch(TimeoutException te) {
					Assert.assertEquals(driver.getCurrentUrl(), CONSTANTS.getProperty("MSTOOL_URL"), "MSTOOL URL is not matched");
				} catch (InterruptedException e) {
					logger.info("MSTOOL URL is not matched");
				}
			}  
		}
	}

