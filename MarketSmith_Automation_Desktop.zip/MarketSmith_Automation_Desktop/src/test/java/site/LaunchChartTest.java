package site;

import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import excelReader.TestUtil;
import genericLib.Utility;
import static genericLib.Utility.*;

public class LaunchChartTest {
	LaunchChart oLaunchChart;
	
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		oLaunchChart=new LaunchChart();
	}
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			Utility.takeScreenShot(imageName);
		} 
	}
	
	@Test(groups={"Regression"})
	public void MSLoginAndLauncTool(){
		if (!TestUtil.isExecutable("chart", "Site",Utility.runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Login to MS site and launc MS tool------------");
	  oLaunchChart.chart();
	}
	
}	