package site;

import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import excelReader.TestUtil;
import static genericLib.Utility.*;

public class HomePageLoggedInUserTest {
	HomePageLoggedInUser siteObj;
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		siteObj=new HomePageLoggedInUser();
	}
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			takeScreenShot(imageName);
		} 
	}
	/*@BeforeTest(alwaysRun=true)
	public void beforeMethodSetting(){
	Hashtable<String, String> data=TestUtil.getData("loginToMarketSmith", "Global",	BaseClass.dataXl);	
    Utility.tc001_loginToMarketSmith(data.get("UserName"), data.get("Password"));	
    }*/
	
	@Test(groups={"Regression"})
	public void tc0851_VerifyContactMarketsmithPageTabs(){
		if (!TestUtil.isExecutable("tc0851_VerifyContactMarketsmithPageTabs", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Verify you have two tabs at the top of the page: GENERAL INQUIRIES and TECHNICAL SUPPORT in contact MarketSmith page.------------");
	  siteObj.tc0851_VerifyContactMarketsmithPageTabs();
	}
	@Test(groups={"Regression"})
	public void tc0857_1VerifyAllLinksUnderLearnMoreSection(){
		if (!TestUtil.isExecutable("tc0857_1VerifyAllLinksUnderLearnMoreSection", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Learn More About Investing section should have the following links: MarketSmith Blog, Stock Guide, Webinars, Stocks Charts, Stock Market, and Video Tutorials----------");
	  siteObj.tc0857_1VerifyAllLinksUnderLearnMoreSection();
	}
	@Test(groups={"Regression"})
	public void tc0857_2ValidateMarketsmitBlogLink(){
		if (!TestUtil.isExecutable("tc0857_2ValidateMarketsmitBlogLink", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing MarketSmith Blog, Make sure  this links work.------------");
	  siteObj.tc0857_2ValidateMarketsmitBlogLink();
	}
	@Test(groups={"Regression"})
	public void tc0857_3ValidateStockGuideLink(){
		if (!TestUtil.isExecutable("tc0857_3ValidateStockGuideLink", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Stock Guide Make sure all of this links work------------");
	  siteObj.tc0857_3ValidateStockGuideLink();
	}
	@Test(groups={"Regression"})
	public void tc0857_4ValidateWebinarsLink(){
		if (!TestUtil.isExecutable("tc0857_4ValidateWebinarsLink", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Webinars,Make sure all of this links work.------------");
	  siteObj.tc0857_4ValidateWebinarsLink();
	}
	@Test(groups={"Regression"})
	public void tc0857_5ValidateStockChartsLink(){
		if (!TestUtil.isExecutable("tc0857_5ValidateStockChartsLink", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Stocks Charts,Make sure all of this links work.------------");
	  siteObj.tc0857_5ValidateStockChartsLink();
	}
	@Test(groups={"Regression"})
	public void tc0857_6ValidateStockMarketLink(){
		if (!TestUtil.isExecutable("tc0857_6ValidateStockMarketLink", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Stock Market,Make sure all of this links work.------------");
	  siteObj.tc0857_6ValidateStockMarketLink();
	}
	@Test(groups={"Regression"})
	public void tc0857_7ValidateVideoTutorialsLink(){
		if (!TestUtil.isExecutable("tc0857_7ValidateVideoTutorialsLink", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Video Tutorials. Make sure all of the links work..------------");
	  siteObj.tc0857_7ValidateVideoTutorialsLink();
	}
	@Test(groups={"Regression"})
	public void tc0880_VerifyProductsOverLinks(){
		if (!TestUtil.isExecutable("tc0880_VerifyProductsOverLinks", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Make sure the following options are listed:MarketSmith Online,Pattern Recognition,Growth 250, and Top Stocks------------");
	  siteObj.tc0880_VerifyProductsOverLinks();
	}
	@Test(groups={"Regression"})
	public void tc0884_1VerifyCommunityHoverLinks(){
		if (!TestUtil.isExecutable("tc0884_1VerifyCommunityHoverLinks", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Hover over the COMMUNITY menu item at the top of the page, and verify that you see the following links:Blogs,Forums,Shared Lists,Shared Screens..------------");
	  siteObj.tc0884_1VerifyCommunityHoverLinks();
	}
	@Test(groups={"Regression"})
	public void tc0884_2ValidateBlogsPage(){
		if (!TestUtil.isExecutable("tc0884_2ValidateBlogsPage", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Validate Community-Blogs------------");
	  siteObj.tc0884_2ValidateBlogsPage();
	}
	@Test(groups={"Regression"})
	public void tc0884_3ValidateSharedListPage(){
		if (!TestUtil.isExecutable("tc0884_3ValidateSharedListPage", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Community-Shared Lists.------------");
	  siteObj.tc0884_3ValidateSharedListPage();
	}
	@Test(groups={"Regression"})
	public void tc0884_4ValidateForumsPage(){
		if (!TestUtil.isExecutable("tc0884_4ValidateForumsPage", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Community-Forums------------");
	  siteObj.tc0884_4ValidateForumsPage();
	}
	@Test(groups={"Regression"})
	public void tc0884_5ValidateSharedScreensPage(){
		if (!TestUtil.isExecutable("tc0884_5ValidateSharedScreensPage", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Community-Shared Screens.------------");
	  siteObj.tc0884_5ValidateSharedScreensPage();
	}
	@Test(groups={"Regression"})
	public void tc0925_1VerifyLearnOverElements(){
		if (!TestUtil.isExecutable("tc0925_1VerifyLearnOverElements", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Learn-The hover menu should appear with the following items:Glossary,Live Events,Stock Charts,Video Tutorials,Stock Guide,Stock Market, and Webinars------------");
	  siteObj.tc0925_1VerifyLearnOverElements();
	}
	@Test(groups={"Regression"})
	public void tc0925_2ValidateLearnGlossaryPage(){
		if (!TestUtil.isExecutable("tc0925_2ValidateLearnGlossaryPage", "Site",	runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Validate Learn-Glossary Link-----------");
	  siteObj.tc0925_2ValidateLearnGlossaryPage();
	}
	@Test(groups={"Regression"})
	public void tc0925_3ValidateLearnLiveEventsPage(){
		if (!TestUtil.isExecutable("tc0925_3ValidateLearnLiveEventsPage", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing VAlidate Learn-Live Events Page------------");
	  siteObj.tc0925_3ValidateLearnLiveEventsPage();
	}
	@Test(groups={"Regression"})
	public void tc0925_4ValidateLearnStockChartPage(){
		if (!TestUtil.isExecutable("tc0925_4ValidateLearnStockChartPage", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Validate Learn-StockCharts Page------------");
	  siteObj.tc0925_4ValidateLearnStockChartPage();
	}
	@Test(groups={"Regression"})
	public void tc0925_5ValidateLearnVideoTutorials(){
		if (!TestUtil.isExecutable("tc0925_5ValidateLearnVideoTutorials", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Validate Learn-Video Tutorials pages------------");
	  siteObj.tc0925_5ValidateLearnVideoTutorials();
	}
	@Test(groups={"Regression"})
	public void tc0925_6ValidateLearnStockGuidePage(){
		if (!TestUtil.isExecutable("tc0925_6ValidateLearnStockGuidePage", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Validate Learn-Stock Guide page------------");
	  siteObj.tc0925_6ValidateLearnStockGuidePage();
	}
	@Test(groups={"Regression"})
	public void tc0925_7ValidateLearnStockMarketsPage(){
		if (!TestUtil.isExecutable("tc0925_7ValidateLearnStockMarketsPage", "Site",	runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing VAlidate Learn-Stock Markets page------------");
	  siteObj.tc0925_7ValidateLearnStockMarketsPage();
	}
	@Test(groups={"Regression"})
	public void tc0925_8ValidateLearnWebinarsPage(){
		if (!TestUtil.isExecutable("tc0925_8ValidateLearnWebinarsPage", "Site",	runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------ExecutingValidate Learn-Webinars page------------");
	  siteObj.tc0925_8ValidateLearnWebinarsPage();
	}
	@Test(groups={"Regression"})
	public void tc0927_VerifyTabsAvailableInLearnsPage(){
		if (!TestUtil.isExecutable("tc0927_VerifyTabsAvailableInLearnsPage", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing tabs are visible in Learn page:Introduction,Screening,Chart Analysis,List Management,Investing,Community.------------");
	  siteObj.tc0927_VerifyTabsAvailableInLearnsPage();
	}
	@Test(groups={"Regression"})
	public void tc0934_VerifySupportMenu(){
		if (!TestUtil.isExecutable("tc0934_VerifySupportMenu", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Click on the SUPPORT menu item at the top of the screen verify you are taken to the SUPPORT page.------------");
	  siteObj.tc0934_VerifySupportMenu();
	}
	@Test(groups={"Regression"})
	public void tc1008_ValidateCommunityTab(){
		if (!TestUtil.isExecutable("tc1008_ValidateCommunityTab", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Verify that user is navigated to community page upon clicking on it..------------");
	  siteObj.tc1008_ValidateCommunityTab();
	}
	@Test(groups={"Regression"})
	public void tc1009_ValidateAccountTab() throws InterruptedException{
		if (!TestUtil.isExecutable("tc1009_ValidateAccountTab", "Site",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Verify that user is navigated to MyIBD upon clicking on it.------------");
	  siteObj.tc1009_ValidateAccountTab();
	}
	
}	