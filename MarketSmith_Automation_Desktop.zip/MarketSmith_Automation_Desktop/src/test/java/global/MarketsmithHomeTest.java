package global;

import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import excelReader.TestUtil;
import static genericLib.Utility.*;

public class MarketsmithHomeTest {
	 MarketsmithHome mshomeObj;
		
		@BeforeTest(alwaysRun=true,groups="Smoke")
		public void initialization() {
			mshomeObj=new MarketsmithHome();
			if (!TestUtil.isExecutable("loginToMarketSmith", "Global",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
			}
			
			Hashtable<String, String> data=TestUtil.getData("loginToMarketSmith", "Global",
					dataXl);	

			mshomeObj.tc001_loginToMarketSmith(data.get("UserName"), data.get("Password"));	
		}
		
		@AfterMethod(alwaysRun=true) 
		public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
			if (testResult.getStatus() == ITestResult.FAILURE) { 
				String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
				takeScreenShot(imageName);
			} 
		}
		@BeforeMethod(alwaysRun=true)
		public void navigateToHomePage() {
			if(!driver.getCurrentUrl().equals(CONFIG.getProperty("testSiteURL"))) {
				driver.navigate().to(CONFIG.getProperty("testSiteURL"));
			}
		}
		
		@AfterTest(alwaysRun=true)
		public void logOut() {
			// check the run mode of test case
			if (!TestUtil.isExecutable("logoutFromMarketSmith", "Global", runModeXl)) {
				throw new SkipException("Runmode set to NO");
			}
			logger.info("------------Executing Test Case : user is logging out------------");
			mshomeObj.tc002_logoutFromMarketSmith();
		}
		
}
