package relatedInformation;

import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import excelReader.TestUtil;
import static genericLib.Utility.*;

public class RelatedInformation3Test {
	RelatedInformation3 riObj;
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		riObj=new RelatedInformation3();
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeErrorPopUp()
	{
		closeErrorMessage();
	}
	
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			takeScreenShot(imageName);
		} 
	}
	@Test(groups={"Regression"})
	public void tc0671_ChartMutualFundTicker(){
		if (!TestUtil.isExecutable("tc0671_ChartMutualFundTicker", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing In List Manager, go to REPORTS>MUTUAL FUNDS, and click on one of the groups in the list to bring up the mutual fund in your CHARTS window------------");
	  riObj.tc0671_ChartMutualFundTicker();
	}
	@Test(groups={"Regression"})
	public void tc0672_VerifyRIForMutualFund(){
		if (!TestUtil.isExecutable("tc0672_VerifyRIForMutualFund", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing When opened, does the sidebar contain the four tabs Profile,Returns,Risk,and Holdings?----------");
	  riObj.tc0672_VerifyRIForMutualFund();
	}
	@Test(groups={"Regression"})
	public void tc0673_VerifyProfileTab(){
		if (!TestUtil.isExecutable("tc0673_VerifyProfileTab", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Open the Profile tab.Verify the following tables appear and load with information:Fund Overview,Expenses,Tax Efficiency,and Purchase Details.----------");
	  riObj.tc0673_VerifyProfileTab();
	}
	@Test(groups={"Regression"})
	public void tc0674_VerifyFundOverviewTable(){
		if (!TestUtil.isExecutable("tc0674_VerifyFundOverviewTable", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Verify Fund Overview contains Net Assets,Objective,Family,O'Neil Ratings vs. Category and All Funds,Fund Manager,Start Date,and Policy Statement.----------");
	  riObj.tc0674_VerifyFundOverviewTable();
	}
	@Test(groups={"Regression"})
	public void tc0675_VerifyExpensesTable(){
		if (!TestUtil.isExecutable("tc0675_VerifyExpensesTable", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Verify Expenses contains Front End Load,Expense Ratio,and 12B-1 Fee.----------");
	  riObj.tc0675_VerifyExpensesTable();
	}
	@Test(groups={"Regression"})
	public void tc0676_VerifyTaxEfficiencyTable(){
		if (!TestUtil.isExecutable("tc0676_VerifyTaxEfficiencyTable", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Verify Tax Efficiency contains Distribtuion Frequency,5-Year After Tax Return,Turnover,and Yield..----------");
	  riObj.tc0676_VerifyTaxEfficiencyTable();
	}
	@Test(groups={"Regression"})
	public void tc0677_VerifyPurchaseDetailsTab(){
		if (!TestUtil.isExecutable("tc0677_VerifyPurchaseDetailsTab", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------ExecutingVerify Verify Purchase Details contains a hyperlink to their website,Phone Number,New Investors, and Min Initial Investment.----------");
	  riObj.tc0677_VerifyPurchaseDetailsTab();
	}
	@Test(groups={"Regression"})
	public void tc0678_ValidateHyperLink(){
		if (!TestUtil.isExecutable("tc0678_ValidateHyperLink", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Does the hyperlink contained in Purchase Details work as expected?----------");
	  riObj.tc0678_ValidateHyperLink();
	}
	@Test(groups={"Regression"})
	public void tc0679_VerifyShowAllFundsInFamily(){
		if (!TestUtil.isExecutable("tc0679_VerifyShowAllFundsInFamily", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing At the bottom, is there a button labeled Show All Funds in Family?----------");
	  riObj.tc0679_VerifyShowAllFundsInFamily();
	}
	@Test(groups={"Regression"})
	public void tc0680_VerifyHideAllFundsFamily(){
		if (!TestUtil.isExecutable("tc0680_VerifyHideAllFundsFamily", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing When clicked, does the button change to Hide All Funds in Family?----------");
	  riObj.tc0680_VerifyHideAllFundsFamily();
	}
	@Test(groups={"Regression"})
	public void tc0681_ValidateHideAllFundsFamily(){
		if (!TestUtil.isExecutable("tc0681_ValidateHideAllFundsFamily", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Does the list manager and sidebar become highlighted and display all Mutual Funds in the family?----------");
	  riObj.tc0681_ValidateHideAllFundsFamily();
	}
	@Test(groups={"Regression"})
	public void tc0682_EnterNewMFWhenLMinHighLightedState(){
		if (!TestUtil.isExecutable("tc0682_EnterNewMFWhenLMinHighLightedState", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing When entering a new mutual fund symbol from a different family, does the list manager display the funds of the new family?----------");
	  Hashtable<String, String> data=TestUtil.getData("tc0682_EnterNewMFWhenLMinHighLightedState", "RelatedInformation",dataXl);
	  riObj.tc0682_EnterNewMFWhenLMinHighLightedState(data.get("Symbol"));
	}
	@Test(groups={"Regression"})
	public void tc0683_VerifyHideAllFundsFamilyText(){
		if (!TestUtil.isExecutable("tc0683_VerifyHideAllFundsFamilyText", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing When clicking Hide All Funds in Family, does the button change back to Show All Funds in Family?----------");
	  riObj.tc0683_VerifyHideAllFundsFamilyText();
	}
	@Test(groups={"Regression"})
	public void tc0684_ValidateShowAllFundsInFamily(){
		if (!TestUtil.isExecutable("tc0684_ValidateShowAllFundsInFamily", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Is the list manager and sidebar no longer highlighted?---------");
	  riObj.tc0684_ValidateShowAllFundsInFamily();	
	}
	@Test(groups={"Regression"})
	public void tc0685_EnterNewMFWhenLMnotHighlighted(){
		if (!TestUtil.isExecutable("tc0685_EnterNewMFWhenLMnotHighlighted", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing When entering a new mutual fund symbol from a different family, do the items in the list manager remain the same?----------");
	  Hashtable<String, String> data=TestUtil.getData("tc0685_EnterNewMFWhenLMnotHighlighted", "RelatedInformation",dataXl);
	  riObj.tc0685_EnterNewMFWhenLMnotHighlighted(data.get("Symbol"));
	}
	@Test(groups={"Regression"})
	public void tc0686_VerifyReturnsTab(){
		if (!TestUtil.isExecutable("tc0686_VerifyReturnsTab", "RelatedInformation",runModeXl)) {
				throw new SkipException("Runmode set to NO");
		     }
		logger.info("------------Executing Open the Returns tab. Verify three tables appear and load with information:Current,Prior Month,and a performance table with no name.----------");
		riObj.tc0686_VerifyReturnsTab();
	}
	@Test(groups={"Regression"})
	public void tc0687_VerifyCurrentAndPriorMonthTabColumns(){
		if (!TestUtil.isExecutable("tc0687_VerifyCurrentAndPriorMonthTabColumns", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	logger.info("------------Executing Verify the Current and Prior Month Tables have three columns. The first being the name of the current mutual fund and the next two of two stock exchanges.---------");
	riObj.tc0687_VerifyCurrentAndPriorMonthTabColumns();
	}
	
	@Test(groups={"Regression"})
	public void TC0688_RelatedInformation(){
		riObj.TC0688_RelatedInformation();
	}
	
	@Test(groups={"Regression"})
	public void TC0689_RelatedInformation(){
		riObj.TC0689_RelatedInformation();
	}
	
	@Test(groups={"Regression"})
	public void TC0690_RelatedInformation(){
		riObj.TC0690_RelatedInformation();
	}
	
	@Test(groups={"Regression"})
	public void TC0691_RelatedInformation(){
		riObj.TC0691_RelatedInformation();
	}
	
	@Test(groups={"Regression"})
	public void TC0692_RelatedInformation(){
		riObj.TC0692_RelatedInformation();
	}
	
	@Test(groups={"Regression"})
	public void TC0693_RelatedInforation(){
		riObj.TC0693_RelatedInforation();
	}
}
