package relatedInformation;

import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import excelReader.TestUtil;
import static genericLib.Utility.*;

public class RelatedInformation2Test {
	RelatedInformation2 riObj;
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		riObj=new RelatedInformation2();
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeErrorPopUp()
	{
		closeErrorMessage();
	}
	
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			takeScreenShot(imageName);
		} 
	}
	@Test(groups={"Regression"})
	public void tc0636_ChartAIndustryGroupTicker(){
		if (!TestUtil.isExecutable("tc0636_ChartAIndustryGroupTicker", "RelatedInformation",runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing select IndustryGroup ticker from 197IndustryGroupsList------------");
	  riObj.tc0636_ChartAIndustryGroupTicker();
	}
	@Test(groups={"Regression"})
	public void tc0637_VerifyRIforIndustryGroups(){
		if (!TestUtil.isExecutable("tc0637_VerifyRIforIndustryGroups", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing the Related Information sidebar contain the four tabs Overview,Stocks in Fund,Top Stocks, and Sector?------------");
	  riObj.tc0637_VerifyRIforIndustryGroups();
	}
	@Test(groups={"Regression"})
	public void tc0638_VerifyOverviewTabSections(){
		if (!TestUtil.isExecutable("tc0638_VerifyOverviewTabSections", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Verify the sections of overview tab;------------");
	  riObj.tc0638_VerifyOverviewTabSections();
	}
	@Test(groups={"Regression"})
	public void tc0639_VerifyIndustrySummaryTable(){
		if (!TestUtil.isExecutable("tc0639_VerifyIndustrySummaryTable", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Verify Industry summary table information------------");
	  riObj.tc0639_VerifyIndustrySummaryTable();
	}
	@Test(groups={"Regression"})
	public void tc0640_VerifyRelativeStrengthTable(){
		if (!TestUtil.isExecutable("tc0640_VerifyRelativeStrengthTable", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  riObj.tc0640_VerifyRelativeStrengthTable();
	}
	@Test(groups={"Regression"})
	public void tc0641_Verify197RankingTable(){
		if (!TestUtil.isExecutable("tc0641_Verify197RankingTable", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Does 197 Ranking contain relevant information for Today,1 Week Ago,4 Weeks Ago,3 Months Ago,6 Months Ago,and 1 Year Ago?----------");
	  riObj.tc0641_Verify197RankingTable();
	}
	@Test(groups={"Regression"})
	public void tc0643_VerifyShow197IndustryGroups(){
		if (!TestUtil.isExecutable("tc0643_VerifyShow197IndustryGroups", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing At the bottom, is there a button labeled Show 197 Industry Groups?----------");
	  riObj.tc0643_VerifyShow197IndustryGroups();
	}
	@Test(groups={"Regression"})
	public void tc0644_VerifyHide197IndustryGroups(){
		if (!TestUtil.isExecutable("tc0644_VerifyHide197IndustryGroups", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing When clicked, does the button change to Hide 197 Industry Groups?----------");
	  riObj.tc0644_VerifyHide197IndustryGroups();
	}
	@Test(groups={"Regression"})
	public void tc0645_ValidateHide197IndustryGrp(){
		if (!TestUtil.isExecutable("tc0645_ValidateHide197IndustryGrp", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Does the list manager and sidebar become highlighted and display all 197 Industry Groups??----------");
	  riObj.tc0645_ValidateHide197IndustryGrp();
	}
	@Test(groups={"Regression"})
	public void tc0646_VerifyHide197IndustryGrptext(){
		if (!TestUtil.isExecutable("tc0646_VerifyHide197IndustryGrptext", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing When clicking Hide 197 Industry Groups, does the button change back to Show 197 Industry Groups?----------");
	  riObj.tc0646_VerifyHide197IndustryGrptext();
	}
	@Test(groups={"Regression"})
	public void tc0647_ValidateShow197IndustryGrp(){
		if (!TestUtil.isExecutable("tc0647_ValidateShow197IndustryGrp", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Is the list manager and sidebar no longer highlighted?----------");
	  riObj.tc0647_ValidateShow197IndustryGrp();
	}
	@Test(groups={"Regression"})
	public void tc0648_VerifyStockInGrpTab(){
		if (!TestUtil.isExecutable("tc0648_VerifyStockInGrpTab", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Open the Stocks in Group tab. Verify that a list of stocks appears and are loaded with information.?----------");
	  riObj.tc0648_VerifyStockInGrpTab();
	}
	@Test(groups={"Regression"})
	public void tc0649_VerifyStocksInGrpSection(){
		if (!TestUtil.isExecutable("tc0649_VerifyStocksInGrpSection", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Verify the list name is the current industry group and contains Symbol,Company, and Mkt Cap (mil) columns----------");
	  riObj.tc0649_VerifyStocksInGrpSection();
	}
	@Test(groups={"Regression"})
	public void tc0650_VerifyMarketCapColumn(){
		if (!TestUtil.isExecutable("tc0650_VerifyMarketCapColumn", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Verify the list is organized high to low by Mkt Cap (mil).----------");
	  riObj.tc0650_VerifyMarketCapColumn();
	}
	@Test(groups={"Regression"})
	public void tc0651_VerifyShowAllComponentData(){
		if (!TestUtil.isExecutable("tc0651_VerifyShowAllComponentData", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing At the bottom, is there a button labeled Show All Component Data?.----------");
	  riObj.tc0651_VerifyShowAllComponentData();
	}
	@Test(groups={"Regression"})
	public void tc0652_VerifyHideAllComponentData(){
		if (!TestUtil.isExecutable("tc0652_VerifyHideAllComponentData", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing When clicked, does the button change to Hide All Component Data?----------");
	  riObj.tc0652_VerifyHideAllComponentData();
	}
	@Test(groups={"Regression"})
	public void tc0653_ValidateHideAllcomponentData(){
		if (!TestUtil.isExecutable("tc0653_ValidateHideAllcomponentData", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Does the list manager and sidebar become highlighted and display the list of stocks in the industry group?.----------");
	  riObj.tc0653_ValidateHideAllcomponentData();
	}
	@Test(groups={"Regression"})
	public void tc0654_EnterNewIGWhenLMinHighLightedState(){
		if (!TestUtil.isExecutable("tc0654_EnterNewIGWhenLMinHighLightedState", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing When entering a new industry group, does the list manager display the stocks in the newly selected industry group?.----------");
	  Hashtable<String, String> data=TestUtil.getData("tc0654_EnterNewIGWhenLMinHighLightedState", "RelatedInformation",
				dataXl);
	  riObj.tc0654_EnterNewIGWhenLMinHighLightedState(data.get("Symbol"));
	}
	@Test(groups={"Regression"})
	public void tc0655_VerifyHideAllcomponentData(){
		if (!TestUtil.isExecutable("tc0655_VerifyHideAllcomponentData", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing When clicking Hide All Component Data, does the button change back to Show All Component Data?.----------");
	  riObj.tc0655_VerifyHideAllcomponentData();
	}
	
	public void tc0656_ValidateShowAllComponentData(){
		if (!TestUtil.isExecutable("tc0656_ValidateShowAllComponentData", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Is the list manager and sidebar no longer highlighted?.----------");
	  riObj.tc0656_ValidateShowAllComponentData();
	}
	@Test(groups={"Regression"})
	public void tc0657_EnterNewIGWhenLMnotHighlighted(){
		if (!TestUtil.isExecutable("tc0657_EnterNewIGWhenLMnotHighlighted", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing When entering a new industry group, does the list manager contain the same items in the list?----------");
	  Hashtable<String, String> data=TestUtil.getData("tc0657_EnterNewIGWhenLMnotHighlighted", "RelatedInformation",
				dataXl);
	  riObj.tc0657_EnterNewIGWhenLMnotHighlighted(data.get("Symbol"));
	}
	@Test(groups={"Regression"})
	public void tc0658_VerifyTopStocksTab(){
		if (!TestUtil.isExecutable("tc0658_VerifyTopStocksTab", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Open the Top Stocks tab. Verify that the following tables appear and are loaded with information:Top RS + EPS Stocks and % Off High.----------");
	  riObj.tc0658_VerifyTopStocksTab();
	}
	@Test(groups={"Regression"})
	public void tc0659_VerifyTopRSEPSStocks(){
		if (!TestUtil.isExecutable("tc0659_VerifyTopRSEPSStocks", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Verify Top RS + EPS Stocks contains Symbol,Company,RS, and EPS columns..----------");
	  riObj.tc0659_VerifyTopRSEPSStocks();
	}
	@Test(groups={"Regression"})
	public void tc0660_VerifyPercentageOffHigh(){
		if (!TestUtil.isExecutable("tc0660_VerifyPercentageOffHigh", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Verify % Off High contains Symbol,Company, and % Off High columns..----------");
	  riObj.tc0660_VerifyPercentageOffHigh();
	}
	@Test(groups={"Regression"})
	public void tc0661_VerifySectors(){
		if (!TestUtil.isExecutable("tc0661_VerifySectors", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Open the Sectors tab. Verify the sector name the industry group belongs to appears on top as well as the Top Industries in Sector table.----------");
	  riObj.tc0661_VerifySectors();
	}
	@Test(groups={"Regression"})
	public void tc0662_VerifyTableColumns(){
		if (!TestUtil.isExecutable("tc0662_VerifyTableColumns", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing Open the Sectors tab. Verify the sector name the industry group belongs to appears on top as well as the Top Industries in Sector table.----------");
	  riObj.tc0662_VerifyTableColumns();
	}
}
