package relatedInformation;

import java.io.IOException;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import genericLib.Utility;

public class RelatedInformation4Test {
	
	RelatedInformation4 oRI4Obj;
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		oRI4Obj=new RelatedInformation4();
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeErrorPopUp()
	{
		Utility.closeErrorMessage();
	}
	
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			Utility.takeScreenShot(imageName);
		} 
	}
	
	
	
//_____________________Test Cases Related to Related Informations 4 Sheet > Indices ________________________
	
	
	@Test(priority = 1)
	public void TC0716_RelatedInformation() throws InterruptedException{
		oRI4Obj.TC0716_RelatedInformation4();
	}
	
	@Test(priority = 2)
	public void TC0717_RelatedInformation(){
		oRI4Obj.TC0717_RelatedInformation4();
	}
	
	@Test(priority = 3)
	public void TC0718_RelatedInformation(){
		oRI4Obj.TC0718_RelatedInformation4();
	}
	
	@Test(priority = 4)
	public void TC0719_RelatedInformation(){
		oRI4Obj.TC0719_RelatedInformation4();
	}
	
	@Test(priority = 5)
	public void TC0720_RelatedInformation() throws Exception{
		oRI4Obj.TC0720_RelatedInformation4();
	}
	
	@Test(priority = 6)
	public void TC0721_RelatedInformation(){
		oRI4Obj.TC0721_RelatedInformation4();
	}

	@Test(priority = 7)
	public void TC0722_RelatedInformation(){
		oRI4Obj.TC0722_RelatedInformation4();
	}
	
	@Test(priority = 8)
	public void TC0723_RelatedInformation(){
		oRI4Obj.TC0723_RelatedInformation4();
	}
	
	@Test(priority = 9)
	public void TC0724_RelatedInformation(){
		oRI4Obj.TC0724_RelatedInformation4();
	}
	
	@Test(priority = 10)
	public void TC0725_RelatedInformation(){
		oRI4Obj.TC0725_RelatedInformation4();
	}
	
/*	@Test(priority = 11)
	public void TC0726_RelatedInformation(){
		oRI4Obj.TC0726_RelatedInformation4();
	}*/
	
	@Test(priority = 12)
	public void TC0727_RelatedInformation(){
		oRI4Obj.TC0727_RelatedInformation4();
	}
	
	@Test(priority = 13)
	public void TC0728_RelatedInformation(){
		oRI4Obj.TC0728_RelatedInformation4();
	}
	
	@Test(priority = 14)
	public void TC0729_RelatedInformation(){
		oRI4Obj.TC0729_RelatedInformation4();
	}
	
/*	@Test(priority = 15)
	public void TC0730_RelatedInformation() throws InterruptedException{
		oRI4Obj.TC0730_RelatedInformation4();
	}*/
	
	/*	@Test(priority = 16)
	public void TC0733_RelatedInformation(){
		oRI4Obj.TC0733_RelatedInformation4();
	}*/
	
	@Test(priority = 17)
	public void TC0735_RelatedInformation(){
		oRI4Obj.TC0735_RelatedInformation4();
	}
	
	@Test(priority = 18)
	public void TC0736_RelatedInformation(){
		oRI4Obj.TC0736_RelatedInformation4();
	}
	
	@Test(priority = 19)
	public void TC0737_RelatedInformation(){
		oRI4Obj.TC0737_RelatedInformation4();
	}
	
	@Test(priority = 20)
	public void TC0738_RelatedInformation(){
		oRI4Obj.TC0738_RelatedInformation4();
	}
	
/*	@Test(priority = 21)
	public void TC0739_RelatedInformation(){
		oRI4Obj.TC0739_RelatedInformation4();
	}*/
	
	@Test(priority = 22)
	public void TC0741_RelatedInformation(){
		oRI4Obj.TC0741_RelatedInformation4();
	}
	
/*	@Test(priority = 23)
	public void TC0742_RelatedInformation(){
		oRI4Obj.TC0742_RelatedInformation4();
	}*/
	
	@Test(priority = 24)
	public void TC0743_RelatedInformation(){
		oRI4Obj.TC0743_RelatedInformation4();
	}
	
	@Test(priority=25)
	public void tc0691_RelatedInformation() throws InterruptedException{
		oRI4Obj.tc0691_RelatedInformation();
	}
	
	@Test(priority=26)
	public void tc0692_RelatedInformation(){
		oRI4Obj.tc0692_RelatedInformation();
	}
	
	@Test(priority=27)
	public void tc0693_RelatedInformation(){
		oRI4Obj.tc0693_RelatedInformation();
	}
	
	@Test(priority=28)
	public void tc0694_RelatedInformation(){
		oRI4Obj.tc0694_RelatedInformation();
	}
	
	@Test(priority=29)
	public void tc0695_RelatedInformation(){
		oRI4Obj.tc0695_RelatedInformation();
	}
	
	@Test(priority=30)
	public void tc0696_RelatedInformation(){
		oRI4Obj.tc0696_RelatedInformation();
	}
	
	@Test(priority=31)
	public void tc0697_RelatedInformation(){
		oRI4Obj.tc0697_RelatedInformation();
	}
	
	@Test(priority=32)
	public void tc0698_RelatedInformation(){
		oRI4Obj.tc0698_RelatedInformation();
	}
	
	@Test(priority=33)
	public void tc0699_RelatedInformation(){
		oRI4Obj.tc0699_RelatedInformation();
	}
	
	@Test(priority=34)
	public void tc0700_RelatedInformation(){
		oRI4Obj.tc0700_RelatedInformation();
	}
	
	@Test(priority=35)
	public void tc0701_RelatedInformation(){
		oRI4Obj.tc0701_RelatedInformation();
	}
	
	@Test(priority=36)
	public void tc0702_RelatedInformation(){
		oRI4Obj.tc0702_RelatedInformation();
	}
	
	@Test(priority=37)
	public void tc0703_RelatedInformation() throws InterruptedException{
		oRI4Obj.tc0703_RelatedInformation();
	}
	
	@Test(priority=38)
	public void tc0704_RelatedInformation() throws InterruptedException{
		oRI4Obj.tc0704_RelatedInformation();
	}
	
	@Test(priority=39)
	public void tc0705_RelatedInformation(){
		oRI4Obj.tc0705_RelatedInformation();
	}
	
	@Test(priority=40)
	public void tc0706_RelatedInformation(){
		oRI4Obj.tc0706_RelatedInformation();
	}
	
	@Test(priority=41)
	public void tc0707_RelatedInformation(){
		oRI4Obj.tc0707_RelatedInformation();
	}
	
	@Test(priority=42)
	public void tc0708_RelatedInformation() throws InterruptedException{
		oRI4Obj.tc0708_RelatedInformation();
	}
	
/*	@Test(priority=43)
	public void tc0709_RelatedInformation() throws InterruptedException{
		oRI4Obj.tc0709_RelatedInformation();
	}*/
	
	@Test(priority=44)
	public void tc0715_RelatedInformation() throws InterruptedException{
		oRI4Obj.tc0715_RelatedInformation();
	}
	
	@Test(priority=45)
	public void tc0714_RelatedInformation() throws InterruptedException{
		oRI4Obj.tc0714_RelatedInformation();
	}
	
}
