package relatedInformation;

import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import excelReader.TestUtil;
import static genericLib.Utility.*;


public class RelatedInformation1Test {
	RelatedInformation1 riObj;
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		riObj=new RelatedInformation1();
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeErrorPopUp()
	{
		closeErrorMessage();
	}
	
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			takeScreenShot(imageName);
		} 
	}
	@Test(groups={"Regression"})
	public void tc0533_VerifyRIOpenAndClose(){
		if (!TestUtil.isExecutable("tc0533_VerifyRIOpenAndClose", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	     }
	  logger.info("------------Executing validate right side RI panel------------");
	  riObj.tc0533_VerifyRIOpenAndClose();
	}
	
	@Test(groups={"Regression"})
	public void tc0534_VerifyRightSidebarName(){
		if (!TestUtil.isExecutable("tc0534_VerifyRightSidebarName", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing When closed, does the side bar contain the words RELATED INFORMATION?------------");
	 riObj.tc0534_VerifyRightSidebarName();
	}
	
	@Test(groups={"Regression"})
	public void tc0535_VerifyArrowDirectionWhenOpened(){
		if (!TestUtil.isExecutable("tc0535_VerifyArrowDirectionWhenOpened", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	  }
	 logger.info("------------Executing When opened, do the arrows change direction to point towards the right side of the screen?----------");
	 riObj.tc0535_VerifyArrowDirectionWhenOpened();
	 }
	
	@Test(groups={"Regression"})
	public void tc0536_VerifyRelatedInformationWordWhenOpened(){
		if (!TestUtil.isExecutable("tc0536_VerifyRelatedInformationWordWhenOpened", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	  }
	 logger.info("------------Executing Are the words RELATED INFORMATION no longer visible?--------");
	 riObj.tc0536_VerifyRelatedInformationWordWhenOpened();
	}
	 @Test(groups={"Regression"})
	 public void tc0537_EnterStockSymbol(){
		 if (!TestUtil.isExecutable("tc0537_EnterStockSymbol", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing Enter a stock symbol such as AAPL(Apple Inc).----------");
		 Hashtable<String, String> data=TestUtil.getData("tc0537_EnterStockSymbol", "RelatedInformation",
					dataXl);
		 riObj.tc0537_EnterStockSymbol(data.get("Symbol"));
	 }
	 @Test(groups={"Regression"})
	 public void tc0538_ValidateRIPanelForStockSymbol(){
		 if (!TestUtil.isExecutable("tc0538_ValidateRIPanelForStockSymbol", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing When opened for a STOCK the sidebar contain the five tabs Owners & Funds,Industry & Sector News,Options Checklist?----------");
		 riObj.tc0538_ValidateRIPanelForStockSymbol(); 
	 }
	 @Test(groups={"Regression"})
	 public void tc0539_VerifyOwnersAndFundsTab(){
		 if (!TestUtil.isExecutable("tc0539_VerifyOwnersAndFundsTab", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing Verify the tables present in Owners And Funds tab----------");
		 riObj.tc0539_VerifyOwnersAndFundsTab();  
	 }
	 @Test(groups={"Regression"})
	 public void tc0540_VerifyInstitutionalTableContent(){
		 if (!TestUtil.isExecutable("tc0540_VerifyInstitutionalTableContent", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing Does Institutional Ownership contain percentages for Funds,Banks,and Insurance Co.?---------");
		 riObj.tc0540_VerifyInstitutionalTableContent();   
	 }
	 @Test(groups={"Regression"})
	 public void tc0541_VerifyManagementTableContent(){
		 if (!TestUtil.isExecutable("tc0541_VerifyManagementTableContent", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing Does Management Ownership contain Percentage Held by management and the current Outstanding Shares in Millions?--------");
		 riObj.tc0541_VerifyManagementTableContent();  
	 }
	 @Test(groups={"Regression"})
	 public void tc0542_VerifyFundOwnershipContent(){
		 if (!TestUtil.isExecutable("tc0542_VerifyFundOwnershipContent", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing Does Fund Ownership Summary display the Date and No of Funds for the eight most recent quarters?--------");
		 riObj.tc0542_VerifyFundOwnershipContent();  
	 }
	 @Test(groups={"Regression"})
	 public void tc0543_VerifyShowFundButton(){
		 if (!TestUtil.isExecutable("tc0543_VerifyShowFundButton", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing At the bottom, is there a button labeled Show Fund Ownership--------");
		 riObj.tc0543_VerifyShowFundButton();  
	 }
	 @Test(groups={"Regression"})
	 public void tc0544_VerifyHideFundOwnership(){
		 if (!TestUtil.isExecutable("tc0544_VerifyHideFundOwnership", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing When clicked, does the button change to Hide Fund Ownership?--------");
		 riObj.tc0544_VerifyHideFundOwnership();  
	 }
	 @Test(groups={"Regression"})
	 public void tc0545_ValidateHideFundOwnerShip(){
		 if (!TestUtil.isExecutable("tc0545_ValidateHideFundOwnerShip", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing Does the list manager and side bar become highlighted and display the funds currently holding shares of the stock?-------");
		 riObj.tc0545_ValidateHideFundOwnerShip(); 
	 }
	 @Test(groups={"Regression"})
	 public void tc0546_ValidateOwnerShipForNewTicker(){
		 if (!TestUtil.isExecutable("tc0546_ValidateOwnerShipForNewTicker", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing When entering a new stock symbol, does the list manager display the funds holding the newly selected stock?-------");
		 Hashtable<String, String> data=TestUtil.getData("tc0546_ValidateOwnerShipForNewTicker", "RelatedInformation",
					dataXl);
		 riObj.tc0546_ValidateOwnerShipForNewTicker(data.get("Symbol"));
	 }
	 @Test(groups={"Regression"})
	 public void tc0547_VerifyHideFundOwnershipText(){
		 if (!TestUtil.isExecutable("tc0547_VerifyHideFundOwnershipText", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing When clicking Hide Fund Ownership, does the button change back to Show Fund Ownership?-------");
		 riObj.tc0547_VerifyHideFundOwnershipText();  
	 }
	 @Test(groups={"Regression"})
	 public void tc0548_ValidateShowFundOwnership(){
		 if (!TestUtil.isExecutable("tc0548_ValidateShowFundOwnership", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing Is the list manager and side bar no longer highlighted?-------");
		 riObj.tc0548_ValidateShowFundOwnership(); 
	 }
	 @Test(groups={"Regression"})
	 public void tc0549_ValidateOwnerShipForNewStock(){
		 if (!TestUtil.isExecutable("tc0549_ValidateOwnerShipForNewStock", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing Entering a new stock symbol. Verify the list manager contains the same items in the list should not change.-------");
		 Hashtable<String, String> data=TestUtil.getData("tc0549_ValidateOwnerShipForNewStock", "RelatedInformation",
					dataXl);
		 riObj.tc0549_ValidateOwnerShipForNewStock(data.get("Symbol"));
	 }
	 @Test(groups={"Regression"})
	 public void tc0550_VerifyRIForMutualFund(){
		 if (!TestUtil.isExecutable("tc0550_VerifyRIForMutualFund", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing Enter a mutual fund into the ticker field (e.g., FDVLX). Verify fund options?--------");
		 Hashtable<String, String> data=TestUtil.getData("tc0550_VerifyRIForMutualFund", "RelatedInformation",
					dataXl);
		 riObj.tc0550_VerifyRIForMutualFund(data.get("Symbol"));
	}
	@Test(groups={"Regression"})
	public void tc0551_ValidateShowAllFundsButton(){
		 if (!TestUtil.isExecutable("tc0551_ValidateShowAllFundsButton", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing Under Profile, if you click the Show All Funds In Family button, does the List Manager show all funds investing this fund? Is the List Manager highlighted blue?--------");
		 riObj.tc0551_ValidateShowAllFundsButton();
	}
	@Test(groups={"Regression"})
	public void  tc0552_EnterTickerWhenLMHighlighted(){
		 if (!TestUtil.isExecutable("tc0552_EnterTickerWhenLMHighlighted", "RelatedInformation",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		  }
		 logger.info("------------Executing change the ticker when the LM is in highlighted state,validate highlight disappeared--------");
		 Hashtable<String, String> data=TestUtil.getData("tc0552_EnterTickerWhenLMHighlighted", "RelatedInformation",
					dataXl);
		 riObj.tc0552_EnterTickerWhenLMHighlighted(data.get("Symbol"));
	}
	@Test(groups={"Regression"})
	public void tc0559_ValidateCloseButton(){
		if (!TestUtil.isExecutable("tc0559_ValidateCloseButton", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Click on the close button (x). Does the side bar close?--------");
	  riObj.tc0559_ValidateCloseButton();
	}
	@Test(groups={"Regression"})
	public void tc0560_VerifyIndustryAndSectorTab(){
		if (!TestUtil.isExecutable("tc0560_VerifyIndustryAndSectorTab", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Open the Industry & Sector tab. Does information load?--------");
	  riObj.tc0560_VerifyIndustryAndSectorTab();
	}
	@Test(groups={"Regression"})
	public void tc0561_VerifySectionsOfIndustryAndSector(){
		if (!TestUtil.isExecutable("tc0561_VerifySectionsOfIndustryAndSector", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   } 
	  logger.info("------------Executing Open the Industry & Sector tab. Does information load?--------");
	  riObj.tc0561_VerifySectionsOfIndustryAndSector();
	}
	@Test(groups={"Regression"})
	public void tc0562_VerifyIndustryGroupSection(){
		if (!TestUtil.isExecutable("tc0562_VerifyIndustryGroupSection", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Does Industry Group contain the industry group name,Today:change and the YTD:performance?--------");
	  riObj.tc0562_VerifyIndustryGroupSection();
	}
	@Test(groups={"Regression"})
	public void tc0563_VerifyCharticon(){
		if (!TestUtil.isExecutable("tc0563_VerifyCharticon", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing Is there a chart icon next to the industry group name?--------");
	  riObj.tc0563_VerifyCharticon();
	}
	@Test(groups={"Regression"})
	public void tc0564_ValidateChartIcon(){
		if (!TestUtil.isExecutable("tc0564_ValidateChartIcon", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing Click on the chart icon. Does the chart load for the industry group?--------");
	  riObj.tc0564_ValidateChartIcon();
	}
	@Test(groups={"Regression"})
	public void tc0565_VerifyIndustryGroupSection(){
		if (!TestUtil.isExecutable("tc0565_VerifyIndustryGroupSection", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing Go back to the side bar for the stock. Does Industry Group contain two tables, industry Summary and Stock Rank in Industry Group--------");
	  riObj.tc0565_VerifyIndustryGroupSection();
	}
	@Test(groups={"Regression"})
	public void tc0566_VerifyIndustrySummaryTable(){
		if (!TestUtil.isExecutable("tc0566_VerifyIndustrySummaryTable", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing Does Industry Summary contain Industry 197 Rank,Industry Market Value,Number of Stocks,New High Stocks,and New Low Stocks?-------");
	  riObj.tc0566_VerifyIndustrySummaryTable();
	}
	@Test(groups={"Regression"})
	public void tc0567_VerifyStockRankTable(){
		if (!TestUtil.isExecutable("tc0567_VerifyStockRankTable", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing Does Stock Rank in Industry Group contain EPS Rating, RS Rating,Acc/Dis Rating,SMR Rating,and Comp Rating-------");
	  riObj.tc0567_VerifyStockRankTable();
	}
	@Test(groups={"Regression"})
	public void tc0568_VerifyViewStocksinIndustry(){
		if (!TestUtil.isExecutable("tc0568_VerifyViewStocksinIndustry", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	  }
	  logger.info("------------Executing Is there a button labeled View Stocks in Industry below the Stock Rank in Industry Group table?-------");
	  riObj.tc0568_VerifyViewStocksinIndustry();
	}
	@Test(groups={"Regression"})
	public void tc0569_ValidateViewStocksinIndustry(){
		if (!TestUtil.isExecutable("tc0569_ValidateViewStocksinIndustry", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing When clicked, does the button change to Hide Stocks in Industry?-------");
	  riObj.tc0569_ValidateViewStocksinIndustry();
	}
	@Test(groups={"Regression"})
	public void tc0570_ValidateHideStocksinIndustry(){
		if (!TestUtil.isExecutable("tc0570_ValidateHideStocksinIndustry", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	  }
	  logger.info("------------Executing Does the list manager and side bar become highlighted and display a list of stocks in the industry?-------");
	  riObj.tc0570_ValidateHideStocksinIndustry();
	}
	@Test(groups={"Regression"})
	public void tc0571_EnterNewTickerWhenLMHighlighted(){
		if (!TestUtil.isExecutable("tc0571_EnterNewTickerWhenLMHighlighted", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing When entering a new stock symbol in a different industry, does the list manager display a new list showing the stocks in the industry of the new stock symbol?-------");
	  Hashtable<String, String> data=TestUtil.getData("tc0571_EnterNewTickerWhenLMHighlighted", "RelatedInformation",
				dataXl);
	  riObj.tc0571_EnterNewTickerWhenLMHighlighted(data.get("Symbol"));
	}
	@Test(groups={"Regression"})
	public void tc0572_VerifyHideStocksinIndustryText(){
		if (!TestUtil.isExecutable("tc0569_ValidateViewStocksinIndustry", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing When clicking Hide Stocks in Industry,does the button change back to View Stocks in Industry?-------");
	  riObj.tc0572_VerifyHideStocksinIndustryText();
	}
	@Test(groups={"Regression"})
	public void tc0573_ValidateViewStocksinIndustry(){
		if (!TestUtil.isExecutable("tc0573_ValidateViewStocksinIndustry", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing Is the list manager and sidebar no longer highlighted?-------");
	  riObj.tc0573_ValidateViewStocksinIndustry();
	}
	@Test(groups={"Regression"})
	public void tc0574_EnterNewTickerWhenLMnotHighlighted(){
		if (!TestUtil.isExecutable("tc0574_EnterNewTickerWhenLMnotHighlighted", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing Enter a new stock symbol in a different industry. Verify the list manager contains the same items in the list should not change-------");
	  Hashtable<String, String> data=TestUtil.getData("tc0574_EnterNewTickerWhenLMnotHighlighted", "RelatedInformation",
				dataXl);
	  riObj.tc0574_EnterNewTickerWhenLMnotHighlighted(data.get("Symbol"));
	}
	@Test(groups={"Regression"})
	public void tc0575_VerifySectorSection(){
		if (!TestUtil.isExecutable("tc0573_ValidateViewStocksinIndustry", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing Does Sector contain the name of the Sector and the table Top Industries in Sector?-------");
	  riObj.tc0575_VerifySectorSection();
	}
	@Test(groups={"Regression"})
	public void tc0576_ValidateTopIndustriesTableData(){
		if (!TestUtil.isExecutable("tc0576_ValidateTopIndustriesTableData", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing Does the table Top Industries in Sector contain a list of Industry Groups contained within the sector sorted high to low by their RS Rating?-------");
	  riObj.tc0576_ValidateTopIndustriesTableData();
	}
	@Test(groups={"Regression"})
	public void tc0577_VerifyViewMoreDetailsLink(){
		if (!TestUtil.isExecutable("tc0577_VerifyViewMoreDetailsLink", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Is there a View More Details link?------");
	  riObj.tc0577_VerifyViewMoreDetailsLink();
	}
	@Test(groups={"Regression"})
	public void tc0578_ValidateViewMoreDetailsLink(){
		if (!TestUtil.isExecutable("tc0578_ValidateViewMoreDetailsLink", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	  }
	  logger.info("------------Executing Click on the View More Details link. Does the list manager display all the industry groups contained within the sector?-------");
	  riObj.tc0578_ValidateViewMoreDetailsLink();
	}
	@Test(groups={"Regression"})
	public void tc0579_VerifyViewStocksInSector(){
		if (!TestUtil.isExecutable("tc0579_VerifyViewStocksInSector", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Is there a button labeled View Stocks in Sector below the Sector table?-------");
	  riObj.tc0579_VerifyViewStocksInSector();
	}
	
	@Test(groups={"Regression"})
	public void tc0580_VerifyHideStocksInsector(){
		if (!TestUtil.isExecutable("tc0580_VerifyHideStocksInsector", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing When clicked, does the button change to Hide Stocks in Sector?-------");
	  riObj.tc0580_VerifyHideStocksInsector();
	}
	@Test(groups={"Regression"})
	public void tc0581_ValidateHideStockInSector(){
		if (!TestUtil.isExecutable("tc0581_ValidateHideStockInSector", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Does Sector contain the name of the Sector and the table Top Industries in Sector?-------");
	  riObj.tc0581_ValidateHideStockInSector();
	}
	@Test(groups={"Regression"})
	public void tc0582_EnterNewTickerWhenLMHighlighted(){
		if (!TestUtil.isExecutable("tc0582_EnterNewTickerWhenLMHighlighted", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing Does the list manager and side bar become highlighted and display a list of stocks in the sector?-------");
	  Hashtable<String, String> data=TestUtil.getData("tc0582_EnterNewTickerWhenLMHighlighted", "RelatedInformation",
				dataXl);
	  riObj.tc0582_EnterNewTickerWhenLMHighlighted(data.get("Symbol"));
	}
	
	public void tc0583_VerfiyViewStocksinSector(){
		if (!TestUtil.isExecutable("tc0583_VerfiyViewStocksinSector", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing When clicking Hide Stocks in Sector, does the button change back to Show Stocks in Sector?-------");
	  riObj.tc0583_VerfiyViewStocksinSector();
	}
	public void tc0584_ValidateViewStocksinSector(){
		if (!TestUtil.isExecutable("tc0584_ValidateViewStocksinSector", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Is the list manager and side bar no longer highlighted?-------");
	  riObj.tc0584_ValidateViewStocksinSector();
	}
	public void tc0585_EnterNewTickerWhenLMnotHighLighted(String symbol){
		if (!TestUtil.isExecutable("tc0585_EnterNewTickerWhenLMnotHighLighted", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing Enter a new stock symbol in a different sector. Verify the list manager contains the same items in the list should not change.-------");
	  Hashtable<String, String> data=TestUtil.getData("tc0582_EnterNewTickerWhenLMHighlighted", "RelatedInformation",
				dataXl);
	  riObj.tc0585_EnterNewTickerWhenLMnotHighLighted(data.get("Symbol"));
	}
	
	@Test(groups={"Regression"})
	public void tc0592_ValidateCloseButton(){
		if (!TestUtil.isExecutable("tc0592_ValidateCloseButton", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Click on the close button (x). Does the side bar close?--------");
	  riObj.tc0559_ValidateCloseButton();
	}
	@Test(groups={"Regression"})
	public void tc0593_VerifyNewsTab(){
		if (!TestUtil.isExecutable("tc0593_VerifyNewsTab", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Open the News tab. Does a list of news appear?--------");
	  riObj.tc0593_VerifyNewsTab();
	}
	@Test(groups={"Regression"})
	public void tc0594_VerifyNewsDropdown(){
		if (!TestUtil.isExecutable("tc0594_VerifyNewsDropdown", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Is there a drop down menu called Edit News?--------");
	  riObj.tc0594_VerifyNewsDropdown();
	}
	@Test(groups={"Regression"})
	public void tc0595_VerifyNewsDropdownOptions(){
		if (!TestUtil.isExecutable("tc0595_VerifyNewsDropdownOptions", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------ExecutingWhen hovering over the drop down menu, do the options StockTwits,Yahoo! Finance,and Google Finance appear?-------");
	  riObj.tc0595_VerifyNewsDropdownOptions();
	}
	@Test(groups={"Regression"})
	public void tc0599_VerifyNewsList(){
		if (!TestUtil.isExecutable("tc0599_VerifyNewsList", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------ExecutingWhen hovering over the drop down menu, do the options StockTwits,Yahoo! Finance,and Google Finance appear?-------");
	  riObj.tc0599_VerifyNewsList();
	}
	@Test(groups={"Regression"})
	public void tc0600_ValidateCloseButton(){
		if (!TestUtil.isExecutable("tc0600_ValidateCloseButton", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Click on the close button (x). Does the side bar close?--------");
	  riObj.tc0559_ValidateCloseButton();
	}
	@Test(groups={"Regression"})
	public void tc0601_VerifyOptionsTab(){
		if (!TestUtil.isExecutable("tc0601_VerifyOptionsTab", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Open the Options tab. Does the information load?--------");
	  riObj.tc0601_VerifyOptionsTab();
	}
	@Test(groups={"Regression"})
	public void tc0602_VerifyCallsAndPutsAndStockData(){
		if (!TestUtil.isExecutable("tc0602_VerifyCallsAndPutsAndStockData", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Is there data for Calls and Puts as well as Stock Data?--------");
	  riObj.tc0602_VerifyCallsAndPutsAndStockData();
	}
	@Test(groups={"Regression"})
	public void tc0603_VerifyCallssAndPutsTableColumns(){
		if (!TestUtil.isExecutable("tc0603_VerifyCallssAndPutsTableColumns", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Do the Calls and Puts tables have Exp.,Strike,Last,Vol,and Open Int columns?--------");
	  riObj.tc0603_VerifyCallssAndPutsTableColumns();
	}
	@Test(groups={"Regression"})
	public void tc0604_VerifyStockDataForLabels(){
		if (!TestUtil.isExecutable("tc0604_VerifyStockDataForLabels", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing verify stock data table have data for labels--------");
	  riObj.tc0604_VerifyStockDataForLabels();
	}
	@Test(groups={"Regression"})
	public void tc0605_VerifyDisclaimerMessage(){
		if (!TestUtil.isExecutable("tc0605_VerifyDisclaimerMessage", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Is there a disclaimer message at the bottom? --------");
	  riObj.tc0605_VerifyDisclaimerMessage();
	}
	@Test(groups={"Regression"})
	public void tc0606_VerifyShowMoreInformation(){
		if (!TestUtil.isExecutable("tc0606_VerifyShowMoreInformation", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Is there a button labeled Show More Information? --------");
	  riObj.tc0606_VerifyShowMoreInformation();
	}
	@Test(groups={"Regression"})
	public void tc0607_ValidateShowMoreInformation(){
		if (!TestUtil.isExecutable("tc0607_ValidateShowMoreInformation", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing When you click on the Show More Information button, does the side bar open up with more information? --------");
	  riObj.tc0607_ValidateShowMoreInformation();
	}
	@Test(groups={"Regression"})
	public void tc0608_VerifyViewByOptions(){
		if (!TestUtil.isExecutable("tc0608_VerifyViewByOptions", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing there should be a View by_ that changes according to which radio button you have selected on the right --------");
	  riObj.tc0608_VerifyViewByOptions();
	}
	@Test(groups={"Regression"})
	public void tc0609_VerifyPreferenceOption(){
		if (!TestUtil.isExecutable("tc0609_VerifyPreferenceOption", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Verify preference options --------");
	  riObj.tc0609_VerifyPreferenceOption();
	}
	@Test(groups={"Regression"})
	public void tc0610_ValidateExpirationDates(){
		if (!TestUtil.isExecutable("tc0610_ValidateExpirationDates", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Select the Expiration Date radio button. A list of expiration dates should be visible with the most recent expiration date on top. --------");
	  riObj.tc0610_ValidateExpirationDates();
	}
	@Test(groups={"Regression"})
	public void tc0611_ValdateRowResultInformation(){
		if (!TestUtil.isExecutable("tc0611_ValdateRowResultInformation", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Clicking on a row will result in information being displayed for that particular expiration date. Is there Call and Put information for the strike price?--------");
	  riObj.tc0611_ValdateRowResultInformation();
	}
	@Test(groups={"Regression"})
	public void tc0612_ValidateStrikePriceRadioButton(){
		if (!TestUtil.isExecutable("tc0612_ValidateStrikePriceRadioButton", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Click the Strike Price radio button. A list should be displayed with options available in order by strike price, low to high.--------");
	  riObj.tc0612_ValidateStrikePriceRadioButton();
	}
	@Test(groups={"Regression"})
	public void tc0613_VerifyStrikePriceInfo(){
		if (!TestUtil.isExecutable("tc0613_VerifyStrikePriceInfo", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Expand a strike price row to display more information. Is there Call and Put information?--------");
	  riObj.tc0613_VerifyStrikePriceInfo();
	}
	@Test(groups={"Regression"})
	public void tc0620_ValidateCloseButton(){
		if (!TestUtil.isExecutable("tc0620_ValidateCloseButton", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Click on the close button (x). Does the side bar close?--------");
	  riObj.tc0620_ValidateCloseButton();
	}
	@Test(groups={"Regression"})
	public void tc0621_VerifyCheckListOption(){
		if (!TestUtil.isExecutable("tc0621_VerifyCheckListOption", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Open the Checklist tab. Does the information load?--------");
	  riObj.tc0621_VerifyCheckListOption();
	}
	@Test(groups={"Regression"})
	public void tc0622_VerifyDropDown(){
		if (!TestUtil.isExecutable("tc0622_VerifyDropDown", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Is there a drop down menu?--------");
	  riObj.tc0622_VerifyDropDown();
	}
	@Test(groups={"Regression"})
	public void tc0623_VerifyTextAboveTheDropdown(){
		if (!TestUtil.isExecutable("tc0623_VerifyTextAboveTheDropdown", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Above the dropdown menu, are the words Base your Checklist on this screen visible?--------");
	  riObj.tc0623_VerifyTextAboveTheDropdown();
	}
	@Test(groups={"Regression"})
	public void tc0624_ValidateDropdownSelection(){
		if (!TestUtil.isExecutable("tc0624_ValidateDropdownSelection", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Does the dropdown menu contain the name of the screen last chosen?--------");
	  riObj.tc0624_ValidateDropdownSelection();
	}
	@Test(groups={"Regression"})
	public void tc0625_VerifyCheckListDropdownOptions(){
		if (!TestUtil.isExecutable("tc0625_VerifyCheckListDropdownOptions", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Click on the dropdown menu. Does a list appear with the MarketSmith Stock Screens?--------");
	  riObj.tc0625_VerifyCheckListDropdownOptions();
	}
	@Test(groups={"Regression"})
	public void tc0626_ValidatePercentageReflecting(){
		if (!TestUtil.isExecutable("tc0626_ValidatePercentageReflecting", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing percentage reflecting how many items the stock satisfies for the criteria of the chosen screen?--------");
	  riObj.tc0626_ValidatePercentageReflecting();
	}
	@Test(groups={"Regression"})
	public void tc0628_VerifyFailiedTextColor(){
		if (!TestUtil.isExecutable("tc0628_VerifyFailiedTextColor", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Are the items rated as Fail highlighted red?--------");
	  riObj.tc0628_VerifyFailiedTextColor();
	}
	@Test(groups={"Regression"})
	public void tc0635_ValidateCloseButton(){
		if (!TestUtil.isExecutable("tc0635_ValidateCloseButton", "RelatedInformation",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Click on the close button (x). Does the sidebar close?--------");
	  riObj.tc0635_ValidateCloseButton();
	}
}
