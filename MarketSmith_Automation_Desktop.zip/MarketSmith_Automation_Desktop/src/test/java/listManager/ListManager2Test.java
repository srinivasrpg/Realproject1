package listManager;

import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import excelReader.TestUtil;
import static genericLib.Utility.*;

public class ListManager2Test {

	ListManager2 listObj;
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		listObj=new ListManager2();
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeErrorPopUp()
	{
		closeErrorMessage();
	}
	
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			takeScreenShot(imageName);
		} 
	}
	
	@Test(groups={"Regression"})
	public void tc0414_ValidateItemsDisplay(){
		if (!TestUtil.isExecutable("tc0414_ValidateItemsDisplay", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing validate item no display------------");
	 listObj.tc0414_ValidateItemsDisplay();
    }
	
	@Test(groups={"Regression"})
	public void tc0416_ValidateItemsOfList(){
	 if (!TestUtil.isExecutable("tc0416_ValidateItemsOfList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing validate items of other list------------");
	 listObj.tc0416_ValidateItemsOfList();	
	}
	@Test(groups={"Regression"})
	public void tc0417_ValidataSpaceBarListPanel(){
	 if (!TestUtil.isExecutable("tc0417_ValidataSpaceBarListPanel", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing validate items of other list------------");
	 listObj.tc0453_LoadChartBySpaceBar();	
	}
	
	@Test(groups={"Regression"})
	public void tc0418_ValidateEnterNewSymbol(){
		if (!TestUtil.isExecutable("tc0418_ValidateEnterNewSymbol", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing :Enter a stock symbol into the Symbol Field. Verify the new symbol is charted correctly.---------");
	 Hashtable<String, String> data=TestUtil.getData("tc0418_ValidateEnterNewSymbol", "ListManager",
				dataXl);
	 listObj.tc0418_ValidateEnterNewSymbol(data.get("Symbol"));	
	}
	@Test(groups={"Regression"})
	public void tc0419_ValidateThirdListDisplay(){
		if (!TestUtil.isExecutable("tc0419_ValidateThirdListDisplay", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing :Enter a stock symbol into the Symbol Field. Verify the new symbol is charted correctly.---------");
	 listObj.tc0419_ValidateThirdListDisplay();	
	}
	@Test(groups={"Regression"})
	public void tc0420_ValidateFlagnThrashForEachItem(){
		 if (!TestUtil.isExecutable("tc0420_ValidateFlagnThrashForEachItem", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		 }
		 logger.info("------------Executing validate flag and thrash icon-----------");
		 listObj.tc0420_ValidateFlagnThrashForEachItem();	
	}
	//@Test(groups={"Regression"})
	public void tc0421_VerifyListPanelScroll(){
		 if (!TestUtil.isExecutable("tc0421_VerifyListPanelScroll", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		 }
		 logger.info("------------Executing The list panel should also be scrollable-----------");
		 listObj.tc0421_VerifyListPanelScroll();	
	}
	@Test(groups={"Regression"})
	public void tc0423_VerifyNameColumnAutoExpansion(){
		if (!TestUtil.isExecutable("tc0423_VerifyNameColumnAutoExpansion", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing/Verify the column auto-expands to the width of the longest line of data-----------");
	 listObj.tc0423_VerifyNameColumnAutoExpansion();
	}
	@Test(groups={"Regression"})
	public void tc0424_VerifyNewWidthCreatedInLastSession() throws InterruptedException{
		if (!TestUtil.isExecutable("tc0424_VerifyNewWidthCreatedInLastSession", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	  }
	 logger.info("------------Executing Verify the new widths you created in the last step are still active.-----------");
	 listObj.tc0424_VerifyNewWidthCreatedInLastSession();
	}
	@Test(groups={"Regression"})
	public void tc0425_ValidateDefaultColumns(){
		if (!TestUtil.isExecutable("tc0425_ValidateDefaultColumns", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing validate default columns----------");
	 listObj.tc0425_ValidateDefaultColumns();	
	}
	
	@Test(groups={"Regression"})
	public void tc0426_VerifyNondragableColumns(){
		if (!TestUtil.isExecutable("tc0426_VerifyNondragableColumns", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing try to drag the hard coded headers into a new order/location:---------");
	 listObj.tc0426_VerifyNondragableColumns();	
	}
	//@Test(groups={"Regression"})
	public void tc0427_VerifyDragableColumns(){
		if (!TestUtil.isExecutable("tc0427_VerifyDragableColumns", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing right of these, and you should be able to drag them around into different orders---------");
	 listObj.tc0427_VerifyDragableColumns();	
	}
	@Test(groups={"Regression"})
	public void tc0428_SortByColumn(){
		 if (!TestUtil.isExecutable("tc0428_SortByColumn", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		 }
		 logger.info("------------Executing Validate whether column items sorted---------");
		 listObj.tc0428_SortByColumn();	
	}
	
	@Test(groups={"Regression"})
	public void tc0429_SortInDesc(){
		 if (!TestUtil.isExecutable("tc0429_SortInDesc", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		 }
		 logger.info("------------Executing Validate whether column items sorted in reverse order---------");
		 listObj.tc0429_SortInDesc();	
	}
		
	@Test(groups={"Regression"})
	public void tc0430_ValidateBlackArrow(){
		if (!TestUtil.isExecutable("tc0430_ValidateBlackArrow", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing validate Black Arrow,verify that the NAME and TYPE columns are hidden----------");
	 listObj.tc0430_ValidateBlackArrow();		
	}
	
	@Test(groups={"Regression"})
	public void tc0431_ReexpandNameAndTypeColumn(){
	    if (!TestUtil.isExecutable("tc0431_ReexpandNameAndTypeColumn", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing Verify a lock appears when clicking on a column title. Is the number within the lock--------");
	 listObj.tc0431_ReexpandNameAndTypeColumn();	
	}
	@Test(groups={"Regression"})
	public void tc0432_VerifyLockWhenColumnSelected(){
		if (!TestUtil.isExecutable("tc0432_VerifyLockWhenColumnSelected", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing validate Black Arrow,verify that the NAME and TYPE columns are reexpand---------");
	 listObj.tc0432_VerifyLockWhenColumnSelected();
	}
	@Test(groups={"Regression"})
	public void tc0433_ChangeToLockedAndUnlockedState(){
		if (!TestUtil.isExecutable("tc0433_ChangeToLockedAndUnlockedState", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing Click on the lock. Does the lock symbol change from being unlocked to locked?---------");
	 listObj.tc0433_ChangeToLockedAndUnlockedState();
	}
	//@Test(groups={"Regression"})
	public void tc0434_VerifySecondColumnLock(){
		if (!TestUtil.isExecutable("tc0434_VerifySecondColumnLock", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	  }
	 logger.info("------------Executing click on another column title. A second lock should appear.Is the list panel sorted correctly according to your sort order? You can lock up to as many columns as are available.---------");
	 listObj.tc0434_VerifySecondColumnLock();
	}
	@Test(groups={"Regression"})
	public void tc0435_VerifyThirdColumnLock(){
		if (!TestUtil.isExecutable("tc0435_VerifyThirdColumnLock", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	  }
	 logger.info("------------Executing Unlock the original locked column title and click on another column title. The original column should no longer have a lock.---------");
	 listObj.tc0435_VerifyThirdColumnLock();
	}
    @Test(groups={"Regression"})
	public  void tc0441_ValidateHighlightedRows(){
		if (!TestUtil.isExecutable("tc0441_ValidateHighlightedRows", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	 logger.info("------------Executing Verify the orange highlight follows your choices.---------");
	 listObj.tc0441_ValidateHighlightedRows();		
	}
    @Test(groups={"Regression"})
    public void tc0442_VerifyChartedTickerHighlighted(){
    	if (!TestUtil.isExecutable("tc0442_VerifyChartedTickerHighlighted", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	 logger.info("-----Executing Type in a symbol from your list into the SEARCH field,verify the highlight once again follows the searched-for item.---------");
	 listObj.tc0442_VerifyChartedTickerHighlighted();	
    }
    @Test(groups={"Regression"})
	public void tc0443_ValidateTrashIcon(){
		if (!TestUtil.isExecutable("tc0443_ValidateTrashIcon", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	  logger.info("------------Executing validate trashCAn deleting selected item.---------");
	  listObj.tc0443_ValidateTrashIcon();			
	}
	@Test(groups={"Regression"})
	public void tc0444_ValidateSymbolOptions(){
		if (!TestUtil.isExecutable("tc0444_ValidateSymbolOptions", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing validate right click options of row.---------");
	 listObj.tc0444_ValidateSymbolOptions();		
	}
	@Test(groups={"Regression"})
	public void tc0445_ValidateDeleteOption(){
		if (!TestUtil.isExecutable("tc0445_ValidateDeleteOption", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing validate delete option.---------");
	 listObj.tc0445_ValidateDeleteOption();		
	}
	@Test(groups={"Regression"})
	public void tc0446_ValidateDeleteRowByDeleteKey(){
		if (!TestUtil.isExecutable("tc0446_ValidateDeleteRowByDeleteKey", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing Click on another row, and hit the DELETE key on the keyboard. Verify the stock is deleted.---------");
	 listObj.tc0446_ValidateDeleteRowByDeleteKey();	
	}
	@Test(groups={"Regression"})
	public void tc0447_ValidateFlagSymbol(){
	  if (!TestUtil.isExecutable("tc0447_ValidateFlagSymbol", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	  }
	  logger.info("------------Executing validate flag option.---------");
	  listObj.tc0447_ValidateFlagSymbol();			
	}
	
	@Test(groups={"Regression"})
	public void tc0447_ValidateFlaggedSymbols(){
	  if (!TestUtil.isExecutable("tc0447_1ValidateFlaggedSymbols", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	  logger.info("------------Executing validate flagged at the top-left of the Tool screen, right next to the Company Name.---------");
	  listObj.tc0447_1ValidateFlaggedSymbols();			
	} 
	
	@Test(groups={"Regression"})
	public void tc0448_ValidateViewComparisonChart(){
		if (!TestUtil.isExecutable("tc0448_ValidateViewComparisonChart", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	  logger.info("------------Executing validate The Comparison Chart window should appear with the selected item displayed.---------");
	  listObj.tc0448_ValidateViewComparisonChart();				
	}
	
	@Test(groups={"Regression"})
	public void tc0449_ValidateSetAlert(){
		if (!TestUtil.isExecutable("tc0449_ValidateSetAlert", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	  logger.info("------------Executing validate set Alert, Verify the Set Price Alert window appears.---------");
	  listObj.tc0449_ValidateSetAlert();		
	}
	@Test(groups={"Regression"})
	 public void tc0450_VerifyChartAppearsForSelectedTicker(){
		if (!TestUtil.isExecutable("tc0450_VerifyChartAppearsForSelectedTicker", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	  logger.info("------------Executing Verify the chart appears for the selected item. .---------");
	  listObj.tc0450_VerifyChartAppearsForSelectedTicker();	 
	 }
	@Test(groups={"Regression"})
	public void tc0451_ListPanelNavigation(){
		 if (!TestUtil.isExecutable("tc0451_ListPanelNavigation", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		 }
		  logger.info("------------Executing Navigate the list panel using the up and down arrow keys.---------");
	  listObj.tc0451_ListPanelNavigation(); 
	}
	@Test(groups={"Regression"})
	public void tc0452_LoadChartByEnter(){
	     if (!TestUtil.isExecutable("tc0452_LoadChartByEnter", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		 }
		  logger.info("------------Executing load a chart by enter key---------");
	  listObj.tc0452_LoadChartByEnter(); 	
	}
	@Test(groups={"Regression"})
	public void tc0453_LoadChartBySpaceBar(){
		 if (!TestUtil.isExecutable("tc0453_LoadChartBySpaceBar", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		 }
		  logger.info("------------Executing The next item on the list should be selected from space bar--------");
	  listObj.tc0453_LoadChartBySpaceBar(); 
	}
	@Test(groups={"Regression"})
	public void tc0454_ValidateAdjustColumnWidth(){
		 if (!TestUtil.isExecutable("tc0454_ValidateAdjustColumnWidth", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		 }
		  logger.info("------------Executing ListPanelOption > Column Width Preference > adjust all columns width within user lists--------");
	  listObj.tc0454_ValidateAdjustColumnWidth();  
	 }
	//@Test(groups={"Regression"})
	public void tc0455_VerifyMovingItemUporDown() {
		if (!TestUtil.isExecutable("tc0455_VerifyMovingItemUporDown", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	  logger.info("------------Executing Click on an item in the list and move it up or down.Verify the item moves to the new location,-------");
      listObj.tc0455_VerifyMovingItemUporDown();  
	}
	//@Test(groups={"Regression"})
	public void tc0456_VerifyHashOrders(){
		if (!TestUtil.isExecutable("tc0456_VerifyHashOrders", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	  logger.info("------------Executing Right click on the # column header, then click Set # Order.Verify the items below are renumbered according to their current position-------");
      listObj.tc0456_VerifyHashOrders();
	}
	@Test(groups={"Regression"})
	public void tc0458_ValidateOptionsForSystemLlist(){
	   if (!TestUtil.isExecutable("tc0458_ValidateOptionsForSystemLlist", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing system list,and validate that you cannot perform the following actions on any items in the list, RENAME, DELETE, change SORT # ORDER.-------");
      listObj.tc0458_ValidateOptionsForSystemLlist();	
	}
	//@Test(groups={"Regression"})
	public void tc0458_ValidateSetOrderForSystemList(){
		 if (!TestUtil.isExecutable("tc0458_ValidateSetOrderForSystemList", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		   }
		  logger.info("------------Executing Validate change SORT # ORDER for system list..-------");
	      listObj.tc0458_ValidateSetOrderForSystemList();
	}
	@Test(groups={"Regression"})
	public void tc0463_VerifyDragTickerToUnAllowedPlace(){
		 if (!TestUtil.isExecutable("tc0463_VerifyDragTickerToUnAllowedPlace", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		   }
		  logger.info("------------Executing Highlight a ticker in the List, then try to drag it to parts of the screen that cannot accept it------");
	      listObj.tc0463_VerifyDragTickerToUnAllowedPlace();
	}
	@Test(groups={"Regression"})
	public void tc0468_ValidateForInValidTickers(){
		if (!TestUtil.isExecutable("tc0468_ValidateForInValidTickers", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	  logger.info("------------Executing if some tickers are invalid, they generate NOT FOUND message in their rows.-------");
      listObj.tc0468_ValidateForInValidTickers();
	}
}
