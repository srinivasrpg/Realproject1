package listManager;

import java.io.IOException;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import excelReader.TestUtil;
import static genericLib.Utility.*;

public class BrowseAndTrackListsTest {
	BrowseAndTrackLists listObj;
	
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		listObj=new BrowseAndTrackLists();
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeErrorPopUp()
	{
		closeErrorMessage();
	}
	
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			takeScreenShot(imageName);
		} 
	}
	
	@Test(groups={"Regression"})
	public void tc0469_ValidateBrowseListButton(){
		if (!TestUtil.isExecutable("tc0469_ValidateBrowseListButton", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	  logger.info("------------Executing Click on the Browse Lists button. Verify the Browse Lists window appears.--------");
      listObj.tc0469_ValidateBrowseListButton();  
	}
	@Test(groups={"Regression"})
	public void tc0470_ValidatePrivateShareRadioButton(){
		if (!TestUtil.isExecutable("tc0470_ValidateRadioButtons", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	  logger.info("------------Executing Validate Sharing radio buttons work(PRIVATE).--------");
      listObj.tc0470_ValidatePrivateShareRadioButton();
	 }
	@Test(groups={"Regression"})
	public void tc0470_ValidatePublicShareRadioButton(){
			if (!TestUtil.isExecutable("tc0470_ValidatePublicShareRadioButton", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		 }
		  logger.info("------------Executing Validate Sharing radio buttons work(PUBLIC).--------");
	      listObj.tc0470_ValidatePublicShareRadioButton();
		}
	@Test(groups={"Regression"})
	public void tc0470_ValidateRadioButtons(){
		if (!TestUtil.isExecutable("tc0470_ValidateRadioButtons", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	  logger.info("------------Executing Validate Sharing radio buttons work(ALL).--------");
      listObj.tc0470_ValidateRadioButtons();
	}
	
	
	@Test(groups={"Regression"})
	public void tc0471_ValidateTagCheckbox(){
		if (!TestUtil.isExecutable("tc0471_ValidateTagCheckbox", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("-----Executing  click on diff tags and ensure the list results window displays only those lists associated with those tags.--");
      listObj.tc0471_ValidateTagCheckbox();
	}
	@Test(groups={"Regression"})
	public void tc0471_ValidateTagsCheckbox(){
		if (!TestUtil.isExecutable("tc0471_ValidateTagsCheckbox", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("----Executing  click on diff tags and ensure the list results window displays only those lists associated with those tags.--");
      listObj.tc0471_ValidateTagsCheckbox();
	}
	@Test(groups={"Regression"})
	public void tc0472_ValidateClear(){
		if (!TestUtil.isExecutable("tc0472_ValidateClear", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("---Click CLEAR,ensure that all the tags you previously selected are now unselected, and that you once again see the whole list");
      listObj.tc0472_ValidateClear();
	}
	@Test(groups={"Regression"})
	public void tc0474_ValidateUpdatedWithinLastDay(){
		if (!TestUtil.isExecutable("tc0474_ValidateUpdatedWithinLastDay", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("---Click Select the radio buttons  Day and ensure the list results to the right are filtered properly");
      listObj.tc0474_ValidateUpdatedWithinLastDay();
	}
	@Test(groups={"Regression"})
	public void tc0475_ValidateKeywordTagAuthorFilter(){
		if (!TestUtil.isExecutable("tc0475_ValidateKeywordTagAuthorFilter", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Validate KEYWORD, TAG, OR AUTHOR filter.--------");
      listObj.tc0475_ValidateKeywordTagAuthorFilter();
	}
	@Test(groups={"Regression"})
	public void tc0476_ValidateKeywordTagAuthorFilter(){
		if (!TestUtil.isExecutable("tc0476_ValidateKeywordTagAuthorFilter", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Validate KEYWORD, TAG, OR AUTHOR filter with upper and lower case letters.--------");
      listObj.tc0476_ValidateKeywordTagAuthorFilter();
	}
	@Test(groups={"Regression"})
	public void tc0477_ValidateKeywordTagAuthorFilter(){
		if (!TestUtil.isExecutable("tc0477_ValidateKeywordTagAuthorFilter", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing Validate KEYWORD, TAG, OR AUTHOR filter removed.--------");
      listObj.tc0477_ValidateKeywordTagAuthorFilter();
	}
	@Test(groups={"Regression"})
	public void tc0478_ValidatePreviouslySelectedFilters(){
		if (!TestUtil.isExecutable("tc0478_ValidatePreviouslySelectedFilters", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executingselect a bunch of filter options, close the BROWSE LISTS window. Then click the BROWSE LISTS button to open the window again--------");
      listObj.tc0478_ValidatePreviouslySelectedFilters();
	}
	@Test(groups={"Regression"})
	public void tc0479_ValidatetheListSharedWithUs(){
		if (!TestUtil.isExecutable("tc0479_ValidatetheListSharedWithUs", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("------------Executing select a shared list.Verify that the COMMUNITY ACTIVITY window for that list appears..--");
      listObj.tc0479_ValidatetheListSharedWithUs();
	}
	@Test(groups={"Regression"})
	public void tc0480_VerifyAllContentsOfCommunity(){
		if (!TestUtil.isExecutable("tc0480_VerifyAllContentsOfCommunity", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing verifying the contents of community window--");
      listObj.tc0480_VerifyAllContentsOfCommunity();
	}
	@Test(groups={"Regression"})
	public void tc0481_ValidateViewListButton(){
		if (!TestUtil.isExecutable("tc0481_ValidateViewListButton", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing VAlidate ViewList Button--");
      listObj.tc0481_ValidateViewListButton();
	}
	@Test(groups={"Regression"})
	public void tc0482_ValidateTrackUntrackButton(){
		if (!TestUtil.isExecutable("tc0482_ValidateTrackUntrackButton", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing VAlidate track/Untrack Button--");
      listObj.tc0482_ValidateTrackUntrackButton();
	}
	@Test(groups={"Regression"})
	public void tc0483_ValidateRatings(){
		if (!TestUtil.isExecutable("tc0483_ValidateRatings", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing Validate RAtings stars Button--");
      listObj.tc0483_ValidateRatings();
	}
	@Test(groups={"Regression"})
	public void tc0484_ValidateAuthorNameLink(){
		if (!TestUtil.isExecutable("tc0484_ValidateAuthorNameLink", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing Click on one of the TAGS Community Activity window,and verify you are taken back to the BROWSE LISTS window--");
      listObj.tc0484_ValidateAuthorNameLink();
	}
	@Test(groups={"Regression"})
	public void tc0485_ValidateTagsPresentInCommunityWindow(){
		if (!TestUtil.isExecutable("tc0485_ValidateTagsPresentInCommunityWindow", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing Validate Author name link--");
      listObj.tc0485_ValidateTagsPresentInCommunityWindow();
	}
	@Test(groups={"Regression"})
	public void tc0486_ValidateAddedCommentsSection(){
		if (!TestUtil.isExecutable("tc0486_ValidateAddedCommentsSection", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing If there are multiple comments in the COMMENTS window, make sure they are being ordered with the oldest comment on top--");
      listObj.tc0486_ValidateAddedCommentsSection();
	}
	@Test(groups={"Regression"})
	public void tc0487_ValidateAddCommentSection(){
		if (!TestUtil.isExecutable("tc0487_ValidateAddCommentSection", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing In the ADD A COMMENT window, type a single character. Verify the SUBMIT button is still greyed out--");
      listObj.tc0487_ValidateAddCommentSection();
	}
	@Test(groups={"Regression"})
	public void tc0488_ValidateSubmitButton(){
		if (!TestUtil.isExecutable("tc0488_ValidateSubmitButton", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing a second character. With two characters, the SUBMIT button should become active.--");
      listObj.tc0488_ValidateSubmitButton();
	}
	@Test(groups={"Regression"})
	public void tc0489_TrackAList(){
		if (!TestUtil.isExecutable("tc0489_TrackAList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing track a list--");
      listObj.tc0489_TrackAList();
	}
	@Test(groups={"Regression"})
	public void tc0490_ValidateTrackedList(){
		if (!TestUtil.isExecutable("tc0490_ValidateTrackedList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing Validate tracked list present in tracked folder--");
      listObj.tc0490_ValidateTrackedList();
	}
	@Test(groups={"Regression"})
	public void tc0491_ValidateTSymbol(){
		if (!TestUtil.isExecutable("tc0491_ValidateTSymbol", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing Validate (T) symbol after the name in the BROWSE LISTS window.--");
      listObj.tc0491_ValidateTSymbol();
	}
	@Test(groups={"Regression"})
	public void tc0492_ValidateViewDetailsOfcreatedList(){
		if (!TestUtil.isExecutable("tc0492_ValidateViewDetailsOfcreatedList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing Validate View Details of user created list contains track button.--");
      listObj.tc0492_ValidateViewDetailsOfcreatedList();
	}
	
	@Test(groups={"Regression"})
	public void tc0493_ValidateViewDetailOfSmartList(){
		if (!TestUtil.isExecutable("tc0493_ValidateViewDetailOfSmartList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing Validateview details of smartList.--");
      listObj.tc0493_ValidateViewDetailOfSmartList();
	}
	
	//@Test(groups={"Regression"})
	public  void tc0495_ValidateDragAndDropInsideTrackedFolder(){
		if (!TestUtil.isExecutable("tc0495_ValidateDragAndDropInsideTrackedFolder", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing  moving one of the tracked lists to a different position in the folder.--");
      listObj.tc0495_ValidateDragAndDropInsideTrackedFolder();	
	}
	@Test(groups={"Regression"})
	public void tc0496_ValidateUntrack(){
		if (!TestUtil.isExecutable("tc0496_ValidateUntrack", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing Validate un track option of the tracked list.--");
      listObj.tc0496_ValidateUntrack();
	}
	@Test(groups={"Regression"})
	public void tc0497_ValidateAppliedTagsSection(){
		if (!TestUtil.isExecutable("tc0497_ValidateAppliedTagsSection", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("--executing Validate Click on a tag,make sure that the Browse Lists window appears,tag show up in the results.--");
      listObj.tc0497_ValidateAppliedTagsSection();
	}
}
