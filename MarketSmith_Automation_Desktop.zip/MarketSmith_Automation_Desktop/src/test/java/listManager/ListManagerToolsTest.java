package listManager;

import java.io.IOException;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import excelReader.TestUtil;
import static genericLib.Utility.*;

public class ListManagerToolsTest {
	ListManagerTools listObj;
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		listObj=new ListManagerTools();
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeErrorPopUp()
	{
		closeErrorMessage();
	}
	
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			takeScreenShot(imageName);
		} 
	}
	
	@Test(groups={"Regression"})
	public void tc0297_VerifyListManagerVisibility() throws InterruptedException{
		if (!TestUtil.isExecutable("tc0297_VerifyListManagerVisibility", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	  }
	 logger.info("-------Executing Verify that a List is present in the LIST MANAGER by default when you open up the MS Tool-----");
	 listObj.tc0297_VerifyListManagerVisibility();
    }
	@Test(groups={"Regression"})
	public void tc0298_VerifyViewIcons(){
		if (!TestUtil.isExecutable("tc0298_VerifyViewIcons", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	  }
	 logger.info("-------Executing Verify There are three view icons- Mini, Max and Default.-----");
	 listObj.tc0298_VerifyViewIcons();
	}
	
	@Test(groups={"Regression"})
	public void tc0299_VerifyPlayButtonAndDropdown(){
		if (!TestUtil.isExecutable("tc0299_VerifyPlayButtonAndDropdown", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing verify is there PLAY button to the left of the view icons, as well as a dropdown button?-----");
		listObj.tc0299_VerifyPlayButtonAndDropdown();
     }
	
	@Test(groups={"Regression"})
	public void tc0300_VerifyToolAndHelpButtons(){
		if (!TestUtil.isExecutable("tc0300_VerifyToolAndHelpButtons", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing verify there is a Tool button (wrench) and a Help button (question mark)-----");
		listObj.tc0300_VerifyToolAndHelpButtons();
	}
	@Test(groups={"Regression"})
	public void tc0301_ValidateDifferentViewButtons(){
		if (!TestUtil.isExecutable("tc0301_ValidateDifferentViewButtons", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Validate we can change the list manager view with the MINI view,the DEFAULT,and the MAX view icon buttons.-----");
		listObj.tc0301_ValidateDifferentViewButtons();
	}
	@Test(groups={"Regression"})
	public void tc0302_ValidateListManagerDrag(){
		if (!TestUtil.isExecutable("tc0302_ValidateListManagerDrag", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Validate you can drag the edge of the panel to any point in between the MAX-MINI defaults.-----");
		listObj.tc0302_ValidateListManagerDrag();   
	}
	@Test(groups={"Regression"})
	public void tc0303_ValidateViewButtons(){
		if (!TestUtil.isExecutable("tc0303_ValidateViewButtons", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Validate we can change the list manager view with the MINI view,the DEFAULT,and the MAX view icon buttons.-----");
		listObj.tc0301_ValidateDifferentViewButtons();
	}
	@Test(groups={"Regression"})
	public void tc0304_ValidatePlayDropdownOptions(){
		if (!TestUtil.isExecutable("tc0304_ValidatePlayDropdownOptions", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Validate we can change the list manager view with the MINI view,the DEFAULT,and the MAX view icon buttons.-----");
		listObj.tc0304_ValidatePlayDropdownOptions();
	}
	@Test(groups={"Regression"})
	 public void tc0305_ValidatePlayButton(){
		if (!TestUtil.isExecutable("tc0305_ValidatePlayButton", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Click on the PLAY button and verify that it works correctly with the time of seconds you have selected.-----");
		listObj.tc0305_ValidatePlayButton();
	}
	@Test(groups={"Regression"})
	public void tc0310_VerifyResumePlayWindow(){
		if (!TestUtil.isExecutable("tc0310_VerifyResumePlayWindow", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Verify that if you start to type or click on the chart, the play list pauses and a window appears.-----");
		listObj.tc0310_VerifyResumePlayWindow();
	}
	
	@Test(groups={"Regression"})
	public void tc0313_ValidatePlayFunctionality(){
		if (!TestUtil.isExecutable("tc0313_ValidatePlayFunctionality", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Start the list playing again, then click on the pause button. Does the playlist stop?.-----");
		listObj.tc0313_ValidatePlayFunctionality();
	}
	@Test(groups={"Regression"})
	public void tc0314_ValidatePlayFunctionality(){
		if (!TestUtil.isExecutable("tc0314_ValidatePlayFunctionality", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Select different functionality while list is playing .-----");
		listObj.tc0314_ValidatePlayFunctionality();
	}
	@Test(groups={"Regression"})
	public void tc0315_ValidatePlayWithRItab(){
		if (!TestUtil.isExecutable("tc0315_ValidatePlayWithRItab", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing select the tab from RI panel while list is playing.-----");
		listObj.tc0315_ValidatePlayWithRItab();
	}
	@Test(groups={"Regression"})
	public void tc0316_VerifyPlayListStopsAtLastItem(){
		if (!TestUtil.isExecutable("tc0316_VerifyPlayListStopsAtLastItem", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Verify the play list stops once the last item is selected.-----");
		listObj.tc0316_VerifyPlayListStopsAtLastItem();
	}
	@Test(groups={"Regression"})
	public void tc0318_VerifyListMangerTool(){
		if (!TestUtil.isExecutable("tc0318_VerifyListMangerTool", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Click on the Tool button (wrench icon) for the List Manager options. Does the dropdown menu appear?-----");
		listObj.tc0318_VerifyListMangerTool(); 
	 }
	@Test(groups={"Regression"})
	public void tc0319_VerifyListManagerDropdown(){
		if (!TestUtil.isExecutable("tc0319_VerifyListManagerDropdown", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Verify the options present in List Manager tools.-----");
		listObj.tc0319_VerifyListManagerDropdown();
	}
	@Test(groups={"Regression"})
	public void tc0320_ValidateViewDetailsOption(){
		if (!TestUtil.isExecutable("tc0320_ValidateViewDetailsOption", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Click on View Details. Verify a window appears with information about the current list. .-----");
		listObj.tc0320_ValidateViewDetailsOption();
	}
	@Test(groups={"Regression"})
	public void tc0321_VerifyContentsOfViewDetails(){
		if (!TestUtil.isExecutable("tc0321_VerifyContentsOfViewDetails", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Verify all contents of view details window-----");
		listObj.tc0321_VerifyContentsOfViewDetails(); 
	}
	@Test(groups={"Regression"})
	public void tc0324_VerifySharingStatus(){
		if (!TestUtil.isExecutable("tc0324_VerifySharingStatus", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Verify sharing status of lists-----");
		listObj.tc0324_VerifySharingStatus();
	}
	@Test(groups={"Regression"})
	public void tc0325_ValidateChangeLink(){
		 if (!TestUtil.isExecutable("tc0325_ValidateChangeLink", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		    }
			logger.info("-------Executing Click on change. Verify a new Share a List window appears-----");
			listObj.tc0325_ValidateChangeLink();
	 }
	@Test(groups={"Regression"})
	 public void tc0326_VerifyContentsOfShareList(){
		 if (!TestUtil.isExecutable("tc0326_VerifyContentsOfShareList", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		    }
			logger.info("-------Executing Verify contents of Share a List window-----");
			listObj.tc0326_VerifyContentsOfShareList(); 
	 }
	@Test(groups={"Regression"})
	 public void tc0327_ValidateEditContentsOfsharedList(){
		 if (!TestUtil.isExecutable("tc0327_ValidateEditContentsOfsharedList", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		    }
			logger.info("-------Executing Edit the list settings by changing the sharing status, editing the description, and adding or removing tags. Click Cancel.-----");
			listObj.tc0327_ValidateEditContentsOfsharedList(); 
	 }
	@Test(groups={"Regression"})
	 public void tc0328_VerifyListSettingsChanged(){
		if (!TestUtil.isExecutable("tc0328_VerifyListSettingsChanged", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Verify the list settings have not been changed..-----");
		listObj.tc0328_VerifyListSettingsChanged(); 
	}
	@Test(groups={"Regression"})
	 public void tc0329_ValidateContentsOfShareList(){
		 if (!TestUtil.isExecutable("tc0329_ValidateContentsOfShareList", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		    }
			logger.info("-------Executing Edit the list settings by changing the sharing status,editing the description, and add or remove tags-----");
			listObj.tc0329_ValidateContentsOfShareList(); 
	 }
	@Test(groups={"Regression"},priority=1)
	public void tc0330_VerifyListSettings(){
		if (!TestUtil.isExecutable("tc0330_VerifyListSettings", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Verify the list settings have been changed.-----");
		listObj.tc0330_VerifyListSettings(); 
	}
	@Test(groups={"Regression"},priority=2)
	public void tc0322_VerifyCommentSectionOfSharedList(){
		if (!TestUtil.isExecutable("tc0322_VerifyCommentSectionOfSharedList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	logger.info("-------Executing Verify the comment section of shared list-----");
	listObj.tc0322_VerifyCommentSectionOfSharedList();
	}
	@Test(groups={"Regression"},priority=3)
	public void tc0323_VerifyRatingSectionOfSharedList(){
		if (!TestUtil.isExecutable("tc0323_VerifyRatingSectionOfSharedList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	logger.info("-------Executing Verify the rating section of shared list.-----");
	listObj.tc0323_VerifyRatingSectionOfSharedList();
	}
	@Test(groups={"Regression"},priority=4)
	public void tc0331_VerifySharedIconForSharedList(){
		if (!TestUtil.isExecutable("tc0331_VerifySharedIconForSharedList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Verify that a shared list shows a shared icon next to the list name on the list manager.-----");
		listObj.tc0331_VerifySharedIconForSharedList(); 
	}
	@Test(groups={"Regression"},priority=5)
	public void tc0339_VerifyExportOptions(){
		if (!TestUtil.isExecutable("tc0339_VerifyExportOptions", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Verify export options.-----");
		listObj.tc0339_VerifyExportOptions(); 
	}
	
	public void tc0340_ValidateCommaDelimitedOption(){
		if (!TestUtil.isExecutable("tc0340_ValidateCommaDelimitedOption", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Select Comma Delimited (.csv) in the Export menu. The file download process starts..-----");
		listObj.tc0340_ValidateCommaDelimitedOption();  
	 }
	@Test(groups={"Regression"},priority=6)
	public void tc0350_VerifyCustomizeColumnLayoutOption(){
		if (!TestUtil.isExecutable("tc0350_VerifyCustomizeColumnLayoutOption", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Click on Customize Column Layout. Does a window appear?.-----");
		listObj.tc0350_VerifyCustomizeColumnLayoutOption();  
	}
	@Test(groups={"Regression"},priority=7)
	public void tc0351_VerifySelectableCriteria(){
		if (!TestUtil.isExecutable("tc0351_VerifySelectableCriteria", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Each dropdown menu will contain selectable criteria in the form of boxes that are draggable to the bottom layout preview.-----");
		listObj.tc0351_VerifySelectableCriteria(); 
	}
	@Test(groups={"Regression"},priority=8)
	public void tc0353_VerifyColumnLayoutOption(){
		if (!TestUtil.isExecutable("tc0353_VerifyColumnLayoutOption", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Validate custom column layout hang over options..-----");
		listObj.tc0353_VerifyColumnLayoutOption();   
	 }
	@Test(groups={"Regression"},priority=9)
	public void tc0354_ValidateColumnLayoutOptions(){
		if (!TestUtil.isExecutable("tc0354_ValidateColumnLayoutOptions", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Click on any column layout. Verify the list panel column titles change to reflect your selection..-----");
		listObj.tc0354_ValidateColumnLayoutOptions();   
	}
	@Test(groups={"Regression"},priority=10)
	 public void tc0356_VerifyColumnWidthPrefButtons(){
		if (!TestUtil.isExecutable("tc0356_VerifyColumnWidthPrefButtons", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
		logger.info("-------Executing Click on Column Width Preference. Verify the Column Width Preference window appears and contains two radio buttons..-----");
		listObj.tc0356_VerifyColumnWidthPrefButtons();   
	}
	
	
	@Test(groups={"Regression"},priority=11)
	public void tc0357_ValidateAdjustColumnWidthforCurrentList(){
		 if (!TestUtil.isExecutable("tc0357_ValidateAdjustColumnWidthforCurrentList", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		    }
		logger.info("-------Executing Validate we can change the list manager view with the MINI view,the DEFAULT,and the MAX view icon buttons.-----");
		listObj.tc0357_ValidateAdjustColumnWidthforCurrentList();	
	 }
	@Test(groups={"Regression"},priority=12)
	public void tc0358_ValidateColumnWidthForAllLists(){
		 if (!TestUtil.isExecutable("tc0358_ValidateColumnWidthForAllLists", "ListManager",
					runModeXl)) {
				throw new SkipException("Runmode set to NO");
		    }
		logger.info("-------Executing Select the second option and hit Accept. Verify adjusting a column will affect it on all lists.-----");
		listObj.tc0358_ValidateColumnWidthForAllLists();
	}
	@Test(groups={"Regression"},priority=13)
	public void tc0359_ValidateColumnWidthPrefCancelButton(){
		if (!TestUtil.isExecutable("tc0359_ValidateColumnWidthPrefCancelButton", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	  logger.info("-------Executing Click on the first radio button again,hit Cancel. When changing the width of a column,are the selected preferences still in affect? .-----");
	  listObj.tc0359_ValidateColumnWidthPrefCancelButton();
	}
	
	@Test(groups={"Regression"},priority=14)
	public void tc0332_ValidateViewDetailsOfListSharedwithUs(){
		if (!TestUtil.isExecutable("tc0332_ValidateViewDetailsOfListSharedwithUs", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	logger.info("-------Executing Click View Details. Verify the information window appears and that the information is correct/related to the List.-----");
	listObj.tc0332_ValidateViewDetailsOfListSharedwithUs();
	}
	@Test(groups={"Regression"},priority=16)
	public void tc0333_ValidateViewListButton(){
		if (!TestUtil.isExecutable("tc0333_ValidateViewListButton", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	logger.info("-------Executing click VIEW LIST button in list details window.-----");
	listObj.tc0333_ValidateViewListButton(); 
	 }
	@Test(groups={"Regression"},priority=15)
	public void tc0334_ViewProfileOfAuthorWhoSharedList(){
		if (!TestUtil.isExecutable("tc0334_ViewProfileOfAuthorWhoSharedList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	logger.info("-------Executing view profile of author who shares list, via browse name link and other way..-----");
	listObj.tc0334_ViewProfileOfAuthorWhoSharedList(); 
	 }
	@Test(groups={"Regression"},priority=17)
	public void tc0335_ValidateTsymbolForTrackedList(){
		if (!TestUtil.isExecutable("tc0335_ValidateTsymbolForTrackedList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	    }
	logger.info("-------Executing validate (T) if you are tracking list.-----");
	listObj.tc0335_ValidateTsymbolForTrackedList(); 
	 }
}
