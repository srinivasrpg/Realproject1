package listManager;

import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import excelReader.TestUtil;
import static genericLib.Utility.*;

public class ListManager1Test {
	ListManager1 listObj;
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		listObj=new ListManager1();
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeErrorPopUp()
	{
		closeErrorMessage();
	}
	
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			takeScreenShot(imageName);
		} 
	}
	
	@Test(groups={"Regression"})
	public void tc0360_VerifyLeftPanel(){
		if (!TestUtil.isExecutable("tc0360_VerifyLeftPanel", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
	 logger.info("------------Executing verify left Panel test------------");
	 listObj.tc0360_VerifyLeftPanel();
    }
	
	@Test(groups={"Regression"})
	public void tc0362_Verify2ButtonsAboveList(){
		if (!TestUtil.isExecutable("tc0362_Verify2ButtonsAboveList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	 }
		logger.info("------------Executing verify top buttons------------");
		listObj.tc0362_Verify2ButtonsAboveList();
	}
	
	@Test(groups={"Regression"})
	public void tc0363_verifyListtitle(){
		if (!TestUtil.isExecutable("tc0363_verifyListtitle", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	logger.info("------------Executing verify list title test------------");
	listObj.tc0363_verifyListtitle();	
	}
	@Test(groups={"Regression"})
	public void tc0364_VerifyHighLightedList(){
		if (!TestUtil.isExecutable("tc0364_VerifyHighLightedList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
	logger.info("------------Executing Click on various lists. Make sure the highlight follows the lists you are clicking on------------");
	listObj.tc0364_VerifyHighLightedList();	
	}
	
	@Test(groups={"Regression"})
	public void tc0366_VerifyDropDownOfCreatedList(){
		if (!TestUtil.isExecutable("tc0366_VerifyDropDownOfCreatedList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
	   }
		logger.info("------------Executing verify dropdown of createdlist------------");
		listObj.tc0366_VerifyDropDownOfCreatedList();
	}
	
	@Test(groups={"Regression"})
	public void tc0367_verifyDropdownOfMsList(){
		if (!TestUtil.isExecutable("tc0367_verifyDropdownOfMsList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing verify dropdown of ms list------------");
	    listObj.tc0367_verifyDropdownOfMsList();
	}
	
	@Test(groups={"Regression"})
	public void tc0369_CreateNewList(){
		if (!TestUtil.isExecutable("tc0369_CreateNewList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		Hashtable<String, String> data=TestUtil.getData("tc0369_CreateNewList", "ListManager",
				dataXl);
		logger.info("------------Executing create a list------------");
		listObj.tc0369_CreateNewList(data.get("ListName"));
	}
	
	@Test(groups={"Regression"},priority=1)
	public void tc0370_CreateNewFolder(){
		if (!TestUtil.isExecutable("tc0370_CreateNewFolder", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		Hashtable<String, String> data=TestUtil.getData("tc0370_CreateNewFolder", "ListManager",
				dataXl);
		logger.info("------------Executing create a folder------------");
		listObj.tc0370_CreateNewFolder(data.get("FolderName"));
	}
	@Test(groups={"Regression"})
	public void tc0373_ValidateCopyOption(){
		if (!TestUtil.isExecutable("tc0373_ValidateCopyOption", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}Hashtable<String, String> data=TestUtil.getData("tc0373_ValidateCopyOption", "ListManager",
				dataXl);
		logger.info("------------Executing Click CANCEL. Verify that a new list is not created.------------");
		listObj.tc0373_ValidateCopyOption(data.get("ListName"));
	}
	
	@Test(groups={"Regression"})
	public void tc0374_CreateCopyOfList(){
		if (!TestUtil.isExecutable("tc0374_CreateCopyOfList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing create copy list------------");
		listObj.tc0374_CreateCopyOfList();
	}
	//@Test(groups={"Regression"})
	public void tc0375_VerifyMoveListByDragAndDrop(){
		if (!TestUtil.isExecutable("tc0375_VerifyMoveListByDragAndDrop", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing MOVE any list by dragging and dropping it. Verify the list successfully moves to the new location.-----");
		listObj.tc0375_VerifyMoveListByDragAndDrop();
	}
	@Test(groups={"Regression"})
	public void tc0376_VerifyListMoveToUnAllowedLoc(){
		if (!TestUtil.isExecutable("tc0376_VerifyListMoveToUnAllowedLoc", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing Try to MOVE a list to a disallowed or locked location, and make sure the list does not move-----------");
		listObj.tc0376_VerifyListMoveToUnAllowedLoc();
	}
	
	@Test(groups={"Regression"})
	public void tc0377_RenameCreateList(){
		if (!TestUtil.isExecutable("tc0377_RenameCreateList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		Hashtable<String, String> data=TestUtil.getData("tc0377_RenameCreateList", "ListManager",
				dataXl);
		logger.info("------------Executing rename created list------------");
		listObj.tc0377_RenameCreateList(data.get("ListName1"));
	}
	
	@Test(groups={"Regression"})
	public void tc0378_ValidateRenameOption(){
		if (!TestUtil.isExecutable("tc0378_ValidateRenameOption", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		Hashtable<String, String> data=TestUtil.getData("tc0378_ValidateRenameOption", "ListManager",
				dataXl);
		logger.info("------------Executing Enter a new name and click CANCEL. Verify that the list name has not been changed.------------");
		listObj.tc0378_ValidateRenameOption(data.get("ListName"));
	}
	
	@Test(groups={"Regression"})
	public void tc0380_AddToFavourites(){
		if (!TestUtil.isExecutable("tc0380_AddToFavourites", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing add to favourite folder");
		listObj.tc0380_AddToFavourites();
	}
	@Test(groups={"Regression"})
	public void tc0381_ValidateFavouriteListColumns(){
		if (!TestUtil.isExecutable("tc0381_ValidateFavouriteListColumns", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing Make sure the columns for the list in Favorites match the column for the list in its original location.");
		listObj.tc0381_ValidateFavouriteListColumns();
	}
	
	@Test(groups={"Regression"})
	public void tc0382_VerifyDropDownOfFavourite(){
		if (!TestUtil.isExecutable("tc0382_VerifyDropDownOfFavourite", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing verify the dropdown of favourite list");
		listObj.tc0382_VerifyDropDownOfFavourite();
	}
	//@Test(groups={"Regression"},priority=14)
	public void tc0383_VerifyDragListInsideFavorite(){
		if (!TestUtil.isExecutable("tc0383_VerifyDragListInsideFavorite", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing Make sure you can change the order of items in the FAVORITES list group.");
		listObj.tc0383_VerifyDragListInsideFavorite();
	}
	@Test(groups={"Regression"})
	public void tc0384_ValidateAddToFavoriteForScreenResults(){
		if (!TestUtil.isExecutable("tc0384_ValidateAddToFavoriteForScreenResults", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing The only folders that can't be copied to FAVORITES are SCREEN RESULTS and TEMPORARY.");
		listObj.tc0384_ValidateAddToFavoriteForScreenResults();
	}
	@Test(groups={"Regression"})
	public void tc0385_ValidateDuplicacyInFavorite(){
		if (!TestUtil.isExecutable("tc0385_ValidateDuplicacyInFavorite", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executingtry dragging the same list there again.Make sure that no duplicate list gets copied.");
		listObj.tc0385_ValidateDuplicacyInFavorite();
	}
	@Test(groups={"Regression"},priority=15)
	public void tc0386_RemoveFromFavourites(){
		if (!TestUtil.isExecutable("tc0386_RemoveFromFavourites", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing verify the remove from favourite list");
		listObj.tc0386_RemoveFromFavourites();
	}
	@Test(groups={"Regression"},priority=6)
	public void tc0387_SharingList(){
		if (!TestUtil.isExecutable("tc0387_SharingList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing verify sharing list");
		listObj.tc0387_SharingList();
	}
	
	@Test(groups={"Regression"},priority=7)
	public void tc0388_ShareWithSpecificMember(){
		if (!TestUtil.isExecutable("tc0388_ShareWithSpecificMember", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing verify share with specific memeber");
		listObj.tc0388_ShareWithSpecificMember();
	}
	
	@Test(groups={"Regression"},priority=8)
	public void tc0389_shareWithEveryone(){
		if (!TestUtil.isExecutable("tc0389_shareWithEveryone", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing verify share with everyone");
		listObj.tc0389_shareWithEveryone();
	}
	@Test(groups={"Regression"},priority=9)
	public void tc0391_VerifyTheTagsApplied(){
		if (!TestUtil.isExecutable("tc0391_VerifyTheTagsApplied", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing choose a few default tags.As you click each button,verify the tag in question populates the TAGS APPLIED section towards the bottom of the window.");
		listObj.tc0391_VerifyTheTagsApplied();
	}
	@Test(groups={"Regression"},priority=10)
	public void tc0392_VerifyAdditionalTags(){
		if (!TestUtil.isExecutable("tc0392_VerifyAdditionalTags", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing Under ADDITIONAL TAGS, make up a few new custom tags..");
		listObj.tc0392_VerifyAdditionalTags();
	}
	@Test(groups={"Regression"},priority=11)
	public void tc0393_VerifyAdditionalTags(){
		if (!TestUtil.isExecutable("tc0393_VerifyAdditionalTags", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing Try typing in one tag that contains non-alphanumeric characters. That one should disappear.");
		listObj.tc0393_VerifyAdditionalTags();
	}
	@Test(groups={"Regression"},priority=12)
	public void tc0395_VerifySharedIconInsideFavourite(){
		if (!TestUtil.isExecutable("tc0395_VerifySharedIconInsideFavourite", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing FAVORITES section, verify that the Shared icon appears next to the list name, just as it did in its previous location.");
		listObj.tc0395_VerifySharedIconInsideFavourite();
	}
	@Test(groups={"Regression"},priority=13)
	public void tc0396_VerifyViewDetailsOfFavoriteList(){
		if (!TestUtil.isExecutable("tc0396_VerifyViewDetailsOfFavoriteList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing select VIEW DETAILS. In that pop-up window,verify that the Sharing Status for the list matches what the status");
		listObj.tc0396_VerifyViewDetailsOfFavoriteList();
	}
	@Test(groups={"Regression"},priority=16)
	public void tc0400_ChangeSharingStatus(){
		if (!TestUtil.isExecutable("tc0400_ChangeSharingStatus", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing change sharing status");
		listObj.tc0400_ChangeSharingStatus();
	}
	@Test(groups={"Regression"},priority=17)
	public void tc0401_verifyCommentSectionOfViewDetails(){
		if (!TestUtil.isExecutable("tc0401_verifyCommentSectionOfViewDetails", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing verify comment section");
		listObj.tc0401_verifyCommentSectionOfViewDetails();
    }
	
	@Test(groups={"Regression"},priority=2)
	public void tc0404_deleteCreatedFolder(){
		if (!TestUtil.isExecutable("tc0404_deleteCreatedFolder", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing delete created folder");
		listObj.tc0402_deleteCreatedList();
	}
	@Test(groups={"Regression"},priority=3)
	public void tc0403_VerifyCancelDeleteList(){
		if (!TestUtil.isExecutable("tc0403_VerifyCancelDeleteList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing Click on Cancel. Verify the list was not deleted and is still in the list manager.r");
		listObj.tc0403_VerifyCancelDeleteList();
	}
	
	@Test(groups={"Regression"},priority=4)
	public void tc0402_deleteCreatedList(){
		if (!TestUtil.isExecutable("tc0402_deleteCreatedList", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing delete created list");
		listObj.tc0402_deleteCreatedList();
	}
	@Test(groups={"Regression"},priority=5)
	public void tc0405_deleteCreatedListWithoutConfirmation(){
		if (!TestUtil.isExecutable("tc0405_deleteCreatedListWithoutConfirmation", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing Delete another created list and verify the list is deleted without a confirmation window appearing. ");
		listObj.tc0405_deleteCreatedListWithoutConfirmation();
	}
	
	@Test(groups={"Regression"},priority=18)
	public void tc0412_VerifyComparisonChart(){
		if (!TestUtil.isExecutable("tc0412_VerifyComparisonChart", "ListManager",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		   }
		logger.info("------Executing verify comparision chart");
		listObj.tc0412_VerifyComparisonChart();
	}
}
