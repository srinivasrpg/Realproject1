package screener;

import java.io.IOException;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import excelReader.TestUtil;
import genericLib.Utility;


import static genericLib.Utility.*;
import org.testng.annotations.*;

public class ScreensTest {
	
	Screens ChartObj;
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		ChartObj=new Screens();
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeErrorPopUp()
	{
		Utility.closeErrorMessage();
	}
	
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			Utility.takeScreenShot(imageName);
		} 
	}
	
	//Set LM to default in order to be able to interact with Screener panel
	@BeforeMethod(alwaysRun=true)
	public void screenerTestSetUp()
	{
		logger.info("---------Executing Screener Panel pre-test set up method------------");
		ChartObj.screenerTestSetUp();
	}
	
	@Test(groups={"Regression"}) //(includes tc0745)
	//@Test(groups={"Regression"},enabled=false)
	public void tc0744_VerifyScreenerPanelClosed(){
		if(!TestUtil.isExecutable("tc0744_VerifyScreenerPanelClosed","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0744_VerifyScreenerPanelClosed------------");
		ChartObj.tc0744_VerifyScreenerPanelClosed();
	}
	
	@Test(groups={"Regression"}) //(includes tc0747)
	//@Test(groups={"Regression"},enabled=false)
	public void tc0746_VerifyScreenerPanelOpen(){
		if(!TestUtil.isExecutable("tc0746_VerifyScreenerPanelOpen","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0746_VerifyScreenerPanelOpen------------");
		ChartObj.tc0746_VerifyScreenerPanelOpen();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0748_VerifyScreenerSubPanels(){
		if(!TestUtil.isExecutable("tc0748_VerifyScreenerSubPanels","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0748_VerifyScreenerSubPanels------------");
		ChartObj.tc0748_VerifyScreenerSubPanels();
	}

	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0749_ScreenSubPanel_ScreeenSections(){
		if(!TestUtil.isExecutable("tc0749_ScreenSubPanel_ScreeenSections","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0749_ScreenSubPanel_ScreeenSections------------");
		ChartObj.tc0749_ScreenSubPanel_ScreeenSections();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0750_ScreenSubPanel_msStockScreens_Presets(){
		if(!TestUtil.isExecutable("tc0750_ScreenSubPanel_msStockScreens_Presets","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0750_ScreenSubPanel_msStockScreens_Presets------------");
		ChartObj.tc0750_ScreenSubPanel_msStockScreens_Presets();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0751_ScreenSubPanel_msFundScreens_Presets(){
		if(!TestUtil.isExecutable("tc0751_ScreenSubPanel_msFundScreens_Presets","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0751_ScreenSubPanel_msFundScreens_Presets------------");
		ChartObj.tc0751_ScreenSubPanel_msFundScreens_Presets();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0753_HoverOverStock_DropDown(){
		if(!TestUtil.isExecutable("tc0753_HoverOverStock_DropDown","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0753_HoverOverStock_DropDown------------");
		ChartObj.tc0753_HoverOverStock_DropDown();
	}

	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0754_MyScreensDropDownMenuContent(){
		if(!TestUtil.isExecutable("tc0754_MyScreensDropDownMenuContent","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0754_MyScreensDropDownMenuContent------------");
		ChartObj.tc0754_MyScreensDropDownMenuContent();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0768_VerifyMarketsmithScreensContent(){
		if(!TestUtil.isExecutable("tc0768_VerifyMarketsmithScreensContent","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0768_VerifyMarketsmithScreensContent------------");
		ChartObj.tc0768_VerifyMarketsmithScreensContent();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0775_VerifyNewButton(){
		if(!TestUtil.isExecutable("tc0775_VerifyNewButton","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0775_VerifyNewButton. Do the options New Stock Screen,New Fund Screen and New Folder appear?------------");
		ChartObj.tc0775_VerifyNewButton();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0758_VerifyShareScreenOption(){
		if(!TestUtil.isExecutable("tc0758_VerifyShareScreenOption","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0758_VerifyShareScreenOption, verify that the Shared symbol is displayed next to the screen name on the right.------------");
		ChartObj.tc0758_VerifyShareScreenOption();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0756_VerifyTrackedScreensMenuContent()
	{
		if(!TestUtil.isExecutable("tc0756_VerifyTrackedScreensMenuContent","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0756_VerifyTrackedScreensMenuContent, verify tracked screens drop down menu content------------");
		ChartObj.tc0756_VerifyTrackedScreensMenuContent();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0757_VerifyFavoriteScreensMenuContent()
	{
		if(!TestUtil.isExecutable("tc0757_VerifyFavoriteScreensMenuContent","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0757_VerifyFavoriteScreensMenuContent, verify tracked screens drop down menu content------------");
		ChartObj.tc0757_VerifyFavoriteScreensMenuContent();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0759_VerifyScreenLoadsInLM()
	{
		if(!TestUtil.isExecutable("tc0759_VerifyScreenLoadsInLM","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0759_VerifyScreenLoadsInLM, verify screen title is loaded in LM nav bar------------");
		ChartObj.tc0759_VerifyScreenLoadsInLM();
	}
	
	@Test(groups={"Regression"})
	public void tc0760_VerifyScreenTopButtons()
	{
		if(!TestUtil.isExecutable("tc0760_VerifyScreenTopButtons","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0760_VerifyScreenTopButtons, verify screener has 3 top buttons------------");
		ChartObj.tc0760_VerifyScreenTopButtons();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0761_VerifyEditScreenButtonToggle_Open()
	{
		if(!TestUtil.isExecutable("tc0761_VerifyEditScreenButtonToggle_Open","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0761_VerifyEditScreenButtonToggle_Open, verify screener edit button toggle OPEN------------");
		ChartObj.tc0761_VerifyEditScreenButtonToggle();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0762_VerifyEditScreenButtonToggle_Close()
	{
		if(!TestUtil.isExecutable("tc0762_VerifyEditScreenButtonToggle_Close","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0762_VerifyEditScreenButtonToggle_Close, verify screener edit button toggle CLOSE------------");
		ChartObj.tc0761_VerifyEditScreenButtonToggle();
	}
	
	
	//@Test(groups={"Regression"})
	@Test(groups={"Regression"},enabled=false)
	public void tcCheckLMUpdatingContent()
	{
		if(!TestUtil.isExecutable("tcCheckLMUpdatingContent","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tcCheckLMUpdatingContent, verify LM content is updating------------");
		//ChartObj.tcCheckLMUpdatingContent();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0763_VerifyEditScreenNameOfScreen()
	{
		if(!TestUtil.isExecutable("tc0763_VerifyEditScreenNameOfScreen","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0763_VerifyEditScreenNameOfScreen, verify edit Screen has correct Screen Name being displayed------------");
		ChartObj.tc0763_VerifyEditScreenNameOfScreen();
	}
	
	//@Test(groups={"Regression"})
	@Test(groups={"Regression"},enabled=false)
	public void tc0776_VerifyScreenNewFolder()
	{
		if(!TestUtil.isExecutable("tc0776_VerifyScreenNewFolder","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0776_VerifyScreenNewFolder, verify Screener, NEW FOLDER option has correct behavior------------");
		ChartObj.tc0776_VerifyScreenNewFolder();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0779_VerifyScreenNewScreen()
	{
		if(!TestUtil.isExecutable("tc0779_VerifyScreenNewScreen","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0779_VerifyScreenNewScreen, verify Screener, NEW SCREEN option has correct behavior------------");
		ChartObj.tc0779_VerifyScreenNewScreen();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0781_VerifyBrowseScreensWindow()
	{
		if(!TestUtil.isExecutable("tc0781_VerifyBrowseScreensWindow","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0781_VerifyBrowseScreensWindow, verify BROWSE SCREEN option has correct behavior------------");
		ChartObj.tc0781_VerifyBrowseScreensWindow();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0783_VerifyBrowseScreensWindowLHSFilterContent()
	{
		if(!TestUtil.isExecutable("tc0783_VerifyBrowseScreensWindowLHSFilterContent","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0783_VerifyBrowseScreensWindowLHSFilterContent, verify BROWSE SCREEN window has correct content on LHS of modal------------");
		ChartObj.tc0783_VerifyBrowseScreensWindowLHSFilterContent();
	}
	
/*	@Test(groups={"Regression"})
	public void tc0788_VerifyBrowseScreensSelectedScreenPopUpContent()
	{
		if(!TestUtil.isExecutable("tc0788_VerifyBrowseScreensSelectedScreenPopUpContent","Screener",BaseClass.runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0788_VerifyBrowseScreensSelectedScreenPopUpContent, verify BROWSE SCREEN selected screen has correct content and is loaded in LM------------");
		ChartObj.tc0788_VerifyBrowseScreensSelectedScreenPopUpContent();
	}*/
	
	@Test(groups={"Regression"})
	public void tc0791_VerifyUserScreenViewDetails()
	{
		if(!TestUtil.isExecutable("tc0791_VerifyUserScreenViewDetails","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0791_VerifyUserScreenViewDetails, verify user scren view details modal has correct content and behaves as expected------------");
		ChartObj.tc0791_VerifyUserScreenViewDetails();
	}
	
	@Test(groups={"Regression"})
	//@Test(groups={"Regression"},enabled=false)
	public void tc0800_VerifyUserScreenCopyOptionAndContent()
	{
		if(!TestUtil.isExecutable("tc0800_VerifyUserScreenCopyOptionAndContent","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0800_VerifyUserScreenCopyOptionAndContent, verify user scren copy option behaves as expected and copied correct Screen and content------------");
		ChartObj.tc0800_VerifyUserScreenCopyOptionAndContent();
	}
	
	@Test(groups={"Regression"})
	public void tc0801_VerifyScreenerCloseButton()
	{
		if(!TestUtil.isExecutable("tc0801_VerifyScreenerCloseButton","Screener",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------tc0801_VerifyScreenerCloseButton, verify close button closes teh left sidebar panel------------");
		ChartObj.tc0801_VerifyScreenerCloseButton();
	}
}