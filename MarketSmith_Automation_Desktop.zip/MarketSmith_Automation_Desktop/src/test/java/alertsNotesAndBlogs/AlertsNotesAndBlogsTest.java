package alertsNotesAndBlogs;


import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import excelReader.TestUtil;
import static genericLib.Utility.*;


public class AlertsNotesAndBlogsTest {
	AlertsNotesAndBlogs alertObj;
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		alertObj=new AlertsNotesAndBlogs();
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeErrorPopUp()
	{
		closeErrorMessage();
	}
	
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			takeScreenShot(imageName);
		} 
	}
	@Test(priority=1)
	public void TC0498_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("tc0498_VerifyAlertsTab","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC0498_AlertsNotesandBlogs();
	}
	
	@Test(priority=2)
	public void TC0499_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0499_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC0499_AlertsNotesandBlogs();
	}
	
	@Test(priority=3)
	public void TC0500_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0500_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC0500_AlertsNotesandBlogs();
	}
	
	@Test(priority=4)
	public void TC0501_AlertsNotesBlogs(){
		if(!TestUtil.isExecutable("tc0501_ValidateSetAlertLink","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click SET ALERT select PRICE, EMAIL NOTIFICATION,and type a NOTE.------------");
		Hashtable<String, String> data=TestUtil.getData("TC0501_AlertsNotesBlogs", "AlertsNotesandBlogs",dataXl);
		alertObj.TC0501_AlertsNotesBlogs(data.get("Price"));
	}
	
	@Test(priority=5)
	public void TC0503_AlertsNotesBlogs(){
		if(!TestUtil.isExecutable("TC0503_AlertsNotesBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		Hashtable<String, String> data=TestUtil.getData("TC0503_AlertsNotesBlogs", "AlertsNotesandBlogs",dataXl);
		alertObj.TC0503_AlertsNotesBlogs(data.get("InValidPrice"));
	}
	
	@Test(priority=6)
	public void TC0504_AlertsNotesBlogs(){
		if(!TestUtil.isExecutable("TC0504_AlertsNotesBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		Hashtable<String, String> data=TestUtil.getData("TC0504_AlertsNotesBlogs", "AlertsNotesandBlogs",dataXl);
		alertObj.TC0504_AlertsNotesBlogs(data.get("ValidPrice"));
	}
	
	@Test(priority=7)
	public void TC0505_AlertsNotesBlogs(){
		if(!TestUtil.isExecutable("tc0505_ValidateManageAlertLink","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click Manage Alerts. The MANAGE ALERTS WINDOW should open.------------");
		alertObj.TC0505_AlertsNotesBlogs();
	}
	
	@Test(priority=8)
	public void TC0506_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC506_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC0506_AlertsNotesandBlogs();
	}
	
	@Test(priority=9)
	public void TC0507_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0507_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC0507_AlertsNotesandBlogs();
	}
	
	@Test(priority=10)
	public void TC508_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("tc0508_VerifyManageAlertWindowTabs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Verify tabs-Active Alerts, Triggered Alerts and List Alert present------------");
		alertObj.TC508_AlertsNotesandBlogs();
	}
	
	@Test(priority=11)
	public void TC509_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC509_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC509_AlertsNotesandBlogs();
	}
	
	@Test(priority=12)
	public void TC510_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC510_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC510_AlertsNotesandBlogs();
	}
	
	@Test(priority=13)
	public void TC0511_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0511_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		Hashtable<String, String> data=TestUtil.getData("TC0504_AlertsNotesBlogs", "AlertsNotesandBlogs",dataXl);
		alertObj.TC0511_AlertsNotesandBlogs(data.get("ValidPrice"));
	}
	
	@Test(priority=14)
	public void TC0513_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0513_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC0513_AlertsNotesandBlogs();
	}
	
	@Test(priority=15)
	public void TC0514_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("tc0514_ValidateNotesTab","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Create a new note. Verify the note appears in a list with the most recent on top. ------------");
		alertObj.TC0514_AlertsNotesandBlogs();
	}
	
	@Test(priority=16)
	public void TC0512_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0512_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC0512_AlertsNotesandBlogs();
	}
	
	@Test(priority=17)
	public void TC0516_ALertNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0516_ALertNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC0516_ALertNotesandBlogs();
	}
	
	@Test(priority=18)
	public void TC0517_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0517_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		Hashtable<String, String> data=TestUtil.getData("TC0517_AlertsNotesandBlogs", "AlertsNotesandBlogs",dataXl);
		alertObj.TC0517_AlertsNotesandBlogs(data.get("SearchKey"));
	}
	
	@Test(priority=19)
	public void TC0518_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0518_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC0518_AlertsNotesandBlogs();
	}
	
	@Test(priority=20)
	public void TC0519_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0519_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC0519_AlertsNotesandBlogs();
	}
	
	@Test(priority=21)
	public void TC0520_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0520_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		Hashtable<String, String> data=TestUtil.getData("TC0520_AlertsNotesandBlogs", "AlertsNotesandBlogs",dataXl);
		alertObj.TC0520_AlertsNotesandBlogs(data.get("NewNote"));
	}
	
	@Test(priority=22)
	public void TC0521_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0521_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Alerts Tab. The dropdown list should default to All and display any alerts created by you for the current stock------------");
		alertObj.TC0521_AlertsNotesandBlogs();
	}
	
	@Test(priority=23)
	public void TC0522_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("tc0522_ValidateBlogsTab","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Blogs tab. Verify a list of blogs appear related to the current stock with the newest on top. ------------");
		alertObj.TC0522_AlertsNotesandBlogs();
	}
	
	@Test(priority=24)
	public void TC0523_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0523_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Blogs tab. Verify a list of blogs appear related to the current stock with the newest on top. ------------");
		alertObj.TC0523_AlertsNotesandBlogs();
	}
	
	@Test(priority=25)
	public void TC0524_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0524_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Blogs tab. Verify a list of blogs appear related to the current stock with the newest on top. ------------");
		alertObj.TC0524_AlertsNotesandBlogs();
	}
	
	@Test(priority=26)
	public void TC0525_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0525_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Blogs tab. Verify a list of blogs appear related to the current stock with the newest on top. ------------");
		alertObj.TC0525_AlertsNotesandBlogs();
	}
	
	@Test(priority=27)
	public void TC0526_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("TC0526_AlertsNotesandBlogs","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Click on the Blogs tab. Verify a list of blogs appear related to the current stock with the newest on top. ------------");
		alertObj.TC0526_AlertsNotesandBlogs();
	}
	
	@Test(priority=28)
	public void TC0527_AlertsNotesandBlogs(){
		if(!TestUtil.isExecutable("tc0527_ValidateCreatePostTab","AlertsNotesBlogs",runModeXl)){
			throw new SkipException("Runmode set to NO");
		} 
		logger.info("---------Executing Go to the Create Post tab. Verify the two check buttons work correctly and that you are able to click the Create Message button which opens up a new page in the web browser. ------------");
		alertObj.TC0527_AlertsNotesandBlogs();
	}
}
