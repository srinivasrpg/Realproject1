package charts;

import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import excelReader.TestUtil;
import static genericLib.Utility.*;


//import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
//import org.testng.annotations.Test;
import charts.ChartPage;
//import excelReader.TestUtil;
//import genericLib.BaseClass;
//import genericLib.Utility;

public class ChartPageTest {
	ChartPage ChartObj;
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		ChartObj=new ChartPage();
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeErrorPopUp()
	{
		closeErrorMessage();
	}
	
	/*@BeforeTest(alwaysRun=true)
		public void beforeMethodSetting(){
		Hashtable<String, String> data=TestUtil.getData("loginToMarketSmith", "Global",
				BaseClass.dataXl);	
        Utility.tc001_loginToMarketSmith(data.get("UserName"), data.get("Password"));	
	}*/
	
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			takeScreenShot(imageName);
		} 
	}
	
	@Test(groups={"Regression"})
	public void tc1010_VerifyFlag(){
		if(!TestUtil.isExecutable("tc1010_VerifyFlag","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify flag icon test------------");
		ChartObj.tc1010_VerifyFlag();
	}
	
	@Test(groups={"Regression"})
	public void tc1010_VerifyFlag_toggle(){
		if(!TestUtil.isExecutable("tc1010_VerifyFlag_toggle","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify flag icon TOGGLE test------------");
		ChartObj.tc1010_VerifyFlag_toggle();
	}
	
	@Test(groups={"Regression"})
	public void tc1011_VerifyAddToList_Content(){
		if(!TestUtil.isExecutable("tc1011_VerifyAddToList_Content","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify Add To List content------------");
		ChartObj.tc1011_VerifyAddToList_Content();
	}
	
	@Test(groups={"Regression"})
	public void tc1012_VerifyAddToList_NewList(){
		if(!TestUtil.isExecutable("tc1012_VerifyAddToList_NewList","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify Add To List New List feature------------");
		ChartObj.tc1012_VerifyAddToList_NewList();
	}
	
	@Test(groups={"Regression"})
	public void tc1013_VerifyNewChart(){
		if(!TestUtil.isExecutable("tc1013_VerifyNewChart","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify New Chart window feature------------");
		ChartObj.tc1013_VerifyNewChart();	
	}
	
	@Test(groups={"Regression"})
	public void tc1014_VerifyNewChart_headerButtons(){
		if(!TestUtil.isExecutable("tc1014_VerifyNewChart_headerButtons","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify New Chart window BUTTONS feature------------");
		ChartObj.tc1014_VerifyNewChart_headerButtons();	
	}
	
	@Test(groups={"Regression"})
	public void tc1015_VerifyNewChart_rightClick(){
		if(!TestUtil.isExecutable("tc1015_VerifyNewChart_rightClick","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify New Chart window RIGHT CLICK feature------------");
		ChartObj.tc1015_VerifyNewChart_rightClick();	
	}
	
	@Test(groups={"Regression"})
	public void tc1016_VerifyNewChart_DontReceiveFromMain(){
		if(!TestUtil.isExecutable("tc1016_VerifyNewChart_DontReceiveFromMain","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify New Chart DOES NOT receives symbol from Main window------------");
		ChartObj.tc1016_VerifyNewChart_DontReceiveFromMain();
	}
	
	@Test(groups={"Regression"})
	public void tc1017_VerifyNewChart_ReceiveFromMain(){
		if(!TestUtil.isExecutable("tc1017_VerifyNewChart_ReceiveFromMain","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify New Chart receives symbol from Main window------------");
		ChartObj.tc1017_VerifyNewChart_ReceiveFromMain();
	}
	
	@Test(groups={"Regression"})
	public void tc1018_VerifyComparisonChart(){
		if(!TestUtil.isExecutable("tc1018_VerifyComparisonChart","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify Comparison Chart------------");
		ChartObj.tc1018_VerifyComparisonChart();
	}
	
	@Test(groups={"Regression"})
	public void tc1019_VerifyComparisonChart_buttons(){
		if(!TestUtil.isExecutable("tc1019_VerifyComparisonChart_buttons","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify Comparison Chart Buttons------------");
		ChartObj.tc1019_VerifyComparisonChart_buttons();
	}
	
	@Test(groups={"Regression"})
	public void tc1020_ComparisonChart_initSymbolColor_Scale(){
		if(!TestUtil.isExecutable("tc1020_ComparisonChart_initSymbolColor_Scale","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify Comparison Chart Init Symbol color & scale------------");
		ChartObj.tc1020_ComparisonChart_initSymbolColor_Scale();
	}
	
	@Test(groups={"Regression"})
	public void tc1020_VerifyComparisonChart_addSymbol(){
		if(!TestUtil.isExecutable("tc1020_VerifyComparisonChart_addSymbol","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify Comparison Chart Add Symbol------------");
		ChartObj.tc1020_VerifyComparisonChart_addSymbol();
	}
	
	@Test(groups={"Regression"})
	public void tc1021_VerifyComparisonChart_addSymbol_dropDown(){
		if(!TestUtil.isExecutable("tc1021_VerifyComparisonChart_addSymbol_dropDown","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify Comparison Chart Add Symbol via Drop Down------------");
		ChartObj.tc1021_VerifyComparisonChart_addSymbol_dropDown();
	}
	
	@Test(groups={"Regression"})
	public void tc1022_VerifyComparisonChart_removeSymbolContent(){
		if(!TestUtil.isExecutable("tc1022_VerifyComparisonChart_removeSymbolContent","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify Comparison Chart Remove Symbols Content and Confirm removal------------");
		ChartObj.tc1022_VerifyComparisonChart_removeSymbolContent();
	}
	
	/*
	 * 
	 * CONTINUE FROM HERE
	 * 
	 * 
	 */
	
	@Test(groups={"Regression"})
	public void tc1023_VerifyComparisonChart_removeAllSymbols(){
		if(!TestUtil.isExecutable("tc1023_VerifyComparisonChart_removeAllSymbols","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify Comparison Chart Remove ALL symbols content and confirm removal------------");
		ChartObj.tc1023_VerifyComparisonChart_removeAllSymbols();
	}
	
	@Test(groups={"Regression"})
	public void tc1024_VerifyComparisonChart_addAListModalBox(){
		if(!TestUtil.isExecutable("tc1024_VerifyComparisonChart_addAListModalBox","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify Comparison Chart Add a List Content------------");
		ChartObj.tc1024_VerifyComparisonChart_addAListModalBox();
	}
	
	
	/*
	 * 
	 * END HERE
	 * 
	 * 
	 */
	
	@Test(groups={"Regression"})
	public void tc1000_VerifyChartedSymbol_priceData(){
		if(!TestUtil.isExecutable("tc1000_VerifyChartedSymbol_priceData","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing verify charted symbol data------------");
		ChartObj.tc1000_VerifyChartedSymbol_priceData();
	}
	
	/*@Test(groups={"Smoke","Regression"})
	public void tc003_launchMSTool() throws IOException {
		// check the run mode of test case
		if (!TestUtil.isExecutable("launchMSTool", "Charts",
				runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		ChartObj.tc003_launchMSTool();
	}*/
	@Test(groups={"Regression"},priority=1)
	public void tc0158_VerifyRecentBreakOutsCharts(){
		if(!TestUtil.isExecutable("tc0158_VerifyRecentBreakOutsCharts","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing REPORTS>MARKETSMITH GROWTH250>G250 - PATTERN RECOGNITION> RECENT BREAKOUTS. All of these charts should have patterns------------");
		ChartObj.tc0158_VerifyRecentBreakOutsCharts();
	}
	@Test(groups={"Regression"},priority=2)
	public void tc0176_VerifyBlackTriangularArrow(){
		if(!TestUtil.isExecutable("tc0176_VerifyBlackTriangularArrow","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing Go to a chart that has an ALERT configured for it.Click the CHART TOOLS button.Toggle the ALERTS checkbox.You should see a small black triangular arrow icon appear and disappear on the right side of the chart,pointing to the exact point where the alert is set to trigger.------------");
		Hashtable<String, String> data=TestUtil.getData("tc0176_VerifyBlackTriangularArrow", "Charts",dataXl);
		ChartObj.tc0176_VerifyBlackTriangularArrow(data.get("Symbol"));
	}
	@Test(groups={"Regression"},priority=3)
	public void tc0177_VerifyMarkupToolOption(){
		if(!TestUtil.isExecutable("tc0177_VerifyMarkupToolOption","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing MARKUP TOOL: Click CHART TOOLS > MARKUP TOOL. Verify that the markup toolbar appears on the chart.------------");
		ChartObj.tc0177_VerifyMarkupToolOption();
	}
	@Test(groups={"Regression"},priority=4)
	public void tc0211_VerifyChartAppearingTime(){
		if(!TestUtil.isExecutable("tc0211_VerifyChartAppearingTime","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing Type in ticker AAPL to bring up Apple Inc. Does the chart appear quickly? (within 1-2 seconds?).------------");
		Hashtable<String, String> data=TestUtil.getData("tc0211_VerifyChartAppearingTime", "Charts",dataXl);
		ChartObj.tc0211_VerifyChartAppearingTime(data.get("Symbol"));
	}
	
	@Test(groups={"Regression"},priority=5)
	public void tc0214_VerifyDataBoxesFOrEnteredTicker(){
		if(!TestUtil.isExecutable("tc0214_VerifyDataBoxesFOrEnteredTicker","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing Verify that databox displayed when user select option in setting.");
		ChartObj.tc0214_VerifyDataBoxesFOrEnteredTicker();
	}
	@Test(groups={"Regression"},priority=6)
	public void tc0235_VerifyWeeklyButton(){
		if(!TestUtil.isExecutable("tc0235_VerifyWeeklyButton","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing Click on the WEEKLY button to bring up a weekly chart. Does the chart appear?.");
		ChartObj.tc0235_VerifyWeeklyButton();
	}
	@Test(groups={"Regression"},priority=7)
	public void tc0240_VerifyLastTradingDate(){
		if(!TestUtil.isExecutable("tc0240_VerifyLastTradingDate","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing Is the last tick for the last valid trading date?");
		ChartObj.tc0240_VerifyLastTradingDate();
	}
	@Test(groups={"Regression"},priority=8)
	public void tc0259_VerifyMonthlyButton(){
		if(!TestUtil.isExecutable("tc0259_VerifyMonthlyButton","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing Click on the MONTHLY button to bring up a monthly chart. Does the chart appear?");
		ChartObj.tc0259_VerifyMonthlyButton();
	}
	@Test(groups={"Regression"},priority=9)
	public void tc0270_VerifyTopDataBoxInfo(){
		if(!TestUtil.isExecutable("tc0270_VerifyTopDataBoxInfo","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing Does the top Data Box contain information for the current Stock??");
		ChartObj.tc0270_VerifyTopDataBoxInfo();
	}
	@Test(groups={"Regression"},priority=10)
	public void tc0277_VerifyIntraDayOptions(){
		if(!TestUtil.isExecutable("tc0277_VerifyIntraDayOptions","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing Click on the INTRADAY button to bring up an intraday chart. Does the chart appear for 1, 5, 10, 15, 30 and 60 Min?");
		ChartObj.tc0277_VerifyIntraDayOptions();
	}
	/*@AfterTest(alwaysRun=true)
	public void logOut() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("logoutFromMarketSmith", "Global", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		Utility.tc002_logoutFromMarketSmith();
	}*/
}