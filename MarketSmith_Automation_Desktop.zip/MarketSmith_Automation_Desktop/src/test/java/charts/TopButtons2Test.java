package charts;

import static genericLib.Utility.*;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import excelReader.TestUtil;

public class TopButtons2Test {
	TopButtons2 oTopButtons2;

	@BeforeClass(alwaysRun=true)
	public void initialization() {
		oTopButtons2=new TopButtons2();
	}

	@AfterMethod(alwaysRun=true)
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "_" + testResult.getName();
			takeScreenShot(imageName);
		}
	}

	@Test
	public void TC002_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC002_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-002 of TopButtons2------------");
		oTopButtons2.TC002_TopButtons2();
	}

	@Test
	public void TC004_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC004_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-004 of TopButtons2------------");
		oTopButtons2.TC004_TopButtons2();
	}

	@Test
	public void TC007_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC007_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-007 of TopButtons2------------");
		oTopButtons2.TC007_TopButtons2();
	}

	@Test
	public void TC008_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC008_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-008 of TopButtons2------------");
		oTopButtons2.TC008_TopButtons2();
	}

	@Test
	public void TC013_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC013_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-013 of TopButtons2------------");
		oTopButtons2.TC013_TopButtons2();
	}

	@Test
	public void TC014_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC014_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-014 of TopButtons2------------");
		oTopButtons2.TC014_TopButtons2();
	}

	@Test
	public void TC019_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC019_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-019 of TopButtons2------------");
		oTopButtons2.TC019_TopButtons2();
	}

	@Test
	public void TC020_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC020_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-020 of TopButtons2------------");
		oTopButtons2.TC020_TopButtons2();
	}

	@Test
	public void TC021_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC021_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-021 of TopButtons2------------");
		oTopButtons2.TC021_TopButtons2();
	}

	@Test
	public void TC026_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC026_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-026 of TopButtons2------------");
		oTopButtons2.TC026_TopButtons2();
	}

	@Test
	public void TC027_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC027_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-027 of TopButtons2------------");
		Hashtable<String, String> data=TestUtil.getData("TC027_TopButtons2", "charts", dataXl);
		oTopButtons2.TC027_TopButtons2(data.get("Time"));
	}

	@Test
	public void TC028_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC028_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-028 of TopButtons2------------");
		Hashtable<String, String> data=TestUtil.getData("TC028_TopButtons2", "charts", dataXl);
		oTopButtons2.TC028_TopButtons2(data.get("ExpectedTime"));
	}
	
	@Test
	public void TC032_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC032_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-032 of TopButtons2------------");
		oTopButtons2.TC032_TopButtons2();
	}
	
	@Test
	public void TC033_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC033_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-033 of TopButtons2------------");
		oTopButtons2.TC033_TopButtons2();
	}
	
	@Test
	public void TC039_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC039_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-039 of TopButtons2------------");
		oTopButtons2.TC039_TopButtons2();
	}
	
	@Test
	public void TC040_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC040_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-040 of TopButtons2------------");
		oTopButtons2.TC040_TopButtons2();
	}
	
	@Test
	public void TC046_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC046_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-046 of TopButtons2------------");
		oTopButtons2.TC046_TopButtons2();
	}
	
	@Test
	public void TC052_TopButtons2() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC052_TopButtons2", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-052 of TopButtons2------------");
		oTopButtons2.TC052_TopButtons2();
	}
}
