package charts;

import java.io.IOException;
import java.text.ParseException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import excelReader.TestUtil;
import static genericLib.Utility.*;

public class TopButtons1Test {
	TopButtons1 oTopButtons1;

	@BeforeClass(alwaysRun=true)
	public void initialization() {
		oTopButtons1=new TopButtons1();
	}

	@AfterMethod(alwaysRun=true)
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "_" + testResult.getName();
			takeScreenShot(imageName);
		}
	}

	@Test
	public void TC003_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC003_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-003 of TopButtons1------------");
		Hashtable<String, String> data=TestUtil.getData("TC058_TopButtons1", "charts",
				dataXl);
		oTopButtons1.TC003_TopButtons1(data.get("Symbol"));
	}

	@Test
	public void TC004_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC004_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-004 of TopButtons1------------");
		Hashtable<String, String> data=TestUtil.getData("TC058_TopButtons1", "charts",
				dataXl);
		oTopButtons1.TC004_TopButtons1(data.get("Symbol"));
	}
	
	@Test
	public void TC009_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC009_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-009 of TopButtons1------------");
		oTopButtons1.TC009_TopButtons1();
	}
	
	@Test
	public void TC010_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC010_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-010 of TopButtons1------------");
		oTopButtons1.TC010_TopButtons1();
	}
	
	@Test
	public void TC012_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC012_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-012 of TopButtons1------------");
		oTopButtons1.TC012_TopButtons1();
	}
	
	@Test
	public void TC014_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC014_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-014 of TopButtons1------------");
		oTopButtons1.TC014_TopButtons1();
	}
	
	@Test
	public void TC015_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC015_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-015 of TopButtons1------------");
		oTopButtons1.TC015_TopButtons1();
	}
	
	@Test
	public void TC016_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC016_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-016 of TopButtons1------------");
		oTopButtons1.TC016_TopButtons1();
	}
	
	@Test
	public void TC017_TopButtons1() throws ParseException {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC017_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-017 of TopButtons1------------");
		oTopButtons1.TC017_TopButtons1();
	}
	
	@Test
	public void TC018_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC018_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-018 of TopButtons1------------");
		Hashtable<String, String> data=TestUtil.getData("TC058_TopButtons1", "charts",
				dataXl);
		oTopButtons1.TC018_TopButtons1(data.get("Date"));
	}
	
	@Test
	public void TC023_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC023_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-023 of TopButtons1------------");
		oTopButtons1.TC023_TopButtons1();
	}
	
	@Test
	public void TC027_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC027_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-027 of TopButtons1------------");
		oTopButtons1.TC027_TopButtons1();
	}
	
	@Test
	public void TC028_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC028_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-028 of TopButtons1------------");
		Hashtable<String, String> data=TestUtil.getData("TC058_TopButtons1", "charts",
				dataXl);
		oTopButtons1.TC028_TopButtons1(data.get("Symbol"));
	}
	
	@Test
	public void TC039_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC039_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-039 of TopButtons1------------");
		oTopButtons1.TC039_TopButtons1();
	}
	
	@Test
	public void TC041_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC041_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-041 of TopButtons1------------");
		oTopButtons1.TC041_TopButtons1();
	}
	
	@Test
	public void TC042_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC042_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-042 of TopButtons1------------");
		oTopButtons1.TC042_TopButtons1();
	}
	
	@Test
	public void TC043_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC043_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-043 of TopButtons1------------");
		oTopButtons1.TC043_TopButtons1();
	}
	
	@Test
	public void TC044_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC044_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-044 of TopButtons1------------");
		oTopButtons1.TC044_TopButtons1();
	}
	
	@Test
	public void TC045_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC045_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-045 of TopButtons1------------");
		oTopButtons1.TC045_TopButtons1();
	}
	
	@Test
	public void TC046_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC046_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-046 of TopButtons1------------");
		oTopButtons1.TC046_TopButtons1();
	}
	
	@Test
	public void TC047_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC047_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-047 of TopButtons1------------");
		oTopButtons1.TC047_TopButtons1();
	}
	
	@Test
	public void TC049_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC049_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-049 of TopButtons1------------");
		oTopButtons1.TC049_TopButtons1();
	}
	
	@Test
	public void TC050_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC050_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-050 of TopButtons1------------");
		oTopButtons1.TC050_TopButtons1();
	}
	
	@Test
	public void TC057_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC057_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-057 of TopButtons1------------");
		oTopButtons1.TC057_TopButtons1();
	}
	
	@Test
	public void TC058_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC058_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		Hashtable<String, String> data=TestUtil.getData("TC058_TopButtons1", "charts",
				dataXl);
		logger.info("------------Executing TC-058 of TopButtons1------------");
		oTopButtons1.TC058_TopButtons1(data.get("SymbolName"), data.get("Price"));
	}
	
	@Test
	public void TC059_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC059_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-059 of TopButtons1------------");
		oTopButtons1.TC059_TopButtons1();
	}

	@Test
	public void TC061_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC061_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		Hashtable<String, String> data=TestUtil.getData("TC061_TopButtons1", "charts",
				dataXl);
		logger.info("------------Executing TC-061 of TopButtons1------------");
		oTopButtons1.TC061_TopButtons1(data.get("SymbolName"), data.get("Price"));
	}
	
	@Test
	public void TC063_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC063_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-063 of TopButtons1------------");
		oTopButtons1.TC063_TopButtons1();
	}
	
	@Test
	public void TC064_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC064_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-064 of TopButtons1------------");
		oTopButtons1.TC064_TopButtons1();
	}
	
	@Test
	public void TC066_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC066_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-066 of TopButtons1------------");
		oTopButtons1.TC066_TopButtons1();
	}
	
	@Test
	public void TC067_TopButtons1() {
		// check the run mode of test case
		if (!TestUtil.isExecutable("TC067_TopButtons1", "charts", runModeXl)) {
			throw new SkipException("Runmode set to NO");
		}
		logger.info("------------Executing TC-067 of TopButtons1------------");
		oTopButtons1.TC067_TopButtons1();
	}
}
