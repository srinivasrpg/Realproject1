package charts;

import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import excelReader.TestUtil;
import static genericLib.Utility.*;


//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.BeforeTest;
import charts.ChartButtons2;
//import excelReader.TestUtil;
//import genericLib.BaseClass;
//import genericLib.Utility;

public class ChartButtons2Test {
	ChartButtons2 ChartObj;
	@BeforeClass(alwaysRun = true)
	public void initialization() {
		ChartObj=new ChartButtons2();
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeErrorPopUp()
	{
		closeErrorMessage();
	}
	
/*	@BeforeTest(alwaysRun=true)
		public void beforeMethodSetting(){
		Hashtable<String, String> data=TestUtil.getData("loginToMarketSmith", "Global",
				BaseClass.dataXl);	
        Utility.tc001_loginToMarketSmith(data.get("UserName"), data.get("Password"));
        Utility.launchMSTool();
	}*/
	
	@AfterMethod(alwaysRun=true) 
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) { 
			String imageName=testResult.getTestClass().getName().replaceAll("\\.", "_") + "-" + testResult.getName();
			takeScreenShot(imageName);
		} 
	}
	
	/*@Test(groups={"Regression"})
	public void analyzeLogs(){
		ChartObj.analyzeLogs();
	}*/
	
	/*@Test(groups={"Regression"})
	public void tc0300_blankChartTest(){
		ChartObj.tc0300_blankChartTest();
	}*/

	
	//*****************************************************************************************************************
	//***************************************** PATTERN RECOGNITION TC ************************************************
	//*****************************************************************************************************************
	@Test(groups={"Regression"})
	public void tc0160_verifyPercentFromPivot(){
		if(!TestUtil.isExecutable("tc0160_verifyPercentFromPivot","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0160_verifyPercentFromPivot: verify % from Pivot on Recent Break Out chart ------------");
		ChartObj.tc0160_verifyPercentFromPivot();
	}
	
	@Test(groups={"Regression"})
	public void tc0162_verifyPRToolTips(){
		if(!TestUtil.isExecutable("tc0162_verifyPRToolTips","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0162_verifyPRToolTips: verify PR tool tips for PR and BreakOut ------------");
		ChartObj.tc0162_verifyPRToolTips();
	}
	
	@Test(groups={"Regression"})
	public void tc0166_verifyLargeVolume(){
		if(!TestUtil.isExecutable("tc0166_verifyLargeVolume","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0166_verifyLargeVolume: verify Large Vol icon on days w/large volume ------------");
		ChartObj.tc0166_verifyLargeVolume();
	}
	

	@Test(groups={"Regression"})
	public void tc0167_verifyPostBreakOut_KeyPriceRanges(){
		if(!TestUtil.isExecutable("tc0167_verifyPostBreakOut_KeyPriceRanges","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0167_verifyPostBreakOut_KeyPriceRanges: verify post break out key price ranges ------------");
		ChartObj.tc0167_verifyPostBreakOut_KeyPriceRanges();
	}
	
	//*****************************************************************************************************************
	//***************************************** PRINT TC **************************************************************
	//*****************************************************************************************************************
	
	
	
	//*****************************************************************************************************************
	//***************************************** CHART TOOLS ***********************************************************
	//*****************************************************************************************************************
	@Test(groups={"Regression"})
	public void tc0193_verifyToggleOfStochastics(){
		if(!TestUtil.isExecutable("tc0193_verifyToggleOfStochastics","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0193_verifyToggleOfStochastics: verify stochastics toggle------------");
		ChartObj.tc0193_verifyToggleOfStochastics();
	}
	
	@Test(groups={"Regression"})
	public void tc0194_verifyToggleOfDataBoxes(){
		if(!TestUtil.isExecutable("tc0194_verifyToggleOfDataBoxes","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0194_verifyToggleOfDataBoxes: verify data boxes toggle------------");
		ChartObj.tc0194_verifyToggleOfDataBoxes();
	}
	
	@Test(groups={"Regression"})
	public void tc0195_verifyToggleOfCorporateEvents(){
		if(!TestUtil.isExecutable("tc0195_verifyToggleOfCorporateEvents","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0195_verifyToggleOfCorporateEvents: verify corporate events toggle------------");
		ChartObj.tc0195_verifyToggleOfCorporateEvents();
	}
	
	@Test(groups={"Regression"})
	public void tc0197_verifyToggleOfIndexLine(){
		if(!TestUtil.isExecutable("tc0197_verifyToggleOfIndexLine","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0197_verifyToggleOfIndexLine: verify index line toggle------------");
		ChartObj.tc0197_verifyToggleOfIndexLine();
	}
	
	@Test(groups={"Regression"})
	public void tc0198_verifyChartLegend(){
		if(!TestUtil.isExecutable("tc0198_verifyChartLegend","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0198_verifyChartLegend: verify New window opens, chart legend------------");
		ChartObj.tc0198_verifyChartLegend();
	}
	
	@Test(groups={"Regression"})
	public void tc0199_verifyMovingAvgsWindow(){
		if(!TestUtil.isExecutable("tc0199_verifyMovingAvgsWindow","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0198_verifyMovingAvgsWindow: verify Moving avgs modal window------------");
		ChartObj.tc0199_verifyMovingAvgsWindow();
	}
	
	//tc0205_verifyLinePenWindow
	@Test(groups={"Regression"})
	public void tc0205_verifyLinePenWindow(){
		if(!TestUtil.isExecutable("tc0205_verifyLinePenWindow","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0205_verifyLinePenWindow: verify Line Pen new window------------");
		ChartObj.tc0205_verifyLinePenWindow();
	}
	
	//tc0206_verifyTightAreas toggle
	@Test(groups={"Regression"})
	public void tc0206_verifyTightAreas(){
		if(!TestUtil.isExecutable("tc0206_verifyTightAreas","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0206_verifyTightAreas: verify tight areas toggle------------");
		ChartObj.tc0206_verifyTightAreas();
	}
	
	//tc0207_verifyKeyPriceRanges toggle
	@Test(groups={"Regression"})
	public void tc0207_verifyKeyPriceRanges(){
		if(!TestUtil.isExecutable("tc0207_verifyKeyPriceRanges","Charts",runModeXl)){
			throw new SkipException("Runmode set to NO");
		}
		logger.info("---------Executing tc0207_verifyKeyPriceRanges: verify key price ranges toggle------------");
		ChartObj.tc0207_verifyKeyPriceRanges();
	}
	
}