package genericLib;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.apache.commons.logging.impl.Log4JLogger;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebDriver;

import org.testng.annotations.*;

import com.browserstack.local.Local;

import charts.ChartPageLib;
import global.MarketsmithHomePageLib;
import listManager.ListManager1Lib;
import listManager.ListManager2Lib;
import relatedInformation.RelatedInformation1Lib;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import static genericLib.Utility.*;

public class BaseClassBrowserStack {
	public WebDriver bsDriver = null;
	public static Local LocalConnection;
	
	@BeforeSuite(alwaysRun=true)
	public void init(){
		if(bsDriver==null){
			// initialize the properties file
			CONFIG= new Properties();
			CONSTANTS = new Properties();
			try{
				// config C:\gitAutomation\MarketSmith_Automation_Desktop\MarketSmith_Automation_Desktop\src\main\resources\ExcelSheets
				FileInputStream fs = new FileInputStream("./src/test/resources/Config/config.properties");
				CONFIG.load(fs);
				/*	//Replacing environment variable to baseUrl in properties files
				if(CONFIG.getProperty("ENVIRONMENT").equalsIgnoreCase("qa")) {
					environment="qainvestors";
				}
				else if(CONFIG.getProperty("ENVIRONMENT").equalsIgnoreCase("production")) {
					environment="investors";
				}
				else if(CONFIG.getProperty("ENVIRONMENT").equalsIgnoreCase("stage")) {
					environment="stageinvestors";
				}

				if(environment!=null) {
					changeEnvVariable(environment, "C:/Automation/MarketSmith_Desktop_Automation/Resources/Config/costants.properties");
					changeEnvVariable(environment, "C:/Automation/MarketSmith_Desktop_Automation/Resources/Config/shoppingProcess.properties");
				}
				else {
					Assert.fail("Environment is not set in config file");
				}*/


				//constants
				fs = new FileInputStream("./src/main/resources/Constants/costants.properties");
				CONSTANTS.load(fs);
				
				//logger
				logger = Logger.getLogger(Log4JLogger.class.getName());
				DOMConfigurator.configure("./log4j.xml");

			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
	}
		
	@Parameters(value={"config", "environment"})
	@BeforeTest
	public void browserstackSetup(String config_file, String environment) throws Exception {
        JSONParser parser = new JSONParser();
        JSONObject config = (JSONObject) parser.parse(new FileReader("./src/main/resources/JSON/" + config_file));
        JSONObject envs = (JSONObject) config.get("environments");

        DesiredCapabilities capabilities = new DesiredCapabilities();
        LocalConnection = new Local();
        @SuppressWarnings (value="unchecked")
        Map<String, String> envCapabilities = (Map<String, String>) envs.get(environment);
		Iterator<Entry<String, String>> it = envCapabilities.entrySet().iterator();
        while (it.hasNext()) {
            @SuppressWarnings("rawtypes")
			Map.Entry pair = (Map.Entry)it.next();
            capabilities.setCapability(pair.getKey().toString(), pair.getValue().toString());
        }
        
        Map<String, String> commonCapabilities = (Map<String, String>) config.get("capabilities");
        it = commonCapabilities.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            if(capabilities.getCapability(pair.getKey().toString()) == null){
                capabilities.setCapability(pair.getKey().toString(), pair.getValue().toString());
            }
        }

        String username = System.getenv("BROWSERSTACK_USERNAME");
        /*if(username == null) {
            username = (String) config.get("user");
        }*/

        String accessKey = System.getenv("BROWSERSTACK_ACCESS_KEY");
        if(accessKey == null) {
            accessKey = (String) config.get("key");
        }
/*        if(!LocalConnection.isRunning()){
        	logger.info("Local connection is active");
        }else */
		if(capabilities.getCapability("browserstack.local") != null && capabilities.getCapability("browserstack.local") == "true"){
        	Map<String, String> options = new HashMap<String, String>();
            options.put("key", accessKey);
            LocalConnection.start(options);
        }
        	bsDriver = new RemoteWebDriver(new URL("http://"+username+":"+accessKey+"@"+config.get("server")+"/wd/hub"), capabilities);
			bsDriver.manage().window().maximize();
			bsDriver.get(CONFIG.getProperty("testSiteURL"));
			waitUntilVisibilityOfElement();
			driver = bsDriver;
			
			pageLib=PageFactory.initElements(driver, MarketsmithHomePageLib.class);
			lMpageLib=PageFactory.initElements(driver, ListManager1Lib.class);
			chartLib=PageFactory.initElements(driver, ChartPageLib.class);
			lipanelLib=PageFactory.initElements(driver, ListManager2Lib.class);
			ripanelLib=PageFactory.initElements(driver, RelatedInformation1Lib.class);
			wait = new WebDriverWait(driver, seconds);
			
			verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
			
			logger.info("===================================================================================================");
			logger.info("===================================================================================================");
	}
	
	
	@AfterSuite(alwaysRun=true)
	public void afterSuite() throws EncryptedDocumentException, InvalidFormatException, IOException, InterruptedException {
		driver.quit();
		driver = null;
		if(LocalConnection != null){
			LocalConnection.stop();
		}
	}
	
}