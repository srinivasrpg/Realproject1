package genericLib;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.logging.impl.Log4JLogger;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import charts.ChartPageLib;
import global.MarketsmithHomePageLib;
import listManager.ListManager1Lib;
import listManager.ListManager2Lib;
import relatedInformation.RelatedInformation1Lib;

import static genericLib.Utility.*;

public class BaseClassServer {
	public WebDriver sDriver = null;
	
	@BeforeSuite(alwaysRun=true)
	public void init(){
		if(sDriver==null){
			// initialize the properties file
			CONFIG= new Properties();
			CONSTANTS = new Properties();
			try{
				// config C:\gitAutomation\MarketSmith_Automation_Desktop\MarketSmith_Automation_Desktop\src\main\resources\ExcelSheets
				FileInputStream fs = new FileInputStream("./src/test/resources/Config/config.properties");
				CONFIG.load(fs);
				/*	//Replacing environment variable to baseUrl in properties files
				if(CONFIG.getProperty("ENVIRONMENT").equalsIgnoreCase("qa")) {
					environment="qainvestors";
				}
				else if(CONFIG.getProperty("ENVIRONMENT").equalsIgnoreCase("production")) {
					environment="investors";
				}
				else if(CONFIG.getProperty("ENVIRONMENT").equalsIgnoreCase("stage")) {
					environment="stageinvestors";
				}

				if(environment!=null) {
					changeEnvVariable(environment, "C:/Automation/MarketSmith_Desktop_Automation/Resources/Config/costants.properties");
					changeEnvVariable(environment, "C:/Automation/MarketSmith_Desktop_Automation/Resources/Config/shoppingProcess.properties");
				}
				else {
					Assert.fail("Environment is not set in config file");
				}*/


				//constants
				fs = new FileInputStream("./src/main/resources/Constants/costants.properties");
				CONSTANTS.load(fs);
				
				//logger
				logger = Logger.getLogger(Log4JLogger.class.getName());
				DOMConfigurator.configure("./log4j.xml");

			}
			catch(Exception e){
				e.printStackTrace();
			}
			
			//UNCOMMENT FOR LOCAL DEV PURPOSES ********* START
			logger.info("===================================================================================================");
			logger.info("===================================================================================================");
			if(CONFIG.getProperty("browser").equalsIgnoreCase("firefox")){
				//FirefoxProfile profile = new FirefoxProfile();
		    	//profile.setPreference("browser. download. manager. closeWhenDone", true);
				sDriver=new FirefoxDriver();
				logger.info("Mozilla Firefox Browser is Launching");
			}else if(CONFIG.getProperty("browser").equalsIgnoreCase("ie")){
				System.setProperty("webdriver.ie.driver", "./src/test/resources/Drivers/IEDriverServer.exe");
				sDriver=new InternetExplorerDriver();
				logger.info("Microsoft Internet Explorer Browser is Launching");
			}else if(CONFIG.getProperty("browser").equalsIgnoreCase("Chrome")){
				System.setProperty("webdriver.chrome.driver", "./src/test/resources/Drivers/chromedriver.exe");
				sDriver=new ChromeDriver();
				logger.info("Google Chrome Browser is Launching");
			}else if(CONFIG.getProperty("browser").equalsIgnoreCase("htmlunit")){
				sDriver = new HtmlUnitDriver();
			}
			
			//broswerDetails();
			sDriver.manage().window().maximize();
			sDriver.get(CONFIG.getProperty("testSiteURL"));
			driver=sDriver;
			
			pageLib=PageFactory.initElements(driver, MarketsmithHomePageLib.class);
			lMpageLib=PageFactory.initElements(driver, ListManager1Lib.class);
			chartLib=PageFactory.initElements(driver, ChartPageLib.class);
			lipanelLib=PageFactory.initElements(driver, ListManager2Lib.class);
			ripanelLib=PageFactory.initElements(driver, RelatedInformation1Lib.class);
			wait = new WebDriverWait(driver, seconds);
			
			Utility.waitUntilVisibilityOfElement();
			Utility.verifyPageTitle(CONSTANTS.getProperty("HOME_PAGE_TITLE"));
			
			logger.info("===================================================================================================");
			logger.info("===================================================================================================");
			 
		}
	}
	
	@AfterSuite(alwaysRun=true)
	public void afterSuite() throws EncryptedDocumentException, InvalidFormatException, IOException, InterruptedException {
		driver.quit();
		driver = null;
	}
	
}