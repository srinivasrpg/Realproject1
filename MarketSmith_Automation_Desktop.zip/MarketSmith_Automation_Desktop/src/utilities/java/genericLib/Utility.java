package genericLib;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import charts.ChartPageLib;
import excelReader.Xls_Reader;
import global.MarketsmithHomePageLib;
import listManager.ListManager1Lib;
import listManager.ListManager2Lib;
import relatedInformation.RelatedInformation1Lib;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utility {
	public static WebDriver driver = null;
	public static Properties CONFIG = null;
	public static Properties CONSTANTS = null;
	public static Xls_Reader dataXl= new Xls_Reader("./src/main/resources/ExcelSheets/TestCases.xlsx");
	public static Xls_Reader runModeXl= new Xls_Reader("./src/main/resources/ExcelSheets/TC_RunMode.xlsx");
	public static Logger logger;
	public static List<String> failedTCId=new ArrayList<String>();
	public static List<String> failedTCDesc=new ArrayList<String>();
	public static String sheetName=null;
	static MarketsmithHomePageLib pageLib=null;
	static ListManager1Lib lMpageLib=null;
	static ChartPageLib chartLib=null;
	static ListManager2Lib lipanelLib=null;
	static RelatedInformation1Lib ripanelLib=null;
	static int seconds = 60;
	static WebDriverWait wait = null;
	
	public static void closeErrorMessage()
	{
		try{
			if(pageLib.getErrorPopUp().getCssValue("display").contains("block"))
			{
				logger.info("Closing Pop Up ERROR message. See TCs causing this ERROR!!!!!");
				pageLib.getErrorCloseButton().click();
			}
			/*else
			{
				System.out.println("NO ERROR");
			}*/
		}
		catch(Exception e){
			
		}
	}
	
	// Implemented to select option in drop down by visible text
	public static void selectOptionInDropDownByVisibleText(WebElement element, String visibleTextOptionToSelect) {
		try {
			Select select = new Select(element);
			select.selectByVisibleText(visibleTextOptionToSelect);
		} catch (NoSuchElementException e) {
			logger.error(visibleTextOptionToSelect + " text not Found in drop down.");
			Assert.fail(visibleTextOptionToSelect + " text not Found in drop down.");
		}
	}

	// Implemented to select option in drop down by value
	public static void selectOptionInDropDownByValue(WebElement element, String valueOfOptionToSelect) {
		try {
			Select select = new Select(element);
			select.selectByValue(valueOfOptionToSelect);
		} catch (NoSuchElementException e) {
			logger.error(valueOfOptionToSelect + " value not Found in drop down.");
			Assert.fail(valueOfOptionToSelect + " value not Found in drop down.");
		}
	}

	// Implemented to select option in drop down by index
	public static void selectOptionInDropDownByIndex(WebElement element, int indexOfOptionToSelect) {
		try {
			Select select = new Select(element);
			select.selectByIndex(indexOfOptionToSelect);
		} catch (NoSuchElementException e) {
			logger.error(indexOfOptionToSelect + " index not Found in drop down.");
			Assert.fail(indexOfOptionToSelect + " index not Found in drop down.");
		}
	}

	// Implemented to get selected option from drop down
	public static String getSelectedOptionFromDropDown(WebElement element) {
		Select select = new Select(element);
		WebElement selectedElement = select.getFirstSelectedOption();
		String selectedOption = selectedElement.getText();
		return selectedOption;
	}

	// Implemented to get all selected option from multi-select drop down
	public static List<String> getAllSelectedOptionFromDropDown(WebElement element) {
		Select select = new Select(element);
		List<WebElement> selectedElements = select.getAllSelectedOptions();
		List<String> selectedOptions = new ArrayList<String>();
		for (WebElement selectedOption : selectedElements) {
			selectedOptions.add(selectedOption.getText());
		}
		return selectedOptions;
	}

	// Implemented to handle multiple windows
	public static void windowHandles() {
		try{
			Thread.sleep(2000);
			for (String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
			}
		}
		catch(Exception e)
		{
			logger.info(e);
		}
	}

	// Implemented to verify page URL
	public static void verifyPageUrl(String expectedUrl) {
		String actualUrl = driver.getCurrentUrl();
		Assert.assertEquals(actualUrl, expectedUrl, "Page URL is not matched");
		logger.info("Page URL is matched. Page URL : " + actualUrl);
	}

	// Implemented to compare text of WebElement with some expected text
	public static void compareWebElementText(WebElement element, String expectedText) {
		String actualText = element.getText();
		Assert.assertEquals(actualText, expectedText, "Text is not matched");
		logger.info("Expected text is matched. Actual text : " + actualText);
	}

	// Implemented to perform mouse hover on a WebElement
	public static void performMouseHover(WebElement element)
	{
		//adding try catch to include wait time after performing hover over action to allow
		//event to complete and DOM to update
		try{
			Actions actions = new Actions(driver);
			actions.moveToElement(element).perform();
			Thread.sleep(1500);
		}catch(Exception e)
		{
			logger.info(e);
		}

		
	}

	// Implemented to wait until element is clickable
	public static boolean waitUntilElementIsClickable(WebElement locator) {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			return true;
		} catch (NoSuchElementException e) {
			Assert.fail("Element state is not clickable after waiting " + seconds + " seconds");
			return false;
		}
	}

	// Implemented to wait until presence of an element
	public static WebElement waitUntilPresenceOfAnElement(String locator) {
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(locator)));
			return driver.findElement(By.cssSelector(locator));
		} catch (NoSuchElementException e) {
			Assert.fail("Element is not present after waiting " + seconds + " seconds");
			return null;
		}
	}

	// Implemented to wait until presence of all elements
	public static List<WebElement> waitUntilPresenceOfAllElements(String locator) {
		try {
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector(locator)));
			return driver.findElements(By.cssSelector(locator));
		} catch (NoSuchElementException e) {
			Assert.fail("Elements are not present after waiting " + seconds + " seconds");
			return null;
		}
	}

	// Implemented to wait until invisibility of an element
	public static boolean waitUntilInvisibilityOfAnElement(String locator) {
		try {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(locator)));
			return true;
		} catch (NoSuchElementException e) {
			Assert.fail("Element is not invisible after waiting " + seconds + " seconds");
			return false;
		}
	}

	/* Implemented to close Welcome to the new Investors.com pop up
	public static void closeWelcomePopup() {
		HomePageLib pageLib = PageFactory.initElements(driver, HomePageLib.class);
		pageLib.getWelcomPopupClose().click();
	}*/

	// Implemented to verify page title
	public static void verifyPageTitle(String expectedTitle) {
		String actualTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, expectedTitle, "Page title is not matched");
		logger.info("Page title is matched. Page title : " + actualTitle);
	}

	// Implemented to take screenshot
	public static void takeScreenShot(String imageName) throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String datePattern = "dd_MMM_yyyy";
		SimpleDateFormat sdf = new SimpleDateFormat(datePattern);
		String filePath = "Screenshots\\Screenshot_" + sdf.format(new Date()) + "\\" + imageName + ".jpg";
		FileUtils.copyFile(scrFile, new File(filePath));
	}

	// Implemented to verify text color
	public static void verifyTextColor(WebElement webElement, String expectedColor) {
		String color = webElement.getCssValue("color");
		String[] hexValue = color.replace("rgba(", "").replace(")", "").split(",");
		int hexValue1 = Integer.parseInt(hexValue[0]);
		hexValue[1] = hexValue[1].trim();
		int hexValue2 = Integer.parseInt(hexValue[1]);
		hexValue[2] = hexValue[2].trim();
		int hexValue3 = Integer.parseInt(hexValue[2]);
		String actualHexColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);
		Hashtable<String, String> colorMap = new Hashtable<String, String>();
		colorMap.put("Black", "#000000");
		colorMap.put("Red", "#c80019");
		colorMap.put("DarkRed", "#ff0000");
		colorMap.put("Green", "#008000");
		colorMap.put("Blue", "#0032aa");
		colorMap.put("Gray", "#666666");
		colorMap.put("TrolleyGray", "#808080");
		colorMap.put("Orange", "#feefd9");
		//Refer : Trolley Grey- #808080 ,http://www.colorhexa.com/808080
		int index = 0;

		Enumeration<String> e = colorMap.keys();
		while (e.hasMoreElements()) {
			String key = e.nextElement();
			if (key.equals(expectedColor)) {
				String expectedHexColor = colorMap.get(key);
				if (actualHexColor.equals(expectedHexColor)) {
					logger.info("Text color is matched. Text : " + webElement.getText() + ". Text color : " + key);
				} else {
					Assert.fail("Text color is not matched. Text : " + webElement.getText() + ". Expected : "
							+ expectedColor + ". Actual : " + actualHexColor);
				}
				break;
			}
			index++;
		}
		if (index == colorMap.size()) {
			Assert.fail(expectedColor + " is not a valid color");
		}
	}
	// Implemented to verify background color
		public static void verifyBackgroundColor(WebElement webElement, String expectedColor) {
			String color = webElement.getCssValue("background-color");
			String[] hexValue = color.replace("rgba(", "").replace(")", "").split(",");
			int hexValue1 = Integer.parseInt(hexValue[0]);
			hexValue[1] = hexValue[1].trim();
			int hexValue2 = Integer.parseInt(hexValue[1]);
			hexValue[2] = hexValue[2].trim();
			int hexValue3 = Integer.parseInt(hexValue[2]);
			String actualHexColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);
			Hashtable<String, String> colorMap = new Hashtable<String, String>();
			colorMap.put("Black", "#000000");
			colorMap.put("Red", "#ff0000");
			colorMap.put("Green", "#008000");
			colorMap.put("Blue", "#0000FF");
			colorMap.put("Gray", "#d3d3d3");
			colorMap.put("White Smoke", "#f5f5f5");
			colorMap.put("Pigment Green", "#04993c");
			colorMap.put("Dark Spring Green", "#0e7743");
			colorMap.put("Nobel", "#999999");
			colorMap.put("Dim Gray", "#666666");
			colorMap.put("International Klein Blue", "#0032aa");
			colorMap.put("Orange", "#feefd9");
			colorMap.put("Yellow", "#fcc878");
			colorMap.put("Bright orange", "#f6b046");
			colorMap.put("Soft blue", "#6badf6");
			//Refer : Trolley Grey- #808080 ,http://www.colorhexa.com/808080
			int index = 0;

			Enumeration<String> e = colorMap.keys();
			while (e.hasMoreElements()) {
				String key = e.nextElement();
				if (key.equals(expectedColor)) {
					String expectedHexColor = colorMap.get(key);
					if (actualHexColor.equals(expectedHexColor)) {
						logger.info("Background color is matched. Background color : " + key);
					} else {
						Assert.fail("Background color is not matched. Expected : "
								+ expectedColor + ". Actual : " + actualHexColor);
					}
					break;
				}
				index++;
			}
			if (index == colorMap.size()) {
				Assert.fail(expectedColor + " is not a valid color");
			}
		}
    /* Implemented to Re-login as default user credentials
	public static void ReLogin() {
		Hashtable<String, String> data = TestUtil.getData("loginWithPositiveCredentials", "Login", BaseClass.dataXl);
		login(data.get("UserName"), data.get("Password"));
	}*/

	// Implemented to verify Ad is displayed
	public static void verifyAdDisplay(WebElement adFrameLocator, WebElement imageLocator) throws IOException {
		driver.switchTo().frame(adFrameLocator);
		String imgSrc = imageLocator.getAttribute("src");
		URL url = new URL(imgSrc);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
		connection.connect();
		int responseCode = connection.getResponseCode();
		String pattern = "20.";
		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(String.valueOf(responseCode));
		Assert.assertTrue(m.find(), "Ad is not displayed. Response code : " + responseCode);
		logger.info("Ad is displayed. Response code : " + responseCode);
		driver.switchTo().defaultContent();
	}

	// Implemented to verify clicking on Ad is working
	public static void verifyAdClicking(WebElement adFrameLocator, WebElement clickOn) throws IOException {
		driver.switchTo().frame(adFrameLocator);
		String href = clickOn.getAttribute("href");
		URL url = new URL(href);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.connect();
		int responseCode = connection.getResponseCode();
		String rerdirectTo = "";
		int count = 0;
		while (responseCode == 302) {
			rerdirectTo = connection.getHeaderField("Location");
			URL newUrl = new URL(connection.getHeaderField("Location"));
			connection = (HttpURLConnection) newUrl.openConnection();
			connection.connect();
			responseCode = connection.getResponseCode();
			count++;
			if (count == 10) {
				Assert.fail("URL redirected several times");
			}
		}
		String pattern = "20.";
		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(String.valueOf(responseCode));
		Assert.assertTrue(m.find(), "Clicking on Ad is not working. Response code : " + responseCode);
		logger.info("Clicking on Ad is working. Response code : " + responseCode + ". Final URL : " + rerdirectTo);
		driver.switchTo().defaultContent();
	}
	
	public static boolean waitUntilElementisVisible(WebElement webelement){
		try {
			wait.until(ExpectedConditions.visibilityOf(webelement));
			return true;
		} catch (NoSuchElementException e) {
			Assert.fail("Elements are not present after waiting " + seconds + " seconds");
			
		}
		return false;
	}
	
	
	public static void loginToMarketSmith(String userName, String password) {

		try {
			WebElement settingIcon=pageLib.getLogoutButton();	
			if(settingIcon.isDisplayed()) {
				logger.info("Already Logged In");
			}
			else {
				throw new Exception();
			}
		}
		catch(Exception e) {
			//adding to click on MAIN Sign In Button to bring up pop up
			pageLib.getMainSignInButton().click();
			waitUntilElementisVisible(pageLib.getSignInModalBox());
			driver.switchTo().frame(pageLib.getLoginFrame());
			waitUntilVisibilityOfElement();
			pageLib.getUserNameTextbox().sendKeys(userName);
			logger.info(userName + " is entered as Username");
			pageLib.getPasswordTextbox().sendKeys(password);
			logger.info(password + " is entered as Password");
			WebElement loginButton=pageLib.getLoginButton();
			String loginButtonText=loginButton.getAttribute("title");
			loginButton.click();
			logger.info("Clicked on " + loginButtonText + " button");
			driver.switchTo().defaultContent();

			if(driver.getCurrentUrl().contains(CONSTANTS.getProperty("CAMPAIGN_URL")))
				driver.navigate().back();
			try {
				wait.until(ExpectedConditions.visibilityOf(pageLib.getLogoutButton()));
				logger.info("User logged in successfully");
				logger.info("------------------------------------------------------------");
			}
			catch(TimeoutException ex) {
				if(driver.getCurrentUrl().contains(CONSTANTS.getProperty("CAMPAIGN_URL")))
					driver.navigate().back();
				try {
					wait.until(ExpectedConditions.visibilityOf(pageLib.getLogoutButton()));
					logger.info("User logged in successfully");
					logger.info("------------------------------------------------------------");
				}
				catch(TimeoutException exc) {
					ex.printStackTrace();
					Assert.fail("Unable to login");
				}
			}
		}
	}

	public static void tc002_logoutFromMarketSmith()
	{
	  try{
			WebElement loginIcon=pageLib.getLoginButton();
		    if(loginIcon.isDisplayed()){
			logger.info("user already logged out");
		 }
	    }catch(Exception e) {
	    	driver.close();
			Utility.windowHandles();
			waitUntilElementIsClickable(pageLib.getLogoutButton());
			pageLib.getLogoutButton().click();
			logger.info("user loggedout successfully");
		}
    }
	
	public static boolean waitUntilTextTobePresentInElement(WebElement element, String text){
		try {
			wait.until(ExpectedConditions.textToBePresentInElement(element, text));
			logger.info("Text is present:"+element.getText());
			return true;
		}catch (NoSuchElementException e) {
		  Assert.assertEquals(element.getText(),text, "text is not matched");
		  return false;
	  }
  }
	
	 //Implemented to change env variable to baseUrl in constants.properties file
		public static void changeEnvVariable(String environment, String filePath) throws IOException {
			File file = new File(filePath);
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line = "", oldtext = "";
			while((line = reader.readLine()) != null)
			{
				oldtext += line + "\r\n";
			}
			reader.close();
			String newtext = oldtext.replaceAll("ENVIRONMENT", environment);
			FileWriter writer = new FileWriter(filePath);
			writer.write(newtext);
			writer.close();
		}
		
	//Implemented to change baseUrl to env variable in constants.properties file
	public static void resetEnvVariable(String environment, String filePath) throws IOException {
		File file = new File(filePath);
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line = "", oldtext = "";
		while((line = reader.readLine()) != null)
		{
			oldtext += line + "\r\n";
		}
		reader.close();
		String newtext = oldtext.replaceAll(environment, "ENVIRONMENT");	     
		FileWriter writer = new FileWriter(filePath);
		writer.write(newtext);
		writer.close();
	}	
	
	//Returns a list of the charted stock Colors on COMPARISON CHARTS
	public static List<String> comparisonChartStockColors(List<WebElement> elems) {
		int temp_size = elems.size();
		List<String> ret_set = new ArrayList<String>();
		String curr_svg_stroke = "";
		int temp_count = 0;
		logger.info("Getting colors from Comparison Charts");
		for(WebElement e: elems){
			//z-index was removed from element
			//int z_index = Integer.parseInt(e.getCssValue("z-index"));
			if(temp_count > 0){
				curr_svg_stroke = e.getAttribute("innerHTML").substring(e.getAttribute("innerHTML").indexOf("<"),e.getAttribute("innerHTML").indexOf(">") + 1);
				curr_svg_stroke = curr_svg_stroke.substring(curr_svg_stroke.indexOf("rgb"),curr_svg_stroke.indexOf(")")+1);
				logger.info("Getting this color, " + curr_svg_stroke);
				//System.out.println("this color " + curr_svg_stroke);
				ret_set.add(curr_svg_stroke);
				//System.out.println(curr_svg_stroke);
			}
			temp_count++;
			if(temp_count >= temp_size)
				logger.info("Done getting colors in Comparison Charts");
				//System.out.println("DONE GETTING COLORS");
		}
		return ret_set;
	}
	
	public static void closeWindow(){
		driver.close();
		Utility.windowHandles();
		try{
			Thread.sleep(1000);
		} catch (InterruptedException e){
			e.printStackTrace();
		}
	}
	
	//implicit wait for visibility of element
	public static boolean waitUntilVisibilityOfElement(){
		 long milliseconds=10000;
			try {
				Thread.sleep(milliseconds);
				return true;
			} catch (InterruptedException e) {
				Assert.fail("Element is not visible after waiting " + milliseconds + " seconds");
				return false;
			}
	}
	//to delete my list elements
	public static void deleteCreatedList(){
		waitUntilElementIsClickable(lMpageLib.getMyListsLink());
		WebElement myListLink=lMpageLib.getMyListsLink();
		WebElement myListElements=lMpageLib.getMyListElements();
		WebElement createdListLink=lMpageLib.getUserCreatedList();
		if(!(myListLink.getAttribute("class").contains("down"))){
		 myListLink.click();
	     }
		 if(myListElements.getAttribute("class").contains("listExplorerItem ")){
		 createdListLink.click();
		 Actions action=new Actions(driver);
		 action.moveToElement(createdListLink).build().perform();
		 lMpageLib.getDropdown().click();
		 waitUntilElementisVisible(lMpageLib.getWaitOptions());
		 lMpageLib.getDeleteListOption().click();
		 } else{
		     logger.info("It Is folder");
	     }
	}
	
	public static void launchMSTool() throws InterruptedException {
		//if logged in, throw exception and execute exception code?
		if (!waitUntilElementisVisible(pageLib.getLogoutButton())) {
			logger.info("Not Logged In");
		} else {
			waitUntilElementIsClickable(chartLib.getOpenChartButton());
			WebElement openChartBtn = chartLib.getOpenChartButton();
			String openChartBtnText = openChartBtn.getText();
			openChartBtn.click();
			logger.info("Clicked on " + openChartBtnText + " button");
			try {
				Utility.windowHandles();
				wait.until(ExpectedConditions.urlToBe(CONSTANTS.getProperty("MSTOOL_URL")));
				Utility.waitUntilElementisVisible(chartLib.getMainPriceChart());
				logger.info("User launched MSTOOL successfully");
				Thread.sleep(5000);
			}
			catch(TimeoutException te) {
				Assert.assertEquals(driver.getCurrentUrl(), CONSTANTS.getProperty("MSTOOL_URL"), "MSTOOL URL is not matched");
			}
		}  
	}
	
	public static void ValidateItemsOfList(){
		waitUntilElementIsClickable(lipanelLib.getMyListsLink());
		WebElement myListLink=lipanelLib.getMyListsLink();
		String MyListText=lipanelLib.getMyListName().getText();
		if(!(myListLink.getAttribute("class").contains("down"))){
		  	myListLink.click();
			logger.info("clicked on "+MyListText+" folder");
		  } 
		   WebElement myListElements=lipanelLib.getmyListElements();
		   if(myListElements.getAttribute("class").contains("listExplorerItem ")){
		   WebElement createdListLink=lipanelLib.getSecondList();
			  String createdListText=createdListLink.getText();
			  createdListLink.click();
			  logger.info("clicked on "+createdListText+" list");
			  waitUntilTextTobePresentInElement(lipanelLib.getCurrentListName(), createdListText);
		}else{
					logger.info("it is a folder ");
				   }
			
	}
	
	public static void EnterStockSymbol(String symbol){
		//Utility.verifyPageUrl(CONSTANTS.getProperty("MSTOOL_URL"));
		waitUntilElementIsClickable(ripanelLib.getSymbolEntryField());
		ripanelLib.getSymbolEntryField().clear();
		ripanelLib.getSymbolEntryField().sendKeys(symbol);
		Actions actions =new Actions(driver);
		actions.sendKeys(Keys.ENTER).build().perform();
		waitUntilVisibilityOfElement();
		waitUntilElementisVisible(ripanelLib.getChartSymbol());
		try{	
			Thread.sleep(3000);
		}catch(InterruptedException ie){
			//System.out.println(ie);
			logger.info(ie);
		}
	}
	
	public static String DB_getRecentBreakOutSymbol()
	{
		String retSymbol = "";
		Connection con;
		try{
			//System.out.println("Inside TRY/CATCH 1");
			//con = DriverManager.getConnection("jdbc:sqlserver://db62master;databaseName=wondb;integratedSecurity=true;packetSize=4096;applicationName=ms-services;sendStringParametersAsUnicode=false;responseBuffering=full");
			con = DriverManager.getConnection("jdbc:sqlserver://db62master;databaseName=wondb;integratedSecurity=true");
			logger.info(con);
			Statement st = con.createStatement();
			
			//GET Symbol: String sql_getOSID = String.format("select top 1 OSID from SECMaster where Symbol = %s", symbol);
			String sql_getSymbol = "select top 1 s.Symbol from PatternRecDB.dbo.PRDataRecentBase pr inner join Wondb.dbo.SECMaster s on (s.OSID=pr.InstrumentID) where IsRecentBreakout = 1 and VersionID=12 and PeriodicityID=0 and Indcd not in ('6722','6725','6723','3442','6724','6146','6730') order by BreakoutDay desc, NEWID() asc";
			ResultSet rs = st.executeQuery(sql_getSymbol);
			//String retSymbol = "";
			while (rs.next()) {
				logger.info("Symbol returned from query is, "+rs.getString("Symbol"));
				retSymbol = rs.getString("Symbol");
			}
		}catch (Exception e){
			logger.info("QUERYING DB FAIL *****");
			logger.info(e);
			logger.info(e.getStackTrace());
		}
		return retSymbol;
	}
	
	// Implemented to wait until presence of all elements
			public static boolean waitUntilVisibilityOfAllElements(List<WebElement> elements) {
				try {
					wait.until(ExpectedConditions.visibilityOfAllElements(elements));
					return true;
				} catch (NoSuchElementException e) {
				Assert.fail("Elements are not visible after waiting " + seconds + " seconds");
				return false;
				}
			}
}