package genericLib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SendMail {

	public static void main(String[] args) throws Exception {
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");

		final String USER_ID = "wonindiaqa@gmail.com";
		final String PWD = "9982387300";	
	    final String TO="rupesh.kumar@williamoneilindia.com,Michael.Delatorre@williamoneil.com,mukund.dwivedi@williamoneilindia.com,vaseem.fahed@williamoneil.com,mamata.bm@williamoneilindia.com,";
		//final String TO="mukund.dwivedi@williamoneilindia.com";
		//final String TO="vishal.vishnoi@williamoneilindia.com";
		// folder path for testng
		final String FOLDER_PATH = "C:/Automation/MarketSmith_Desktop_Automation/output";

		// folder path for reportng
		//final String FOLDER_PATH = "C:\\I.Com_Desktop_Automation\\output\\html";

		Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(USER_ID, PWD);
			}
		});

		try {
			addFolderToZip(FOLDER_PATH);
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(USER_ID));
			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(TO));
			message.setSubject("MarketSmith_Desktop Regression Automation Report");
			BodyPart messageBodyPart = new MimeBodyPart();
			String myMessage1="Hi All, <br><br>Please find attached Test Execution report.<br>";
			String myMessage2="<br><br>Regards<br>MarketSmith_Desktop_Automation";
			Hashtable<String, String> hashTable = readAllData("Visitor");
			List<String> visitorKeys=new ArrayList<String>();
			visitorKeys.addAll(hashTable.keySet());
			String visitorResultTable="";
			String loggedInResultTable="";
			if(visitorKeys.size()>0) {
				Collections.reverse(visitorKeys);
				String visitorResult="";
				for(String key: visitorKeys){
					visitorResult=visitorResult + "<tr><td>" + key + "</td><td>" + hashTable.get(key) + "</td></tr>";
				}
				visitorResultTable="<html><body><table border='1' style='border-collapse: collapse;'><tr bgcolor='#666633'><th colspan='2' align='center'>Failed Test Cases For Visitor</th></tr><tr bgcolor='#a3a375'><th align='center'>Test Case ID</th><th align='center'>Test Cases Description</th></tr>" 
						+ visitorResult			      
						+ "</table></body></html>";
			}
			hashTable = readAllData("LoggedIn");
			List<String> loggedInKeys=new ArrayList<String>();
			loggedInKeys.addAll(hashTable.keySet());
			if(loggedInKeys.size()>0) {
				Collections.reverse(loggedInKeys);
				String loggedInResult="";
				for(String key: loggedInKeys){
					loggedInResult=loggedInResult + "<tr><td>" + key + "</td><td>" + hashTable.get(key) + "</td></tr>";
				}
				loggedInResultTable="<html><body><table border='1' style='border-collapse: collapse;'><tr bgcolor='#666633'><th colspan='2' align='center'>Failed Test Cases For Logged In Users</th></tr><tr bgcolor='#a3a375'><th align='center'>Test Case ID</th><th align='center'>Test Cases Description</th></tr>" 
						+ loggedInResult			      
						+ "</table></body></html>";
			}



			//For TestNG Report
			String pageSource = new Scanner(new File(FOLDER_PATH + "\\emailable-report.html")).useDelimiter("\\Z").next();
			String table1=pageSource.substring(pageSource.indexOf("<table"), pageSource.indexOf("</table>")).replaceAll("\\<table.+\\>", "<table border='1' style='border-collapse: collapse;'>").replaceFirst("<tr>", "<tr bgcolor='#666633'>").replaceAll("<th colspan=\"7\"", "<th colspan=\"8\" bgcolor='#a3a375'")+"</table>";
			messageBodyPart.setContent(myMessage1 + "<br>" + table1 + "<br>" + visitorResultTable + "<br>" + loggedInResultTable + "<br>" + myMessage2, "text/html");

			//For ReportNG Report
			/*	String pageSource = new Scanner(new File(FOLDER_PATH + "\\overview.html")).useDelimiter("\\Z").next();
			String table=pageSource.substring(pageSource.lastIndexOf("<table"), pageSource.lastIndexOf("</table>")).replaceAll("\\<table.+\\>", "<table border='1'>")+"</table>";		
			messageBodyPart.setContent(myMessage1 + "<br>" + table + myMessage2, "text/html"); */

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);
			messageBodyPart = new MimeBodyPart();
			String filename = FOLDER_PATH + ".zip";
			DataSource source = new FileDataSource(filename);
			messageBodyPart.setDataHandler(new DataHandler(source));
			messageBodyPart.setFileName(filename);
			multipart.addBodyPart(messageBodyPart);
			message.setContent(multipart);
			Transport.send(message);
			System.out.println("Done");

		} catch (MessagingException e) {
			// throw new RuntimeException(e);
			System.out.println("Exception occurs in mailing");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}

	//Add folder to zip
	public static void addFolderToZip(String folderPath) throws Exception {
		String sourceFolderName = folderPath;
		String outputFileName = folderPath + ".zip";

		FileOutputStream fos = new FileOutputStream(outputFileName);
		ZipOutputStream zos = new ZipOutputStream(fos);
		// level - the compression level (0-9)
		zos.setLevel(9);
		addFolder(zos, sourceFolderName, sourceFolderName);
		zos.close();
	}

	//Convert files to zip
	private static void addFolder(ZipOutputStream zos, String folderName, String baseFolderName) throws Exception {
		File f = new File(folderName);
		if (f.exists()) {
			if (f.isDirectory()) {
				if (!folderName.equalsIgnoreCase(baseFolderName)) {
					String entryName = folderName.substring(baseFolderName.length() + 1, folderName.length())
							+ File.separatorChar;
					ZipEntry ze = new ZipEntry(entryName);
					zos.putNextEntry(ze);
				}
				File f2[] = f.listFiles();
				for (int i = 0; i < f2.length; i++) {
					addFolder(zos, f2[i].getAbsolutePath(), baseFolderName);
				}
			} else {
				// add file
				// extract the relative name for entry purpose
				String entryName = folderName.substring(baseFolderName.length() + 1, folderName.length());
				ZipEntry ze = new ZipEntry(entryName);
				zos.putNextEntry(ze);
				FileInputStream in = new FileInputStream(folderName);
				int len;
				byte buffer[] = new byte[1024];
				while ((len = in.read(buffer)) > 0) {
					zos.write(buffer, 0, len);
				}
				in.close();
				zos.closeEntry();
			}
		} else {
			System.out.println("File or directory not found " + folderName);
		}
	}
	
	public static Hashtable<String, String> readAllData(String sheetName) throws IOException {
		String tempFilePath="C:/Automation/MarketSmith_Desktop_Automation/Resources/ExcelSheets/tempFile.xlsx";
		FileInputStream fis=new FileInputStream(tempFilePath);
		Workbook workbook = new XSSFWorkbook(fis);
		Sheet sheet=workbook.getSheet(sheetName);
		int lastRowNum=sheet.getLastRowNum();
		Hashtable<String,String> table = new Hashtable<String,String>();
		for (int index=0;index<=lastRowNum;index++) {
			if(lastRowNum!=0)
				if(sheet.getRow(index).getCell(0).getStringCellValue()!=null && sheet.getRow(index).getCell(1).getStringCellValue()!=null)
					table.put(sheet.getRow(index).getCell(0).getStringCellValue(), sheet.getRow(index).getCell(1).getStringCellValue());
		}
		workbook.close();
		return table;
	}
}
