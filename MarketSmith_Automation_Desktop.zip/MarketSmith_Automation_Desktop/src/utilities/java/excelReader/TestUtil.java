package excelReader;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.util.List;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestUtil {

	public static boolean isExecutable(String testName, String sheetName, Xls_Reader xls){

		for(int rNum=2;rNum<=xls.getRowCount(sheetName);rNum++){

			if(testName.equals(xls.getCellData(sheetName, "TC Name", rNum))){
				if(xls.getCellData(sheetName, "RunMode", rNum).equalsIgnoreCase("y")){
					return true;
				}
				//Needed to NOT run TCs that have N on excel sheet
				else{
					//return false;
					return true;
				}	
			}

		}

		return true;
	}

	public static Hashtable<String,String> getData(String testName, String sheetName, Xls_Reader xls){
		int testCaseStartIndex=0;
		for(int rNum=1;rNum<=xls.getRowCount(sheetName);rNum++){
			if(testName.equals(xls.getCellData(sheetName, 0, rNum))){
				testCaseStartIndex=rNum;
				break;
			}
		}

		int colStartIndex=testCaseStartIndex+1;
		int cols=1;
		while(!xls.getCellData(sheetName, cols, colStartIndex).equals("")){
			cols++;
		}

		int dataStartIndex=testCaseStartIndex+2;
		int rows=0;
		while(!xls.getCellData(sheetName, 1, (dataStartIndex+rows)).equals("")){
			rows++;
		}
		Hashtable<String,String> table = null;
		for(int rNum=dataStartIndex;rNum<(dataStartIndex+rows);rNum++){
			table = new Hashtable<String,String>();
			for(int cNum=0;cNum<cols;cNum++){
				table.put(xls.getCellData(sheetName, cNum, colStartIndex), xls.getCellData(sheetName, cNum, rNum));
			}
		}
		return table;
	}

	public static void writeData(String sheetName, List<String> tcId, List<String> tcDesc) throws EncryptedDocumentException, InvalidFormatException, IOException {
		String tempFilePath="C:/gitAutomation/MarketSmith_Automation_Desktop/src/main/resources/ExcelSheets/tempFile.xlsx";
		FileInputStream fis=new FileInputStream(tempFilePath);
		Workbook workbook = new XSSFWorkbook(fis);
		Sheet sheet=workbook.getSheet(sheetName);
		int lastRowNum=sheet.getLastRowNum();
		if(lastRowNum>0) {
			for (int index=0;index<=lastRowNum;index++) {
				sheet.removeRow(sheet.getRow(index));
			}
		}
		for(int index=0;index<tcId.size();index++) {
			Row row=sheet.createRow(index);
			Cell cell=row.createCell(0);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			cell.setCellValue(tcId.get(index));
			cell=row.createCell(1);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			cell.setCellValue(tcDesc.get(index));
		}
		FileOutputStream fos=new FileOutputStream(tempFilePath);
		workbook.write(fos);
	}

	public static Hashtable<String,String> getFailureData(String testName, String sheetName, Xls_Reader xls){
		int testCaseStartIndex=0;
		for(int rNum=1;rNum<=xls.getRowCount(sheetName);rNum++){
			if(testName.equals(xls.getCellData(sheetName, 2, rNum))){
				testCaseStartIndex=rNum;
				break;
			}
		}

		int cols=0;
		while(!xls.getCellData(sheetName, cols, testCaseStartIndex).equals("")){
			cols++;
		}

		Hashtable<String,String> table = null;
		table = new Hashtable<String,String>();
		for(int cNum=0;cNum<cols;cNum++){
			table.put(xls.getCellData(sheetName, cNum, 1), xls.getCellData(sheetName, cNum, testCaseStartIndex));

		}
		return table;
	}
}
